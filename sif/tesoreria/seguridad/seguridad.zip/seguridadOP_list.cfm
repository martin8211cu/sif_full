﻿<form name="formList" method="post" action="seguridadOP.cfm">
	<table width="100%" cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td nowrap="nowrap" class="tituloListas">
				<strong>Tesorería:</strong>
			</td>

			<td class="tituloListas">
				<cf_cboTESid tipo="" onChange="this.form.submit();" tabindex="1">
			</td>
			<td width="1000" class="tituloListas">
				&nbsp;&nbsp;&nbsp;
			</td>
		</tr>
	</table>
	<cf_dbfunction name="to_char" args="tu.Usucodigo" returnVariable="LvarUsucodigo">
	<cfset LvarImgChecked	= "'<img border=""0"" src=""/cfmx/sif/imagenes/borrar01_S.gif"" style=""cursor:pointer;"" onClick=""sbBaja(' || #LvarUsucodigo# || ');"">'">
	<cfinvoke component="sif.Componentes.pListas" method="pLista"
		tabla="
				TESusuarioOP tu
					inner join Usuario u
						inner join DatosPersonales dp
						   on dp.datos_personales = u.datos_personales
						on u.Usucodigo = tu.Usucodigo
				"
		columnas="
				  tu.TESid, tu.Usucodigo
				, u.Usulogin
				, dp.Pnombre || ' ' || dp.Papellido1 || ' ' || dp.Papellido2 as Usuario
				, #preserveSingleQuotes(LvarImgChecked)# as borrar
			"
		filtro="tu.TESid = #session.Tesoreria.TESid# order by u.Usulogin"
		desplegar="borrar, Usulogin, Usuario"
		etiquetas=" ,Usuario, Nombre"
		formatos="U,S,S"
		align="left,left,left"
		ira="seguridadOP.cfm"
		form_method="post"
		keys="Usulogin"
		showLink="no"
		incluyeForm="no"
		formName="formList"
	
		mostrar_filtro="yes"
		filtrar_automatico="yes"
		filtrar_Por=" , Usulogin, dp.Pnombre || ' ' || dp.Papellido1 || ' ' || dp.Papellido2"
	/>
</form>
<script language="javascript">
	function sbBaja(Usucodigo)
	{
		if (confirm("¿Desea borrar al usuario?"))
		{
			location.href = "seguridadOP_sql.cfm?btnBaja&usucodigo=" + Usucodigo;
		}
		return false;
	}
</script>