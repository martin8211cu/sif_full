﻿<cf_templateheader title="Usuarios de Solicitudes de Gastos de Empleado">
	<cf_web_portlet_start _start titulo="Usuarios de Solicitudes de Gastos de Empleado">

		<cf_navegacion name="Usucodigo" default="" navegacion="">
		<cf_navegacion name="CFid" default="" navegacion="">

		<table width="100%" align="center">
			<tr>
				<td align="center">
				<cfif form.Usucodigo EQ '' AND NOT isdefined("btnNuevo") AND NOT isdefined("btnNuevoCF")>
					<cfif isdefined("btnNuevo")>
						<cfset form.CFid = "">
					</cfif>
					<cfinclude template="seguridadGE_list.cfm">
				<cfelse>
					<cfinclude template="seguridadGE_form.cfm">
				</cfif>
				</td>
			</tr>
		</table>
	<cf_web_portlet_start _end>
<cf_templatefooter>

