﻿<form name="formList" method="post" action="seguridadSP.cfm">
	<table width="100%" cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td nowrap="nowrap" class="tituloListas">
				<strong>Centro Funcional:</strong>
			</td>

			<td class="tituloListas">
				<cf_navegacion name="filtro_CFid" default="-1" session>
				<cfif form.filtro_CFid EQ "">
					<cfset form.filtro_CFid = -1>
				</cfif>
				<cfquery name="rsFiltro_CFid" datasource="#session.DSN#">
					select CFid as filtro_CFid, CFcodigo as filtro_CFcodigo, CFdescripcion as filtro_CFdescripcion
					  from CFuncional
					 where CFid = #form.filtro_CFid#
				</cfquery>
				<cf_rhcfuncional 
					form="formList" 
					id="filtro_CFid"
					name="filtro_CFcodigo"
					desc="filtro_CFdescripcion" 
					query="#rsFiltro_CFid#"
					titulo="Seleccione el Centro Funcional" 
					size="40" excluir="-1" tabindex="1"
				>
				<cfif form.filtro_CFid NEQ "-1">
					<cfset LvarFiltro_CF = "and tu.CFid = #form.filtro_CFid#">
				<cfelse>
					<cfset LvarFiltro_CF = "">
				</cfif>
			</td>
			<td width="1000" class="tituloListas">
				&nbsp;&nbsp;&nbsp;
			</td>
		</tr>
	</table>
	<cfset LvarImgChecked  	 = "<img border=""0"" src=""/cfmx/sif/imagenes/checked.gif"">">
	<cfset LvarImgUnchecked	 = "<img border=""0"" src=""/cfmx/sif/imagenes/unchecked.gif"">">
	<cfquery name="rsSiNo" datasource="#session.DSN#">
		select -1 as value, '' as description, 1 as orden from dual
		UNION
		select 1 as value, 'Si' as description, 2 from dual
		UNION
		select 0, 'No', 3 from dual
		order by orden
	</cfquery>
	<cfinvoke component="sif.Componentes.pListas" method="pLista"
		tabla="
				TESusuarioSP tu
					inner join Usuario u
						inner join DatosPersonales dp
						   on dp.datos_personales = u.datos_personales
						on u.Usucodigo = tu.Usucodigo
					inner join CFuncional cf
						on cf.CFid = tu.CFid
				"
		columnas="
				  tu.CFid, tu.Usucodigo
				
				, cf.CFcodigo || ' - ' || cf.CFdescripcion as CentroFuncional
				, u.Usulogin
				, dp.Pnombre || ' ' || dp.Papellido1 || ' ' || dp.Papellido2 as Usuario
				, case
					when tu.TESUSPsolicitante = 1 
						then '#PreserveSingleQuotes(LvarImgChecked)#'
						else '#PreserveSingleQuotes(LvarImgUnChecked)#'
				  end as Solicitante
				, case
					when tu.TESUSPaprobador = 1 
						then '#PreserveSingleQuotes(LvarImgChecked)#'
						else '#PreserveSingleQuotes(LvarImgUnChecked)#'
				  end as Aprobador
				, tu.TESUSPmontoMax as montoMaximo
				, case 
					when tu.TESUSPcambiarTES = 1 
						then '#PreserveSingleQuotes(LvarImgChecked)#'
						else '#PreserveSingleQuotes(LvarImgUnChecked)#'
				  end as CambiarTES
			"
		filtro="tu.Ecodigo = #session.Ecodigo# #LvarFiltro_CF# order by cf.CFcodigo, u.Usulogin"
		cortes="CentroFuncional"
		desplegar="Usulogin, Usuario, Solicitante, Aprobador, montoMaximo, CambiarTES"
		etiquetas="Usuario, Nombre, Solicitante, Aprobador, Monto Maximo<BR>a Aprobar, Puede Cambiar<BR>Tesorería"
		formatos="S,S,S,S,M,S"
		align="left,left,center,center,right,center"
		ira="seguridadSP.cfm"
		form_method="post"
		keys="CFid,Usulogin"
		showLink="yes"
		incluyeForm="no"
		formName="formList"
	
		mostrar_filtro="yes"
		filtrar_automatico="yes"
		filtrar_Por="Usulogin, dp.Pnombre || ' ' || dp.Papellido1 || ' ' || dp.Papellido2, TESUSPsolicitante, TESUSPaprobador, TESUSPmontoMax, TESUSPcambiarTES"
		rsSolicitante="#rsSINO#"
		rsAprobador="#rsSINO#"
		rsCambiarTES="#rsSINO#"
	
		botones="Nuevo"
	/>
</form>