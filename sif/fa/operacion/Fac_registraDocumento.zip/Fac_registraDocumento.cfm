<!--- Modificacion: Se agregan los campos TESRPTCid, TESRPTCietu
	Justificacion: Se modifica componente para tomar en cuenta el Concepto de cobro por cambio de IETU
	Fecha: 07/07/2009 
	Realizo: ABG --->

<!------
	Proceso de Aplicacion de cotizaciones
	Creado 4 septiembre 2008
	por ABG
------->
<cfset varControlFlujo = true>
<cfset varControlFiltro = true>
<cfset varPosteo = true>
<cfset busca = ' '>


    
<!--- Fin del Codifo de prueba para la factura electronica --->

    <cfquery name="rsupdfac1" datasource="#session.DSN#">				
				select  idprefactura,enviamail,ltrim(rtrim(foliofacele)) as foliofacele ,ltrim(rtrim(seriefacele))  as seriefacele,pftcodigo
				FROM FAEOrdenImpresion a   
				inner join faprefacturae f
			    on a.oidocumento = f.ddocumentoref
				WHERE a.OImpresionID =  #OImpresionID#
     </cfquery>     
      		<cfif #rsupdfac1.enviamail# neq 1>	
                	<cfabort showerror="No se ha generado el Archivo XML y/o enviado el mail">            		
            </cfif>
<!---	   <cfif  not isdefined("form.ErrorDoc")>
        	<cfoutput>Entro form.ErrorDoc #form.ErrorDoc# </cfoutput>
           	<!--- Se actualiza Orden de Impresion Se regresa al estado en Preparacion--->
	        <cfquery datasource="#session.DSN#">
    	    	update FAEOrdenImpresion
        	    set OIEstado = 'P'
            	where OImpresionID = <cfqueryparam cfsqltype="cf_sql_integer" value="#form.OImpresionID#">
            	and Ecodigo = <cfqueryparam cfsqltype="cf_sql_integer" value="#session.Ecodigo#">
        	</cfquery>
		</cfif> --->
		 
		<cfif  #rsupdfac1.foliofacele# gt 0>                    
 	            	<cfif #rsupdfac1.pftcodigo# eq 'PF'>
                	<cfset busca= 'FE'>
                </cfif>
                <cfif #rsupdfac1.pftcodigo# eq 'PN'>
                	<cfset busca= 'NE'>
                </cfif>

            	<!--- Busca si el Documento No existe en los documentos Aplicados --->            	
                <cfquery name="rsVerifica" datasource="#session.DSN#">
                	select 1 from HDocumentos
                    where Ecodigo = <cfqueryparam cfsqltype="cf_sql_integer" value="#session.Ecodigo#">
                    and Ddocumento = <cfqueryparam cfsqltype="cf_sql_varchar" value="#busca#-#rsupdfac1.foliofacele#">
                    and CCTcodigo = <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.CCTcodigo#">
                </cfquery>
                <cfquery name="rsVerifica2" datasource="#session.DSN#">
                	select 1 from EDocumentosCxC
                    where Ecodigo = <cfqueryparam cfsqltype="cf_sql_integer"value="#session.Ecodigo#">
                    and EDdocumento = <cfqueryparam cfsqltype="cf_sql_varchar"value="FE-#rsupdfac1.foliofacele#">
                    and CCTcodigo = <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.CCTcodigo#">
                </cfquery>
                
              	<cfif rsVerifica.recordcount GT 0 OR rsVerifica2.recordcount GT 0>              	
              	
              	    <cfquery  datasource="#session.DSN#">				
						update faprefacturae 
					   	   set foliofacele = 0,seriefacele='',factura = 0
					     wHERE idprefactura = <cfqueryparam cfsqltype="cf_sql_varchar"value="#rsupdfac1.idprefactura#">
     				 </cfquery>     
     				 
					<cfabort showerror="Documento #rsupdfac1.seriefacele##rsupdfac1.foliofacele# ya existe en los Documentos de CxC">
                	
				</cfif>
				
                <!--- Inserta del Documento en el auxiliar de CxC --->
				<cftransaction>
                <cfquery name="rsOIinsert" datasource="#session.DSN#">
					select * 
				    from FAEOrdenImpresion a
				    where a.OImpresionID = <cfqueryparam cfsqltype="cf_sql_integer" value="#form.OImpresionID#">
				    and a.Ecodigo = <cfqueryparam cfsqltype="cf_sql_integer" value="#session.Ecodigo#">
				</cfquery>
                <!--- Para Obtener la cuenta del Encabezado --->
                <!--- si la id Direccion es nula toma la cuenta del socio --->
				<cfif rsOIinsert.id_direccionFact EQ "">
                	<cfset varCuenta = rsOIinsert.Ccuenta>
                <cfelse>
                	<!--- Busca la cuenta de la direccion indicada --->
                    <!--- Si la direccion no tiene cuenta Contable usa la cuenta del socio --->
                    <cfquery name="rsCuentaD" datasource="#session.DSN#">
						select SNDCFcuentaCliente 
                        from SNDirecciones sd
                        	inner join SNegocios sn
                            on sd.Ecodigo = sn.Ecodigo 
                            and sd.SNid = sn.SNid
                        where sn.Ecodigo = <cfqueryparam value="#session.Ecodigo#" cfsqltype="cf_sql_integer">
						and sn.SNcodigo = <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIinsert.SNcodigo#">
                        and sd.id_direccion = <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIinsert.id_direccionFact#">
                    </cfquery>
                 	<cfif rsCuentaD.SNDCFcuentaCliente EQ "">
                    		<cfset varCuenta = rsOIinsert.Ccuenta>
                    	<cfelse>
                    		<cfset varCuenta = rsCuentaD.SNDCFcuentaCliente>
                  	</cfif>
                </cfif>
				<!--- Encabezado --->
                
                <cfquery name="insertDoc"datasource="#session.DSN#">
                	insert into EDocumentosCxC	
                        (Ocodigo, CCTcodigo, EDdocumento, SNcodigo, Mcodigo,
                    	EDtipocambio, Ccuenta, EDdescuento, EDporcdesc, EDimpuesto, 
                        EDtotal, EDfecha, EDusuario, EDselect, Interfaz, 
                        id_direccionFact, id_direccionEnvio, DEdiasVencimiento, EDvencimiento, 
                    	DEobservacion, DEdiasMoratorio, Ecodigo, BMUsucodigo, TESRPTCid, TESRPTCietu)
					values
                		(<cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIinsert.Ocodigo#">,
                         <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIinsert.CCTcodigo#">,
                         <!--- <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.DocCxC#">,--->
                         <cfqueryparam cfsqltype="cf_sql_varchar" value="#busca#-#rsupdfac1.foliofacele#">,                        
                         <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIinsert.SNcodigo#">,
            	         <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIinsert.Mcodigo#">,
	                     <cfqueryparam cfsqltype="cf_sql_float" value="#rsOIinsert.OItipoCambio#">,
                         <cfqueryparam cfsqltype="cf_sql_integer" value="#varCuenta#">,
                         <cfqueryparam cfsqltype="cf_sql_money" value="#rsOIinsert.OIdescuento#">,
                         	0,
                         <cfqueryparam cfsqltype="cf_sql_money" value="#rsOIinsert.OIimpuesto#">,
                         <cfqueryparam cfsqltype="cf_sql_money" value="#rsOIinsert.OItotal#">,
                         <cfqueryparam cfsqltype="cf_sql_date" value="#rsOIinsert.OIfecha#">,
    	                 <cfqueryparam cfsqltype="cf_sql_varchar" value="#session.Usuario#">,
                         0,
                         0,
                         <cfif rsOIinsert.id_direccionFact EQ "">
							 null,
                         <cfelse>
                             <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIinsert.id_direccionFact#">,
                         </cfif>
                         <cfif rsOIinsert.id_direccionEnvio EQ "">
                         	null,
                         <cfelse>   
        	             	<cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIinsert.id_direccionEnvio#">,
                         </cfif>
                         <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIinsert.OIdiasvencimiento#">, 
                         <cfqueryparam cfsqltype="cf_sql_date" value="#rsOIinsert.OIvencimiento#">,
                         <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIinsert.OIobservacion#">,
                         0,
                         <cfqueryparam value="#session.Ecodigo#" cfsqltype="cf_sql_integer">,
        	             <cfqueryparam cfsqltype="cf_sql_numeric" value="#session.Usucodigo#">,
                         <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIinsert.TESRPTCid#">,
                         <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIinsert.TESRPTCietu#">
                     	)
            			<cf_dbidentity1 datasource="#session.DSN#">
				</cfquery>
				<cf_dbidentity2 datasource="#session.DSN#" name="insertDoc"  >
                <cfquery name="rsOIDinsert" datasource="#session.DSN#">
					select * 
				    from FADOrdenImpresion a
				    where a.OImpresionID = <cfqueryparam cfsqltype="cf_sql_integer" value="#form.OImpresionID#">
				    and a.Ecodigo = <cfqueryparam cfsqltype="cf_sql_integer" value="#session.Ecodigo#">
				</cfquery>
      
				<!--- Detalles --->
                <cfloop query="rsOIDinsert">
	                <cfquery datasource="#session.DSN#">
    	            	insert DDocumentosCxC
        	            	(EDid, Aid, Cid, Alm_Aid, 
            	             Ccuenta, Ecodigo, DDdescripcion, DDdescalterna,
                	         DDcantidad, DDpreciou, DDdesclinea, 
                    	     DDporcdesclin, DDtotallinea, DDtipo, Icodigo, CFid,
                        	 BMUsucodigo,Dcodigo)
	                    values
    	                	(<cfqueryparam cfsqltype="cf_sql_integer" value="#insertDoc.identity#">, 
        	                 <cfif rsOIDinsert.ItemTipo EQ "A">
	        	            	<cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIDinsert.ItemCodigo#">,
                	       	 <cfelse>
                    	       	null,
                        	 </cfif>
	                         <cfif rsOIDinsert.ItemTipo EQ "S">
		                        <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIDinsert.ItemCodigo#">,
        	                 <cfelse>
            	             	null,
                	         </cfif>
                    	     <cfif rsOIDinsert.ItemTipo EQ "A">
	                    	 	<cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIDinsert.OIDAlmacen#">,
	                         <cfelse>
    	                     	null,
        	                 </cfif>
            	             <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIDinsert.Ccuenta#">,
                	         <cfqueryparam value="#session.Ecodigo#" cfsqltype="cf_sql_integer">,
                    	     <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIDinsert.OIDdescripcion#">,
                        	 <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIDinsert.OIDdescnalterna#">,
	                         <cfqueryparam cfsqltype="cf_sql_float" value="#rsOIDinsert.OIDCantidad#">,
   	    	                 <cfqueryparam cfsqltype="cf_sql_money" value="#rsOIDinsert.OIDPrecioUni#">,
    	                     <cfqueryparam cfsqltype="cf_sql_money" value="#rsOIDinsert.OIDdescuento#">,
            	             0,
                	         <cfqueryparam cfsqltype="cf_sql_money" value="#rsOIDinsert.OIDtotal#">,
                    	     <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIDinsert.ItemTipo#">,
                        	 <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIDinsert.Icodigo#">,
							 <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIDinsert.CFid#">,
    	                     <cfqueryparam cfsqltype="cf_sql_numeric" value="#session.Usucodigo#">,
        	                 0
            	            )
                	</cfquery>
                </cfloop>
                </cftransaction>
                <!--- Postea Documento CxC 
          <cfif varPosteo>--->
       
		<!---	  </cfif> --->
                <!--- Inserta un registro en la Bitacora para la PF--->
                <cfquery datasource="#session.DSN#">
	                insert FABitacoraMovPF (Ecodigo, IDpreFactura, DdocumentoREF, CCTcodigoREF, SNcodigoREF, 
                    		FechaAplicacion, TipoMovimiento, BMUsucodigo)
    	            select <cfqueryparam value="#session.Ecodigo#" cfsqltype="cf_sql_integer">,    
                    		IDprefactura,
                            <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsupdfac1.seriefacele##rsupdfac1.foliofacele#">,
                            <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIinsert.CCTcodigo#">,
                            <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIinsert.SNcodigo#">,
                            <cfqueryparam cfsqltype="cf_sql_date" value="#now()#">,
                            'A',
                            <cfqueryparam cfsqltype="cf_sql_numeric" value="#session.Usucodigo#">
                    from FAPreFacturaE
                    where Ecodigo= <cfqueryparam value="#session.Ecodigo#" cfsqltype="cf_sql_integer">
					and DdocumentoREF = <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIinsert.OIdocumento#">
			        and CCTcodigoREF = <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIinsert.CCTcodigo#">
				</cfquery>
                <!--- Inserta un registro en la Bitacora para la OI--->
                <cfquery datasource="#session.DSN#">
	                insert FABitacoraMovPF (Ecodigo, OImpresionID, DdocumentoREF, CCTcodigoREF, SNcodigoREF, 
                    		FechaAplicacion, TipoMovimiento, BMUsucodigo)
    	            values (<cfqueryparam value="#session.Ecodigo#" cfsqltype="cf_sql_integer">,    
                    		<cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIinsert.OImpresionID#">,
                            <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsupdfac1.seriefacele##rsupdfac1.foliofacele#">,
                            <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIinsert.CCTcodigo#">,
                            <cfqueryparam cfsqltype="cf_sql_integer" value="#rsOIinsert.SNcodigo#">,
                            <cfqueryparam cfsqltype="cf_sql_date" value="#now()#">,
                            'A',
                            <cfqueryparam cfsqltype="cf_sql_numeric" value="#session.Usucodigo#">)
				</cfquery>
                <!--- Marca las PreFacturas con el Documento Generado --->
                <cfquery datasource="#session.DSN#">
	                update FAPreFacturaE
    	                set DdocumentoREF = <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsupdfac1.seriefacele##rsupdfac1.foliofacele#">,
        	            CCTcodigoREF = <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIinsert.CCTcodigo#">,
            	        TipoDocumentoREF = 2
                    from FAPreFacturaE
                    where Ecodigo= <cfqueryparam value="#session.Ecodigo#" cfsqltype="cf_sql_integer">
					and DdocumentoREF = <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIinsert.OIdocumento#">
			        and CCTcodigoREF = <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsOIinsert.CCTcodigo#">
				</cfquery>
                
				<!--- Marca la Orden de Impresion como Terminada --->
		        <cfquery datasource="#session.DSN#">
    		    	update FAEOrdenImpresion
        		    set OIEstado = 'T'
            		where OImpresionID = <cfqueryparam cfsqltype="cf_sql_integer" value="#form.OImpresionID#">
            		and Ecodigo = <cfqueryparam cfsqltype="cf_sql_integer" value="#session.Ecodigo#">
	        	</cfquery>
	   	
    	         	 <cfinvoke component="sif.Componentes.CC_PosteoDocumentosCxC"
						method="PosteoDocumento"
						EDid	= "#insertDoc.identity#"
						Ecodigo = "#Session.Ecodigo#"
						usuario = "#Session.usuario#"
						debug = "N"
					/>     	  
                <cfset From.SNcodigo = "">
                <cfset Form.OIdocumento = "">
                <cfset form.PFDocumento = "">
                <cfset varControlFiltro = false>
				<cfset varControlFlujo = false>	

	<!--- <cfinclude template="ListaImprimeDocumento.cfm"> --->
</cfif>