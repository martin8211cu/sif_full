﻿<cfif isdefined("session.Usulogin") and len(trim(session.Usulogin))>
	<cfquery name="rsPeriodoAux" datasource="#session.DSN#">
		select Pvalor
		from Parametros
		where Ecodigo = #Session.Ecodigo#
		  and Pcodigo = 50
    </cfquery>
    <cfquery name="rsMesAux" datasource="#session.DSN#">
		select Pvalor
		from Parametros
		where Ecodigo = #Session.Ecodigo#
		  and Pcodigo = 60
    </cfquery>
    <cfquery name="rsVales" datasource="#session.DSN#">
    	select count(1) as cantidad
        from AFResponsables
        where Ecodigo = #session.Ecodigo#
    </cfquery>
    Registros existentes antes del insert:
    <cfoutput>#rsVales.cantidad#</cfoutput><br />
    
    <cftransaction>
        <cfquery datasource="#session.DSN#">
             insert into AFResponsables 
                (
                    Ecodigo, 
                    DEid, 
                    Alm_Aid, 
                    Aid, 
                    CFid, 
                    CRCCid, 
                    CRTDid, 
                    AFRfini, 
                    AFRffin, 
                    Usucodigo, 
                    Ulocalizacion, 
                    BMUsucodigo, 
                    CRTCid, 
                    Monto
                )
            select 
                a.Ecodigo,
                 (
                    select min(ec.DEid)
                    from EmpleadoCFuncional ec
                    where ec.CFid = s.CFid
                      and getdate() between ec.ECFdesde and ec.ECFhasta
                ),
                null,
                a.Aid,
				s.CFid,
                (
                    select min(td.CRTDid)
                    from CRTipoDocumento td 
                    where td.Ecodigo = a.Ecodigo
                ),
                 (
                    select min(CRCCid)
                    from CRCentroCustodia 
                    where Ecodigo = a.Ecodigo
                ),
                dateadd(dd, 1, 
                    coalesce((select max(AFRffin)
                            from AFResponsables resp
                            where resp.Aid = a.Aid
                              and AFRffin < '61000101'), '19700101') )
                ,
                '61000101',
                (
                    select min(Usucodigo)
                    from Usuario
                    where Usulogin = '04rv8267'),
                '00',
                (
                    select min(Usucodigo)
                    from Usuario
                    where Usulogin = '04rv8267'),
                
                (select min(CRTCid)
                from CRTipoCompra ct
                where ct.Ecodigo = a.Ecodigo
                ), 
                0
            
            from Activos a
            	inner join AFSaldos s
                on s.Aid = a.Aid
            where a.Ecodigo = #session.Ecodigo#
            	and Astatus < 60
                and s.AFSperiodo = #rsPeriodoAux.Pvalor#
                and s.AFSmes     = #rsMesAux.Pvalor#
	            and (
                    select count(1)
                        from AFResponsables b
                        where b.Aid = a.Aid
                           and getdate() between b.AFRfini and b.AFRffin
                    ) = 0
        </cfquery>
	</cftransaction>

    <cfquery name="rsVales" datasource="#session.DSN#">
    	select count(1) as cantidad
        from AFResponsables
        where Ecodigo = #session.Ecodigo#
    </cfquery>
    Registros existentes después del insert:
    <cfoutput>#rsVales.cantidad#</cfoutput><br /><br />
   	Inserción de vales finalizada<br />
    <a href="/cfmx/home/menu/empresa.cfm">Regresar</a><br />
</cfif>