<cfcomponent>
	<cfset this.name = "smsStock">
	
	<cffunction name="onApplicationStart">
		<cfobject name="application.cfcStockTools" component="smsStock.components.stockTools">
	</cffunction>
	
</cfcomponent>