


<cfdump var="#application.cfcStockTools.getQuote("LLY")#">

<cfscript>
	symbol = "LLY";
	quoteData = application.cfcStockTools.getQuote("LLY");

	returnMessage.command = "submit";
	returnMessage.destAddress = 5551234;
	returnMessage.shortMessage = quoteData.symbol & ":" & dollarformat(quoteData.quote);
	sendGatewayMessage("smsStock", returnMessage);
</cfscript>
