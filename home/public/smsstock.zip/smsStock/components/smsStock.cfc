u<cfcomponent>
	<cffunction name="onIncomingMessage">
		<cfargument name="cfEvent" required="yes" type="struct">
		
		<cfset var symbol = "">
		<cfset var quoteData = StructNew()>
		<cfset var returnMessage = StructNew()>
		<cfscript>
			symbol = arguments.cfEvent.data.message;
			quoteData = application.cfcStockTools.getQuote(symbol);
		
			returnMessage.command = "submit";
			returnMessage.sourceAddress = arguments.cfEvent.gatewayId;
			returnMessage.destAddress = arguments.cfEvent.originatorId;
			returnMessage.shortMessage = quoteData.symbol & ":" & dollarformat(quoteData.quote);
		</cfscript>
		
		<cfreturn returnMessage>
	</cffunction>
</cfcomponent>