<cfcomponent>
	<cffunction name="getQuote" access="public" returntype="struct" output="false">
		<cfargument name="symbol" required="yes" type="string"> 
		
		<cfset var quoteData = StructNew()>
		<cfset var quote = "">
		
		<cfinvoke 
			webservice="http://www.webservicex.net/stockquote.asmx?WSDL"
			method="getQuote"
			symbol="#arguments.symbol#"
			returnVariable="quote"
			/>
		
		<cfset quote = XMLParse(quote)>
		
		<cfset quoteData.symbol = arguments.symbol>
		<cfset quoteData.quote = quote.StockQuotes.Stock.XMLChildren[2].XMLText>
		
		<cfreturn quoteData>
	</cffunction>
</cfcomponent>