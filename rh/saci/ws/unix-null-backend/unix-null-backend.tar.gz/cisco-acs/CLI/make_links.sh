ln -s .cli_wrapper AddProfile
ln -s .cli_wrapper ChangePassword
ln -s .cli_wrapper DeleteProfile
ln -s .cli_wrapper ChangeParent
chmod 500 AddProfile ChangePassword DeleteProfile ChangeParent

