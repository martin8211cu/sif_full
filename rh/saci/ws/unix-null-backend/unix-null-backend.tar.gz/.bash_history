cat /etc/passwd
su -
ls -l
ls -la
cp -fR .ssh .sshbak
unzip -t content.zip 
unzip content.zip cisco/acs
unzip content.zip cisco/acs/*
unzip content.zip cisco/ipass/*
ls -l
ls cisco/
mv cisco/* .
rmdir cisco/
ls -la
mv acs cisco-acs
ls -l
cd cisco-acs/
ls -l
cd CLI/
ls -l
make_links.sh
./make_links.sh
chmod +x make_links.sh 
./make_links.sh
ls -l
rm Cha*
rm Add*
rm Del
rm Del*
ls -l
./make_links.sh 
ls -la
ls -l
cd ..
pwd
ls -l
cd ..
ls -la
ls cisco-acs/
ssh intf@10.25.10.51
ls -la
cd .sunw/
ls -la
cd pkcs11_softtoken/
ls -l
cd
cd .ssh
ls -l
ssh -v intf@10.25.10.51
clear
clear
ls
ssh-keygen 
ssh --help
ssh-keygen --help
ls
ssh-keygen -b 1024 -t RSA -f id_rsa
ssh-keygen -b 1024 -t DSA -f id_rsa
ssh-keygen -b 1024  -f id_rsa
man ssh-keygen
ssh-keygen -b 1024 -t rsa1 -f id_rsa
ls -la
view id_rsa.pub 
ls -l
cat authorized_keys 
mv authorized_keys au2
cat au2 id_rsa.pub > authorizad_keys
ls -l
chmod 600 *
ls -l
cat authorizad_keys 
ls -l
cd .ssh
ls -l
mv authorizad_keys au1
mv au1 authorized_keys
ssh intf@10.25.10.51
ssh -v intf@10.25.10.51
cd .ssh
ls
ssh-keygen -b 1024 -t dsa -f id_dsa
ls -l
rm id_rsa*
cat au2 id_dsa > authorized_keys 
/ssh 10
ssh intf@10.25.10.51
ssh -v intf@10.25.10.51
cd .ssh
ls -l
pwd
rm id_dsa
mv au2 authorized_keys 
ls -l
pwd
ls -l
passwd
whoami
ls
cd ipass/
ls
ls -l
cd data/
ls -l
date
rm policy.txt.bak 
ls -l
w
ls ../bin
ls -la
cd ../bin
ls -l
chmod +x saci-*
ls -l
cat saci-add.sh 
/bin/sh
ls -l
view *sh
ls -l
w
whoami
who am i
chmod o+w *sh
ls -l
chmod u+w *sh
ls -l
vi *sh
./saci-add.sh x y
vi .sh
ls -l
view saci-add.sh 
cat > saci-add.sh
cat > saci-rm.sh
ls -l
vi saci-add.sh 
chmod 500 saci-*.sh
./saci-add.sh 
./saci-add.sh x y
cat saci-add.sh 
touch x
cat saci-add.sh 
./saci-add.sh x y
cat x
./saci-add.sh x y
./saci-add.sh 
./saci-add.sh x z
./saci-add.sh x jmrod
cat x
./saci-rm.sh x z
cat ./saci-rm.sh 
if [ $# -ne 2 ] ; then echo hola; fi
if [ $# -eq 2 ] ; then echo hola; fi
cat ./saci-rm.sh 
vi saci-rm.sh
ls -l
cat saci-rm.sh
set -v
. saci-rm.sh x z
./saci-rm.sh x z
cat ./saci-rm.sh 
file=3; uid=7
echo $uid
echo ${#uid}
file=3; uid=7asd
echo ${#uid}
while [ ${#uid} -lt 17 ]; do uid="${uid} "; done
echo ${#uid}
file=x
ls
rm x.bak
mv ${file} ${file}.bak
ls
cat saci-rm.sh 
grep -v -w ${uid} ${file}.bak > ${file}
ls -l
diff x*
unset -v
diff x*
set -v off
set -v off
unset -v
./saci-rm.sh x y
ls -l
./saci-add.sh x jiji
diff x*
ls -l
rm x.bak 
./saci-rm.sh x m
ls -l
cp saci-rm.sh k
ls -l
chmod 700 k
cat k
pwd
k x y 
./k x y
ls -l
./k x y
./k x y
./k x y
./k x y
./k x y
diff k saci-rm.sh 
vi saci-add.sh 
ls -l
cat > saci-rm.sh
#!/bin/bash
# Elimina un usuario del policy.txt
# regresa 1 si no existe, y 0 si ya existe
if [ $# -ne 2 ]; then echo "Usage: $(dirname $0) policyFile username"; fi
file=$1; uid=$2
# Completar a 17 chars
while [ ${#uid} -lt 17 ]; do uid="${uid} "; done
sp1="*                  "
grep -w ${uid} ${file} > /dev/null || exit 1
cd ipass/bin/
ls -l
rm *
ls -la
ls bak/
ls -l bak/
rm -fR bak/
cat > saci-add.sh
cat > saci-rm.sh
chmod 500 saci-*.sh
ls -la
./saci-add.sh x y
./saci-add.sh x y
./saci-add.sh x u
./saci-add.sh x m
./saci-add.sh x asdfasdjfasdfoiausdfoiuasdf98
cat x}
cat x
saci-rm x m
./saci-rm.sh x m
cat x
rm x
ls -l
rm x.bak 
ls -l
cd ipass/
cd data/
ls -l
cd ipass/
cd data/
ls
tail policy.txt 
tail policy.txt 
tail policy.txt 
ls-l
ls -l
head policy.txt
head policy.txt
head policy.txt
top
top
head policy.txt
prstat
ls -l
head policy.txt
head policy.txt
ls
ls -l
ls -l
ls -l
ls -l ..
ls -l ../..
unzip -t ../../content.zip 
unzip --help
unzip -l ../../content.zip 
ls -l}
ls -l
cat policy.txt
cat policy.txt
