<cfset action = "HorarioTipo.cfm">

<cfif not isdefined("form.btnNuevoD") and  not isdefined("form.btnNuevoE")>
	<cftry>
		<cfset modo="CAMBIO">
		<cfquery name="ABC_HorarioTipo" datasource="#Session.DSN#">
			set nocount on
			
			<!--- Caso 1: Agregar Encabezado --->
			<cfif isdefined("Form.btnAgregarE")>
				set nocount on
				insert HorarioTipo (CEcodigo, Hnombre)
					values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
							<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Hnombre#">
							)
				select @@identity as id
				set nocount off
				<cfset modoDet="ALTA">
				
			<!--- Caso 1.1: Cambia Encabezado --->
			<cfelseif isdefined("Form.btnCambiarE")>
				update HorarioTipo
				set Hnombre = <cfqueryparam value="#form.Hnombre#" cfsqltype="cf_sql_varchar">
				where Hcodigo = <cfqueryparam value="#form.Hcodigo#" cfsqltype="cf_sql_numeric">
				  and CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				  
				<cfset modoDet="ALTA">
				
			<!--- Caso 2: Borrar un Encabezado del Tipo de Horario --->
			<cfelseif isdefined("Form.btnBorrarE")>			
				<cfif isdefined("Form.Hcodigo") AND Form.Hcodigo NEQ "" >
					delete Horario 
					from  Horario a , HorarioTipo b
					where a.Hcodigo=<cfqueryparam value="#form.Hcodigo#" cfsqltype="cf_sql_numeric">				
					  and b.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
					  and a.Hcodigo = b.Hcodigo 
				
					delete HorarioAplica
					where Hcodigo=<cfqueryparam value="#form.Hcodigo#" cfsqltype="cf_sql_numeric">
					 
				 
					delete HorarioTipo
					where Hcodigo=<cfqueryparam value="#form.Hcodigo#" cfsqltype="cf_sql_numeric">
					  and CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
					  
					<cfset action = "listaHorarioTipo.cfm">
					<cfset modo = "ALTA">
					<cfset modoDet="ALTA">
				</cfif>

			<!--- Caso 3: Agregar Detalle de Horarios y opcionalmente modificar el encabezado --->
			<cfelseif isdefined("Form.btnAgregarD")>
				<cfif isdefined("Form.Hcodigo") AND Form.Hcodigo NEQ "" >
					insert Horario 
					(Hcodigo, Hbloquenombre, Hentrada, Hsalida, Htipo)
					values (<cfqueryparam value="#form.Hcodigo#" cfsqltype="cf_sql_numeric">,
							<cfqueryparam value="#form.Hbloquenombre#" cfsqltype="cf_sql_varchar">,
							<cfqueryparam value="#form.Hentrada&'.'&form.HentradaMin#" cfsqltype="cf_sql_float">,
							<cfqueryparam value="#form.Hsalida&'.'&form.HsalidaMin#" cfsqltype="cf_sql_float">,
							<cfqueryparam value="#form.Htipo#" cfsqltype="cf_sql_smallint">)			
				
					<!--- Modificar Encabezado --->
					update HorarioTipo
					set Hnombre = <cfqueryparam value="#form.Hnombre#" cfsqltype="cf_sql_varchar">
					where Hcodigo = <cfqueryparam value="#form.Hcodigo#" cfsqltype="cf_sql_numeric">
					  and CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">

					<cfset modoDet="ALTA">
				</cfif>
				
			<!--- Caso 4: Modificar Detalle de Tabla de Evaluacion y modificar el encabezado --->			
			<cfelseif isdefined("Form.btnCambiarD")>
				update Horario
				set	Hbloquenombre =	<cfqueryparam value="#form.Hbloquenombre#" cfsqltype="cf_sql_varchar">,
					Hentrada = <cfqueryparam value="#form.Hentrada&'.'&form.HentradaMin#" cfsqltype="cf_sql_float">,
					Hsalida  = <cfqueryparam value="#form.Hsalida&'.'&form.HsalidaMin#" cfsqltype="cf_sql_float">,
					Htipo  	 = <cfqueryparam value="#form.Htipo#" cfsqltype="cf_sql_smallint">
				from Horario a , HorarioTipo b					
				where a.Hcodigo = <cfqueryparam value="#form.Hcodigo#" cfsqltype="cf_sql_numeric">
				  and Hbloque = <cfqueryparam value="#form.Hbloque#" cfsqltype="cf_sql_numeric">
				  and b.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				  and a.Hcodigo = b.Hcodigo 

				<!--- Modificar Encabezado --->
				update HorarioTipo
				set Hnombre = <cfqueryparam value="#form.Hnombre#" cfsqltype="cf_sql_varchar">
				where Hcodigo = <cfqueryparam value="#form.Hcodigo#" cfsqltype="cf_sql_numeric">
				  and CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">

				<cfset modoDet="CAMBIO">
				
			<!--- Caso 5: Borrar detalle de tabla de Evaluacion --->
			<cfelseif isdefined("Form.btnBorrarD")>
				delete Horario 
				from Horario a , HorarioTipo b					
				where a.Hcodigo = <cfqueryparam value="#form.Hcodigo#" cfsqltype="cf_sql_numeric">
				  and Hbloque = <cfqueryparam value="#form.Hbloque#" cfsqltype="cf_sql_numeric">
				  and b.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				  and a.Hcodigo = b.Hcodigo 
								
				<cfset modoDet="ALTA">
			</cfif>
			
			set nocount off					
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>		
<cfelse> 
	<cfif isdefined("form.btnNuevoE")>
		<cfset modo = "ALTA" >
		<cfset modoDet = "ALTA">
	<cfelseif isdefined("form.btnNuevoD")>
		<cfset modo = "CAMBIO" >
		<cfset modoDet = "ALTA">
	</cfif>
</cfif>

<cfif isdefined("Form.btnAgregarE")>
	<cfset form.Hcodigo = "#ABC_HorarioTipo.id#">
</cfif>

<cfoutput>
<form action="#action#" method="post" name="sql">
	<input name="modo" type="hidden" value="<cfif isdefined("modo")>#modo#</cfif>">
	<input name="modoDet" type="hidden" value="<cfif isdefined("modoDet")>#modoDet#</cfif>">
	<cfif modo EQ "CAMBIO">
		<input name="Hcodigo"   type="hidden" value="<cfif modo EQ "CAMBIO">#Form.Hcodigo#</cfif>">
	</cfif>
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")>#Form.Pagina#</cfif>">
</form>
</cfoutput>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>
