<cfset action = "PlanEvaluacion.cfm">

<cfif not isdefined("form.btnNuevoD") and  not isdefined("form.btnNuevoE")>
	<cftry>
		<cfset modo="CAMBIO">
		<cfquery name="ABC_PlanEvaluacion" datasource="#Session.DSN#">
			set nocount on
			<!--- Caso 1: Agregar Encabezado --->
			<cfif isdefined("Form.btnAgregarE")>
				insert EvaluacionPlan (CEcodigo, EPnombre)
					values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
							<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.EPnombre#">
								)
				select @@identity as id
				<cfset modoDet="ALTA">
				
			<!--- Caso 1.1: Cambia Encabezado --->
			<cfelseif isdefined("Form.btnCambiarE")>
				update EvaluacionPlan
				set EPnombre = <cfqueryparam value="#form.EPnombre#" cfsqltype="cf_sql_varchar">
				where EPcodigo = <cfqueryparam value="#form.EPcodigo#" cfsqltype="cf_sql_numeric">
				<cfset modoDet="ALTA">				
				
			<!--- Caso 2: Borrar un Encabezado del Plan de Evaluacion --->
			<cfelseif isdefined("Form.btnBorrarE")>			
				<cfif isdefined("Form.EPcodigo") AND Form.EPcodigo NEQ "" >
					delete EvaluacionPlanConcepto 
					where EPcodigo=<cfqueryparam value="#form.EPcodigo#" cfsqltype="cf_sql_numeric">				
					
					delete EvaluacionPlan
					where EPcodigo=<cfqueryparam value="#form.EPcodigo#" cfsqltype="cf_sql_numeric">
				</cfif>
				<cfset modo = "ALTA">
				<cfset modoDet="ALTA">
				<cfset action = "listaEvaluacionPlan.cfm">

			<!--- Caso 3: Agregar Detalle de Tablas de Evaluacion y opcionalmente modificar el encabezado --->
			<cfelseif isdefined("Form.btnAgregarD")>
				<cfif isdefined("Form.EPcodigo") AND Form.EPcodigo NEQ "" >
					insert EvaluacionPlanConcepto 
					(EPcodigo, EVTcodigo, ECcodigo, EPCnombre, EPCporcentaje)
					values (<cfqueryparam value="#form.EPcodigo#" cfsqltype="cf_sql_numeric">,
							<cfif #Form.EVTcodigo# NEQ -1>
								<cfqueryparam value="#form.EVTcodigo#" cfsqltype="cf_sql_numeric">,
							<cfelse>
								null,	
							</cfif>
							<cfqueryparam value="#form.ECcodigo#" cfsqltype="cf_sql_numeric">,	
							<cfqueryparam value="#form.EPCnombre#" cfsqltype="cf_sql_varchar">,
							<cfqueryparam value="#form.EPCporcentaje#" cfsqltype="cf_sql_numeric">)			
				
					<!--- Modificar Encabezado --->
					update EvaluacionPlan
					set EPnombre = <cfqueryparam value="#form.EPnombre#" cfsqltype="cf_sql_varchar">
					where EPcodigo = <cfqueryparam value="#form.EPcodigo#" cfsqltype="cf_sql_numeric">
				</cfif>
				<cfset modoDet="ALTA">
				
			<!--- Caso 4: Modificar Detalle de Tabla de Evaluacion y modificar el encabezado --->			
			<cfelseif isdefined("Form.btnCambiarD")>
				update EvaluacionPlanConcepto
				set EPcodigo  	= <cfqueryparam value="#form.EPcodigo#" cfsqltype="cf_sql_numeric">,
					<cfif #Form.EVTcodigo# NEQ -1 >
						EVTcodigo  	= <cfqueryparam value="#form.EVTcodigo#" cfsqltype="cf_sql_numeric">,
					<cfelse>
						EVTcodigo  	= null,	
					</cfif>
					ECcodigo  	= <cfqueryparam value="#form.ECcodigo#" cfsqltype="cf_sql_numeric">,					
					EPCnombre  	= <cfqueryparam value="#form.EPCnombre#" cfsqltype="cf_sql_varchar">,					
					EPCporcentaje  = <cfqueryparam value="#form.EPCporcentaje#" cfsqltype="cf_sql_numeric">
				where EPCcodigo     = <cfqueryparam value="#form.EPCcodigo#"    cfsqltype="cf_sql_numeric">

				<!--- Modificar Encabezado --->
				update EvaluacionPlan
				set EPnombre = <cfqueryparam value="#form.EPnombre#" cfsqltype="cf_sql_varchar">
				where EPcodigo = <cfqueryparam value="#form.EPcodigo#" cfsqltype="cf_sql_numeric">

				<cfset modoDet="CAMBIO">
				
			<!--- Caso 5: Borrar detalle de tabla de Evaluacion --->
			<cfelseif isdefined("Form.btnBorrarD")>
				delete EvaluacionPlanConcepto 
				where EPCcodigo = <cfqueryparam value="#form.EPCcodigo#" cfsqltype="cf_sql_numeric">
				<cfset modoDet = "ALTA">							
			</cfif>					
		set nocount off					
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>		
<cfelse> 
	<cfif isdefined("form.btnNuevoE")>
		<cfset modo = "ALTA" >
		<cfset modoDet = "ALTA">
	<cfelseif isdefined("form.btnNuevoD")>
		<cfset modo = "CAMBIO" >
		<cfset modoDet = "ALTA">
	</cfif>
</cfif>

<cfif isdefined("Form.btnAgregarE")>
	<cfset Form.EPcodigo = "#ABC_PlanEvaluacion.id#">
</cfif>

<cfoutput>
<form action="#action#" method="post" name="sql">
	<input name="modo" type="hidden" value="<cfif isdefined("modo")>#modo#</cfif>">
	<input name="modoDet" type="hidden" value="<cfif isdefined("modoDet")>#modoDet#</cfif>">
	<cfif modo EQ "CAMBIO">
		<input name="EPcodigo"  type="hidden" value="<cfif modo EQ "CAMBIO">#Form.EPcodigo#</cfif>">
	</cfif>
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")>#Form.Pagina#</cfif>">
</form>
</cfoutput>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>