<cfif not isdefined("form.Nuevo")>
<!--- 	<cfif form.PEorden eq "" and isdefined("form.Alta") >
		<cfquery name="rsOrden" datasource="#session.DSN#">
			select isnull(max(a.PEorden),0) + 1 as PEorden 
			from PeriodoEvaluacion a, Nivel b
			where a.Ncodigo=b.Ncodigo and b.CEcodigo=<cfqueryparam value="#session.CEcodigo#" cfsqltype="cf_sql_numeric">
		</cfquery>
		<cfif rsOrden.RecordCount gt 0>
			<cfset form.PEorden = rsOrden.PEorden>
		<cfelse>
			<cfset form.PEorden = 1>
		</cfif>
	</cfif>
--->
	<cftry> 
		<cfquery name="abc_periodoevaluacion" datasource="#session.DSN#">
			set nocount on
			<cfif isdefined("form.Alta")>
				 declare @cont int
				 select @cont = isnull(max(c.PEorden),0)+10 
				 from Nivel b, PeriodoEvaluacion c
				 where c.Ncodigo 	= <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
				   and b.CEcodigo 	= <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
				   and b.Ncodigo 	= c.Ncodigo
				if not exists ( select 1 from Nivel a, PeriodoEvaluacion b  
								where Upper(rtrim(ltrim(b.PEdescripcion))) = <cfqueryparam value="#Ucase(rtrim(ltrim(form.PEdescripcion)))#" cfsqltype="cf_sql_varchar">
								  and a.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
								  and a.Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
								  and a.Ncodigo = b.Ncodigo
				)
				begin
					insert PeriodoEvaluacion ( Ncodigo, PEdescripcion, PEorden )
								values( <cfqueryparam value="#form.Ncodigo#"       cfsqltype="cf_sql_numeric">, 
										<cfqueryparam value="#form.PEdescripcion#" cfsqltype="cf_sql_varchar">,
										<cfif len(trim(Form.PEorden)) NEQ 0>
											<cfqueryparam value="#Form.PEorden#" cfsqltype="cf_sql_integer">
										<cfelse>
											@cont	
										</cfif>
									  )
				end
				else
				begin
					select 1
				end
				<cfset modo="ALTA">
			<cfelseif isdefined("form.Baja")>
				<!--- Para que no valide constraint --->
				delete from PeriodoVigente
				where PEevaluacion = <cfqueryparam value="#Form.PEcodigo#" cfsqltype="cf_sql_numeric">

				delete PeriodoEvaluacion
				where PEcodigo = <cfqueryparam value="#form.PEcodigo#" cfsqltype="cf_sql_numeric">
				
				<cfset modo="ALTA">
			<cfelseif isdefined("form.Cambio")>
				 declare @cont int
				 select @cont = isnull(max(c.PEorden),0)+10 
				 from Nivel b, PeriodoEvaluacion c
				 where c.Ncodigo 	= <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
				   and b.CEcodigo 	= <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
				   and b.Ncodigo 	= c.Ncodigo
				 if not exists ( select 1 from EvaluacionConceptoMateria a, PeriodoEvaluacion b  
									where a.PEcodigo = <cfqueryparam value="#form.PEcodigo#" cfsqltype="cf_sql_numeric">
									  and a.PEcodigo = b.PEcodigo
					)
				 begin 
					update PeriodoEvaluacion 
					set Ncodigo       	= <cfqueryparam value="#form.Ncodigo#"       cfsqltype="cf_sql_numeric">,
						PEdescripcion 	= <cfqueryparam value="#form.PEdescripcion#" cfsqltype="cf_sql_varchar">,
						<cfif len(trim(Form.PEorden)) NEQ 0>
							PEorden 	= <cfqueryparam value="#Form.PEorden#" cfsqltype="cf_sql_integer">
						<cfelse>
							PEorden 	= @cont	
						</cfif>
					where PEcodigo    = <cfqueryparam value="#form.PEcodigo#" cfsqltype="cf_sql_numeric">
				 end
				 else
				 begin
					update PeriodoEvaluacion 
					set PEdescripcion = <cfqueryparam value="#form.PEdescripcion#" cfsqltype="cf_sql_varchar">,
					<cfif len(trim(Form.PEorden)) NEQ 0>
						PEorden 	= <cfqueryparam value="#Form.PEorden#" cfsqltype="cf_sql_integer">
					<cfelse>
						PEorden 	= @cont	
					</cfif>
					where PEcodigo    = <cfqueryparam value="#form.PEcodigo#"      cfsqltype="cf_sql_numeric">
				 end
				  <cfset modo="ALTA">
			</cfif>
			set nocount off
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>
</cfif>

<form action="PeriodoEvaluacion.cfm" method="post" name="sql">
	<input name="modo"     type="hidden" value="<cfif isdefined("modo")><cfoutput>#modo#</cfoutput></cfif>">
	<input name="PEcodigo" type="hidden" value="<cfif isdefined("Form.MTcodigo")><cfoutput>#Form.PEcodigo#</cfoutput></cfif>">
	<input name="Pagina"   type="hidden" value="<cfif isdefined("Form.Pagina")><cfoutput>#Form.Pagina#</cfoutput></cfif>">	
</form>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>


