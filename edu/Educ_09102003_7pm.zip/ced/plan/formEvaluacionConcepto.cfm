<!-- Establecimiento del modo -->
<cfif isdefined("form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("form.modo")>
		<cfset modo="ALTA">
	<cfelseif #form.modo# EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>

<!--- ==================== --->
<!---       Consultas      --->
<!--- ==================== --->
<!--- 1. Form --->
<cfquery name="rsForm" datasource="#session.DSN#">
	select ECcodigo, ECnombre, ECorden
	from EvaluacionConcepto
	<cfif isdefined("form.ECcodigo") and form.ECcodigo neq "">
		where ECcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.ECcodigo#">
	</cfif>	  
</cfquery>

<cfif modo NEQ "ALTA" and isdefined("Form.ECcodigo") and len(trim("Form.ECcodigo")) GT 0>
	<!--- 3. Validaciones de dependencias--->
	<!---  Rodolfo JImenez Jara, SOIN, 03/12/2002 --->
	<cfquery datasource="#Session.DSN#" name="rsHayEvaluacionConceptoMateria">
		select 1 from EvaluacionConceptoMateria
		where ECcodigo  = <cfqueryparam value="#Form.ECcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>
	<cfquery datasource="#Session.DSN#" name="rsHayEvaluacionPlanConcepto">
		select 1 from EvaluacionPlanConcepto
		where ECcodigo  = <cfqueryparam value="#Form.ECcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>
	<cfquery datasource="#Session.DSN#" name="rsHayEvaluacionConceptoCurso">
		select 1 from EvaluacionConceptoCurso
		where ECcodigo  = <cfqueryparam value="#Form.ECcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>
</cfif>

<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" type="text/JavaScript">
<!--
// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
	
	botonActual = "";
	
	function btnSelected(name, f) {
		if (f != null) {
			return (f["botonSel"].value == name)
		} else {
			return (botonActual == name)
		}
	}
	
	function validaForm(f) {
		if (f.ECnombre.obj.disabled) {
			f.ECnombre.obj.disabled = false;
		}
		return true;
	}
function qf(Obj){
	var VALOR=""
	var HILERA=""
	var CARACTER=""
	if(Obj.name)
	  VALOR=Obj.value
	else
	  VALOR=Obj
	
	for (var i=0; i<VALOR.length; i++) {	
	
		CARACTER =VALOR.substring(i,i+1);
		if (CARACTER=="," || CARACTER==" ") {
			CARACTER=""; //CAMBIA EL CARACTER POR BLANCO
		}  
		HILERA+=CARACTER;
	}
	return HILERA
}

<!--
//-->
</script>


<form action="SQLEvaluacionConcepto.cfm" method="post" name="EvaluacionConcepto" onSubmit="javascript:return validaForm(this);">
  <!--- <table width="85%" height="56%" align="center">
	<tr>
	<a href="EvaluacionConcepto.cfm?Ayuda=<cfif Session.Ayuda EQ 0>1<cfelse>0</cfif>" ><img src="../../Imagenes/Help01_T.gif" alt="Ayuda del Portal"  border="0" align="baseline"> </a>
	<cfif Session.Ayuda EQ 0> 
	 		  La clasificaci�n de los per�odos de evaluaci�n depender�n de las pol�ticas de cada instituci�n, estas 
			  pueden ser: bimestrales, trimestrales y semestrales o la combinaci�n de varios rubros.<br>
		<cfif modo eq "ALTA">
			<td width="100%" height="50%" valign="top">
			  <p><strong><font size="2">Agregar</font></strong>:<font size="1">Al 
			  realizar un click sobre la opci&oacute;n de Agregar, grabar� los datos 
			  del ingresados por usted; tales como: &nbsp;&nbsp;<strong>&nbsp;Descripci&oacute;n 
			  del Periodo de Evaluaci�n </strong> (Nombre del Periodo), <strong>Nivel:&nbsp;</strong>(definidos 
			  por usted seg&uacute;n las politicas del Centro Educativo) &nbsp; y el <strong>Orden</strong> 
			  (Posici&oacute;n en que se mostrar&aacute; en el portal,en  m&uacute;ltiplos 
			  de 10), si deja este campo vac�o, el sistema le asignar� un valor automaticamente 
			  (el �ltimo orden definido por el usuario mas 10) . </font><font size="2">&nbsp;</font> </p>
			  <p><font size="2"><strong>Limpiar:</strong> <font size="1">Al &nbsp; 
				realizar un click sobre la opci&oacute;n de <strong>Limpiar</strong> 
				desaparecer�n de la pantalla, todos aquellos datos digitados por usted en ese nuevo registro ,
				sin alterar la informaci�n del Portal.</font> </font></p>
				<p>
				<cfif rsNivel.RecordCount eq 0>
					<font size="2"><strong>Agregar Nuevo Nivel:</strong><font size="1"> Esta opci�n aparece solo cuando no hay niveles 
					definidos para ese Centro Educativo, por lo que al realizar un click sobre esta opci�n, �sta lo llevar� al 
					Mantenimiento de Niveles para que defina por lo menos un nivel, y hac� pueda continuar el mantenimiento del Portal.
					As� mismo en la pantalla de Mantenimiento de Niveles, aparecer� un bot�n que lo regresar� al mantenimiento de Periodos 
					de Evaluaci�n cuando pulse click sobre �l.
					</font> </font>
				</cfif>
				</p>
				</td>
		<cfelse>
			<td width="100%" height="50%" valign="top"> 
			  <p><strong><font size="2">Nuevo</font></strong>:<font size="1">Al
			  realizar un click sobre la opci&oacute;n de Nuevo, usted podr&aacute; 
			  ingresar los datos del del Periodo de Evaluaci�n como:&nbsp;&nbsp;<strong>&nbsp;Descripci&oacute;n 
			  del Periodo</strong> (Nombre del Periodo), <strong>Nivel:&nbsp;</strong>(definidos 
			  por usted seg&uacute;n las politicas del Centro Educativo) &nbsp; y el <strong>Orden</strong> (Posici&oacute;n 
			  en que se mostrar&aacute; en el portal, m&uacute;ltiplos de 10) . </font><font size="2">&nbsp;</font> </p>
			  <p><font size="2"><strong>Modificar:</strong> <font size="1">Al realizar 
				  un click sobre la opci&oacute;n de <strong>Modificar</strong> usted 
				  podr&aacute; modificar los siguientes datos : <strong>Descripci&oacute;n</strong> 
				  (Nombre del Periodo),<strong> Nivel</strong>  (Si esta opci�n esta deshabilitada, no podr� realizar modificaciones al Periodo de Evaluaci�n, ya que hay grupos dependientes de este Periodo, si no esta deshabilitada, el Portal le permite cambiar el nivel de este Periodo.) y <strong>el 
				  Orden</strong> (Posici&oacute;n en que se mostrar&aacute; en el portal, 
				  m&uacute;ltiplos de 10), si deja este campo vac�o, el sistema le asignar� un valor automaticamente (el �ltimo orden definido por el usuario mas 10).</font> </font></p>
				<p><font size="2"><strong>Eliminar</strong></font><font size="1">; Escoja 
				  el Periodo que desee eliminar y realice un click sobre la opci&oacute;n 
				  Borrar, el portal refrescar&aacute; la vista sin mostrar el &iacute;tem 
				  que se indic&oacute; anteriormente.</font></p></td>
				
		</cfif>
	</cfif> 
			  
    </tr>
  </table>		 --->
  <table width="100%" border="0" cellpadding="1" cellspacing="1">
    <tr>
      <td class="tituloMantenimiento" colspan="2" align="center"><font size="3">
        <cfif modo eq "ALTA">
          Nuevo Concepto De Evaluaci&oacute;n
          <cfelse>
          Modificar Concepto De Evaluaci&oacute;n
        </cfif>
        </font></td>
    </tr>
    <tr> 
      <td align="right" valign="baseline">Descripci&oacute;n:&nbsp;</td>
      <td valign="baseline"><input name="ECnombre" type="text" value="<cfif modo neq 'ALTA'><cfoutput>#rsForm.ECnombre#</cfoutput></cfif>" size="50" maxlength="80" alt="El valor de la Descripci�n" onfocus="javascript:this.select();"></td>
    </tr>
    <tr> 
      <td align="right"> 
        Orden: </td>
      <td align="left"><input name="ECorden" align="left" type="text" id="ECorden" size="8" maxlength="8" value="<cfif modo NEQ "ALTA"><cfoutput>#rsForm.ECorden#</cfoutput></cfif>" onfocus="javascript:this.value=qf(this); this.select();" onblur="javascript:fm(this,0);"  onkeyup="javascript:if(snumber(this,event,0)){ if(Key(event)=='13') {this.blur();}}" ></td>
    </tr>
    <tr> 
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
    </tr>
    <tr> 
      <td align="center" colspan="2"><cfinclude template="../../portlets/pBotones.cfm"></td>
    </tr>
    <cfif modo neq 'ALTA'>
	<cfoutput>
      <tr> 
        <td colspan="2">
			<input type="hidden" name="ECcodigo"  value="#rsForm.ECcodigo#">
			<input type="hidden" name="HayEvaluacionConceptoMateria"  value="#rsHayEvaluacionConceptoMateria.recordCount#">
			<input type="hidden" name="HayEvaluacionPlanConcepto"  value="#rsHayEvaluacionPlanConcepto.recordCount#">
			<input type="hidden" name="HayEvaluacionConceptoCurso"  value="#rsHayEvaluacionConceptoCurso.recordCount#">
		</td>
      </tr>
	</cfoutput>
    </cfif>
  </table>

</form>

<script language="JavaScript">
	function deshabilitarValidacion() {
		objForm.ECnombre.required = false;
	}
	
	function habilitarValidacion() {
		objForm.ECnombre.required = true;
	}
		
	// Se aplica la descripcion del Grado 
	function __isTieneDependencias() {
		if(btnSelected("Baja", this.obj.form)) {
				// Valida que el Grado no tenga dependencias con otros.
				var msg = "";
				//alert(new Number(this.obj.form.HayEvaluacionConceptoMateria.value)); 
				if (new Number(this.obj.form.HayEvaluacionConceptoMateria.value) > 0) {
					msg = msg + "conceptos de evaluaci�n de materias"
				}
				//alert(new Number(this.obj.form.HayEvaluacionPlanConcepto.value));
				if (new Number(this.obj.form.HayEvaluacionPlanConcepto.value) > 0) {
					if (msg != "") msg += ', ';
					msg = msg + "conceptos de planes de evaluaci�n"
				}
				//alert(new Number(this.obj.form.HayEvaluacionConceptoCurso.value));
				if (new Number(this.obj.form.HayEvaluacionConceptoCurso.value) > 0) {
					if (msg != "") msg += ', ';
					msg = msg + "conceptos de evaluaci�n de cursos"
				}
				if (msg != "")
				{
					this.error = "Usted no puede eliminar el Concepto de evaluaci�n '" + this.obj.form.ECnombre.value + "' porque �ste tiene asociado: " + msg + ".";
					this.obj.form.ECnombre.focus();
				}
		}
	}
	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isTieneDependencias", __isTieneDependencias);
	
	objForm = new qForm("EvaluacionConcepto");

	<cfif modo EQ "ALTA">
		objForm.ECnombre.required = true;
		objForm.ECnombre.description = "Descripci�n";
		objForm.ECorden.description = "Orden";
	<cfelseif modo EQ "CAMBIO">
		objForm.ECnombre.required = true;
		objForm.ECnombre.description = "Descripci�n";
		objForm.ECnombre.validateTieneDependencias();
	</cfif>
</script>
