<cfinclude template="/edu/Utiles/general.cfm">
<!---
** Mantenimiento Materias Sustitutivas
** Hecho por: 		Rodolfo Jim�nez Jara
** Fecha: 			10-Enero-2003
** Comentarios: 
** Aqu� se relacionan las materias sustitutivas con los grados en que se podran recibir.
** una vez asociada esta con una materia electiva, no se puede borrar la relacion, primero ir al manntenimiento 
** de las electivas borrar la relaci�n
--->
<!--- Consultas --->
<cfif isdefined("Url.Mconsecutivo") and not isdefined("Form.Mconsecutivo")>
	<cfparam name="Form.Mconsecutivo" default="#Url.Mconsecutivo#">
</cfif>

<cfquery datasource="#Session.DSN#" name="rsMateria">
	select substring(c.Mnombre,1,50) as Mnombre, substring(a.Ndescripcion,1,50) as Ndescripcion, isnull(b.Gdescripcion,'No Aplica') as Gdescripcion,
	       case c.Melectiva
		        when 'R' then 'Regular'
				when 'S' then 'Sustitutiva'
				when 'E' then 'Electiva'
				when 'C' then 'Complementaria'
				else ''
			end as Modalidad,
			d.MTdescripcion
	from Nivel a, Grado b, Materia c, MateriaTipo d
	where a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
	  and c.Mconsecutivo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Mconsecutivo#">
	  and a.Ncodigo = c.Ncodigo 
	  and b.Ncodigo =* c.Ncodigo 
	  and b.Gcodigo =* c.Gcodigo 
	  and c.MTcodigo = d.MTcodigo
</cfquery>

<cfif isdefined("Form.btnAplicar")>
	<cfquery name="rsDelete" datasource="#Session.DSN#">
		set nocount on
		delete GradoSustitutivas 
        from GradoSustitutivas x
		where Gcodigo in (#form.Cual_Grupo#)  
		  and Ncodigo in (#form.Cual_Nivel#)  
		  and Mconsecutivo = #Form.Mconsecutivo#  
		  and not exists ( select 1
									from MateriaElectiva a, Materia b
									where a.Melectiva = b.Mconsecutivo
									and b.Gcodigo = x.Gcodigo
		  )
										<!--- es para evitar que exista una relaci�n en  MateriaElectiva --->
		set nocount off
	</cfquery>
	<cfif isdefined("Form.Chk")>
		<cfset a=ListToArray(Form.Chk,',')>
		<cfloop index="i" from="1" to="#ArrayLen(a)#">
			<cfset b = ListToArray(a[i],'|')>
			 <cfset Gcodigo = b[1]>
			<cfset Ncodigo = b[2]>
			<cfset Mconsecutivo2 = b[3]>
			
			<cfquery name="ABC_GradoAplica" datasource="#Session.DSN#">
				set nocount on
				if not exists( 	select Mconsecutivo 
							   	from GradoSustitutivas
							 	where Gcodigo = #Gcodigo#
								  and Ncodigo = #Ncodigo# 
								  and Mconsecutivo = #Mconsecutivo2#
				
							)
				begin  
					insert GradoSustitutivas (Gcodigo, Ncodigo, Mconsecutivo)
					values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Gcodigo#">,
							<cfqueryparam cfsqltype="cf_sql_numeric" value="#Ncodigo#">,
							<cfqueryparam cfsqltype="cf_sql_numeric" value="#Mconsecutivo2#">
							)
		 		end
				else
					select 1  
				set nocount off
			</cfquery>
		</cfloop>
	</cfif>
</cfif>
<link href="../../css/estilos.css" rel="stylesheet" type="text/css">
<!---------------------------------------------------------------------------------- --->
	<form name="filtros" action="MateriasSustitutivas.cfm" method="post">
		<table class="areaDatos" width="100%">
			<thead>
				<tr> 
					<td colspan="5">Datos de Materia</td>
				</tr>
			</thead>
			<tbody>
				<tr> 
					<td width="35%" rowspan="2" align="center" valign="middle" style="font-size: 13pt; font-weight: bold;" nowrap><cfoutput>#rsMateria.Mnombre#</cfoutput></td>
					<td nowrap><strong>Nivel:</strong> <cfoutput>#rsMateria.Ndescripcion#</cfoutput> </td>
					<td nowrap><strong>Tipo de Materia:</strong> <cfoutput>#rsMateria.MTdescripcion#</cfoutput></td>
				</tr>
				<tr> 
					<td nowrap> <strong>Grado:</strong> <cfoutput>#rsMateria.Gdescripcion#</cfoutput> </td>
					<td nowrap><strong>Modalidad:</strong> <cfoutput>#rsMateria.Modalidad#</cfoutput></td>
				</tr>
			</tbody>
		</table>
		<input name="Cual_Grupo" type="hidden" id="Cual_Grupo" value="">
		<input name="Cual_Nivel" type="hidden" id="Cual_Nivel" value="">
		<input name="Cual_Materia" type="hidden" id="Cual_Materia" value="">
	</form>
	<table width="100%" cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td>
		<strong> &nbsp;&nbsp;&nbsp; 
			<input name="chkTodos" type="checkbox" value="" border="1" onClick="javascript:Marcar(this);">
			Seleccionar Todos</strong>
		</td>
	</tr>
    <tr> 
    	<td>
	 	<form name="lista" method="post" action="MateriasSustitutivas.cfm">
			<input name="Mnombre" type="hidden" id="Mnombre" value="<cfif isdefined("Form.Mnombre")><cfoutput>#Form.Mnombre#</cfoutput></cfif>">
			<input name="Cual_Grupo" type="hidden" id="Cual_Grupo" value="">
			<input name="Cual_Nivel" type="hidden" id="Cual_Nivel" value="">
			<input name="Cual_Materia" type="hidden" id="Cual_Materia" value="">
			<cfset navegacion = "">
			<cfset navegacion = "Mconsecutivo=" & Form.Mconsecutivo >
			<cfinvoke 
			 component="edu.Componentes.pListas"
			 method="pListaEdu"
			 returnvariable="pListaEduRet">
				<cfinvokeargument name="tabla" value="Materia m, MateriaTipo mt, Grado a, Nivel b, GradoSustitutivas c"/>
				<cfinvokeargument name="columnas" value="convert(varchar, a.Ncodigo) as Ncodigo, convert(varchar, a.Gcodigo) as Gcodigo, #Form.Mconsecutivo# as KMateria, substring(b.Ndescripcion,1,50) as Ndescripcion, substring(a.Gdescripcion,1,50) as Gdescripcion, a.Gorden, convert(varchar, c.Gcodigo)+'|'+convert(varchar, c.Ncodigo)+'|'+convert(varchar, c.Mconsecutivo) as checked"/>
				<cfinvokeargument name="desplegar" value="Gdescripcion, Gorden"/>
				<cfinvokeargument name="etiquetas" value="Descripci�n, Orden"/>
				<cfinvokeargument name="formatos" value=""/>
				<cfinvokeargument name="filtro" value="m.Mconsecutivo = #Form.Mconsecutivo#
														and mt.CEcodigo = #Session.CEcodigo#
														and c.Mconsecutivo = #Form.Mconsecutivo#
														and m.MTcodigo = mt.MTcodigo
														and b.CEcodigo = mt.CEcodigo
														and a.Ncodigo = b.Ncodigo
														and a.Ncodigo = m.Ncodigo 
														and a.Gcodigo *= c.Gcodigo
														order by b.Norden, a.Gorden"/>
				<cfinvokeargument name="align" value="left, left"/>
				<cfinvokeargument name="ajustar" value="N,N"/>
				<cfinvokeargument name="irA" value="MateriasSustitutivas.cfm"/>
				<cfinvokeargument name="botones" value=""/>
				<cfinvokeargument name="cortes" value="Ndescripcion"/>
				<cfinvokeargument name="checkboxes" value="S"/>
				<cfinvokeargument name="debug" value="N"/>
				<cfinvokeargument name="incluyeForm" value="false"/>
				<cfinvokeargument name="formName" value="lista"/>
				<cfinvokeargument name="keys" value="Gcodigo, Ncodigo,KMateria"/>
				<cfinvokeargument name="checkedcol" value="checked"/>
				<cfinvokeargument name="botones" value="Aplicar"/>
				<cfinvokeargument name="navegacion" value="#navegacion#"/>
			</cfinvoke>
			<input type="hidden" name="Mconsecutivo" value="<cfif isdefined("Form.Mconsecutivo")><cfoutput>#Form.Mconsecutivo#</cfoutput></cfif>"> 
			 <script language="JavaScript">
				if (document.lista.chk != null) {
					if (document.lista.chk.value != null) {
						if (document.lista.chk.checked) document.lista.chk.checked = true; else document.lista.chk.checked = false;
							var a = document.lista.chk.value.split("|");
							var Melectiva = a[0];
							var Nivel = a[1];
							var Materia = a[2];
							
							document.lista.Cual_Grupo.value += Melectiva ;
							document.lista.Cual_Nivel.value += Nivel ;
							document.lista.Cual_Materia.value += Materia ;
						
					} else {
						for (var counter = 0; counter < document.lista.chk.length; counter++) {
							var a = document.lista.chk[counter].value.split("|");
							var Melectiva = a[0];
							var Nivel = a[1];
							var Materia = a[2];
							
							document.lista.Cual_Grupo.value += Melectiva + ",";
							document.lista.Cual_Nivel.value += Nivel + ",";
							document.lista.Cual_Materia.value += Materia + ",";
						
						}
						if (document.lista.Cual_Grupo.value != "") {
							document.lista.Cual_Grupo.value = document.lista.Cual_Grupo.value.substring(0,document.lista.Cual_Grupo.value.length-1);
						}
						if (document.lista.Cual_Nivel.value != "") {
							document.lista.Cual_Nivel.value = document.lista.Cual_Nivel.value.substring(0,document.lista.Cual_Nivel.value.length-1);
						}
						if (document.lista.Cual_Materia.value != "") {
							document.lista.Cual_Materia.value = document.lista.Cual_Materia.value.substring(0,document.lista.Cual_Materia.value.length-1);
						}
					}
				}
			</script>
		</form>
		</td>
	</tr>
</table>

<script language="JavaScript1.2">
function Marcar(c) {
	if (document.lista.chk != null) { //existe?
		if (document.lista.chk.value != null) {// solo un check
			if (c.checked) document.lista.chk.checked = true; else document.lista.chk.checked = false;
		}
		else {
			if (c.checked) {
				for (var counter = 0; counter < document.lista.chk.length; counter++)
				{
					if ((!document.lista.chk[counter].checked) && (!document.lista.chk[counter].disabled))
						{  document.lista.chk[counter].checked = true;}
				}
				if ((counter==0)  && (!document.lista.chk.disabled)) {
					document.lista.chk.checked = true;
				}
			}
			else {
				for (var counter = 0; counter < document.lista.chk.length; counter++)
		
				{
					if ((document.lista.chk[counter].checked) && (!document.lista.chk[counter].disabled))
						{  document.lista.chk[counter].checked = false;}
				};
				if ((counter==0) && (!document.lista.chk.disabled)) {
					document.lista.chk.checked = false;
				}
			};
		}
	}
}

</script>

