
<cfif not isdefined("Form.Nuevo")>
	<cftry>
		<cfif isdefined("Form.Alta")>
			<cfquery name="ABC_PeriodoEscolar" datasource="#Session.DSN#">
				set nocount on	
				if not exists ( select 1 from PeriodoEscolar a, Nivel b
					where a.Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
					  and b.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">
					  and rtrim(ltrim(a.PEdescripcion)) = <cfqueryparam value="#Form.PEdescripcion#" cfsqltype="cf_sql_varchar">
					  and a.Ncodigo = b.Ncodigo
				)
				begin
					declare @cont int
					select @cont = isnull(max(a.PEorden),0)+10 
					from PeriodoEscolar a, Nivel b
					where a.Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
					  and b.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">
					  and a.Ncodigo = b.Ncodigo
				
					insert into PeriodoEscolar ( Ncodigo, PEdescripcion, PEorden )
					values
						(
							<cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">,
							<cfqueryparam value="#Form.PEdescripcion#" cfsqltype="cf_sql_varchar">,
							<!--- <cfqueryparam value="#Form.Ganual#" cfsqltype="cf_sql_smallint">, --->
							<cfif #len(trim(Form.PEorden))# NEQ 0 >
								<cfqueryparam value="#Form.PEorden#" cfsqltype="cf_sql_smallint">
							<cfelse>
								@cont	
							</cfif>
						)
				end
				else 
					select 1
				set nocount off
			</cfquery>
			<cfset modo="ALTA">
		<cfelseif isdefined("Form.Baja")>
			<cfquery name="ABC_PeriodoEscolar" datasource="#Session.DSN#">
				set nocount on
				delete from PeriodoEscolar
				where PEcodigo = <cfqueryparam value="#Form.PEcodigo#" cfsqltype="cf_sql_numeric">
				  and Ncodigo = <cfqueryparam value="#Form._Ncodigo#" cfsqltype="cf_sql_numeric">
				set nocount off
			</cfquery>
			<cfset modo="ALTA">
		<cfelseif isdefined("Form.Cambio")>
			<cfquery name="ABC_PeriodoEscolar" datasource="#Session.DSN#">
				set nocount on
				declare @cont int
				select @cont = isnull(max(a.PEorden),0)+10 
				from PeriodoEscolar a, SubPeriodoEscolar b
				where a.Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
				  and a.PEcodigo  = <cfqueryparam value="#Form.PEcodigo#" cfsqltype="cf_sql_numeric">
				  and a.PEcodigo = b.PEcodigo

				if not exists ( select 1 from PeriodoEscolar a, SubPeriodoEscolar b
						where a.PEcodigo  = <cfqueryparam value="#Form.PEcodigo#" cfsqltype="cf_sql_numeric">
						  and a.PEcodigo = b.PEcodigo
					)
				begin
					update PeriodoEscolar set
					PEdescripcion = <cfqueryparam value="#Form.PEdescripcion#" cfsqltype="cf_sql_varchar">,
					Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">,
					<cfif #len(trim(Form.PEorden))# NEQ 0 >
						PEorden = <cfqueryparam value="#Form.PEorden#" cfsqltype="cf_sql_smallint">
					<cfelse>
						PEorden = @cont	
					</cfif>
					where PEcodigo = <cfqueryparam value="#Form.PEcodigo#" cfsqltype="cf_sql_numeric">
					  and Ncodigo = <cfqueryparam value="#Form._Ncodigo#" cfsqltype="cf_sql_numeric">
					set nocount off
					select <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric"> as Ncodigo
				end
				else
				begin
					update PeriodoEscolar set
					PEdescripcion = <cfqueryparam value="#Form.PEdescripcion#" cfsqltype="cf_sql_varchar">,
					<cfif #len(trim(Form.PEorden))# NEQ 0 >
						PEorden = <cfqueryparam value="#Form.PEorden#" cfsqltype="cf_sql_smallint">
					<cfelse>
						PEorden = @cont	
					</cfif>
					where PEcodigo = <cfqueryparam value="#Form.PEcodigo#" cfsqltype="cf_sql_numeric">
					  and Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
					
					select <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric"> as Ncodigo
				end
				set nocount off
				</cfquery>
				<cfset modo="CAMBIO">
	</cfif>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>
</cfif>
<form action="PeriodoEscolar.cfm" method="post" name="sql">
	<input name="modo" type="hidden" value="<cfif isdefined("modo")><cfoutput>#modo#</cfoutput></cfif>">
	<input name="Ncodigo" type="hidden" value="<cfif isdefined("Form.Ncodigo")><cfoutput>#Form.Ncodigo#</cfoutput></cfif>">
	<input name="PEcodigo" type="hidden" value="<cfif isdefined("Form.PEcodigo")><cfoutput>#Form.PEcodigo#</cfoutput></cfif>">
</form>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>

