<cfif isdefined("Form.Codigo")>
	<cfset Form.EPCcodigo = Form.Codigo>
</cfif>

<cfif isdefined("Url.EPCcodigo") and not isdefined("Form.EPCcodigo")>
	<cfset Form.EPCcodigo = Url.EPCcodigo>
</cfif>
<cfif isdefined("Url.EPcodigo") and not isdefined("Form.EPcodigo")>
	<cfset Form.EPcodigo = Url.EPcodigo>
</cfif>

<cfif isdefined("Form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("Form.modo")>
		<cfset modo="ALTA">
	<cfelseif Form.modo EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>

<cfif not isdefined("Form.modoDet")>
	<cfset modoDet = "ALTA">
</cfif>

<!-- modo para el detalle -->
<cfif isdefined("Form.EPcodigo")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfset modo="ALTA">
	<cfset modoDet="ALTA">
</cfif>

<cfif isdefined("Form.EPCcodigo")>
	<cfset modoDet="CAMBIO">
<cfelse>
	<cfset modoDet="ALTA">
</cfif>  

<cfif isdefined("Form.btnNuevo")>
	<cfset modo="ALTA">
	<cfset modoDet="ALTA">
</cfif>

<!--- 1. Form Encabezado --->
<cfquery datasource="#Session.DSN#" name="rsForm">
	select convert(varchar, EPcodigo) as EPcodigo, EPnombre from EvaluacionPlan
	where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
	
	<cfif isdefined("Form.EPcodigo") AND Form.EPcodigo NEQ "" >
		and EPcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.EPcodigo#">
	</cfif>	
</cfquery>

<!--- Seccion del detalle --->
<cfif modoDet NEQ "ALTA">
	<cfquery datasource="#Session.DSN#" name="rsFormDetalle">
		Select convert(varchar, EPCcodigo) as EPCcodigo,
		       convert(varchar, EPcodigo) as EPcodigo, 
			   convert(varchar, EVTcodigo) as EVTcodigo, 
			   convert(varchar, ECcodigo) as ECcodigo,
		       EPCnombre, str(EPCporcentaje,6,2) as EPCporcentaje
		from EvaluacionPlanConcepto
		where EPcodigo= <cfqueryparam value="#form.EPcodigo#" cfsqltype="cf_sql_numeric">
		and EPCcodigo=<cfqueryparam value="#form.EPCcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>
</cfif>

<cfif modo NEQ "ALTA" and isdefined("Form.EPcodigo") and Form.EPcodigo NEQ "">
	<cfquery datasource="#Session.DSN#" name="rsFormTablaEvaluac">
		select convert(varchar, EVTcodigo) as EVTcodigo,
		       EVTnombre from EvaluacionValoresTabla	
		where CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
	</cfquery>

	<cfquery datasource="#Session.DSN#" name="rsDisponible">
		<!--- Todos menos el seleccionado --->
		select (100 - isnull(sum(EPCporcentaje),0.00)) as SumaPorc
		from EvaluacionPlanConcepto
		where EPcodigo = <cfqueryparam value="#form.EPcodigo#" cfsqltype="cf_sql_numeric">
		<cfif modoDet NEQ "ALTA" and isdefined("Form.EPCcodigo") and Form.EPCcodigo NEQ "">
			and EPCcodigo <> <cfqueryparam value="#Form.EPCcodigo#" cfsqltype="cf_sql_numeric">
		</cfif>	
	</cfquery>

	<cfquery datasource="#Session.DSN#" name="rsHayMateria">
		<!--- Existen dependencias con Materias--->
		select 1 from Materia
		where EPcodigo= <cfqueryparam value="#form.EPcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>

	<cfquery datasource="#Session.DSN#" name="rsFormConceptoEvaluac">
		select convert(varchar, ECcodigo) as ECcodigo,ECnombre 
		from EvaluacionConcepto	
		where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
			and ECcodigo not in (select ECcodigo from EvaluacionPlanConcepto
				where EPcodigo = <cfqueryparam value="#form.EPcodigo#" cfsqltype="cf_sql_numeric">
			<cfif modoDet NEQ "ALTA">
				and EPCcodigo != <cfqueryparam value="#form.EPCcodigo#" cfsqltype="cf_sql_numeric">
			</cfif>
		)
		order by ECorden
	</cfquery>
</cfif>

<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" type="text/JavaScript">

	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
	
	function irALista() {
		location.href = "listaEvaluacionPlan.cfm";
	}

	<cfif modo EQ "CAMBIO">
	function crearNuevaTablaEval(c) {
		if (c.value == "0") {
			c.selectedIndex = 0;
			location.href='tablaEvaluac.cfm?RegresarURL=PlanEvaluacion.cfm'+'<cfoutput>#URLEncodedFormat("?")#EPcodigo#URLEncodedFormat("=")##Form.EPcodigo#</cfoutput>';
		}
		else if (c.value == "") 
			c.selectedIndex = 0;
	}
	
	function crearNuevoConceptoEval(c) {
		if (c.value == "0") {
			c.selectedIndex = 0;
			location.href='EvaluacionConcepto.cfm?RegresarURL=PlanEvaluacion.cfm'+'<cfoutput>#URLEncodedFormat("?")#EPcodigo#URLEncodedFormat("=")##Form.EPcodigo#</cfoutput>';
		}
		else if (c.value == "") 
			c.selectedIndex = 0;
	}
	</cfif>
	
	function validaForm(f){
		<cfif modo NEQ "ALTA">
		f.obj.EPCporcentaje.value = qf(f.obj.EPCporcentaje.value);
		</cfif>
		return true;
	}

</script>

<form name="form1" method="post" action="SQLPlanEvaluacion.cfm" onSubmit="return validaForm(this);">
  <input name="EPcodigo" id="EPcodigo" value="<cfif modo NEQ "ALTA"><cfoutput>#Form.EPcodigo#</cfoutput></cfif>" type="hidden">
  <table width="100%" border="0">
    <tr> 
      <td <cfif modo NEQ "ALTA">colspan="2" </cfif>class="tituloMantenimiento"><cfif modo EQ "ALTA">Nuevo <cfelse>Modificar </cfif>Plan de Evaluaci&oacute;n</td>
    </tr>
    <tr> 
		<td <cfif modo NEQ "ALTA">colspan="2" </cfif>valign="top">
			<table width="100%" cellpadding="2" cellspacing="2" border="0">
				<tr> 
					<td align="right" width="30%" nowrap>Descripci&oacute;n</td>
					<td width="70%" nowrap><input name="EPnombre" type="text" id="EPnombre" size="80" maxlength="80" tabindex="1" value="<cfif modo NEQ "ALTA"><cfoutput>#rsForm.EPnombre#</cfoutput></cfif>"></td>
				</tr>
			</table>
		</td>
	</tr>
    <tr> 
      	<td <cfif modo NEQ "ALTA">colspan="2" </cfif>align="center"> 
			<cfif modo EQ "ALTA">
				<input type="submit" name="btnAgregarE" tabindex="1" value="Agregar" onClick="javascript: setBtn(this);" > 
			<cfelseif modo NEQ "ALTA">
				<input type="hidden" name="HayMateria" value="<cfoutput>#rsHayMateria.recordCount#</cfoutput>">
				<input type="submit" name="btnCambiarE" tabindex="1" value="Modificar Plan" onClick="javascript: setBtn(this); deshabilitarDetalle(); habilitarValidacion(); " >
				<input type="submit" name="btnBorrarE" tabindex="1" value="Borrar Plan" onClick="javascript: setBtn(this); deshabilitarDetalle(); deshabilitarValidacion(); return confirm('�Esta seguro(a) que desea borrar este plan de evaluaci�n ?')" > 
				<input type="submit" name="btnNuevoE" tabindex="1" value="Nuevo Plan" onClick="javascript: setBtn(this); deshabilitarDetalle(); deshabilitarValidacion(); " >
			</cfif>
			<input type="button" name="btnLista" tabindex="1" value="Lista de Planes de Evaluaci�n" onClick="javascript: irALista();">
		</td>
    </tr>
	<cfif modo NEQ "ALTA">
	<tr>
		<td colspan="2"><hr></td>
	</tr>
	<tr>
		<td width="50%" valign="top">
			<cfinvoke 
			 component="edu.Componentes.pListas"
			 method="pListaEdu"
			 returnvariable="pListaPlanEvalDet">
				<cfinvokeargument name="tabla" value="EvaluacionPlanConcepto a, EvaluacionConcepto b, EvaluacionValoresTabla c"/>
				<cfinvokeargument name="columnas" value="a.EPCcodigo as Codigo,isnull(EVTnombre, '-- Digitar Nota --') as TipoEval,ECnombre as Concepto,EPCnombre as Nombre,str(EPCporcentaje,6,2) + ' %' as PorcentajeConc"/>
				<cfinvokeargument name="desplegar" value="Concepto, TipoEval, PorcentajeConc, Nombre"/>
				<cfinvokeargument name="etiquetas" value="Concepto, Tipo de Evaluaci&oacute;n, Porcentaje, Prefijo Componente de Evaluaci&oacute;n"/>
				<cfinvokeargument name="formatos" value=""/>
				<cfinvokeargument name="filtro" value="EPcodigo = #form.EPcodigo# and a.ECcodigo=b.ECcodigo and a.EVTcodigo *= c.EVTcodigo order by b.ECorden" />
				<cfinvokeargument name="align" value="left,left,right, left"/>
				<cfinvokeargument name="ajustar" value="N"/>
				<cfinvokeargument name="irA" value="PlanEvaluacion.cfm"/>
				<cfinvokeargument name="incluyeForm" value="false"/>
				<cfinvokeargument name="debug" value="N"/>
				<cfinvokeargument name="formName" value="form1"/>
			</cfinvoke>	
			<table border="0" cellpadding="3" cellspacing="3">
			<tr>
			  <td><strong>TOTAL</strong></td>
			  <td width="70">&nbsp;</td>
			  <td width="75">&nbsp;</td>
			  <cfquery name="sumListaPlanEvalDet" datasource="#Session.DSN#">
			  set nocount on
			  select str(isnull(sum(epc.EPCporcentaje),0),6,2)+' %' as Total
			  from EvaluacionPlanConcepto epc, EvaluacionConcepto ec
			  where epc.EPcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.EPcodigo#">
			  and epc.ECcodigo = ec.ECcodigo
			  set nocount off
			  </cfquery>
			  <td style="text-align:right">
			  <cfoutput query="sumListaPlanEvalDet">
			  <strong>#Total#</strong>
			  </cfoutput>
			  </td>
			</tr>
			</table>
		</td>
		<td width="50%" valign="top" style="padding-left: 10px">
			<cfif modoDet NEQ "ALTA">
				<input type="hidden" name="EPCcodigo" id="EPCcodigo" value="<cfoutput>#Form.EPCcodigo#</cfoutput>">
			</cfif>
			<input type="hidden" name="Disponible" value="<cfoutput>#rsDisponible.SumaPorc#</cfoutput>">
			<table border="0" width="100%" cellpadding="2" cellspacing="2">
				<tr> 
				  <td align="right" nowrap>Concepto de Evaluaci&oacute;n</td>
				  <td nowrap> 
					<select name="ECcodigo" id="ECcodigo" tabindex="3" onChange="javascript: crearNuevoConceptoEval(this);">
					  <cfoutput query="rsFormConceptoEvaluac"> 
						  <option value="#rsFormConceptoEvaluac.ECcodigo#" <cfif modoDet NEQ "ALTA" and rsFormConceptoEvaluac.ECcodigo EQ rsFormDetalle.ECcodigo>selected</cfif>>#rsFormConceptoEvaluac.ECnombre#</option>
					  </cfoutput> 
					  <option value="">-------------------</option>
					  <option value="0">Crear Nuevo ...</option>
					</select>
				  </td>
				</tr>
				<tr> 
				  <td align="right" nowrap>Tipo de Evaluaci&oacute;n </td>
				  <td nowrap> 
					<select name="EVTcodigo" id="EVTcodigo" tabindex="3" onChange="javascript: crearNuevaTablaEval(this);">
					  <option value="-1">-- Digitar Nota --</option>
					  <cfoutput query="rsFormTablaEvaluac"> 
						<option value="#EVTcodigo#" <cfif modoDet NEQ "ALTA" and rsFormTablaEvaluac.EVTcodigo EQ rsFormDetalle.EVTcodigo>selected</cfif>>Usar 
						Tabla: #EVTnombre#</option>
					  </cfoutput> 
					  <option value="">-------------------</option>
					  <option value="0">Crear Nueva Tabla ...</option>
					</select>
				  </td>
				</tr>
				<tr> 
				  <td align="right" nowrap>Porcentaje</td>
				  <td nowrap> 
					<input name="EPCporcentaje" type="text" id="EPCporcentaje" tabindex="3" style="text-align: right;"  onFocus="javascript:this.value=qf(this); this.select();" onBlur="javascript:fm(this,2) "  onKeyUp="javascript:if(snumber(this,event,2)){ if(Key(event)=='13') {this.blur();}}" value="<cfif modoDet NEQ "ALTA"><cfoutput>#rsFormDetalle.EPCporcentaje#</cfoutput></cfif>" size="10" maxlength="6">
					% </td>
				</tr>
				<tr> 
				  <td align="right" nowrap>Prefijo Componente de Evaluaci&oacute;n</td>
				  <td nowrap> 
					<input name="EPCnombre" type="text" id="EPCnombre" tabindex="3" size="30" maxlength="80" value="<cfif modoDet NEQ "ALTA"><cfoutput>#rsFormDetalle.EPCnombre#</cfoutput></cfif>">
				  </td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<cfif modoDet EQ "ALTA">
							<input type="submit" name="btnAgregarD" tabindex="4" value="Agregar Concepto" onClick="javascript: setBtn(this); habilitarDetalle(); habilitarValidacion(); " > 
						<cfelseif modoDet NEQ "ALTA">
							<input type="submit" name="btnCambiarD" tabindex="4" value="Modificar Concepto" onClick="javascript: setBtn(this); habilitarDetalle(); habilitarValidacion();" > 
							<input type="submit" name="btnBorrarD" tabindex="4" value="Borrar Concepto" onClick="javascript: setBtn(this); deshabilitarDetalle(); deshabilitarValidacion(); return confirm('�Esta seguro(a) que desea borrar este concepto?')" > 
							<input type="submit" name="btnNuevoD" tabindex="4" value="Nuevo Concepto" onClick="javascript: setBtn(this); deshabilitarDetalle(); deshabilitarValidacion();" >	
						</cfif>
					</td>
				</tr>
			</table>
		</td>
    </tr>
	</cfif>
  </table>
</form>

<script language="JavaScript">

	function deshabilitarValidacion() {
		objForm.EPnombre.required = false;
	}
	
	function habilitarValidacion() {
		objForm.EPnombre.required = true;
	}	
	
	function deshabilitarDetalle() {
		objForm.ECcodigo.required = false;
		objForm.EVTcodigo.required = false;
		objForm.EPCporcentaje.required = false;
		objForm.EPCnombre.required = false;
	}

	function habilitarDetalle() {
		objForm.ECcodigo.required = true;
		objForm.EVTcodigo.required = true;
		objForm.EPCporcentaje.required = true;
		objForm.EPCnombre.required = true;
	}

	function __isPorcentaje() {	
		if(btnSelected("btnAgregarD") || btnSelected("btnCambiarD")) {
			// Valida que el porcentaje se encuentre entre el rango permitido
			if (new Number(qf(this.obj.form.Disponible.value)) == 0 && new Number(qf(this.value)) > 0) {
				this.error = "El porcentaje solamente puede ser 0";
				this.obj.focus();
			} else if (new Number(qf(this.value)) < 0 || new Number(qf(this.value)) > new Number(qf(this.obj.form.Disponible.value))) {
				this.error = "El porcentaje no puede ser menor a 0 ni mayor que " + this.obj.form.Disponible.value;
				this.obj.focus();
			}
		}
	}
	
	function __isDependencias() {
		if (btnSelected("btnBorrarE")) {
			// Valida que la Tabla de Evaluacion no tenga dependencias con otros.
			var msg = "";
			if (new Number(this.obj.form.HayMateria.value) > 0) {
				msg = msg + "materias";
			}
			if (msg != "")
			{
				this.error = "Usted no puede eliminar el plan de evaluaci�n '" + this.obj.form.EPnombre.value + "' porque �ste tiene asociado: " + msg + ".";
				this.obj.form.EPnombre.focus();
			}
		}
	}

	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isDependencias", __isDependencias);
	_addValidator("isPorcentaje", __isPorcentaje);
	objForm = new qForm("form1");

	<cfif modo EQ "ALTA">
		objForm.EPnombre.required = true;
		objForm.EPnombre.description = "Descripci�n";
	<cfelseif modo NEQ "ALTA">
		objForm.EPnombre.required = true;
		objForm.EPnombre.description = "Descripci�n";
		objForm.EPnombre.validateDependencias();
		<cfif modoDet EQ "ALTA">
			objForm.ECcodigo.required = true;
			objForm.ECcodigo.description = "Concepto de Evaluaci�n";
			objForm.EVTcodigo.required = true;
			objForm.EVTcodigo.description = "Tipo de Evaluaci�n";
			objForm.EPCporcentaje.required = true;
			objForm.EPCporcentaje.description = "Porcentaje";
			objForm.EPCporcentaje.validatePorcentaje();
			objForm.EPCnombre.required = true;
			objForm.EPCnombre.description = "Prefijo Componente de Evaluaci�n";
		<cfelseif modoDet NEQ "ALTA">
			objForm.ECcodigo.required = true;
			objForm.ECcodigo.description = "Concepto de Evaluaci�n";
			objForm.EVTcodigo.required = true;
			objForm.EVTcodigo.description = "Tipo de Evaluaci�n";
			objForm.EPCporcentaje.required = true;
			objForm.EPCporcentaje.description = "Porcentaje";
			objForm.EPCporcentaje.validatePorcentaje();
			objForm.EPCnombre.required = true;
			objForm.EPCnombre.description = "Prefijo Componente de Evaluaci�n";
		</cfif>		
	</cfif>		
</script>
