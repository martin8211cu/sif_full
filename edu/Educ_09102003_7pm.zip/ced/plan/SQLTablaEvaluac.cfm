<cfset action = "tablaEvaluac.cfm">

<cfif not isdefined("form.btnNuevoD") and  not isdefined("form.btnNuevoE")>
	<cftry>
		<cfquery name="ABC_TablaEvaluac" datasource="#Session.DSN#">
			<!--- Caso 1: Agregar Encabezado --->
			set nocount on
			<cfif isdefined("Form.btnAgregarE")>
				insert EvaluacionValoresTabla (CEcodigo, EVTnombre,EVTtipo)
					values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
							<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.EVTnombre#">,
							<cfqueryparam cfsqltype="cf_sql_char" value="#form.EVTtipo#">
								)
				select @@identity as id
				<cfset modo="CAMBIO">
				
			<!--- Caso 1.1: Cambia Encabezado --->
			<cfelseif isdefined("Form.btnCambiarE")>
				update EvaluacionValoresTabla
				set EVTnombre = <cfqueryparam value="#form.EVTnombre#" cfsqltype="cf_sql_varchar">,
					EVTtipo=<cfqueryparam value="#form.EVTtipo#" cfsqltype="cf_sql_char">
				where EVTcodigo = <cfqueryparam value="#form.EVTcodigo#" cfsqltype="cf_sql_numeric">
				<cfset modo="CAMBIO">
							
			<!--- Caso 2: Borrar un Encabezado de Tablas de Evaluacion --->
			<cfelseif isdefined("Form.btnBorrarE")>			
				<cfif isdefined("Form.EVTcodigo") AND Form.EVTcodigo NEQ "">
					delete EvaluacionValores
					where EVTcodigo=<cfqueryparam value="#form.EVTcodigo#" cfsqltype="cf_sql_numeric">
					
					delete EvaluacionValoresTabla 
					where EVTcodigo=<cfqueryparam value="#form.EVTcodigo#" cfsqltype="cf_sql_numeric">				
					<cfset modo="ALTA">									
				</cfif>
				<cfset modo="ALTA">
				<cfset action = "listaTablaEvaluac.cfm">

			<!--- Caso 3: Agregar Detalle de Tablas de Evaluacion y opcionalmente modificar el encabezado --->
			<cfelseif isdefined("Form.btnAgregarD")>
				insert EvaluacionValores (EVTcodigo, EVvalor, EVdescripcion, EVequivalencia)
				values (<cfqueryparam value="#form.EVTcodigo#" cfsqltype="cf_sql_numeric">,
						<cfqueryparam value="#form.EVvalor#" cfsqltype="cf_sql_varchar">,
						<cfqueryparam value="#form.EVdescripcion#" cfsqltype="cf_sql_varchar">, 
						<cfqueryparam value="#form.EVequivalencia#" cfsqltype="cf_sql_numeric">)
			
				<!--- Modificar Encabezado --->
				update EvaluacionValoresTabla
				set EVTnombre = <cfqueryparam value="#form.EVTnombre#" cfsqltype="cf_sql_varchar">,
					EVTtipo=<cfqueryparam value="#form.EVTtipo#" cfsqltype="cf_sql_char">
				where EVTcodigo = <cfqueryparam value="#form.EVTcodigo#" cfsqltype="cf_sql_numeric">
				<cfset modo="CAMBIO">
				
			<!--- Caso 4: Modificar Detalle de Tabla de Evaluacion y modificar el encabezado --->			
			<cfelseif isdefined("Form.btnCambiarD")>
				update EvaluacionValores
				set EVdescripcion   = <cfqueryparam value="#form.EVdescripcion#" cfsqltype="cf_sql_varchar">, 
					EVequivalencia  = <cfqueryparam value="#form.EVequivalencia#" cfsqltype="cf_sql_numeric">
				where EVTcodigo     = <cfqueryparam value="#form.EVTcodigo#"    cfsqltype="cf_sql_numeric">
				  and EVvalor   	= <cfqueryparam value="#form.EVvalor#" cfsqltype="cf_sql_varchar">

				<!--- Modificar Encabezado --->
				update EvaluacionValoresTabla
				set EVTnombre = <cfqueryparam value="#form.EVTnombre#" cfsqltype="cf_sql_varchar">,
					EVTtipo=<cfqueryparam value="#form.EVTtipo#" cfsqltype="cf_sql_char">
				where EVTcodigo = <cfqueryparam value="#form.EVTcodigo#" cfsqltype="cf_sql_numeric">
				<cfset modo="CAMBIO">				
				
			<!--- Caso 5: Borrar detalle de tabla de Evaluacion --->
			<cfelseif isdefined("Form.btnBorrarD")>
				delete EvaluacionValores
				where EVTcodigo=<cfqueryparam value="#form.EVTcodigo#" cfsqltype="cf_sql_numeric">
				and EVvalor=<cfqueryparam value="#form.EVvalor#" cfsqltype="cf_sql_varchar">				
				<cfset modo="CAMBIO">								
			</cfif>					
			set nocount off				
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>		
<cfelse>
	<cfif isdefined("form.btnNuevoE")>
		<cfset modo = "ALTA" >
	<cfelse>	
		<cfset modo = "CAMBIO" >
	</cfif>
</cfif>

<!--- Actualizacion de los montos de minimo y maximo solo en ALTA o CAMBIO de Detalle --->
<cftry>
	<cfif isdefined("Form.btnCambiarE") or isdefined("Form.btnAgregarD") or isdefined("Form.btnCambiarD") or isdefined("Form.btnBorrarD")>
		<cfquery name="ABC_TablaEvaluacMinMax" datasource="#Session.DSN#">
			set nocount on
			<cfif form.EVTtipo EQ "1"> <!--- Hacia arriba --->
				update EvaluacionValores
				   set EVminimo = (
						  select convert(numeric(6,3),isnull(max(Ant.EVequivalencia)+0.001,0))
							from EvaluacionValores Ant
						   where Ant.EVTcodigo = ev.EVTcodigo
							 and Ant.EVequivalencia < ev.EVequivalencia
					   ),
					   EVmaximo = EVequivalencia
				  from EvaluacionValores ev
				 where ev.EVTcodigo      = <cfqueryparam value="#form.EVTcodigo#"    cfsqltype="cf_sql_numeric">
			
				update EvaluacionValores
				   set EVmaximo = 100
				   from EvaluacionValores ev
				  where ev.EVTcodigo      = <cfqueryparam value="#form.EVTcodigo#"    cfsqltype="cf_sql_numeric">
					and ev.EVequivalencia = (
						 select max(May.EVequivalencia)
						   from EvaluacionValores May
						  where May.EVTcodigo = ev.EVTcodigo
						)			
			<cfelseif form.EVTtipo EQ "2"> <!--- Hacia Abajo --->
				update EvaluacionValores
				   set EVmaximo = (
						 select convert(numeric(6,3),isnull(min(Ant.EVequivalencia)-0.001,100))
						   from EvaluacionValores Ant
						  where Ant.EVTcodigo = ev.EVTcodigo
							and Ant.EVequivalencia > ev.EVequivalencia
					   ),
					   EVminimo = EVequivalencia
				   from EvaluacionValores ev
				  where ev.EVTcodigo      = <cfqueryparam value="#form.EVTcodigo#"    cfsqltype="cf_sql_numeric">

				update EvaluacionValores
				   set EVminimo = 0
				   from EvaluacionValores ev
				  where ev.EVTcodigo      = <cfqueryparam value="#form.EVTcodigo#"    cfsqltype="cf_sql_numeric">
					and ev.EVequivalencia = (
						 select min(May.EVequivalencia)
						   from EvaluacionValores May
						  where May.EVTcodigo = ev.EVTcodigo
						)	
			<cfelseif form.EVTtipo EQ "0"> <!--- El mas cercano --->
				update EvaluacionValores
				  set EVminimo = (
						 select convert(numeric(6,3),isnull((max(Ant.EVequivalencia)+ev.EVequivalencia)/2,0))
						   from EvaluacionValores Ant
						  where Ant.EVTcodigo = ev.EVTcodigo
							and Ant.EVequivalencia < ev.EVequivalencia
					  ),
					  EVmaximo = (
						 select convert(numeric(6,3),isnull((min(Ant.EVequivalencia)+ev.EVequivalencia)/2-0.0001,100))
						   from EvaluacionValores Ant
						  where Ant.EVTcodigo = ev.EVTcodigo
							and Ant.EVequivalencia > ev.EVequivalencia
					  )
				  from EvaluacionValores ev
				 where ev.EVTcodigo      = <cfqueryparam value="#form.EVTcodigo#"    cfsqltype="cf_sql_numeric">
			</cfif>
			set nocount off
		</cfquery>
	</cfif>
<cfcatch type="any">
	<cfinclude template="../../errorPages/BDerror.cfm">
	<cfabort>
</cfcatch>
</cftry>
		
<cfif isdefined("Form.btnAgregarE")>
	<cfset Form.EVTcodigo = #ABC_TablaEvaluac.id#>
</cfif>

<cfoutput>
<form action="#action#" method="post" name="sql">
	<input name="modo"   type="hidden" value="<cfif isdefined("modo")>#modo#</cfif>">
	<input name="EVTcodigo" type="hidden" value="<cfif modo EQ "CAMBIO">#Form.EVTcodigo#</cfif>">
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")>#Form.Pagina#</cfif>">
</form>
</cfoutput>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>