<cfset dupla = #ListToArray(Form.ConceptosEval, ';')#>
<cfif not isdefined("Form.Nuevo")>
	<cftry>
		<cfif isdefined("Form.Alta")>
			<cfquery name="ABC_Nivel" datasource="#Session.DSN#">
			set nocount on
				declare @cont numeric, @id numeric
				select @cont = isnull(max(c.Morden),0)+10 from Nivel a, Grado b, Materia c
				where a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				  and c.Ncodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Ncodigo#">
				  and c.Gcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Gcodigo#">
				  and a.Ncodigo = b.Ncodigo 
				  and b.Ncodigo = c.Ncodigo 
				  and b.Gcodigo = c.Gcodigo 
				insert into Materia (
									<cfif isdefined("Form.Melectiva") and form.Melectiva NEQ 'S'> 
										Gcodigo, 
									</cfif>
									Ncodigo, MTcodigo, EVTcodigo, Mcodigo, Mnombre, Mobservaciones, Mreglamentos,
								   	Mhoras, Mcreditos, Mtipoevaluacion, Melectiva, Morden 
									<cfif isdefined("Form.EPcodigo") and (form.Melectiva EQ 'R' or form.Melectiva EQ 'S' )> 
										,EPcodigo
									</cfif>
									, Mactiva
									)
				values(
					<cfif isdefined("Form.Melectiva") and form.Melectiva NEQ 'S'> 
						<cfqueryparam value="#Form.Gcodigo#" cfsqltype="cf_sql_numeric">, 
					</cfif>
					<cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">,
					<cfqueryparam value="#Form.MTcodigo#" cfsqltype="cf_sql_numeric">,
					<cfif Form.Mtipoevaluacion NEQ "-1">
						<cfqueryparam value="#Form.Mtipoevaluacion#" cfsqltype="cf_sql_numeric">,
					<cfelse>
						null,	
					</cfif>
					<cfqueryparam value="#Form.Mcodigo#" cfsqltype="cf_sql_varchar">,
					<cfqueryparam value="#Form.Mnombre#" cfsqltype="cf_sql_varchar">,
					<cfqueryparam value="#Form.Mobservaciones#" cfsqltype="cf_sql_varchar">,
					<cfqueryparam value="#Form.Mreglamentos#"  cfsqltype="cf_sql_varchar">,
					<cfqueryparam value="#Form.Mhoras#" cfsqltype="cf_sql_smallint">,
					<cfqueryparam value="#Form.Mcreditos#" cfsqltype="cf_sql_smallint">,
					<cfif Form.Mtipoevaluacion NEQ "-1">
						<cfqueryparam value="1" cfsqltype="cf_sql_char">,
					<cfelse>
						<cfqueryparam value="0" cfsqltype="cf_sql_char">,
					</cfif>
					<cfqueryparam value="#Form.Melectiva#" cfsqltype="cf_sql_char">,
					<cfif #len(trim(Form.Morden))# NEQ 0>
						<cfqueryparam value="#Form.Morden#" cfsqltype="cf_sql_numeric">
					<cfelse>
						@cont	
					</cfif>
					<cfif isdefined("Form.EPcodigo") and (form.Melectiva EQ 'R' or form.Melectiva EQ 'S' )> 
						,<cfqueryparam value="#Form.EPcodigo#" cfsqltype="cf_sql_numeric">
					</cfif>
					,<cfqueryparam value="#Form.Mactiva#" cfsqltype="cf_sql_bit">
					)
					
				if @@rowcount = 1
				begin
					select @id = @@identity
					
					insert EvaluacionConceptoMateria(Mconsecutivo, PEcodigo, ECcodigo, ECMporcentaje)
					select a.Mconsecutivo, c.PEcodigo, b.ECcodigo, b.EPCporcentaje
					from Materia a, EvaluacionPlanConcepto b, PeriodoEvaluacion c
					where a.Mconsecutivo = @id
					and (a.Melectiva = 'R' or a.Melectiva = 'S')
					and a.EPcodigo = b.EPcodigo
					and a.Ncodigo = c.Ncodigo

					<!---					
					<cfloop index="i" from="1" to="#ArrayLen(dupla)#">
						<cfset conceptos = #ListToArray(dupla[i], ',')#>
						<cfif Val(conceptos[2]) GT 1>
							<cfloop index="k" from="1" to="#Val(conceptos[2])-1#">
								insert EvaluacionMateria(Mconsecutivo, PEcodigo, ECcodigo, EVTcodigo, EMporcentaje, EMnombre)
								select a.Mconsecutivo, c.PEcodigo, b.ECcodigo, b.EVTcodigo, convert(numeric(6,2),(100 / (<cfqueryparam cfsqltype="cf_sql_numeric" value="#conceptos[2]#"> * 1.0))) as Porcentaje, b.EPCnombre + ' #k#' as Nombre
								from Materia a, EvaluacionPlanConcepto b, PeriodoEvaluacion c
								where a.Mconsecutivo = @id
								and a.EPcodigo = b.EPcodigo
								and a.Ncodigo = c.Ncodigo
								and b.ECcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#conceptos[1]#">
							</cfloop>
							insert EvaluacionMateria(Mconsecutivo, PEcodigo, ECcodigo, EVTcodigo, EMporcentaje, EMnombre)
							select a.Mconsecutivo, c.PEcodigo, b.ECcodigo, b.EVTcodigo, convert(numeric(6,2),(100 - (select sum(EMporcentaje) from EvaluacionMateria where Mconsecutivo = @id and ECcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#conceptos[1]#"> and PEcodigo = c.PEcodigo))) as Porcentaje, b.EPCnombre + ' #conceptos[2]#' as Nombre
							from Materia a, EvaluacionPlanConcepto b, PeriodoEvaluacion c
							where a.Mconsecutivo = @id
							and a.EPcodigo = b.EPcodigo
							and a.Ncodigo = c.Ncodigo
							and b.ECcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#conceptos[1]#">
						<cfelse>
							insert EvaluacionMateria(Mconsecutivo, PEcodigo, ECcodigo, EVTcodigo, EMporcentaje, EMnombre)
							select a.Mconsecutivo, c.PEcodigo, b.ECcodigo, b.EVTcodigo, 100, b.EPCnombre
							from Materia a, EvaluacionPlanConcepto b, PeriodoEvaluacion c
							where a.Mconsecutivo = @id
							and a.EPcodigo = b.EPcodigo
							and a.Ncodigo = c.Ncodigo
							and b.ECcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#conceptos[1]#">
						</cfif>
					</cfloop>
					--->
				end
				set nocount off
			</cfquery>
			<cfset modo="ALTA">
		<cfelseif isdefined("Form.Baja")>
			<cfquery name="ABC_Nivel" datasource="#Session.DSN#">
				set nocount on
				if not exists (select 1 from Curso 
								where Mconsecutivo =  <cfqueryparam value="#Form.Mconsecutivo#" cfsqltype="cf_sql_numeric">
				)
				begin
					delete from MateriaElectiva
					where (Mconsecutivo = <cfqueryparam value="#Form.Mconsecutivo#" cfsqltype="cf_sql_numeric">
					or Melectiva = <cfqueryparam value="#Form.Mconsecutivo#" cfsqltype="cf_sql_numeric">)
					
					delete from EvaluacionMateria
					where Mconsecutivo = <cfqueryparam value="#Form.Mconsecutivo#" cfsqltype="cf_sql_numeric">

					delete from EvaluacionConceptoMateria
					where Mconsecutivo = <cfqueryparam value="#Form.Mconsecutivo#" cfsqltype="cf_sql_numeric">
				
					delete from GradoSustitutivas
					where Mconsecutivo = <cfqueryparam value="#Form.Mconsecutivo#" cfsqltype="cf_sql_numeric">

					delete from Materia
					where Mconsecutivo = <cfqueryparam value="#Form.Mconsecutivo#" cfsqltype="cf_sql_numeric">
				end
				else 
					select 1
				<cfset modo="ALTA">
			set nocount off
			</cfquery>
		<cfelseif isdefined("Form.Cambio")>
			<cfquery name="ABC_Nivel" datasource="#Session.DSN#">
			set nocount on
				declare @cont numeric
				select @cont = isnull(max(c.Morden),0)+10 from Nivel a, Grado b, Materia c
				where a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				  and c.Ncodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Ncodigo#">
				  and c.Gcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Gcodigo#">
				  and a.Ncodigo = b.Ncodigo 
				  and b.Ncodigo = c.Ncodigo 
				  and b.Gcodigo = c.Gcodigo 
				  and c.Mconsecutivo != <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Mconsecutivo#">
				update Materia set
				    <cfif isdefined("Form.Melectiva") and form.Melectiva NEQ 'S'>
						Gcodigo 		= <cfqueryparam value="#Form.Gcodigo#" cfsqltype="cf_sql_numeric">, 
					<cfelse>
						Gcodigo         = null, 
					</cfif>
					<!--- Ncodigo 		= <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">,   --->
					MTcodigo 		= <cfqueryparam value="#Form.MTcodigo#" cfsqltype="cf_sql_numeric">, 
					<cfif Form.Mtipoevaluacion NEQ "-1">
						EVTcodigo 	= <cfqueryparam value="#Form.Mtipoevaluacion#" cfsqltype="cf_sql_numeric">,
					<cfelse>
						EVTcodigo 	= null,	
					</cfif>
					Mnombre 		= <cfqueryparam value="#Form.Mnombre#" cfsqltype="cf_sql_varchar">,
					Mobservaciones 	= <cfqueryparam value="#Form.Mobservaciones#" cfsqltype="cf_sql_varchar">, 
					Mreglamentos 	= <cfqueryparam value="#Form.Mreglamentos#"  cfsqltype="cf_sql_varchar">,
					Mhoras			= <cfqueryparam value="#Form.Mhoras#" cfsqltype="cf_sql_smallint">,
					Mcreditos		= <cfqueryparam value="#Form.Mcreditos#" cfsqltype="cf_sql_smallint">,
					<cfif Form.Mtipoevaluacion NEQ "-1">
						Mtipoevaluacion = <cfqueryparam value="1" cfsqltype="cf_sql_char">,
					<cfelse>
						Mtipoevaluacion = <cfqueryparam value="0" cfsqltype="cf_sql_char">,
					</cfif>
					Melectiva 		= <cfqueryparam value="#Form.Melectiva#"  cfsqltype="cf_sql_char">,
					<cfif #len(trim(Form.Morden))# NEQ 0>
						Morden      = <cfqueryparam value="#Form.Morden#" cfsqltype="cf_sql_numeric">
					<cfelse>
						Morden      = @cont	
					</cfif>
					,Mactiva 		= <cfqueryparam value="#Form.Mactiva#"  cfsqltype="cf_sql_bit">
					where Mconsecutivo = <cfqueryparam value="#Form.Mconsecutivo#" cfsqltype="cf_sql_numeric">
			set nocount off
			</cfquery>
		    <cfset modo="CAMBIO">
		</cfif>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>
</cfif>
<form action="Materias.cfm" method="post" name="sql">
	<input name="modo" type="hidden" value="<cfif isdefined("modo")><cfoutput>#modo#</cfoutput></cfif>">
	<cfif isdefined("modo") and modo NEQ "ALTA">
		<input name="Mconsecutivo" type="hidden" value="<cfif isdefined("Form.Mconsecutivo")><cfoutput>#Form.Mconsecutivo#</cfoutput></cfif>">
	</cfif>
	<cfif isdefined("Form.Buscar")>
		<input name="FMcodigo" type="hidden" value="<cfif isdefined("Form.Mcodigo") and Len(Trim(Form.Mcodigo)) NEQ 0><cfoutput>#Form.Mcodigo#</cfoutput></cfif>">
		<input name="FMnombre" type="hidden" value="<cfif isdefined("Form.Mnombre") and Len(Trim(Form.Mnombre)) NEQ 0><cfoutput>#Form.Mnombre#</cfoutput></cfif>">
		<input name="FNcodigo" type="hidden" value="<cfif isdefined("Form.Ncodigo") and Len(Trim(Form.Ncodigo)) NEQ 0><cfoutput>#Form.Ncodigo#</cfoutput><cfelse><cfoutput>-1</cfoutput></cfif>">
		<cfif isdefined("Form.Melectiva") and Len(Trim(Form.Melectiva)) NEQ 0 and Form.Melectiva EQ 'S'>
			<input name="FGcodigo" type="hidden" value="-1">
		<cfelse>
			<input name="FGcodigo" type="hidden" value="<cfif isdefined("Form.Gcodigo") and Len(Trim(Form.Gcodigo)) NEQ 0><cfoutput>#Form.Gcodigo#</cfoutput><cfelse><cfoutput>-1</cfoutput></cfif>">
		</cfif>
		<input name="FMTcodigo" type="hidden" value="<cfif isdefined("Form.MTcodigo") and Len(Trim(Form.MTcodigo)) NEQ 0><cfoutput>#Form.MTcodigo#</cfoutput></cfif>">
		<input name="FMelectiva" type="hidden" value="<cfif isdefined("Form.Melectiva") and Len(Trim(Form.Melectiva)) NEQ 0><cfoutput>#Form.Melectiva#</cfoutput></cfif>">
	<cfelse>
	  <cfif isdefined("Form.FNcodigo")>
		 <input type="hidden" name="FNcodigo" value="<cfoutput>#Form.FNcodigo#</cfoutput>">
	  </cfif>
	  <cfif isdefined("Form.FGcodigo")>
		 <input type="hidden" name="FGcodigo" value="<cfoutput>#Form.FGcodigo#</cfoutput>">
	  </cfif>
	  <cfif isdefined("Form.FMcodigo")>
		 <input type="hidden" name="FMcodigo" value="<cfoutput>#Form.FMcodigo#</cfoutput>">
	  </cfif>
	  <cfif isdefined("Form.FMTcodigo")>
		 <input type="hidden" name="FMTcodigo" value="<cfoutput>#Form.FMTcodigo#</cfoutput>">
	  </cfif>
	  <cfif isdefined("Form.FMnombre")>
		 <input type="hidden" name="FMnombre" value="<cfoutput>#Form.FMnombre#</cfoutput>">
	  </cfif>
	  <cfif isdefined("Form.FMelectiva")>
		 <input type="hidden" name="FMelectiva" value="<cfoutput>#Form.FMelectiva#</cfoutput>">
	  </cfif>
	</cfif>
</form>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>
