<cfif isdefined("Form.SubPeriodo")>
	<cfset Form.SPEcodigo = Form.SubPeriodo>
</cfif>
<cfif isdefined("Form.PerCod")>
	<cfset Form.PEcodigo = Form.PerCod>
</cfif>
<cfif isdefined("Form.Evaluacion")>
	<cfset Form.PEevaluacion = Form.Evaluacion>
</cfif>

<cfif isdefined("Url.SubPeriodo") and not isdefined("Form.SubPeriodo")>
	<cfset Form.SPEcodigo = Url.SubPeriodo>
</cfif>
<cfif isdefined("Url.PerCod") and not isdefined("Form.PerCod")>
	<cfset Form.PEcodigo = Url.PerCod>
</cfif>

<cfif isdefined("Form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("Form.modo")>
		<cfset modo="ALTA">
	<cfelseif Form.modo EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>

<cfif not isdefined("Form.modoDet")>
	<cfset modoDet = "ALTA">
</cfif>


<cfif isdefined("Form.PEcodigo") and isdefined("Form.SPEcodigo")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfset modo="ALTA">
	<cfset modoDet="ALTA">
</cfif>

<cfif isdefined("Form.PEcodigo") and isdefined("Form.SPEcodigo") and isdefined("Form.PEevaluacion")>
	<cfset modoDet="CAMBIO">
<cfelse>
	<cfset modoDet="ALTA">
</cfif>

<cfif isdefined("Form.btnNuevo") >
	<cfset modo="ALTA">
	<cfset modoDet="ALTA">
</cfif>

<!--- Consultas --->
<cfif modo EQ "ALTA">
	<cfquery datasource="#Session.DSN#" name="rsPeriodoEscolar">	
			select convert(varchar,b.PEcodigo) as PEcodigo, rtrim(c.Ndescripcion) + ' : ' + rtrim(b.PEdescripcion) as PEdescripcion
			from PeriodoEscolar b, Nivel c 
			where c.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
			  and b.Ncodigo = c.Ncodigo
	</cfquery>
</cfif>

<cfif modo NEQ "ALTA">
	<!--- 1. Form Encabezado --->
	<cfquery datasource="#Session.DSN#" name="rsSubPeriodoEscolar">
		select convert(varchar,a.SPEcodigo) as SPEcodigo, convert(varchar,a.PEcodigo) as PEcodigo, a.SPEorden, a.SPEdescripcion,
		convert(varchar,a.SPEfechafin,103) as SPEfechafin, convert(varchar,a.SPEfechainicio,103) as SPEfechainicio, c.Ndescripcion,
		b.Ncodigo, b.PEdescripcion
		from SubPeriodoEscolar a, PeriodoEscolar b, Nivel c 
		where c.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
		  and a.PEcodigo = b.PEcodigo 
		  and b.Ncodigo = c.Ncodigo
		  and a.PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
		  and a.SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.SPEcodigo#">
	 </cfquery>

	<cfquery datasource="#Session.DSN#" name="rsHayGrupo">
		<!--- Existen dependencias con Curso--->
		select 1 from Grupo a,  SubPeriodoEscolar b
		where a.SPEcodigo = <cfqueryparam value="#form.SPEcodigo#" cfsqltype="cf_sql_numeric">
		  and a.PEcodigo = <cfqueryparam value="#form.PEcodigo#" cfsqltype="cf_sql_numeric">
		  and a.PEcodigo  = b.PEcodigo
		  and a.SPEcodigo = b.SPEcodigo
	</cfquery>

	<cfquery datasource="#Session.DSN#" name="rsHayCurso">
		<!--- Existen dependencias con Curso--->
		select 1 from Curso  a,  SubPeriodoEscolar b
		where a.SPEcodigo = <cfqueryparam value="#form.SPEcodigo#" cfsqltype="cf_sql_numeric">
		  and a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
		  and a.SPEcodigo = b.SPEcodigo
	</cfquery> 

	<cfif modoDet NEQ "ALTA">
		<cfquery datasource="#Session.DSN#" name="rsPeriodoOcurrencia">
			select convert(varchar, c.PEcodigo) as PEcodigo,
				   c.PEdescripcion,
				   convert(varchar,b.POfechainicio,103) as POfechainicio, 
				   convert(varchar, b.POfechafin,103) as POfechafin, 
				   b.POvigente
			from SubPeriodoEscolar a, PeriodoOcurrencia b, PeriodoEvaluacion c
			where a.PEcodigo = b.PEcodigo
			  and b.PEcodigo =<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
			  and b.SPEcodigo =<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.SPEcodigo#">
			  and b.PEevaluacion =<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEevaluacion#">
			  and b.PEevaluacion = c.PEcodigo
		</cfquery>
	
	<cfelseif modoDet EQ "ALTA">
		<cfquery datasource="#Session.DSN#" name="rsPeriodoEvaluacion">	
			select convert(varchar,c.PEcodigo) as PEcodigo, c.PEdescripcion
			from PeriodoEscolar a, Nivel b, PeriodoEvaluacion c
			where a.PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
			and a.Ncodigo = b.Ncodigo
			and b.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
			and b.Ncodigo = c.Ncodigo
			and c.PEcodigo not in (select PEevaluacion from PeriodoOcurrencia 
								   where PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
								   and SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.SPEcodigo#"> 
								   <cfif modoDet NEQ "ALTA">
								   and PEevaluacion != <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEevaluacion#"> 
								   </cfif>
								  )
		</cfquery>
	</cfif>

</cfif>

<link href="../../css/estilos.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" src="../../js/calendar.js"></script>
<script language="JavaScript" type="text/JavaScript">
	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
	
	function crearNuevoPeriodo(c) {
		if (c.value == "0") {
			c.selectedIndex = 0;
			location.href='PeriodoEscolar.cfm?RegresarURL=SubPeriodoEscolar.cfm';
		}
		else if (c.value == "") 
			c.selectedIndex = 0;
	}

	<cfif modo NEQ "ALTA">
	function crearNuevoPeriodoEvaluacion(c) {
		if (c.value == "0") {
			c.selectedIndex = 0;
			location.href='PeriodoEvaluacion.cfm?RegresarURL=SubPeriodoEscolar.cfm'+'<cfoutput>#URLEncodedFormat("?")#SubPeriodo#URLEncodedFormat("=")##Form.SPEcodigo#</cfoutput><cfoutput>#URLEncodedFormat("&")#PerCod#URLEncodedFormat("=")##Form.PEcodigo#</cfoutput>';
		}
		else if (c.value == "") 
			c.selectedIndex = 0;
	}
	</cfif>
	
	function irALista() {
		location.href = "listaSubPeriodoEscolar.cfm";
	}
</script>

<form name="form1" method="post" action="SQLSubPeriodoEscolar.cfm">
    <input name="SPEcodigo" id="SPEcodigo" value="<cfif modo NEQ "ALTA"><cfoutput>#Form.SPEcodigo#</cfoutput></cfif>" type="hidden">
  <table width="100%" border="0">
    <tr> 
      <td <cfif modo NEQ "ALTA">colspan="2" </cfif>class="tituloMantenimiento">
	  	<cfif modo EQ "ALTA">
			Nuevo <cfelse>Modificar 
		</cfif>
        Curso Lectivo</td>
    </tr>
    <tr> 
		
      <td align="center" <cfif modo NEQ "ALTA">colspan="2" </cfif>valign="top"> 
        <table width="50%" cellpadding="2" cellspacing="2" border="0">
          <tr> 
            <td width="16%" align="center" nowrap>Descripci&oacute;n:</td>
            <td width="52%" nowrap><input name="SPEdescripcion" type="text" id="SPEdescripcion" size="40" tabindex="1" maxlength="100" onFocus="javascript:this.select();" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsSubPeriodoEscolar.SPEdescripcion#</cfoutput></cfif>"></td>
            <td width="52%" nowrap>Tipo de Curso Lectivo</td>
            <td width="52%" nowrap>
				<cfif modo EQ "ALTA">
				<select name="PEcodigo" id="PEcodigo"  tabindex="1" onChange="javascript: crearNuevoPeriodo(this);" >
                <cfoutput query="rsPeriodoEscolar"> 
                  <option value="#rsPeriodoEscolar.PEcodigo#"<cfif modo NEQ "ALTA" and rsSubPeriodoEscolar.PEcodigo eq rsPeriodoEscolar.PEcodigo>selected<cfelseif isdefined("Form.PEcodigo") AND form.PEcodigo EQ rsPeriodoEscolar.PEcodigo>selected</cfif>>#rsPeriodoEscolar.PEdescripcion# 
                  </option>
                </cfoutput> 
                <option value="">-------------------</option>
                <option value="0">Crear Nuevo ...</option>
              </select>
			  <cfelseif modo NEQ "ALTA">
			  	<input type="hidden" name="PEcodigo" value="<cfoutput>#Form.PEcodigo#</cfoutput>">
				<cfoutput>#rsSubPeriodoEscolar.PEdescripcion#</cfoutput>
			  </cfif>
			  </td>
            <cfoutput> 
              <cfif modo NEQ "ALTA" and isdefined("Form.PEcodigo") and len(trim(Form.PEcodigo)) NEQ 0>
                 <input type="hidden" name="HayCurso" value="#rsHayCurso.recordCount#"> 
				 <input type="hidden" name="HayGrupo" value="#rsHayGrupo.recordCount#"> 
              </cfif>
            </cfoutput> </tr>
          <tr>
            <td height="22" nowrap>Fecha Inicio:</td>
            <td><input name="SPEfechainicio"  tabindex="1" onFocus="this.select()" type="text" onBlur="javascript: onblurdatetime(this)" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsSubPeriodoEscolar.SPEfechainicio#</cfoutput></cfif>" size="12" maxlength="10" >
              <a href="#"><img src="/cfmx/edu/Imagenes/date_d.GIF" alt="Calendario" name="Calendar1" width="11" height="11" border="0" id="Calendar1" onClick="javascript:showCalendar('document.form1.SPEfechainicio');"></a></td>
            <td nowrap>Fecha Fin:</td>
            <td nowrap>
              <input name="SPEfechafin"  tabindex="1"  onFocus="this.select()" type="text" onBlur="javascript: onblurdatetime(this)" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsSubPeriodoEscolar.SPEfechafin#</cfoutput></cfif>" size="12" maxlength="10" >
              <a href="#"><img src="/cfmx/edu/Imagenes/date_d.GIF" alt="Calendario" name="Calendar1" width="11" height="11" border="0" id="Calendar1" onClick="javascript:showCalendar('document.form1.SPEfechafin');"></a></td>
          </tr>
          <tr> 
            <td height="22" nowrap>Orden:</td>
            <td><input name="SPEorden" type="text" id="SPEorden4" tabindex="1" size="5" maxlength="80" onFocus="javascript:this.select();" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsSubPeriodoEscolar.SPEorden#</cfoutput></cfif>"></td>
            <td nowrap>&nbsp;</td>
            <td nowrap>&nbsp;</td>
          </tr>
        </table>
		</td>
	</tr>
    <tr> 
      	<td <cfif modo NEQ "ALTA">colspan="2" </cfif>align="center"> 
			<cfif modo EQ "ALTA">
				<input type="submit" name="btnAgregarE" tabindex="1" value="Agregar" onClick="javascript: setBtn(this);"> 
			<cfelseif modo NEQ "ALTA">
				<input type="submit" name="btnCambiarE" tabindex="1" value="Modificar Curso Lectivo" onClick="javascript: setBtn(this); deshabilitarDetalle(); habilitarValidacion(); " >
				<input type="submit" name="btnBorrarE" tabindex="1" value="Borrar Curso Lectivo" onClick="javascript: setBtn(this); deshabilitarDetalle(); deshabilitarValidacion(); return confirm('�Esta seguro(a) que desea borrar este SubPeriodo?')" > 
				<input type="submit" name="btnNuevoE" tabindex="1" value="Nuevo Curso Lectivo" onClick="javascript: setBtn(this); deshabilitarDetalle(); deshabilitarValidacion();" >
			</cfif>
			<input type="button" name="btnLista" tabindex="1" value="Lista de Cursos Lectivos" onClick="javascript: irALista();">
		</td>
    </tr>
	<cfif modo NEQ "ALTA">
	<tr>
		<td colspan="2"><hr></td>
	</tr>
	<tr>
		<td width="50%" valign="top">
			<cfinvoke 
			 component="edu.Componentes.pListas"
			 method="pListaEdu"
			 returnvariable="pListaPlan">
				<cfinvokeargument name="tabla" value="SubPeriodoEscolar a, PeriodoOcurrencia b, PeriodoEvaluacion c"/>
				<cfinvokeargument name="columnas" value=" substring(c.PEdescripcion,1,50) as PEdescripcion, convert(varchar,b.SPEcodigo) as SubPeriodo, convert(varchar,b.PEcodigo) as PerCod, PEevaluacion as Evaluacion, convert(varchar,POfechainicio,103) as FechaInicio, convert(varchar,POfechafin,103) as  Salida, case POvigente when 1 then '<img border=''0'' src=''../../Imagenes/educ/DSL_D.gif''>' when 0 then '' else '' end as vigente "/>
				<cfinvokeargument name="desplegar" value="PEdescripcion, FechaInicio, Salida, vigente "/>
				<cfinvokeargument name="etiquetas" value="Descripcion Periodo, Fecha de Inicio, Fecha de Salida, Vigente"/>
				<cfinvokeargument name="formatos" value=""/>
				<cfinvokeargument name="filtro" value="a.PEcodigo = #form.PEcodigo# and a.SPEcodigo = #form.SPEcodigo# and a.PEcodigo = b.PEcodigo and a.SPEcodigo = b.SPEcodigo and b.PEevaluacion = c.PEcodigo order by c.PEorden"/>
				<cfinvokeargument name="align" value="left,right,right,center"/>
				<cfinvokeargument name="ajustar" value="N,N,N,N"/>,
				<cfinvokeargument name="irA" value="SubPeriodoEscolar.cfm"/>
				<cfinvokeargument name="incluyeForm" value="false"/>
				<cfinvokeargument name="formName" value="form1"/>
				<cfinvokeargument name="debug" value="N"/>
			</cfinvoke>
		</td>
		<td width="50%" valign="top" style="padding-left: 10px">
			<table border="0" width="100%" cellpadding="2" cellspacing="2">
			<tr align="center"> 
              <td  colspan="2" class="tituloMantenimiento" > 
                <cfif modoDet EQ "ALTA">
                  Nueva 
                <cfelse>
				  Modificar 
				</cfif>
                Ocurrencia 
			  </td>
			</tr>
				<tr>
					
              <td align="right" nowrap>Periodo de Evaluaci�n:</td>
					
              <td nowrap> 
                <cfif modoDet EQ "ALTA">
                  <select name="PEevaluacion" id="PEevaluacion"  tabindex="2" onChange="javascript: crearNuevoPeriodoEvaluacion(this);" >
                    <cfoutput query="rsPeriodoEvaluacion"> 
                      <option value="#PEcodigo#"<cfif modoDet NEQ "ALTA" and rsPeriodoOcurrencia.PEevaluacion eq rsPeriodoEvaluacion.PEcodigo>selected<cfelseif isdefined("Form.PEcodigo") AND form.PEcodigo EQ rsPeriodoEvaluacion.PEcodigo>selected</cfif>>#PEdescripcion# 
                      </option>
                    </cfoutput> 
                    <option value="">-------------------</option>
                    <option value="0">Crear Nuevo ...</option>
                  </select>
                  <cfelse>
					  <cfoutput>
						  <input name="PEevaluacion" id="PEevaluacion" value="<cfif modo NEQ "ALTA">#Form.PEevaluacion#</cfif>" type="hidden">
						  <input name="PEevaluacion_text"  class="cajasinborde" tabindex="2" onFocus="this.select()" type="text"  value="<cfif modoDet NEQ 'ALTA'>#rsPeriodoOcurrencia.PEdescripcion#</cfif>" <cfif modoDet NEQ 'ALTA'>readonly</cfif> size="30" maxlength="30">
					  </cfoutput>
                </cfif> </td>
				</tr>
				<tr>
              <td align="right" nowrap>Fecha de Inicio:</td>
              <td nowrap>
                <input name="POfechainicio"  tabindex="2" onFocus="this.select()" type="text" onBlur="javascript: onblurdatetime(this)" value="<cfif modoDet NEQ 'ALTA'><cfoutput>#rsPeriodoOcurrencia.POfechainicio#</cfoutput></cfif>" size="12" maxlength="10" >
                <a href="#"><img src="/cfmx/edu/Imagenes/date_d.GIF" alt="Calendario" name="Calendar1" width="11" height="11" border="0" id="Calendar1" onClick="javascript:showCalendar('document.form1.POfechainicio');"></a> 
              </td>
				</tr>
				<tr>
              <td align="right" nowrap>Fecha T&eacute;rmino:</td>
              <td nowrap>
                  <input name="POfechafin"  tabindex="2" onFocus="this.select()" type="text" onBlur="javascript: onblurdatetime(this)" value="<cfif modoDet NEQ 'ALTA'><cfoutput>#rsPeriodoOcurrencia.POfechafin#</cfoutput></cfif>" size="12" maxlength="10" >
                  <a href="#"><img src="/cfmx/edu/Imagenes/date_d.GIF" alt="Calendario" name="Calendar1" width="11" height="11" border="0" id="Calendar1" onClick="javascript:showCalendar('document.form1.POfechafin');"></a>
              </td>
				</tr>
				<tr>
              <td align="right" nowrap>Vigente:</td>
              <td nowrap><input type="checkbox" name="POvigente"  tabindex="2" <cfif modoDet NEQ "ALTA" and rsPeriodoOcurrencia.POvigente EQ 1>disabled</cfif>>
              </td>
				</tr>
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="2" align="center" nowrap>
						<cfif modoDet EQ "ALTA">
							<input type="submit" name="btnAgregarD" tabindex="4" value="Agregar Ocurrencia" onClick="javascript: setBtn(this); habilitarDetalle(); habilitarValidacion(); " > 
						<cfelseif modoDet NEQ "ALTA">
							<input type="submit" name="btnCambiarD" tabindex="4" value="Modificar Ocurrencia" onClick="javascript: setBtn(this); habilitarDetalle(); habilitarValidacion();" > 
							<input type="submit" name="btnBorrarD" tabindex="4" value="Eliminar Ocurrencia" onClick="javascript: setBtn(this); deshabilitarValidacion(); deshabilitarDetalle(); return confirm('�Esta seguro(a) que desea borrar esta Ocurrencia?')" > 
							<input type="submit" name="btnNuevoD" tabindex="4" value="Nuevo Ocurrencia" onClick="javascript: setBtn(this); deshabilitarValidacion(); deshabilitarDetalle();" >
						</cfif>
					</td>
				</tr>
			</table>
		</td>
    </tr>
	</cfif>
  </table>
  </form>

<script language="JavaScript">
	//Rodolfo Jim�nez Jara, SOIN,17/12/2002
	function deshabilitarValidacion() {
		objForm.SPEdescripcion.required = false;
		objForm.SPEfechainicio.required = false;
		objForm.SPEfechafin.required = false;
	}
	
	function habilitarValidacion() {
		objForm.SPEdescripcion.required = true;
		objForm.SPEfechainicio.required = true;
		objForm.SPEfechafin.required = true;
	}	
	
	function deshabilitarDetalle() {
		<cfif modoDet EQ "ALTA">
			objForm.PEevaluacion.required = false;
		</cfif>
		objForm.POfechainicio.required = false;
		objForm.POfechafin.required = false;
	}

	function habilitarDetalle() {
		<cfif modoDet EQ "ALTA">
			objForm.PEevaluacion.required = true;
		</cfif>
		objForm.POfechainicio.required = true;
		objForm.POfechafin.required = true;
	}
	
	function __isValida() {
		if(btnSelected("btnBorrarE")) {
			//Rodolfo Jimenez Jara, 17/12/2002
			// Valida que la Tabla de Tipo de Horario no tenga dependencias con otros.
			var msg = "";
			//alert(new Number(this.obj.form.HayPeriodoVigente.value)); 
			//if (new Number(this.obj.form.HayPeriodoVigente.value) > 0) {
			//	msg = msg + "Periodo Vigente"
			//}
			//alert(new Number(this.obj.form.HayCurso.value)); 
			if (new Number(this.obj.form.HayCurso.value) > 0) {
				msg = msg + "Cursos"
			}
			//alert(new Number(this.obj.form.HayGrupo.value)); 
			if (new Number(this.obj.form.HayGrupo.value) > 0) {
				msg = msg + ", Grupos"
			}			
			if (msg != "")
			{
				this.error = "Usted no puede eliminar el Curso Lectivo '" + this.obj.form.SPEdescripcion.value + "' porque �ste tiene asociado: " + msg + ".";
				this.obj.form.SPEdescripcion.focus();
			}
		}
	}

	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isValida", __isValida);
	objForm = new qForm("form1");

	<cfif modo EQ "ALTA">
		objForm.SPEdescripcion.required = true;
		objForm.SPEdescripcion.description = "Descripci�n";
		objForm.SPEfechainicio.required = true;
		objForm.SPEfechainicio.description = "Fecha inicio";
		objForm.SPEfechafin.required = true;
		objForm.SPEfechafin.description = "Fecha fin";
	<cfelseif modo NEQ "ALTA">
		objForm.SPEdescripcion.required = true;
		objForm.SPEdescripcion.description = "Nombre del SubPeriodo";
		objForm.SPEdescripcion.validateValida();
		objForm.SPEfechainicio.required = true;
		objForm.SPEfechainicio.description = "Fecha Inicio";
		objForm.SPEfechafin.required = true;
		objForm.SPEfechafin.description = "Fecha Fin";		
		<cfif modoDet EQ "ALTA">
			objForm.PEevaluacion.required = true;
			objForm.PEevaluacion.description = "Evaluaci�n del SubPeriodo";
			objForm.POfechainicio.required = true;
			objForm.POfechainicio.description = "Fecha de Inicio";
			objForm.POfechafin.required = true;
			objForm.POfechafin.description = "Fecha de T�rmino";
		<cfelseif modoDet NEQ "ALTA">
			objForm.POfechainicio.required = true;
			objForm.POfechainicio.description = "Fecha de Inicio";
			objForm.POfechafin.required = true;
			objForm.POfechafin.description = "Fecha de T�rmino";
		</cfif>		 
	</cfif>		
</script>