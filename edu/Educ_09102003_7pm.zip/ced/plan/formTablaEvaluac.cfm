<cfif isdefined("Form.Valor")>
	<cfset Form.EVvalor = Form.Valor>
</cfif>

<cfif isdefined("Form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("Form.modo")>
		<cfset modo="ALTA">
	<cfelseif Form.modo EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>

<cfif isdefined("Form.btnNuevo")>
	<cfset modo="ALTA">
</cfif>

<!-- modo para el detalle -->
<cfif isdefined("Form.EVvalor")>
	<cfset modo="CAMBIO">
	<cfset modoDet="CAMBIO">
<cfelse>
	<cfif not isdefined("Form.EVvalor")>
		<cfset modoDet="ALTA">
	<cfelseif Form.modoDet EQ "CAMBIO">
		<cfset modoDet="CAMBIO">
	<cfelse>
		<cfset modoDet="ALTA">
	</cfif>
</cfif>

<!--- Consultas --->

<!--- 1. Form --->
<cfquery datasource="#Session.DSN#" name="rsForm">
	select EVTnombre, EVTtipo from EvaluacionValoresTabla	
	where CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
	
	<cfif isdefined("Form.EVTcodigo") AND #Form.EVTcodigo# NEQ "" >
		and EVTcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.EVTcodigo#">
	</cfif>	
</cfquery>
<cfif isdefined("Form.EVTcodigo") AND #Form.EVTcodigo# NEQ "" >
	<cfquery datasource="#Session.DSN#" name="rsCual_Valor">
		Select EVvalor, EVdescripcion, str(EVequivalencia,5,2) as EVequivalencia
		from EvaluacionValores
		where EVTcodigo= <cfqueryparam value="#form.EVTcodigo#" cfsqltype="cf_sql_numeric">
		<cfif isdefined("Form.EVvalor") and Form.EVvalor NEQ "">
			and EVvalor !=<cfqueryparam value="#form.EVvalor#" cfsqltype="cf_sql_varchar">
		</cfif>
		  
	</cfquery>
</cfif>
<!--- Seccion del detalle --->
<cfif modo NEQ 'ALTA'>
	<cfif isdefined("Form.EVTcodigo") and Form.EVTcodigo NEQ "" and isdefined("Form.EVvalor") and Form.EVvalor NEQ "" >
		<!--- 1. Form --->	
		<cfquery datasource="#Session.DSN#" name="rsFormDetalle">
			Select convert(varchar, EVTcodigo) as EVTcodigo,EVvalor,EVdescripcion, str(EVequivalencia,5,2) as EVequivalencia
			from EvaluacionValores
			where EVTcodigo= <cfqueryparam value="#form.EVTcodigo#" cfsqltype="cf_sql_numeric">
			and EVvalor=<cfqueryparam value="#form.EVvalor#" cfsqltype="cf_sql_varchar">
		</cfquery>
		
	</cfif>
</cfif>

<cfif modo NEQ "ALTA" and isdefined("Form.EVTcodigo") and len(trim("Form.EVTcodigo")) GT 0>
	<!--- 3. Validaciones de dependencias--->
	<!---  Rodolfo JImenez Jara, SOIN, 03/12/2002 --->
	<cfquery datasource="#Session.DSN#" name="rsHayMateria">
		select 1 from Materia
		where EVTcodigo  = <cfqueryparam value="#Form.EVTcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>
	<cfquery datasource="#Session.DSN#" name="rsHayEvaluacionMateria">
		select 1 from EvaluacionMateria
		where EVTcodigo  = <cfqueryparam value="#Form.EVTcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>
	<cfquery datasource="#Session.DSN#" name="rsHayEvaluacionPlanConcepto">
		select 1 from EvaluacionPlanConcepto
		where EVTcodigo  = <cfqueryparam value="#Form.EVTcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>
	<cfquery datasource="#Session.DSN#" name="rsHayEvaluacionCurso">
		select 1 from EvaluacionCurso
		where EVTcodigo  = <cfqueryparam value="#Form.EVTcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>

</cfif>	  

<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" type="text/JavaScript">

	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");

	function irALista() {
		location.href = "listaTablaEvaluac.cfm";
	}

	function TraeEquiv(dato1, EVTcodigo,dato2) {
	if (dato1!="") {
		//document.all["FrEquiv"].src="validaequiv.cfm?EVTcodigo="+EVTcodigo+"&EVequivalencia="+dato+"&modo="+'<cfoutput>#modoDet#</cfoutput>';
		document.all["FrEquiv"].src="validaequiv.cfm?EVTcodigo="+EVTcodigo+"&EVequivalencia="+dato1+"&EVvalor="+dato2+"&modo="+'<cfoutput>#modoDet#</cfoutput>';		
	}
	return;
}

	function valValorEquiv(dato1, dato2, dato3) {
	if (dato!="") {
		document.all["FrEquiv"].src="validaequiv.cfm?EVTcodigo="+dato3+"&EVequivalencia="+dato1+"&EVvalor="+dato2+"&modo="+'<cfoutput>#modoDet#</cfoutput>';
	}
	return;
}

</script>

<form name="form1" method="post" action="SQLTablaEvaluac.cfm">
  <input type="hidden" id="EVTcodigo" name="EVTcodigo" value="<cfif modo NEQ "ALTA"><cfoutput>#Form.EVTcodigo#</cfoutput></cfif>">
  <input type="hidden" id="ExisteEVvalor" name="ExisteEVvalor" value="">
    <input type="hidden" id="ExisteEVequivalencia" name="ExisteEVequivalencia" value="">
  <table width="100%" border="0">
    <tr> 
      <td <cfif modo NEQ "ALTA">colspan="2" </cfif>class="tituloMantenimiento"><cfif modo EQ "ALTA">Nueva <cfelse>Modificar </cfif>Tabla de Evaluaci&oacute;n</td>
    </tr>
    <tr> 
		<td <cfif modo NEQ "ALTA">colspan="2" </cfif>valign="top">
			<table width="100%" cellpadding="2" cellspacing="2" border="0">
				<tr>
				  <td align="right" nowrap>Descripci&oacute;n</td>
				  <td nowrap><input name="EVTnombre" type="text" id="EVTnombre" size="40" tabindex="1" maxlength="80" onfocus="javascript:this.select();" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.EVTnombre#</cfoutput></cfif>"></td>
				  <td align="right" nowrap>Tipo de Redondeo</td>
				  <td>
					<select name="EVTtipo" id="EVTtipo" tabindex="1">
					  <option value="0" <cfif modo NEQ 'ALTA' and #rsForm.EVTtipo# EQ 0>selected</cfif>>El m&aacute;s cercano</option>
					  <option value="1" <cfif modo NEQ 'ALTA' and #rsForm.EVTtipo# EQ 1>selected</cfif>>Hacia arriba</option>
					  <option value="2" <cfif modo NEQ 'ALTA' and #rsForm.EVTtipo# EQ 2>selected</cfif>>Hacia abajo</option>
					</select>
					<cfoutput>
						<cfif modo NEQ 'ALTA' and isdefined("Form.EVTcodigo")>
							<input type="hidden" name="HayMateria"  value="#rsHayMateria.recordCount#">
							<input type="hidden" name="HayEvaluacionMateria"  value="#rsHayEvaluacionMateria.recordCount#">
							<input type="hidden" name="HayEvaluacionPlanConcepto"  value="#rsHayEvaluacionPlanConcepto.recordCount#">
							<input type="hidden" name="HayEvaluacionCurso"  value="#rsHayEvaluacionCurso.recordCount#">
						</cfif>
					</cfoutput>
				  </td>
				</tr>
			</table>
		</td>
	</tr>
    <tr> 
      	<td <cfif modo NEQ "ALTA">colspan="2" </cfif>align="center"> 
			<cfif modo EQ "ALTA">
				<input type="submit" name="btnAgregarE" tabindex="1" value="Agregar" onClick="javascript: setBtn(this); " > 
			<cfelseif modo NEQ "ALTA">
				<input type="submit" name="btnCambiarE" tabindex="1" value="Modificar Tabla" onClick="javascript: setBtn(this); deshabilitarDetalle(); habilitarValidacion(); " >
				<input type="submit" name="btnBorrarE" tabindex="1" value="Borrar Tabla" onClick="javascript: setBtn(this); deshabilitarDetalle(); deshabilitarValidacion(); return confirm('�Esta seguro(a) que desea borrar esta tabla de evaluaci�n ?')" > 
				<input type="submit" name="btnNuevoE" tabindex="1" value="Nueva Tabla" onClick="javascript: setBtn(this); deshabilitarValidacion(); deshabilitarDetalle();">
			</cfif>
			<input type="button" name="btnLista" tabindex="1" value="Lista de Tablas de Evaluaci�n" onClick="javascript: irALista();">
		</td>
    </tr>
	<cfif modo NEQ "ALTA">
	<tr>
		<td colspan="2"><hr></td>
	</tr>
	<tr>
		<td width="50%" valign="top">
			<cfinvoke 
			 component="edu.Componentes.pListas"
			 method="pListaEdu"
			 returnvariable="pListaTabEvalDet">
				<cfinvokeargument name="tabla" value="EvaluacionValores a,EvaluacionValoresTabla b"/>
				<cfinvokeargument name="columnas" value="EVdescripcion as Descripcion,EVvalor as Valor,str(EVequivalencia,6,2) as Equivalencia, str(EVminimo,7,3) as Minimo, str(EVmaximo,7,3) as Maximo"/>
				<cfinvokeargument name="desplegar" value="Valor,Descripcion,Equivalencia, Minimo, Maximo"/>
				<cfinvokeargument name="etiquetas" value="Valor,Descripci&oacute;n,Equivalencia, M&iacute;nimo, M&aacute;ximo"/>
				<cfinvokeargument name="formatos" value=""/>
				<cfinvokeargument name="filtro" value="a.EVTcodigo=b.EVTcodigo and a.EVTcodigo = #form.EVTcodigo# order by convert(numeric, a.EVequivalencia) desc" />
				<cfinvokeargument name="align" value="left,left,right,right,right"/>
				<cfinvokeargument name="ajustar" value="N"/>
				<cfinvokeargument name="irA" value="tablaEvaluac.cfm"/>
				<cfinvokeargument name="incluyeForm" value="false"/>
				<cfinvokeargument name="formName" value="form1"/>
				<cfinvokeargument name="debug" value="N"/>
			</cfinvoke>	
		</td>
		<td width="50%" valign="top" style="padding-left: 10px">
			<table border="0" width="100%" cellpadding="2" cellspacing="2">
				<tr>
					<td align="right" nowrap>Valor</td>
					
						<cfoutput>
							<td nowrap><input name="EVvalor" type="text" id="EVvalor" tabindex="3" size="10" maxlength="3"   <cfif modoDet NEQ 'ALTA'>readonly="true"</cfif> value="<cfif modoDet NEQ 'ALTA'>#rsFormDetalle.EVvalor#</cfif>">
							<cfset valores ="">
							<cfset equivalencia ="">
							<cfloop query="rsCual_Valor">
                        		<cfset valores = valores & rsCual_Valor.EVvalor & ",">
								<cfset equivalencia = equivalencia & rsCual_Valor.EVequivalencia & ",">
							</cfloop>
							<input type="hidden" name="Cual_Valor"  value="#valores#">
							<input type="hidden" name="Cual_Equivalencia1"  value="#equivalencia#"> 
						</td></cfoutput>
					
				</tr>
				<tr>
					
              <td height="28" align="right" nowrap>Descripci&oacute;n</td>
					<td nowrap><input name="EVdescripcion" type="text" id="EVdescripcion" tabindex="3" size="35" maxlength="80"  onfocus="javascript:this.select();" value="<cfif modoDet NEQ 'ALTA'><cfoutput>#rsFormDetalle.EVdescripcion#</cfoutput></cfif>"></td>
				</tr>
				<tr>
					<td align="right" nowrap>Equivalencia</td>
					<td nowrap><input name="EVequivalencia" type="text" id="EVequivalencia" tabindex="3" size="10" maxlength="6"  value="<cfif modoDet NEQ 'ALTA'><cfoutput>#rsFormDetalle.EVequivalencia#</cfoutput></cfif>" style="text-align: right;" onBlur="javascript:fm(this,2); "  onFocus="javascript:this.value=qf(this); this.select();"  onKeyUp="javascript:if(snumber(this,event,2)){ if(Key(event)=='13') {this.blur();}}"></td>
				</tr>
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<cfif modoDet EQ "ALTA">
							<input type="submit" name="btnAgregarD" tabindex="4" value="Agregar Valor" onClick="javascript: setBtn(this); habilitarDetalle(); habilitarValidacion(); " > 
						<cfelseif modoDet NEQ "ALTA">
							<input type="submit" name="btnCambiarD" tabindex="4" value="Modificar Valor" onClick="javascript: setBtn(this); habilitarDetalle(); habilitarValidacion();" > 
							<input type="submit" name="btnBorrarD" tabindex="4" value="Borrar Valor" onClick="javascript: setBtn(this); deshabilitarDetalle(); deshabilitarValidacion(); return confirm('�Esta seguro(a) que desea borrar este valor?')" > 
							<input type="submit" name="btnNuevoD" tabindex="4" value="Nuevo Valor" onClick="javascript: setBtn(this); deshabilitarDetalle(); deshabilitarValidacion();" >	
						</cfif>
					</td>
				</tr>
			</table>
		</td>
    </tr>
	</cfif>
  </table>
  <!---  Este Iframe funciona, pero solo tiene la inconveniencia de que si el usuario no hace el onblur, no funciona. --->
  <iframe name="FrEquiv" marginheight="0" marginwidth="0" frameborder="0" height="0" width="0" scrolling="auto" src="validaequiv.cfm" ></iframe>

<!--- <script>
  	<cfif modo EQ "CAMBIO">
		valValorEquiv(document.form1.EVequivalencia.value, document.form1.EVvalor.value, document.form1.EVTcodigo.value);

	</cfif>
</script> --->
</form>
	
<script language="JavaScript">
	
	function deshabilitarValidacion() {
		objForm.EVTnombre.required = false;
		objForm.EVvalor.required = false;
		objForm.EVequivalencia.required = false
	}
	
	function habilitarValidacion() {
		objForm.EVTnombre.required = true;
	}	
	
	function deshabilitarDetalle() {
		objForm.EVvalor.required = false;
		objForm.EVdescripcion.required = false;
		objForm.EVequivalencia.required = false;
	}

	function habilitarDetalle() {
		objForm.EVvalor.required = true;
		objForm.EVdescripcion.required = true;
		objForm.EVequivalencia.required = true;
	}

	function __isValidaEquivalencia() {	
		if(btnSelected("btnAgregarD") || btnSelected("btnCambiarD")) {
			// Valida que la equivalencia se encuentre entre el rango permitido
			//alert(new Number(this.obj.form.EVequivalencia.value)); 
			if (new Number(this.obj.form.EVequivalencia.value) < 0 || new Number(this.obj.form.EVequivalencia.value) > 100) {
				this.error = "Equivalencia incorrecta, el rango sugerido es: mayor que cero y menor o igual que 100";
				this.obj.form.EVequivalencia.focus();
			}
		}
	}

	function __isValidaValor() {	
		//alert(this.obj.form.ExisteEVvalor.value);
		if (this.obj.form.ExisteEVvalor.value == 'S')  {
			this.error = "Valor incorrecto, Ya existe el valor en la Tabla de Evaluacion!";
			this.obj.form.EVvalor.focus();
		}			
 	}

	function __isValidaEquiv() {	
		//alert(this.obj.form.ExisteEVequivalencia.value);
		if (this.obj.form.ExisteEVequivalencia.value == 'S')  {
			this.error = "Valor incorrecto, Ya existe la Equivalencia en la Tabla de Evaluacion!";
			this.obj.form.EVequivalencia.focus();
		}			
 	}
	function __isCual_Valor(){

		if(btnSelected("btnCambiarD") || btnSelected("btnAgregarD")) {
			var valor_digitado = this.obj.form.EVvalor.value + ",";
			var valores = this.obj.form.Cual_Valor.value;
			
			if (valores.indexOf(valor_digitado) == -1) {
				//alert("No lo encontre");
			} else {
				//alert("Si lo encontre");
				this.error = "Valor incorrecto, Ya existe el valor en la Tabla de Evaluacion!";
				this.obj.form.EVvalor.focus();
			}
		}
	}
	
	function __isCual_Equivalencia() {
	
		if(btnSelected("btnCambiarD") || btnSelected("btnAgregarD")) {
			var equivalencia_digitada = this.obj.form.EVequivalencia.value;
			var equivalencia = this.obj.form.Cual_Equivalencia1.value;
			
			var equivArray = equivalencia.split(',');
			for (var i=0; i<equivArray.length; i++) {
				if (equivArray[i] != "" && (new Number(equivArray[i]).valueOf() == new Number(equivalencia_digitada).valueOf())) {
					this.error = "Valor incorrecto, Ya existe la equivalencia en la Tabla de Evaluacion!";
					this.obj.form.EVequivalencia.focus();
					break;
				}
			}
		}
		
		/*if (equivalencia.indexOf(equivalencia_digitada) == -1) {
			//alert("No lo encontre");
		} else {
			//alert("Si lo encontre");
			this.error = "Valor incorrecto, Ya existe la equivalencia en la Tabla de Evaluacion!";
			this.obj.form.EVequivalencia.focus();
		}*/
	}

	
	function __isValida() {
		if(btnSelected("btnBorrarE")) {
			//Rodolfo Jimenez Jara, 05/12/2002
			// Valida que la Tabla de Evaluacion no tenga dependencias con otros.
			var msg = "";
			//alert(new Number(this.obj.form.HayMateria.value)); 
			if (new Number(this.obj.form.HayMateria.value) > 0) {
				msg = msg + "materias"
			}
			//alert(new Number(this.obj.form.HayEvaluacionMateria.value)); 
			if (new Number(this.obj.form.HayEvaluacionMateria.value) > 0) {
				msg = msg + "evaluacion de materias"
			}
			//alert(new Number(this.obj.form.HayEvaluacionPlanConcepto.value)); 
			if (new Number(this.obj.form.HayEvaluacionPlanConcepto.value) > 0) {
				msg = msg + "conceptos de planes de evaluacion"
			}
			//alert(new Number(this.obj.form.HayEvaluacionCurso.value)); 
			if (new Number(this.obj.form.HayEvaluacionCurso.value) > 0) {
				msg = msg + "cursos de evaluacion"
			}
			if (msg != "")
			{
				this.error = "Usted no puede eliminar la tabla de evaluacion '" + this.obj.form.EVTnombre.value + "' porque �ste tiene asociado: " + msg + ".";
				this.obj.form.EVTnombre.focus();
			}
		}
	}

	qFormAPI.errorColor = "#FFFFCC";
	//_addValidator("isValidaValor", __isValidaValor);
	//_addValidator("isValidaEquiv", __isValidaEquiv);
	_addValidator("isCual_Valor", __isCual_Valor);
	_addValidator("isCual_Equivalencia", __isCual_Equivalencia);	
	
	_addValidator("isValida", __isValida);
	_addValidator("isValidaEquivalencia", __isValidaEquivalencia);
	objForm = new qForm("form1");
	
	<cfif modo EQ "ALTA">
		objForm.EVTnombre.required = true;
		objForm.EVTnombre.description = "Descripci�n";
		objForm.EVTnombre.validateValida();
	<cfelseif modo NEQ "ALTA">
		objForm.EVTnombre.required = true;
		objForm.EVTnombre.description = "Descripci�n";
		objForm.EVTnombre.validateValida();
		objForm.EVvalor.required = true;
		<cfif modoDet EQ "ALTA">
			objForm.EVvalor.required = true;
			objForm.EVvalor.description = "Valor";
			objForm.EVdescripcion.required = true;
			objForm.EVdescripcion.description = "Descripci�n del valor";
			objForm.EVequivalencia.required = true;
			objForm.EVequivalencia.description = "Equivalencia";
			objForm.EVequivalencia.validateValidaEquivalencia();
			objForm.EVequivalencia.validateCual_Equivalencia();
			objForm.EVvalor.required = true;
			<cfif modo NEQ "ALTA">
				//objForm.EVequivalencia.validateValidaEquiv();
				objForm.EVvalor.validateCual_Valor();
				objForm.EVequivalencia.validateCual_Equivalencia();
			</cfif>
		<cfelseif modoDet NEQ "ALTA">
			objForm.EVequivalencia.required = true;
			objForm.EVequivalencia.description = "Valor";
			objForm.EVdescripcion.required = true;
			objForm.EVdescripcion.description = "Descripci�n";
			objForm.EVTnombre.validateValida();
			objForm.EVequivalencia.validateValidaEquivalencia();
			objForm.EVequivalencia.validateCual_Equivalencia();
			<cfif modo NEQ "ALTA">
				//objForm.EVequivalencia.validateValidaEquiv();
			</cfif>
		</cfif>		
	</cfif>		
</script>
