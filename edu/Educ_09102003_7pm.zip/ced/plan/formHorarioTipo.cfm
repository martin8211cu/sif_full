<cfif isdefined("Form.Bloque")>
	<cfset Form.Hbloque = Form.Bloque>
</cfif>

<cfif isdefined("Url.Hcodigo") and not isdefined("Form.Hcodigo")>
	<cfset Form.Hcodigo = Url.Hcodigo>
</cfif>
<cfif isdefined("Url.Hbloque") and not isdefined("Form.Hbloque")>
	<cfset Form.Hbloque = Url.Hbloque>
</cfif>

<cfif isdefined("Form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("Form.modo")>
		<cfset modo="ALTA">
	<cfelseif Form.modo EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>

<cfif not isdefined("Form.modoDet")>
	<cfset modoDet = "ALTA">
</cfif>

<!-- modo para el detalle -->
<cfif isdefined("Form.Hcodigo")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfset modo="ALTA">
	<cfset modoDet="ALTA">
</cfif>

<cfif isdefined("Form.Hbloque")>
	<cfset modoDet="CAMBIO">
<cfelse>
	<cfset modoDet="ALTA">
</cfif>  

<cfif isdefined("Form.btnNuevo")>
	<cfset modo="ALTA">
	<cfset modoDet="ALTA">
</cfif>

<!--- Consultas --->

<!--- 1. Form Encabezado --->
<!--- Seccion del detalle --->
<cfif modoDet NEQ 'ALTA'>
	<cfif isdefined("Form.Hcodigo") and Form.Hcodigo NEQ "" and isdefined("Form.Hbloque") and Form.Hbloque NEQ "" >
		<!--- 1. Form --->	
		<cfquery datasource="#Session.DSN#" name="rsHorarioDetalle">
			select convert(varchar,b.Hcodigo) as Hcodigo, b.Hbloque,  b.Hbloquenombre, isnull(b.Hentrada,0) as Hentrada, isnull(b.Hsalida,0) as Hsalida,  b.Htipo  
			from HorarioTipo a, Horario b 
			where a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
			  and a.Hcodigo = b.Hcodigo
			<cfif isdefined("Form.Hcodigo") AND Form.Hcodigo NEQ "" >
			  and b.Hcodigo =<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Hcodigo#">
			</cfif>
			<cfif isdefined("Form.Hbloque") AND Form.Hbloque NEQ "" >
			  and b.Hbloque =<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Hbloque#">
			</cfif>	
		</cfquery>
	</cfif>
</cfif>

<cfif modo NEQ 'ALTA' and isdefined("Form.Hcodigo") and Form.Hcodigo NEQ "">
	<cfquery datasource="#Session.DSN#" name="rsHorario">
		select Hnombre from HorarioTipo 
		where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
		<cfif isdefined("Form.Hcodigo") AND #Form.Hcodigo# NEQ "" >
		  and Hcodigo =<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Hcodigo#">
		</cfif>	
	</cfquery>

	<cfquery datasource="#Session.DSN#" name="rsHayHorarioGuia">
		<!--- Existen dependencias con HorarioGuia--->
		select 1 from HorarioGuia a, HorarioTipo b
		where a.Hcodigo= <cfqueryparam value="#form.Hcodigo#" cfsqltype="cf_sql_numeric">
		  and a.Hcodigo = b.Hcodigo
		  and b.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
	</cfquery>
	<cfif modoDet NEQ 'ALTA' and isdefined("Form.Bloque") >
		<cfquery datasource="#Session.DSN#" name="rsHayHorarioGuiaDetalle">
			<!--- Existen dependencias con HorarioGuia--->
			select isnull(1,0) from HorarioGuia a, HorarioTipo b
			where a.Hcodigo= <cfqueryparam value="#form.Hcodigo#" cfsqltype="cf_sql_numeric">
			  and a.Hbloque= <cfqueryparam value="#form.Bloque#" cfsqltype="cf_sql_numeric">
			  and b.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
			  and a.Hcodigo = b.Hcodigo
		</cfquery>
	</cfif>
	
	<!--- <cfquery datasource="#Session.DSN#" name="rsHayHorarioAplica">
		<!--- Existen dependencias con HorarioAplica--->
		select 1 from HorarioAplica  a,  HorarioTipo b
		where a.Hcodigo= <cfqueryparam value="#form.Hcodigo#" cfsqltype="cf_sql_numeric">
		  and a.Hcodigo = b.Hcodigo
		  and b.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 		
	</cfquery> --->

</cfif>	

<!---------------------------------------------------------------------------------- --->

<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" type="text/JavaScript">

	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
	
	var popUpWin=0; 
	function popUpWindow(URLStr, left, top, width, height)
	{
	  if(popUpWin)
	  {
		if(!popUpWin.closed) popUpWin.close();
	  }
	  popUpWin = open(URLStr, 'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=no,resizable=no,copyhistory=yes,width='+width+',height='+height+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
	}
		
	function doConlisAplicaGradoAhorario() {
		//alert(Hcodigo);
		popUpWindow("ConlisAplicaGradoAhorario.cfm?Hcodigo="+document.form1.Hcodigo.value,250,100,650,500);
	}
	
	function irALista() {
		location.href = "listaHorarioTipo.cfm";
	}

</script>

<form name="form1" method="post" action="SQLHorarioTipo.cfm">
  <input name="Hcodigo" id="Hcodigo" value="<cfif modo NEQ "ALTA"><cfoutput>#Form.Hcodigo#</cfoutput></cfif>" type="hidden">
  <table width="100%" border="0">
    <tr> 
      <td <cfif modo NEQ "ALTA">colspan="2" </cfif>class="tituloMantenimiento"><cfif modo EQ "ALTA">Nuevo <cfelse>Modificar </cfif>Horario</td>
    </tr>
	<cfoutput>
    <tr> 
		<td <cfif modo NEQ "ALTA">colspan="2" </cfif>valign="top">
			<table width="100%" cellpadding="2" cellspacing="2" border="0">
				<tr>
				  <td width="30%" align="right" nowrap>Descripci&oacute;n</td>
				  <td width="70%" nowrap><input name="Hnombre" type="text" id="Hnombre" size="80" tabindex="1" maxlength="100" onfocus="javascript:this.select();" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsHorario.Hnombre#</cfoutput></cfif>"></td>
				
						<cfif modo NEQ "ALTA" and isdefined("Form.Hcodigo")>
						  <input type="hidden" name="HayHorarioGuia" value="#rsHayHorarioGuia.recordCount#" >
						
						  <!--- <input type="hidden" name="HayHorarioAplica" value="#rsHayHorarioAplica.recordCount#"> --->
						</cfif>
					
				</tr>
			</table>
			<cfif modoDet NEQ 'ALTA' and isdefined("Form.Bloque")>
				  <input type="hidden" name="HayHorarioGuiaDetalle" value="<cfif #rsHayHorarioGuiaDetalle.recordCount# GT 0>#rsHayHorarioGuiaDetalle.recordCount#<cfelse>0</cfif>">
			</cfif>
		</td>
	</tr>
	</cfoutput>
    <tr> 
      	<td <cfif modo NEQ "ALTA">colspan="2" </cfif>align="center"> 
			<cfif modo EQ "ALTA">
				<input type="submit" name="btnAgregarE" tabindex="1" value="Agregar" onClick="javascript: setBtn(this);"> 
			<cfelseif modo NEQ "ALTA">
				<input type="submit" name="btnCambiarE" tabindex="1" value="Modificar Horario" onClick="javascript: setBtn(this); deshabilitarDetalle(); habilitarValidacion();" >
				<input type="submit" name="btnBorrarE" tabindex="1" value="Borrar Horario" onClick="javascript: setBtn(this); deshabilitarValidacion(); deshabilitarDetalle(); return confirm('�Esta seguro(a) que desea borrar este horario?');" > 
				<input type="submit" name="btnNuevoE" tabindex="1" value="Nuevo Horario" onClick="javascript: setBtn(this); deshabilitarDetalle(); deshabilitarValidacion();" >
				 <input name="btnHorarioAplica" type="button" value="Aplicar a Grados" onClick="javascript:doConlisAplicaGradoAhorario();">
			</cfif>
			<input type="button" name="btnLista" tabindex="1" value="Lista de Tipos de Horario" onClick="javascript: irALista();">
		</td>
    </tr>
	<cfif modo NEQ "ALTA">
	<tr>
		<td colspan="2"><hr></td>
	</tr>
	<tr>
		<td width="50%" valign="top">
			<cfinvoke 
			 component="edu.Componentes.pListas"
			 method="pListaEdu"
			 returnvariable="pListaPlanEvalDet">
				<cfinvokeargument name="tabla" value="HorarioTipo a, Horario b"/>
				<cfinvokeargument name="columnas" value=" b.Hbloque as Bloque, b.Hbloquenombre as NombreBloque, str(b.Hentrada,5,2) as Entrada, str(b.Hsalida,5,2) as Salida, (case b.Htipo when 1 then 'Clase' when 2 then 'Recreo' when 3 then 'Almuerzo' when 4 then 'Actividad no curricular' else 'No definido' end) as Tipo"/>
				<cfinvokeargument name="desplegar" value="NombreBloque, Tipo, Entrada, Salida"/>
				<cfinvokeargument name="etiquetas" value="Bloque, Tipo, Hora Entrada, Hora Salida"/>
				<cfinvokeargument name="formatos" value=""/>
				<cfinvokeargument name="filtro" value=" a.CEcodigo = #Session.CEcodigo# and a.Hcodigo = #form.Hcodigo# and a.Hcodigo = b.Hcodigo order by a.Hcodigo"/>
				<cfinvokeargument name="align" value="left,left,right,right"/>
				<cfinvokeargument name="ajustar" value="N,N,N,N"/>,
				<cfinvokeargument name="irA" value="HorarioTipo.cfm"/>
				<cfinvokeargument name="incluyeForm" value="false"/>
				<cfinvokeargument name="formName" value="form1"/>
			</cfinvoke>	
		</td>
		<td width="50%" valign="top" style="padding-left: 10px">
			<cfif modoDet NEQ "ALTA">
				<input type="hidden" name="Hbloque" id="Hbloque" value="<cfoutput>#Form.Hbloque#</cfoutput>">
			</cfif>
			<table border="0" width="100%" cellpadding="2" cellspacing="2">
				<tr>
					<td align="right" nowrap>Nombre</td>
					<td nowrap><input name="Hbloquenombre" type="text" id="Hbloquenombre" tabindex="1" size="30" maxlength="80" onfocus="javascript:this.select();" value="<cfif modoDet NEQ 'ALTA'><cfoutput>#rsHorarioDetalle.Hbloquenombre#</cfoutput></cfif>"></td>
				</tr>
				<tr>
					<td align="right" nowrap>Tipo</td>
					<td nowrap>
						<select name="Htipo" id="Htipo" tabindex="1">
						  <option value="1" <cfif modoDet NEQ 'ALTA' and #rsHorarioDetalle.Htipo# EQ 1>selected</cfif>>Clase</option>
						  <option value="2" <cfif modoDet NEQ 'ALTA' and #rsHorarioDetalle.Htipo# EQ 2>selected</cfif>>Recreo</option>
						  <option value="3" <cfif modoDet NEQ 'ALTA' and #rsHorarioDetalle.Htipo# EQ 3>selected</cfif>>Almuerzo</option>
						  <option value="4" <cfif modoDet NEQ 'ALTA' and #rsHorarioDetalle.Htipo# EQ 4>selected</cfif>>Actividad no curricular</option>
						</select>
					</td>
				</tr>
				<tr>
					<td align="right" nowrap>Hora de Entrada</td>
					<td nowrap>
					<cfoutput>
					  <select name="Hentrada" id="Hentrada" tabindex="1">
						<cfif modoDet NEQ 'ALTA' and rsHorarioDetalle.recordCount NEQ 0>
						  <cfset residuo = Fix(Val(rsHorarioDetalle.Hentrada))>
						</cfif>
						<cfloop index="i" from="0" to="23">
						  <option value="#i#"<cfif modoDet NEQ 'ALTA' and rsHorarioDetalle.recordCount NEQ 0 and #residuo# EQ i>selected</cfif>>#i# 
						  h</option>
						</cfloop>
					  </select>
					  <select name="HentradaMin" id="HentradaMin" tabindex="1">
						<cfif modoDet NEQ 'ALTA' and rsHorarioDetalle.recordCount NEQ 0>
						  <cfset residuo2 = 100 * (Val(rsHorarioDetalle.Hentrada) - Fix(Val(rsHorarioDetalle.Hentrada)))>
						</cfif>
						<cfloop index="i" from="0" to="55" step="5">
						  <option value="<cfif i LESS THAN 10>0</cfif>#i#"<cfif modoDet NEQ 'ALTA' and rsHorarioDetalle.recordCount NEQ 0 and Val(residuo2) EQ Val(i)>selected</cfif>>#i# 
						  min</option>
						</cfloop>
					  </select>
					</cfoutput>
					</td>
				</tr>
				<tr>
					<td align="right" nowrap>Hora de Salida</td>
					<td nowrap>
					<cfoutput>
					  <select name="Hsalida" id="Hsalida" tabindex="1">
						<cfif modoDet NEQ 'ALTA' and rsHorarioDetalle.recordCount NEQ 0>
						  <cfset residuo = Fix(Val(rsHorarioDetalle.Hsalida))>
						</cfif>
						<cfloop index="i" from="0" to="23">
						  <option value="#i#"<cfif modoDet NEQ 'ALTA' and rsHorarioDetalle.recordCount NEQ 0 and val(residuo) EQ val(i)>selected</cfif>>#i# 
						  h</option>
						</cfloop>
					  </select>
					  <select name="HsalidaMin" id="HsalidaMin" tabindex="1">
						<cfif modoDet NEQ 'ALTA' and rsHorarioDetalle.recordCount NEQ 0>
						  <cfset residuo2 = 100 * (Val(rsHorarioDetalle.Hsalida) - Fix(Val(rsHorarioDetalle.Hsalida)))>
						</cfif>
						<cfloop index="i" from="0" to="55" step="5">
						  <option value="<cfif i LESS THAN 10>0</cfif>#i#"<cfif modoDet NEQ 'ALTA' and rsHorarioDetalle.recordCount NEQ 0 and Val(residuo2) EQ Val(i)>selected</cfif>>#i# 
						  min</option>
						</cfloop>
					  </select>
					</cfoutput>
					</td>
				</tr>
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<cfif modoDet EQ "ALTA">
							<input type="submit" name="btnAgregarD" tabindex="4" value="Agregar bloque" onClick="javascript: setBtn(this); habilitarDetalle(); habilitarValidacion(); " > 
						<cfelseif modoDet NEQ "ALTA">
							<input type="submit" name="btnCambiarD" tabindex="4" value="Modificar Bloque" onClick="javascript: setBtn(this); habilitarDetalle(); habilitarValidacion(); " > 
							<input type="submit" name="btnBorrarD" tabindex="4" value="Borrar Bloque" onClick="javascript: setBtn(this); deshabilitarValidacion(); deshabilitarDetalle(); return confirm('�Esta seguro(a) que desea borrar este bloque?')" > 
							<input type="submit" name="btnNuevoD" tabindex="4" value="Nuevo Bloque" onClick="javascript: setBtn(this); deshabilitarValidacion(); deshabilitarDetalle();" >	
						</cfif>
					</td>
				</tr>
			</table>
		</td>
    </tr>
	</cfif>
  </table>
  </form>


<script language="JavaScript">
	function deshabilitarValidacion() {
		objForm.Hnombre.required = false;
	}
	
	function habilitarValidacion() {
		objForm.Hnombre.required = true;
	}	
	
	function deshabilitarDetalle() {
		objForm.Hbloquenombre.required = false;
	}

	function habilitarDetalle() {
		objForm.Hbloquenombre.required = true;
	}
	
	function __isValida() {
		if(btnSelected("btnBorrarE")) {
			//Rodolfo Jimenez Jara, 10/12/2002
			// Valida que la Tabla de Tipo de Horario no tenga dependencias con otros.
			var msg = "";
			//alert(new Number(this.obj.form.HayHorarioGuia.value)); 
			if (new Number(this.obj.form.HayHorarioGuia.value) > 0) {
				msg = msg + " Cursos "
			}
			//alert(new Number(this.obj.form.HayHorarioAplica.value)); 
			/*if (new Number(this.obj.form.HayHorarioAplica.value) > 0) {
				msg = msg + " horarios "
			}*/
			if (msg != "")
			{
				this.error = "Usted no puede eliminar el tipo de horario '" + this.obj.form.Hnombre.value + "' porque �ste tiene asociado: " + msg + ".";
				this.obj.form.Hnombre.focus();
			}
		}
	}
	function __isValidaDetalle() {
		if(btnSelected("btnBorrarD")) {
			//Rodolfo Jimenez Jara, 10/12/2002
			// Valida que la Tabla de Tipo de Horario no tenga dependencias con otros.
			var msg = "";
			//alert(new Number(this.obj.form.HayHorarioGuiaDetalle.value)); 
			if (new Number(this.obj.form.HayHorarioGuiaDetalle.value) > 0) {
				msg = msg + " Cursos "
			}
			if (msg != "")
			{
				this.error = "Usted no puede eliminar el tipo de horario '" + this.obj.form.Hbloquenombre.value + "' porque �ste tiene asociado: " + msg + ".";
				this.obj.form.Hbloquenombre.focus();
			}
		}		
	}
	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isValida", __isValida);
	_addValidator("isValidaDetalle", __isValidaDetalle);
	objForm = new qForm("form1");
				
	objForm.Hnombre.validateValida();
	objForm.Hbloquenombre.validateValidaDetalle();

	<cfif modoDet EQ "ALTA">
		objForm.Hnombre.required = true;
		objForm.Hnombre.description = "Descripci�n";	
	<cfelse>
		objForm.Hnombre.required = true;
		objForm.Hnombre.description = "Descripci�n";	
		<cfif modoDet EQ "ALTA">
			objForm.Hbloquenombre.required = true;
			objForm.Hbloquenombre.description = "Nombre del bloque";
		<cfelse>
			objForm.Hbloquenombre.required = true;
			objForm.Hbloquenombre.description = "Nombre del bloque";
			//objForm.Hbloquenombre.validateValida();			
		</cfif>
	</cfif>			
</script>