<cfif isdefined("Url.Mconsecutivo") and not isdefined("Form.Mconsecutivo")>
	<cfparam name="Form.Mconsecutivo" default="#Url.Mconsecutivo#">
	<cfparam name="Form.modo" default="CAMBIO">
</cfif>
<cfif isdefined("Url.FNcodigo") and not isdefined("Form.FNcodigo")>
	<cfparam name="Form.FNcodigo" default="#Url.FNcodigo#">
</cfif>
<cfif isdefined("Url.FGcodigo") and not isdefined("Form.FGcodigo")>
	<cfparam name="Form.FGcodigo" default="#Url.FGcodigo#">
</cfif>
<cfif isdefined("Url.FMcodigo") and not isdefined("Form.FMcodigo")>
	<cfparam name="Form.FMcodigo" default="#Url.FMcodigo#">
</cfif>
<cfif isdefined("Url.FMTcodigo") and not isdefined("Form.FMTcodigo")>
	<cfparam name="Form.FMTcodigo" default="#Url.FMTcodigo#">
</cfif>
<cfif isdefined("Url.FMnombre") and not isdefined("Form.FMnombre")>
	<cfparam name="Form.FMnombre" default="#Url.FMnombre#">
</cfif>
<cfif isdefined("Url.FMelectiva") and not isdefined("Form.FMelectiva")>
	<cfparam name="Form.FMelectiva" default="#Url.FMelectiva#">
</cfif>

<cfif isdefined("Form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("Form.modo")>
		<cfset modo="ALTA">
	<cfelseif #Form.modo# EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>

<cfquery name="rsPlanesEval" datasource="#Session.DSN#">
	select distinct convert(varchar, a.EPcodigo) as EPcodigo, substring(a.EPnombre,1,50) as EPnombre
	from EvaluacionPlan a, EvaluacionPlanConcepto b
	where a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
	and a.EPcodigo = b.EPcodigo
    group by a.EPcodigo
	having sum(b.EPCporcentaje) = 100
	order by a.EPnombre
</cfquery>

<cfquery datasource="#Session.DSN#" name="rsNiveles">
	select convert(varchar, Ncodigo) as Ncodigo, 
	substring(Ndescripcion ,1,50) as Ndescripcion from Nivel 
	where CEcodigo = <cfqueryparam cfsqltype="cf_sql_integer" value="#Session.CEcodigo#">
	order by Norden
</cfquery>

<cfquery datasource="#Session.DSN#" name="rsGrado">
	select convert(varchar, b.Ncodigo)
	       + '|' + convert(varchar, b.Gcodigo) as Codigo, 
		   substring(b.Gdescripcion ,1,50) as Gdescripcion 
	from Nivel a, Grado b
	where a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_integer" value="#Session.CEcodigo#">
	and a.Ncodigo = b.Ncodigo 
	order by a.Norden, b.Gorden
</cfquery>

<cfquery datasource="#Session.DSN#" name="rsMateriaTipo">
	select convert(varchar,MTcodigo) as MTcodigo, substring(MTdescripcion,1,50) 
	as MTdescripcion from MateriaTipo 
	where CEcodigo = <cfqueryparam cfsqltype="cf_sql_integer" value="#Session.CEcodigo#">
	order by MTdescripcion
</cfquery>

<cfquery datasource="#Session.DSN#" name="rsEvaluacionValoresTabla">
	select convert(varchar,EVTcodigo) as EVTcodigo, 
	substring(EVTnombre,1,50) as EVTnombre 
	from EvaluacionValoresTabla
	where CEcodigo = <cfqueryparam cfsqltype="cf_sql_integer" value="#Session.CEcodigo#">
	order by EVTnombre
</cfquery>

<cfif modo NEQ "ALTA">

	<cfquery datasource="#Session.DSN#" name="rsMateria">
		select convert(varchar, c.Mconsecutivo) as Mconsecutivo, 
		       convert(varchar, c.Gcodigo) as Gcodigo,
		       convert(varchar, c.Ncodigo) as Ncodigo, 
			   convert(varchar, c.MTcodigo) as MTcodigo, 
			   convert(varchar, c.EVTcodigo) as EVTcodigo, 
			   c.Mcodigo, 
			   convert(varchar, EPcodigo) as EPcodigo,
			   c.Mnombre, c.Mobservaciones, c.Mreglamentos, c.Mhoras, c.Mcreditos, c.Mtipoevaluacion, c.Melectiva, c.Morden, c.Manterior
			   , Mactiva 
		from Nivel a, Grado b, Materia c
		where a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
		  and c.Mconsecutivo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Mconsecutivo#">
		  and a.Ncodigo = c.Ncodigo 
		  and b.Ncodigo =* c.Ncodigo 
		  and b.Gcodigo =* c.Gcodigo 
	</cfquery>
	
	<cfquery datasource="#Session.DSN#" name="rsAsociadas">
		Select count(*) as asociadas from MateriaElectiva 
		where Mconsecutivo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Mconsecutivo#">
		or Melectiva = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Mconsecutivo#">
	</cfquery>
	<cfquery datasource="#Session.DSN#" name="rsHayCurso">
		select 1 from Curso
		where Mconsecutivo  = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Mconsecutivo#">
	</cfquery>

	<cfquery datasource="#Session.DSN#" name="rsHayMateriaElectiva">
		select 1 from MateriaElectiva
		where Mconsecutivo  = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Mconsecutivo#">
	</cfquery>
	<!--- Desde aqui Rodolfo Jim�nez Jara, 22/01/2003 --->
	<cfquery datasource="#Session.DSN#" name="rsHayMateriaElectiva2">
		select 1 from MateriaElectiva
		where Melectiva  = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Mconsecutivo#">
	</cfquery>
	<cfquery datasource="#Session.DSN#" name="rsHayGradoSustitutivas">
		select 1 from GradoSustitutivas
		where Mconsecutivo  = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Mconsecutivo#">
	</cfquery>
	<cfquery datasource="#Session.DSN#" name="rsHayEvaluacionConceptoMateria">
		select 1 from EvaluacionConceptoMateria
		where Mconsecutivo  = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Mconsecutivo#">
	</cfquery>
</cfif>
<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" type="text/javascript">

 	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
	
	var popUpWin=0;
	function popUpWindow(URLStr, left, top, width, height)
	{
	  if(popUpWin)
	  {
		if(!popUpWin.closed) popUpWin.close();
	  }
	  popUpWin = open(URLStr, 'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=no,resizable=no,copyhistory=yes,width='+width+',height='+height+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
	}

	/*
	function genEvaluaciones(EPcodigo) {
		popUpWindow("genMateriaConceptos.cfm?form=form1&id=ConceptosEval&EPcodigo="+EPcodigo,250,200,650,350);
	}

	function OcultaTablaEval(f) {
		if (f.Mtipoevaluacion.value == "0") {      
			f.EVTcodigo.style.visibility = 'hidden';
			f.Label_EVTcodigo.style.visibility = 'hidden';
		} else {    
			f.EVTcodigo.style.visibility = 'visible';
			f.Label_EVTcodigo.style.visibility = 'visible';
		}
	}  
	*/
	
	function cambioMod(obj){
		var grado1= document.getElementById("sustit1");
		var grado2= document.getElementById("sustit2");
		
		var plan1= document.getElementById("Elect_o_Comp1");
		var plan2= document.getElementById("Elect_o_Comp2");
		
				
		if(obj.value == 'S'){
			objForm.Gcodigo.required = false;
			grado1.style.display = "none";
			grado2.style.display = "none";
			plan1.style.display = "";
			plan2.style.display = "";
			<!---
			<cfif modo EQ "ALTA">
			objForm.EPcodigo.required = true;
			</cfif>
			--->
			objForm.Gcodigo.required = false;
		}else if (obj.value == 'E' || obj.value == 'C' ){
			objForm.EPcodigo.required = false;
			plan1.style.display = "none";
			plan2.style.display = "none";
			grado1.style.display = "";
			grado2.style.display = "";
			<!---
			<cfif modo EQ "ALTA">
			objForm.EPcodigo.required = false;
			</cfif>
			--->
			objForm.Gcodigo.required = true;
		}else{
			grado1.style.display = "";
			grado2.style.display = "";
			objForm.Gcodigo.required = true;
			plan1.style.display = "";
			plan2.style.display = "";
			<!---
			<cfif modo EQ "ALTA">
			objForm.EPcodigo.required = true;
			</cfif>
			--->
			objForm.Gcodigo.required = true;
		}
	}
	
	function crearNuevoTipoMateria(c) {
		if (c.value == "0") {
			c.selectedIndex = 0;
			location.href='MateriaTipo.cfm?RegresarURL=Materias.cfm';
		}
		else if (c.value == "") 
			c.selectedIndex = 0;
	}
	
	function crearNuevoNivel(c) {
		if (c.value == "0") {
			c.selectedIndex = 0;
			location.href='Nivel.cfm?RegresarURL=Materias.cfm';
		}
		else if (c.value == "") 
			c.selectedIndex = 0;
	}
	
	function crearNuevoGrado(c) {
		if (c.value == "0") {
			c.selectedIndex = 0;
			location.href='Grado.cfm?RegresarURL=Materias.cfm';
		}
		else if (c.value == "") 
			c.selectedIndex = 0;
	}

	function crearNuevaTablaEval(c) {
		if (c.value == "0") {
			c.selectedIndex = 0;
			location.href='tablaEvaluac.cfm?RegresarURL=Materias.cfm';
		}
		else if (c.value == "") 
			c.selectedIndex = 0;
	}
	
	function crearNuevoPlanEvaluacion(c) {
		if (c.value == "0") {
			c.selectedIndex = 0;
			location.href='PlanEvaluacion.cfm?RegresarURL=Materias.cfm';
		}
		else if (c.value == "") {
			c.selectedIndex = 0;
		}
		/*
		else if (c.value != "") {
			genEvaluaciones(c.value);
		}
		*/
	}

	<cfif modo NEQ "ALTA">
	function irADetalle(f) {
		f.action='MateriaDetalle.cfm?Mconsecutivo=' + '<cfoutput>#Form.Mconsecutivo#</cfoutput>';
		f.submit();
	}
	</cfif>

	var gradostext = new Array();
	var grados = new Array();
	var niveles = new Array();

    // Esta funci�n �nicamente debe ejecutarlo una vez
	function obtenerGrados(f) {
        for(i=0; i<f.FGcodigo.length; i++) {
			var s = f.FGcodigo.options[i].value.split("|");
            // C�digos de los detalles
            niveles[i]= s[0];
			grados[i] = s[1];
			gradostext[i] = f.FGcodigo.options[i].text;
        }
	}
	
    function cargarGrados(csource, ctarget, vdefault, t){
		// Limpiar Combo
		for (var i=ctarget.length-1; i >=0; i--) {
			ctarget.options[i]=null;
		}
		var k = csource.value;
		var j = 0;
		if (t) {
			var nuevaOpcion = new Option("Todos","-1");
			ctarget.options[j]=nuevaOpcion;
			j++;
		}
		if (k != "-1") {
			for (var i=0; i<grados.length; i++) {
				if (niveles[i] == k) {
					nuevaOpcion = new Option(gradostext[i],grados[i]);
					ctarget.options[j]=nuevaOpcion;
					if (vdefault != null && grados[i] == vdefault) {
						ctarget.selectedIndex = j;
					}
					j++;
				}
			}
		} else {
			for (var i=0; i<grados.length; i++) {
				nuevaOpcion = new Option(gradostext[i],grados[i]);
				ctarget.options[i+1]=nuevaOpcion;
				if (vdefault != null && grados[i] == vdefault) {
					ctarget.selectedIndex = i+1;
				}
			}
		}
		if (!t) {
			var j = ctarget.length;
			nuevaOpcion = new Option("-------------------","");
			ctarget.options[j++]=nuevaOpcion;
			nuevaOpcion = new Option("Crear Nuevo ...","0");
			ctarget.options[j]=nuevaOpcion;
		}
    }
	
	function MateriaActiva()
	 {
	 //alert(document.form1.Mactiva1.checked);		
		 if(!document.form1.Mactiva1.checked ) 
		 {
			 document.form1.Mactiva.value=0;        	
		 }
		 else
		 {
			 document.form1.Mactiva.value=1;     	
		 }
		//alert(form.Mactiva.value);
	 }
	 
	 function validaForm(f) {
		f.Ncodigo.obj.disabled = false;
		return true;
	 }
	
</script>

<form action="SQLMaterias.cfm" method="post" name="form1" onSubmit="return validaForm(this);">
  <cfif isdefined("Form.FNcodigo")>
  	 <input type="hidden" name="FNcodigo" value="<cfoutput>#Form.FNcodigo#</cfoutput>">
  </cfif>
  <cfif isdefined("Form.FGcodigo")>
  	 <input type="hidden" name="FGcodigo" value="<cfoutput>#Form.FGcodigo#</cfoutput>">
  </cfif>
  <cfif isdefined("Form.FMcodigo")>
  	 <input type="hidden" name="FMcodigo" value="<cfoutput>#Form.FMcodigo#</cfoutput>">
  </cfif>
  <cfif isdefined("Form.FMTcodigo")>
  	 <input type="hidden" name="FMTcodigo" value="<cfoutput>#Form.FMTcodigo#</cfoutput>">
  </cfif>
  <cfif isdefined("Form.FMnombre")>
  	 <input type="hidden" name="FMnombre" value="<cfoutput>#Form.FMnombre#</cfoutput>">
  </cfif>
  <cfif isdefined("Form.FMelectiva")>
  	 <input type="hidden" name="FMelectiva" value="<cfoutput>#Form.FMelectiva#</cfoutput>">
  </cfif>
  <table border="0" width="100%" align="center">
    <tr> 
      <td class="tituloMantenimiento" colspan="4" align="center"><font size="3"> 
        <cfif modo eq "ALTA">
          Nueva Materia 
          <cfelse>
          Modificar Materia 
        </cfif>
        </font></td>
    </tr>
    <tr> 
      <td colspan="4" align="right" valign="top" nowrap>&nbsp;</td>
    <tr> 
      <td align="right" valign="middle" nowrap>* C&oacute;digo</td>
      <td valign="middle" nowrap> 
        <cfif modo NEQ "ALTA">
          <cfoutput>#rsMateria.Mcodigo#</cfoutput> 
          <cfelse>
          <input name="Mcodigo" type="text" value="" size="10" maxlength="10" tabindex="1" alt="El c�digo de la Materia">
        </cfif>
      </td>
      <td align="right" valign="middle" nowrap>* Nombre</td>
      <td valign="middle" nowrap> 
        <input name="Mnombre" type="text" value="<cfif modo NEQ "ALTA"><cfoutput>#rsMateria.Mnombre#</cfoutput></cfif>" size="30" maxlength="255" tabindex="1" alt="La descripci&oacute;n del Nivel">
      </td>
    <tr> 
      <td align="right" valign="middle" nowrap>* Tipo Materia</td>
      <td valign="middle" nowrap> 
        <select name="MTcodigo" id="MTcodigo" tabindex="1" onChange="javascript: crearNuevoTipoMateria(this);">
          <cfoutput query="rsMateriaTipo"> 
            <option value="#MTcodigo#" <cfif modo NEQ "ALTA" AND rsMateria.MTcodigo EQ rsMateriaTipo.MTcodigo>selected</cfif>>#MTdescripcion#</option>
          </cfoutput> 
          <option value="">-------------------</option>
          <option value="0">Crear Nuevo ...</option>
        </select>
      </td>
      <td align="right" valign="middle" nowrap>* Modalidad</td>
      <td valign="middle" nowrap> 
        <select name="Melectiva" tabindex="1" onChange="javascript: cambioMod(this)">
          <option value="R" <cfif modo NEQ "ALTA" AND "R" EQ rsMateria.Melectiva>selected</cfif>>Regular</option>
          <option value="S" <cfif modo NEQ "ALTA" AND "S" EQ rsMateria.Melectiva>selected</cfif>>Sustitutiva</option>
          <option value="E" <cfif modo NEQ "ALTA" AND "E" EQ rsMateria.Melectiva>selected</cfif>>Electiva</option>
          <option value="C" <cfif modo NEQ "ALTA" AND "C" EQ rsMateria.Melectiva>selected</cfif>>Complementaria</option>
        </select>
        <cfif modo NEQ "ALTA">
          <input name="MelectivaAnterior" type="hidden" id="MelectivaAnterior" value="<cfoutput>#rsMateria.Melectiva#</cfoutput>">
          <input name="NumAsociadas" type="hidden" id="NumAsociadas" value="<cfoutput>#rsAsociadas.asociadas#</cfoutput>">
        </cfif>
      </td>
    </tr>
    <tr> 
      <td align="right" valign="middle" nowrap>Tipo de Evaluaci&oacute;n</td>
      <td valign="middle" nowrap> 
        <!---
        <select name="Mtipoevaluacion" tabindex="2" onChange="javascript: OcultaTablaEval(this.form);">
          <option value="0" <cfif (isDefined("rsMateria.Mtipoevaluacion") AND "0" EQ rsMateria.Mtipoevaluacion)>selected</cfif>>Porcentual</option>
          <option value="1" <cfif (isDefined("rsMateria.Mtipoevaluacion") AND "1" EQ rsMateria.Mtipoevaluacion)>selected</cfif>>Tabla 
          de Valores</option>
        </select>
		--->
        <select name="Mtipoevaluacion" id="Mtipoevaluacion" onChange="javascript: crearNuevaTablaEval(this);" tabindex="1">
          <option value="-1" <cfif (isDefined("rsMateria.Mtipoevaluacion") AND "0" EQ rsMateria.Mtipoevaluacion)>selected</cfif>>-- 
          Digitar Nota --</option>
          <cfoutput query="rsEvaluacionValoresTabla"> 
            <option value="#EVTcodigo#" <cfif modo NEQ "ALTA" AND rsMateria.EVTcodigo EQ rsEvaluacionValoresTabla.EVTcodigo>selected</cfif>>Usar 
            Tabla: #EVTnombre#</option>
          </cfoutput> 
          <option value="">-------------------</option>
          <option value="0">Crear Nueva Tabla ...</option>
        </select>
      </td>
      <td align="right" valign="middle" nowrap> 
        <div id="Elect_o_Comp1">
			<input name="ConceptosEval" type="hidden" id="ConceptosEval2">
    	   	Plan de Evaluaci�n
		</div>
	  </td>
      <td valign="middle" nowrap> 
		  <div id="Elect_o_Comp2">
			<select name="EPcodigo" id="select" tabindex="1" onChange="javascript: crearNuevoPlanEvaluacion(this);" <cfif modo NEQ "ALTA">disabled</cfif>>
			  <option value="">(Seleccione un Plan de Evaluaci�n)</option>
			  <cfoutput query="rsPlanesEval"> 
				<option value="#EPcodigo#" <cfif modo NEQ "ALTA" AND rsMateria.EPcodigo EQ rsPlanesEval.EPcodigo>selected</cfif>>#EPnombre#</option>
			  </cfoutput> 
			  <option value="">-------------------</option>
			  <option value="0">Crear Nuevo ...</option>
			</select>
		  </div>	
      </td>
    </tr>
    <tr> 
      <td align="right" valign="middle" nowrap>* Nivel</td>
      <td valign="middle" nowrap> 
        <select name="Ncodigo" id="Ncodigo" tabindex="1" onchange="javascript: crearNuevoNivel(this); cargarGrados(this, this.form.Gcodigo, '<cfif modo NEQ "ALTA"><cfoutput>#rsMateria.Gcodigo#</cfoutput></cfif>', false)" >
          <cfoutput query="rsNiveles"> 
            <option value="#Ncodigo#" <cfif modo NEQ "ALTA" AND rsMateria.Ncodigo EQ rsNiveles.Ncodigo>selected</cfif>>#Ndescripcion#</option>
          </cfoutput> 
          <option value="">-------------------</option>
          <option value="0">Crear Nuevo ...</option>
        </select>
      </td>
      <td align="right" valign="middle" nowrap><div id="sustit1">* Grado</div></td>
      <td valign="middle" nowrap>
	  	<div id="sustit2">
        <select name="Gcodigo" id="Gcodigo" tabindex="1" onchange="javascript: crearNuevoGrado(this);">
          <cfoutput query="rsGrado"> 
            <option value="#Codigo#">#rsGrado.Gdescripcion#</option>
          </cfoutput> 
          <option value="">-------------------</option>
          <option value="0">Crear Nuevo ...</option>
        </select>
		</div>
      </td>
    </tr>
    <tr> 
      <td align="right" valign="middle" nowrap>Cr&eacute;ditos</td>
      <td valign="middle" nowrap> 
        <input name="Mcreditos" type="text" tabindex="1" value="<cfif modo NEQ "ALTA"><cfoutput>#rsMateria.Mcreditos#</cfoutput></cfif>" size="8" maxlength="3" style="text-align: right;" alt="Los cr�ditos de la Materia"  onBlur="javascript: fm(this,0);" onFocus="javascript: this.value=qf(this); this.select();" onKeyUp="javascript: if(snumber(this,event,0)){ if(Key(event)=='13') {this.blur();}}">
      </td>
      <td align="right" valign="middle" nowrap>Horas</td>
      <td valign="middle" nowrap> 
        <input name="Mhoras" type="text" tabindex="1" value="<cfif modo NEQ "ALTA"><cfoutput>#rsMateria.Mhoras#</cfoutput></cfif>" size="8" maxlength="3" style="text-align: right;" alt="Las Horas de la Materia"  onBlur="javascript: fm(this,0);" onFocus="javascript: this.value=qf(this); this.select();" onKeyUp="javascript: if(snumber(this,event,0)){ if(Key(event)=='13') {this.blur();}}">
      </td>
      <!--- <cfif modo NEQ "ALTA" and rsHayGrupos.recordCount NEQ 0>disabled</cfif> --->
    </tr>
    <tr>
      <td align="right" valign="middle" nowrap>Orden</td>
      <td valign="middle" nowrap> 
        <input name="Morden" type="text" id="Morden" tabindex="1" size="8" maxlength="8" value="<cfif modo NEQ "ALTA"><cfoutput>#rsMateria.Morden#</cfoutput></cfif>" onfocus="javascript:this.value=qf(this); this.select();" onblur="javascript:fm(this,0);"  onkeyup="javascript:if(snumber(this,event,0)){ if(Key(event)=='13') {this.blur();}}" style="text-align: right;">
      </td>
      <td align="right" valign="middle" nowrap>Activa</td>
      <td valign="middle" nowrap><input type="checkbox" name="Mactiva1"  value="<cfif modo NEQ "ALTA"><cfoutput>#rsMateria.Mactiva#</cfoutput></cfif>" 
	  <cfif modo NEQ "ALTA"><cfif #rsMateria.Mactiva# EQ 1> checked </cfif><cfelseif modo EQ "ALTA"> checked</cfif>
	  size="32"   onClick="javascript:MateriaActiva();"></td>
    </tr>
    <tr> 
      <td align="right" valign="top" nowrap>Observaciones </td>
      <td valign="top" nowrap> 
        <textarea name="Mobservaciones" cols="30" rows="3" id="Mobservaciones" tabindex="1"><cfif modo NEQ "ALTA"><cfoutput>#Trim(rsMateria.Mobservaciones)#</cfoutput></cfif></textarea>
      </td>
      <td align="right" valign="top" nowrap>Reglamentos </td>
      <td valign="top" nowrap> 
        <textarea name="Mreglamentos" cols="30" rows="3" id="Mreglamentos" tabindex="1"><cfif modo NEQ "ALTA"><cfoutput>#rsMateria.Mreglamentos#</cfoutput></cfif></textarea>
      </td>
    </tr>
    <tr> 
      <td colspan="4" align="right" valign="middle" nowrap>&nbsp;</td>
    </tr>
    <tr> 
      <td colspan="4" align="center" valign="baseline" nowrap> 
        <cfinclude template="../../portlets/pBotones.cfm">
        <cfif modo NEQ "ALTA">
		  <cfif rsMateria.Melectiva EQ "R" or rsMateria.Melectiva EQ "S">
          <input type="button" name="Detalle" value="Detalle" onClick="javascript: irADetalle(this.form);">
		  </cfif>
		  <cfoutput>
			  <input type="hidden" name="Mconsecutivo" value="#rsMateria.Mconsecutivo#">
			  <input type="hidden" name="HayCurso" value="#rsHayCurso.recordCount#">
			  <input type="hidden" name="HayMateriaElectiva" value="#rsHayMateriaElectiva.recordCount#">
			  <input type="hidden" name="HayMateriaElectiva2" value="#rsHayMateriaElectiva2.recordCount#">
			  <input type="hidden" name="HayGradoSustitutivas" value="#rsHayGradoSustitutivas.recordCount#">
  			  <input type="hidden" name="HayEvaluacionConceptoMateria" value="#rsHayEvaluacionConceptoMateria.recordCount#">
			  
		  </cfoutput>
        </cfif>
			<input type="hidden" name="Mactiva" value="<cfif #modo# NEQ "ALTA"><cfoutput>#rsMateria.Mactiva#</cfoutput></cfif>">
		  <input type="submit" name="Buscar" value="Buscar" onClick="javascript: deshabilitarValidacion();">
      </td>
    </tr>
    <tr> 
      <td colspan="4" align="center" valign="middle" nowrap>Nota: Las b�squedas funcionan para campos con un (*)</td>
    </tr>
  </table>
 
 </form>
 <form action="Materias.cfm" method="post" name="FiltroMaterias">
	
  <table class="areaFiltro" width="100%" border="0" cellpadding="0" cellspacing="0">
    <tr> 
      <td nowrap class="subTitulo">Nivel</td>
      <td nowrap class="subTitulo">Grado</td>
      <td nowrap class="subTitulo">C&oacute;digo</td>
      <td nowrap class="subTitulo">Tipo de Materia</td>
      <td nowrap class="subTitulo">Nombre</td>
      <td nowrap class="subTitulo">Modalidad</td>
      <td nowrap>&nbsp;</td>
    </tr>
    <tr> 
      <td nowrap> 
        <select name="FNcodigo" id="FNcodigo" tabindex="5" onChange="javascript: cargarGrados(this, this.form.FGcodigo, '<cfif isdefined("Form.FGcodigo")><cfoutput>#Form.FGcodigo#</cfoutput></cfif>', true)">
          <option value="-1">Todos</option>
          <cfoutput query="rsNiveles"> 
            <option value="#Ncodigo#" <cfif isdefined("Form.FNcodigo") AND (Form.FNcodigo EQ rsNiveles.Ncodigo)>selected</cfif>>#Ndescripcion#</option>
          </cfoutput> 
        </select>
      </td>
      <td nowrap> 
        <select name="FGcodigo" id="FGcodigo" tabindex="5">
          <cfoutput query="rsGrado"> 
            <option value="#Codigo#">#Gdescripcion#</option>
          </cfoutput> 
        </select>
      </td>
      <td nowrap> 
        <input name="FMcodigo" type="text" size="10" maxlength="10" tabindex="5" value="<cfif isdefined("Form.FMcodigo")><cfoutput>#Form.FMcodigo#</cfoutput></cfif>">
      </td>
      <td nowrap>
        <select name="FMTcodigo" id="FMTcodigo" tabindex="1">
          <option value="-1">Todos</option>
          <cfoutput query="rsMateriaTipo"> 
            <option value="#MTcodigo#" <cfif isdefined("Form.FMTcodigo") and Form.FMTcodigo EQ rsMateriaTipo.MTcodigo>selected</cfif>>#MTdescripcion#</option>
          </cfoutput> 
        </select>
	  </td>
      <td nowrap> 
        <input name="FMnombre" type="text" maxlength="255" tabindex="5" value="<cfif isdefined("Form.FMnombre")><cfoutput>#Form.FMnombre#</cfoutput></cfif>">
      </td>
      <td nowrap> 
        <select name="FMelectiva" tabindex="5">
          <option value="-1">Todas</option>
          <option value="R" <cfif isDefined("Form.FMelectiva") AND Form.FMelectiva EQ "R">selected</cfif>>Regular</option>
          <option value="S" <cfif isDefined("Form.FMelectiva") AND Form.FMelectiva EQ "S">selected</cfif>>Sustitutiva</option>
          <option value="E" <cfif isDefined("Form.FMelectiva") AND Form.FMelectiva EQ "E">selected</cfif>>Electiva</option>
          <option value="C" <cfif isDefined("Form.FMelectiva") AND Form.FMelectiva EQ "C">selected</cfif>>Complementaria</option>
        </select>
      </td>
      <td align="center" nowrap> 
	  
        <input type="submit" name="Filtrar" tabindex="5" value="Buscar">
      </td>
    </tr>
  </table>
 </form>
 <cfset filtro = "">
 <cfset navegacion = "">
 <cfset f1 = "-1">
 <cfset f2 = "-1">
 <cfset f3 = "">
 <cfset f4 = "-1">
 <cfset f5 = "">
 <cfset f6 = "-1">
 <cfif isdefined("Form.FNcodigo") and Form.FNcodigo NEQ -1>
 	<cfset filtro = filtro & " and c.Ncodigo = " & Form.FNcodigo>
	<cfset f1 = Form.FNcodigo>
	<cfset navegacion = "FNcodigo=" & Form.FNcodigo>
 </cfif>
 <cfif isdefined("Form.FGcodigo") and Form.FGcodigo NEQ -1>
 	<cfset filtro = filtro & " and c.Gcodigo = " & Form.FGcodigo>
	<cfset f2 = Form.FGcodigo>
	<cfset navegacion = navegacion & Iif(Len(Trim(navegacion)) NEQ 0, DE("&"), DE("")) & "FGcodigo=" & Form.FGcodigo>
 </cfif>
 <cfif isdefined("Form.FMcodigo") and Len(Trim(Form.FMcodigo)) NEQ 0>
 	<cfset filtro = filtro & " and upper(c.Mcodigo) like '%" & #UCase(Form.FMcodigo)# & "%'">
	<cfset f3 = Form.FMcodigo>
	<cfset navegacion = navegacion & Iif(Len(Trim(navegacion)) NEQ 0, DE("&"), DE("")) & "FMcodigo=" & Form.FMcodigo>
 </cfif>
 <cfif isdefined("Form.FMTcodigo") and Form.FMTcodigo NEQ -1>
 	<cfset filtro = filtro & " and c.MTcodigo = " & Form.FMTcodigo>
	<cfset f4 = Form.FMTcodigo>
	<cfset navegacion = navegacion & Iif(Len(Trim(navegacion)) NEQ 0, DE("&"), DE("")) & "FMTcodigo=" & Form.FMTcodigo>
 </cfif>
 <cfif isdefined("Form.FMnombre") and Len(Trim(Form.FMnombre)) NEQ 0>
 	<cfset filtro = filtro & " and upper(c.Mnombre) like '%" & #UCase(Form.FMnombre)# & "%'">
	<cfset f5 = Form.FMnombre>
	<cfset navegacion = navegacion & Iif(Len(Trim(navegacion)) NEQ 0, DE("&"), DE("")) & "FMnombre=" & Form.FMnombre>
 </cfif>
 <cfif isdefined("Form.FMelectiva") and Form.FMelectiva NEQ "-1">
 	<cfset filtro = filtro & " and c.Melectiva = '" & #UCase(Form.FMelectiva)# & "'">
	<cfset f6 = Form.FMelectiva>
	<cfset navegacion = navegacion & Iif(Len(Trim(navegacion)) NEQ 0, DE("&"), DE("")) & "FMelectiva=" & Form.FMelectiva>
 </cfif>

<cfinvoke component="edu.Componentes.pListas" method="pListaEdu" returnvariable="pListaRet">
	<cfinvokeargument name="tabla" value="Nivel a, Grado b, Materia c, MateriaTipo d"/>
	<cfinvokeargument name="columnas" value="'#f1#' as FNcodigo, '#f2#' as FGcodigo, '#f3#' as FMcodigo, '#f4#' as FMTcodigo, '#f5#' as FMnombre, '#f6#' as FMelectiva, convert(varchar, c.Ncodigo) as Ncodigo, convert(varchar, c.Gcodigo) as Gcodigo, c.Mcodigo as Mcodigo, convert(varchar, c.Mconsecutivo) as Mconsecutivo, substring(c.Mnombre,1,35) as Mnombre, a.Ndescripcion+': '+(case when c.Gcodigo is null then 'Sustitutivas' else b.Gdescripcion end) as Grado, case c.Melectiva when 'R' then 'Regular' when 'S' then 'Sustitutiva' when 'E' then 'Electiva' when 'C' then 'Complementaria' else '' end as Melectiva, c.Morden as Morden, d.MTdescripcion"/>
	<cfinvokeargument name="desplegar" value="Mcodigo, Mnombre, Melectiva, MTdescripcion, Morden"/>
	<cfinvokeargument name="etiquetas" value="Codigo, Materia, Modalidad, Tipo de Materia, Orden"/>
	<cfinvokeargument name="formatos" value=""/>
	<cfinvokeargument name="filtro" value=" a.CEcodigo = #Session.CEcodigo# and a.Ncodigo = c.Ncodigo and b.Ncodigo =* c.Ncodigo and b.Gcodigo =* c.Gcodigo and c.MTcodigo = d.MTcodigo #filtro# order by a.Norden, b.Gorden, c.Morden, c.Mcodigo, c.Mnombre, d.MTdescripcion"/>
	<cfinvokeargument name="align" value="left,left,left,left,left"/>
	<cfinvokeargument name="ajustar" value="N,N,N,N,N"/>
	<cfinvokeargument name="irA" value="Materias.cfm"/>
	<cfinvokeargument name="cortes" value="Grado"/>
	<cfinvokeargument name="navegacion" value="#navegacion#"/>
	<cfinvokeargument name="debug" value="N"/>
</cfinvoke>

<script language="JavaScript" type="text/JavaScript">

	//OcultaTablaEval(document.form1);
	obtenerGrados(document.FiltroMaterias);
	cargarGrados(document.FiltroMaterias.FNcodigo, document.FiltroMaterias.FGcodigo, '<cfif isdefined("Form.FGcodigo")><cfoutput>#Form.FGcodigo#</cfoutput></cfif>', true);
	cargarGrados(document.form1.Ncodigo, document.form1.Gcodigo, '<cfif modo NEQ "ALTA"><cfoutput>#rsMateria.Gcodigo#</cfoutput></cfif>', false);

	function habilitarValidacion() {
		<cfif modo EQ "ALTA">
			objForm.Mcodigo.required = true;
			objForm.Mnombre.required = true;
			objForm.MTcodigo.required = true;
			objForm.Ncodigo.required = true;
			objForm.Gcodigo.required = true;
			objForm.Mhoras.required = true;
			objForm.Mcreditos.required = true;
			objForm.Mtipoevaluacion.required = true;
			objForm.EPcodigo.required = true;
		<cfelseif modo EQ "CAMBIO">
			objForm.Mnombre.required = true;
			objForm.MTcodigo.required = true;
			objForm.Ncodigo.required = true;
			objForm.Gcodigo.required = true;
			objForm.Mhoras.required = true;
			objForm.Mcreditos.required = true;
			objForm.Mtipoevaluacion.required = true;
		</cfif>
	}

	function deshabilitarValidacion() {
		<cfif modo EQ "ALTA">
			objForm.Mcodigo.required = false;
			objForm.Mnombre.required = false;
			objForm.MTcodigo.required = false;
			objForm.Ncodigo.required = false;
			objForm.Gcodigo.required = false;
			objForm.Mhoras.required = false;
			objForm.Mcreditos.required = false;
			objForm.Mtipoevaluacion.required = false;
			objForm.EPcodigo.required = false;
		<cfelseif modo EQ "CAMBIO">
			objForm.Mnombre.required = false;
			objForm.MTcodigo.required = false;
			objForm.Ncodigo.required = false;
			objForm.Gcodigo.required = false;
			objForm.Mhoras.required = false;
			objForm.Mcreditos.required = false;
			objForm.Mtipoevaluacion.required = false;
		</cfif>
	}

    // Se aplica la descripcion del Grado 
	function __isTieneDependencias() {
		if(btnSelected("Baja", this.obj.form)) {
				// Valida que el Grado no tenga dependencias con otros.
				var msg = "";
				//alert(new Number(this.obj.form.HayCurso.value));
				if (new Number(this.obj.form.HayCurso.value) > 0) {
					msg = msg + "curso"
				}
				//alert(new Number(this.obj.form.HayMateriaElectiva.value));
				/*
				if (new Number(this.obj.form.HayMateriaElectiva.value) > 0) {
					if (msg != "") msg += ', ';
					msg = msg + "Materia Electiva (Mconsecutivo)"
				}
				if (new Number(this.obj.form.HayMateriaElectiva2.value) > 0) {
					if (msg != "") msg += ', ';
					msg = msg + "Materia Electiva (MElectiva) "
				}
				if (new Number(this.obj.form.HayGradoSustitutivas.value) > 0) {
					if (msg != "") msg += ', ';
					msg = msg + "Materias Sustitutivas-Grados"
				}
				if (new Number(this.obj.form.HayEvaluacionConceptoMateria.value) > 0) {
					if (msg != "") msg += ', ';
					msg = msg + "Materias En Conceptos de Evaluaci�n"
				}
				*/

				if (msg != "")
				{
					this.error = "Usted no puede eliminar la Materia " + this.obj.form.Mnombre.value + " porque �ste tiene asociado: " + msg + ".";
					this.obj.form.Mnombre.focus();
				}
		}
	}

	function __isMateriasAsociadas() {
		if (btnSelected("Cambio", this.obj.form)) {
			if ((this.obj.form.MelectivaAnterior.value=='E' || this.obj.form.MelectivaAnterior.value =='S' || this.obj.form.MelectivaAnterior.value =='C') 
					&& (new Number(this.obj.form.NumAsociadas.value) > 0) && (this.obj.form.MelectivaAnterior.value != this.obj.form.Melectiva.value)) {
				this.error = "Esta materia no puede cambiar de modalidad porque ya tiene materias asociadas";
				if (this.obj.form.MelectivaAnterior.value == 'C') {
					this.obj.form.Melectiva.selectedIndex = 3;
				} else if (this.obj.form.MelectivaAnterior.value == 'E') {
					this.obj.form.Melectiva.selectedIndex = 2;
				} else if (this.obj.form.MelectivaAnterior.value == 'S') {
					this.obj.form.Melectiva.selectedIndex = 1;
				} else {
					this.obj.form.Melectiva.selectedIndex = 0;
				}
			}
		}
	}
	
	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isMateriasAsociadas", __isMateriasAsociadas);
	_addValidator("isTieneDependencias", __isTieneDependencias);
	objForm = new qForm("form1");

	<cfif modo EQ "ALTA">
		objForm.Mcodigo.obj.focus();
		objForm.Mcodigo.required = true;
		objForm.Mcodigo.description = "C�digo de Materia";
		objForm.Mnombre.required = true;
		objForm.Mnombre.description = "Nombre de Materia";
		objForm.MTcodigo.required = true;
		objForm.MTcodigo.description = "Tipo de Materia";
		objForm.Ncodigo.required = true;
		objForm.Ncodigo.description = "Nivel";
		objForm.Gcodigo.required = true;
		objForm.Gcodigo.description = "Grado";
		objForm.Mhoras.required = true;
		objForm.Mhoras.description = "Horas";
		objForm.Mcreditos.required = true;
		objForm.Mcreditos.description = "Cr�ditos";
		objForm.Mtipoevaluacion.required = true;
		objForm.Mtipoevaluacion.description = "Tipo de Evaluaci�n";
		objForm.EPcodigo.required = true;
		objForm.EPcodigo.description = "Plan de Evaluaci�n";
	<cfelseif modo EQ "CAMBIO">
		objForm.Mnombre.required = true;
		objForm.Mnombre.description = "Nombre de Materia";
		objForm.Mnombre.validateTieneDependencias();
		objForm.MTcodigo.required = true;
		objForm.MTcodigo.description = "Tipo de Materia";
		objForm.Ncodigo.required = true;
		objForm.Ncodigo.description = "Nivel";
		objForm.Gcodigo.required = true;
		objForm.Gcodigo.description = "Grado";
		objForm.Melectiva.description = "Modalidad";
		objForm.Melectiva.validateMateriasAsociadas();
		objForm.Mhoras.required = true;
		objForm.Mhoras.description = "Horas";
		objForm.Mcreditos.required = true;
		objForm.Mcreditos.description = "Cr�ditos";
		objForm.Mtipoevaluacion.required = true;
		objForm.Mtipoevaluacion.description = "Tipo de Evaluaci�n";
		objForm.EPcodigo.description = "Plan de Evaluaci�n";
	</cfif>

	cambioMod(document.form1.Melectiva);
	MateriaActiva(document.form1.Mactiva1);
	<cfif modo NEQ "ALTA">
		document.form1.Ncodigo.disabled = true;
	</cfif>
</script>
