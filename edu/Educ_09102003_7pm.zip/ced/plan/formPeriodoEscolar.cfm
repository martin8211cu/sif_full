<cfif isdefined("Form.Cambio")>
  <cfset modo="CAMBIO">
  <cfelse>
  <cfif not isdefined("Form.modo")>
    <cfset modo="ALTA">
    <cfelseif #Form.modo# EQ "CAMBIO">
    <cfset modo="CAMBIO">
    <cfelse>
    <cfset modo="ALTA">
  </cfif>
</cfif>

<cfquery datasource="#Session.DSN#" name="rsNiveles">
	select convert(varchar, Ncodigo) as Ncodigo, Ndescripcion 
	from Nivel 
	where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
	and Ncodigo not in (
			select 	b.Ncodigo
			from PeriodoEscolar a, Nivel b
			where b.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
			and a.Ncodigo = b.Ncodigo
			<cfif modo EQ "CAMBIO">
			and a.PEcodigo != <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
			</cfif>
			)
</cfquery>

<cfif modo NEQ "ALTA">
	<cfif isdefined("Form.PEcodigo") and len(trim("Form.PEcodigo")) NEQ 0>
		<cfquery datasource="#Session.DSN#" name="rsPeriodoEscolar">
			select PEcodigo, PEdescripcion, Ncodigo, PEorden from PeriodoEscolar 
			where PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
		</cfquery>
	</cfif>
<cfquery datasource="#Session.DSN#" name="rsHaySubPeriodoEscolar">
		select 1 from SubPeriodoEscolar 
		where PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
	</cfquery>
</cfif>

<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" type="text/JavaScript">
	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
	
	function validaForm(f) {
		if (f.Ncodigo.obj.disabled) {
			f.Ncodigo.obj.disabled = false;
		}
		return true;
	}
		function crearNuevoNivel(c) {
		if (c.value == "0") {
			c.selectedIndex = 0;
			location.href='Nivel.cfm?RegresarURL=PeriodoEscolar.cfm';
		}
		else if (c.value == "") 
			c.selectedIndex = 0;
	}
</script>

 
<form action="SQLPeriodoEscolar.cfm" method="post" name="form1" onSubmit="javascript:return validaForm(this);">
  <table width="100%" align="center">
    <tr> 
      <td class="tituloMantenimiento" colspan="2" align="center"><font size="3"> 
        <cfif modo eq "ALTA">
          Nuevo Tipo de Curso Lectivo 
          <cfelse>
          Modificar Tipo de Curso Lectivo 
        </cfif>
        </font></td>
    </tr>
    <tr valign="baseline"> 
      <td width="291" align="right" valign="middle" nowrap>Descripci�n</td>
      <td width="361"><input name="PEdescripcion" onfocus="javascript:this.select();"  type="text" value="<cfif modo NEQ "ALTA"><cfoutput>#rsPeriodoEscolar.PEdescripcion#</cfoutput></cfif>" size="50" maxlength="255" alt="La descripci&oacute;n del Nivel"> 
      </td>
    <tr valign="baseline"> 
      <td nowrap align="right">Nivel:</td>
      <td><select name="Ncodigo" id="Ncodigo" onChange="javascript: crearNuevoNivel(this);" <cfif modo NEQ "ALTA" and (rsHaySubPeriodoEscolar.recordCount NEQ 0)>disabled</cfif>>
          <cfoutput query="rsNiveles"> 
            <option value="#rsNiveles.Ncodigo#" <cfif modo NEQ "ALTA" and rsPeriodoEscolar.Ncodigo eq rsNiveles.Ncodigo>selected<cfelseif isdefined("Form.Ncodigo") AND form.Ncodigo EQ rsNiveles.Ncodigo>selected</cfif>>#rsNiveles.Ndescripcion# 
            </option>
          </cfoutput> 
          <option value="">-------------------</option>
          <option value="0">Crear Nuevo ...</option>
        </select></td>
    </tr>
    <tr valign="baseline"> 
      <td nowrap align="right">Orden</td>
      <td><input name="PEorden" align="left" type="text" id="PEorden" size="8" maxlength="8" style="text-align: right;" value="<cfif modo NEQ "ALTA"><cfoutput>#rsPeriodoEscolar.PEorden#</cfoutput></cfif>" onfocus="javascript:this.value=qf(this); this.select();" onblur="javascript:fm(this,0);"  onkeyup="javascript:if(snumber(this,event,0)){ if(Key(event)=='13') {this.blur();}}" > 
      </td>
    </tr>
    <tr valign="baseline"> 
      <td colspan="2" align="center" nowrap><cfinclude template="../../portlets/pBotones.cfm"> 
	  <input type="hidden" name="_Ncodigo" value="<cfif modo NEQ "ALTA"><cfoutput>#rsPeriodoEscolar.Ncodigo#</cfoutput></cfif>">
		<cfif modo NEQ "ALTA">
			<input type="hidden" name="HaySubPeriodoEscolar" value="<cfoutput>#rsHaySubPeriodoEscolar.recordCount#</cfoutput>">
			<input type="hidden" name="PEcodigo" value="<cfoutput>#rsPeriodoEscolar.PEcodigo#</cfoutput>">
		</cfif>
      </td>
    </tr>
  </table>
</form>

<script language="JavaScript">

	function deshabilitarValidacion() {
		objForm.PEdescripcion.required = false;
		objForm.Ncodigo.required = false;
	}
	
	function habilitarValidacion() {
		objForm.PEdescripcion.required = true;
		objForm.Ncodigo.required = true;
	}	
	// Se aplica la descripci�n del Periodo Escolar
	// Rodolfo Jim�nes Jara, SOIN de Costa Rica, 12/12/2002
	function __isTieneDependencias() {
			if (btnSelected("Baja", this.obj.form)) {
				// Valida que el Periodo Escolar no tenga dependencias con otros.
				var msg = "";

				if (new Number(this.obj.form.HaySubPeriodoEscolar.value) > 0) {
					msg = msg + "Cursos Lectivos"
				}
				if (msg != "")
				{
					this.error = "Usted no puede eliminar el Tipo de Curso Lectivo " + this.obj.form.PEdescripcion.value + " porque �ste tiene asociado: " + msg + ".";
					this.obj.form.PEdescripcion.focus();
				}
		}
	}
	
	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isTieneDependencias", __isTieneDependencias);
	objForm = new qForm("form1");

	<cfif modo EQ "ALTA">
		objForm.PEdescripcion.required = true;
		objForm.PEdescripcion.description = "Descripci�n";
		objForm.PEorden.description = "Orden";
		objForm.Ncodigo.required = true;
		objForm.Ncodigo.description = "Nivel";
	<cfelseif modo EQ "CAMBIO">
		objForm.PEdescripcion.required = true;
		objForm.PEdescripcion.description = "Descripci�n";
		objForm.Ncodigo.required = true;
		objForm.Ncodigo.description = "Nivel";
		objForm.PEdescripcion.validateTieneDependencias();
		// Agregar validacion de dependencias
	</cfif>
</script>