<cfif not isdefined("form.Nuevo")>
	<cftry>
		<cfquery name="abc_materiatipo" datasource="#session.DSN#">
			set nocount on
			<cfif isdefined("Form.Alta")>
			if not exists ( select 1 from MateriaTipo   
								where Upper(rtrim(ltrim(MTdescripcion))) = <cfqueryparam value="#Ucase(rtrim(ltrim(form.MTdescripcion)))#" cfsqltype="cf_sql_varchar">
								  and CEcodigo = <cfqueryparam value="#session.CEcodigo#" cfsqltype="cf_sql_numeric">
				)
				begin
					insert MateriaTipo ( CEcodigo, MTdescripcion )
							values( <cfqueryparam value="#session.CEcodigo#"   cfsqltype="cf_sql_numeric">, 
										<cfqueryparam value="#form.MTdescripcion#" cfsqltype="cf_sql_varchar"> 
								  )
				end
				else
				begin
					select 1
				end
				
				<cfset modo="ALTA">
			<cfelseif isdefined("form.Baja")>
				delete MateriaTipo
				where CEcodigo = <cfqueryparam value="#session.CEcodigo#" cfsqltype="cf_sql_numeric">
				  and MTcodigo = <cfqueryparam value="#form.MTcodigo#" cfsqltype="cf_sql_numeric">

				  <cfset modo="ALTA">

			<cfelseif isdefined("form.Cambio")> 

				 update MateriaTipo 
				 set MTdescripcion = <cfqueryparam value="#rtrim(ltrim(form.MTdescripcion))#" cfsqltype="cf_sql_varchar">
				 where CEcodigo = <cfqueryparam value="#session.CEcodigo#" cfsqltype="cf_sql_numeric">
				   and MTcodigo = <cfqueryparam value="#form.MTcodigo#" cfsqltype="cf_sql_numeric">

				  <cfset modo="ALTA">
			</cfif>
			set nocount off
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>
</cfif>

<form action="MateriaTipo.cfm" method="post" name="sql">
	<input name="modo"     type="hidden" value="<cfif isdefined("modo")><cfoutput>#modo#</cfoutput></cfif>">
	<input name="MTcodigo" type="hidden" value="<cfif isdefined("Form.MTcodigo")><cfoutput>#Form.MTcodigo#</cfoutput></cfif>">
	<input name="Pagina"   type="hidden" value="<cfif isdefined("Form.Pagina")><cfoutput>#Form.Pagina#</cfoutput></cfif>">	
</form>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>


