<cfset action = "SubPeriodoEscolar.cfm">

<cfif not isdefined("form.btnNuevoD") and not isdefined("form.btnNuevoE")>
	<cftry>
		<cfset modo="CAMBIO">
		<cfquery name="ABC_SubPeriodoEscolar" datasource="#Session.DSN#">
			set nocount on
			<!--- Caso 1: Agregar Encabezado --->
			<cfif isdefined("Form.btnAgregarE")>
				declare @cont int, @SPEcodigo numeric
				select @cont = isnull(max(a.SPEorden),0)+10 
				from SubPeriodoEscolar a, PeriodoEscolar b, Nivel c 
				where c.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
				  and a.PEcodigo = b.PEcodigo 
				  and b.Ncodigo = c.Ncodigo
				  and a.PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
				
				insert SubPeriodoEscolar (PEcodigo, SPEorden, SPEdescripcion, SPEfechafin , SPEfechainicio )
					values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.PEcodigo#">,
							<cfif #len(trim(Form.SPEorden))# NEQ 0 >
								<cfqueryparam cfsqltype="cf_sql_smallint" value="#form.SPEorden#">,
							<cfelse>
								@cont,	
							</cfif>
							<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.SPEdescripcion#">,
							convert(datetime, <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.SPEfechafin#">, 103),
							convert(datetime, <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.SPEfechainicio#">, 103) 
							)
				select @SPEcodigo = @@identity
				
				<!--- Rutina dada por el Ing. Oscar Bonilla, MBA, SOIN Costa Rica, 18/12/2002 --->
				insert into PeriodoOcurrencia (SPEcodigo, PEcodigo, PEevaluacion, POfechainicio,POfechafin,POvigente)
				select sp.SPEcodigo, sp.PEcodigo, pe.PEcodigo,
						-- POfechainicio: inicio+(final-inicio+1)/N*(i-1), donde N=CantidadPeriodos, i=ConsecutivoPeriodo
				dateadd(dd,	convert(int,(datediff(dd,sp.SPEfechainicio,sp.SPEfechafin)+1.0)*1.0 /(select count(*)*1.0
				from PeriodoEvaluacion N
				where N.Ncodigo = p.Ncodigo) * (select count(*)*1.0 
												from PeriodoEvaluacion i
												where i.Ncodigo = p.Ncodigo
												  and (i.PEorden < pe.PEorden
												  or (i.PEorden = pe.PEorden and i.PEcodigo < pe.PEcodigo))
												)
				), 
				sp.SPEfechainicio),
				-- POfechafin: inicio+((final-inicio+1)/N*(i-0) - 1), donde N=CantidadPeriodos, i=ConsecutivoPeriodo
				dateadd(dd, convert(int,(datediff(dd,sp.SPEfechainicio,sp.SPEfechafin)+1.0)*1.0 
				/(select count(*)*1.0
				from PeriodoEvaluacion N
				where N.Ncodigo = p.Ncodigo
				)
				*(select count(*)*1.0
				from PeriodoEvaluacion i
				where i.Ncodigo = p.Ncodigo
				and (i.PEorden < pe.PEorden
				or (i.PEorden = pe.PEorden and i.PEcodigo <=
				pe.PEcodigo))
				)
				) - 1, sp.SPEfechainicio),
				-- POvigente: Para uso futuro
				0
				from PeriodoEscolar p, SubPeriodoEscolar sp, PeriodoEvaluacion pe
				where sp.PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.PEcodigo#">
				and sp.SPEcodigo= @@identity
				and p.Ncodigo = pe.Ncodigo
				and p.PEcodigo = sp.PEcodigo
				order by p.PEcodigo, sp.SPEcodigo, p.Ncodigo, pe.PEorden, pe.PEcodigo
				
				select @SPEcodigo as id
				<!--- <cfset action = "SubPeriodoEscolar.cfm"> --->
				<cfset modoDet="ALTA">
			
			<!--- Caso 1.1: Cambia Encabezado --->
			<cfelseif isdefined("Form.btnCambiarE")>
				declare @cont int
				select @cont = isnull(max(a.SPEorden),0)+10 
				from SubPeriodoEscolar a, PeriodoEscolar b, Nivel c 
				where c.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
				  and b.Ncodigo = c.Ncodigo
				  and a.PEcodigo = b.PEcodigo 
				  and a.PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
				  and a.SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.SPEcodigo#">
				  
				update SubPeriodoEscolar
				set SPEdescripcion = <cfqueryparam value="#form.SPEdescripcion#" cfsqltype="cf_sql_varchar">,
				<cfif #len(trim(Form.SPEorden))# NEQ 0 >
					SPEorden = <cfqueryparam cfsqltype="cf_sql_smallint" value="#form.SPEorden#">,
				<cfelse>
					SPEorden = @cont,
				</cfif>
				SPEfechafin = convert(datetime, <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.SPEfechafin#">, 103),
				SPEfechainicio = convert(datetime, <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.SPEfechainicio#">, 103) 
				where SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.SPEcodigo#">
				  and PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
					  
				<!--- <cfset action = "SubPeriodoEscolar.cfm"> --->								
				<cfset modoDet="ALTA">
			
			<!--- Caso 2: Borrar un Encabezado del Sub periodo --->
			<cfelseif isdefined("Form.btnBorrarE")>			
				<cfif isdefined("Form.PEcodigo") AND Form.PEcodigo NEQ "" >
				  	delete PeriodoVigente
					where PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
					  and SPEcodigo = <cfqueryparam value="#form.SPEcodigo#" cfsqltype="cf_sql_numeric">
					  
				  	delete PeriodoOcurrencia
					where PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
					  and SPEcodigo= <cfqueryparam value="#form.SPEcodigo#" cfsqltype="cf_sql_numeric">
					  
					delete SubPeriodoEscolar 
					where PEcodigo=<cfqueryparam value="#form.PEcodigo#" cfsqltype="cf_sql_numeric">				
					  and SPEcodigo=<cfqueryparam value="#form.SPEcodigo#" cfsqltype="cf_sql_numeric">				
					
					<cfset modoDet="ALTA">									
					<cfset action = "listaSubPeriodoEscolar.cfm">

				</cfif>
			<!--- Caso 3: Agregar Detalle de Sub periodo y opcionalmente modificar el encabezado --->
			<cfelseif isdefined("Form.btnAgregarD")>
				<cfif isdefined("Form.SPEcodigo") AND Form.SPEcodigo NEQ "" >
				
				<cfif isdefined("form.POvigente")>
					update PeriodoOcurrencia 
					set POvigente = 0 
					where PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">	
					  
				  	delete PeriodoVigente
					where PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
					
					insert PeriodoVigente (Ncodigo,SPEcodigo,PEcodigo, PEevaluacion)
					select Ncodigo, <cfqueryparam value="#form.SPEcodigo#" cfsqltype="cf_sql_numeric">, PEcodigo, <cfqueryparam value="#form.PEevaluacion#" cfsqltype="cf_sql_numeric">
					from PeriodoEscolar 
					where PEcodigo = <cfqueryparam value="#form.PEcodigo#" cfsqltype="cf_sql_numeric">

				</cfif>
				
					insert PeriodoOcurrencia (SPEcodigo,PEcodigo, PEevaluacion, POfechainicio, POfechafin, POvigente)
					values (<cfqueryparam value="#form.SPEcodigo#" cfsqltype="cf_sql_numeric">,
							<cfqueryparam value="#form.PEcodigo#" cfsqltype="cf_sql_numeric">,
							<cfqueryparam value="#form.PEevaluacion#" cfsqltype="cf_sql_numeric">,
							convert(datetime, <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.POfechainicio#">, 103),
							convert(datetime, <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.POfechafin#">, 103),							
							<cfif isdefined("form.POvigente")>
								1)
							<cfelse>
								0)	
							</cfif>

					declare @cont int
					select @cont = isnull(max(a.SPEorden),0)+10 
					from SubPeriodoEscolar a, PeriodoEscolar b, Nivel c 
					where c.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
					  and b.Ncodigo = c.Ncodigo
					  and a.PEcodigo = b.PEcodigo 
					  and a.PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
					  and a.SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.SPEcodigo#">
					  
					update SubPeriodoEscolar
					set SPEdescripcion = <cfqueryparam value="#form.SPEdescripcion#" cfsqltype="cf_sql_varchar">,
					<cfif #len(trim(Form.SPEorden))# NEQ 0 >
						SPEorden = <cfqueryparam cfsqltype="cf_sql_smallint" value="#form.SPEorden#">,
					<cfelse>
						SPEorden = @cont,
					</cfif>
					SPEfechafin = convert(datetime, <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.SPEfechafin#">, 103),
					SPEfechainicio = convert(datetime, <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.SPEfechainicio#">, 103) 
 					where SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.SPEcodigo#">
					  and PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
					
					<!--- <cfset action = "SubPeriodoEscolar.cfm"> --->								
					<cfset modoDet="ALTA">
				</cfif>
				
			<!--- Caso 4: Modificar Detalle del Sub Periodo y modificar el encabezado --->			
			<cfelseif isdefined("Form.btnCambiarD")>
				<cfif isdefined("form.POvigente")>
					update PeriodoOcurrencia 
					set POvigente = 0 
					where PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">	
					  
				  	delete PeriodoVigente
					where PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
					
					insert PeriodoVigente (Ncodigo,SPEcodigo,PEcodigo, PEevaluacion)
					select Ncodigo, <cfqueryparam value="#form.SPEcodigo#" cfsqltype="cf_sql_numeric">, PEcodigo, <cfqueryparam value="#form.PEevaluacion#" cfsqltype="cf_sql_numeric">
					from PeriodoEscolar 
					where PEcodigo = <cfqueryparam value="#form.PEcodigo#" cfsqltype="cf_sql_numeric">
				</cfif>

				update PeriodoOcurrencia 
				   set POfechainicio=convert(datetime, <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.POfechainicio#">, 103),
					   POfechafin=convert(datetime, <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.POfechafin#">, 103)
					<cfif isdefined("form.POvigente")>
						, POvigente = 1
					</cfif>
					where SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.SPEcodigo#">
					  and PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
					  and PEevaluacion = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEevaluacion#">

					<!--- Modificar Encabezado --->
					declare @cont int
					select @cont = isnull(max(a.SPEorden),0)+10 
					from SubPeriodoEscolar a, PeriodoEscolar b, Nivel c 
					where c.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
					  and b.Ncodigo = c.Ncodigo
					  and a.PEcodigo = b.PEcodigo 
					  and a.PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
					  and a.SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.SPEcodigo#">
					  
					update SubPeriodoEscolar
					set SPEdescripcion = <cfqueryparam value="#form.SPEdescripcion#" cfsqltype="cf_sql_varchar">,
					<cfif #len(trim(Form.SPEorden))# NEQ 0 >
						SPEorden = <cfqueryparam cfsqltype="cf_sql_smallint" value="#form.SPEorden#">,
					<cfelse>
						SPEorden = @cont,
					</cfif>
					SPEfechafin = convert(datetime, <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.SPEfechafin#">, 103),
					SPEfechainicio = convert(datetime, <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.SPEfechainicio#">, 103) 
 					where SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.SPEcodigo#">
					  and PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">

				<!--- <cfset action = "SubPeriodoEscolar.cfm"> --->								
				<cfset modoDet="CAMBIO">				
				
			<!--- Caso 5: Borrar detalle de tabla de Evaluacion --->
			<cfelseif isdefined("Form.btnBorrarD")>
				delete PeriodoOcurrencia 
				where SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.SPEcodigo#">
				  and PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEcodigo#">
				  and PEevaluacion = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.PEevaluacion#">
								
				<!--- <cfset action = "SubPeriodoEscolar.cfm"> --->				
				<cfset modoDet="ALTA">								
			</cfif>					
			set nocount off
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>		
<cfelse>
	<cfif isdefined("form.btnNuevoE")>
		<cfset modo = "ALTA" >
		<cfset modoDet = "ALTA">
	<cfelseif isdefined("form.btnNuevoD")>
		<cfset modo = "CAMBIO" >
		<cfset modoDet = "ALTA">
	</cfif>
</cfif>

<cfif isdefined("Form.btnAgregarE")>
	<cfset form.SPEcodigo_alta = "#ABC_SubPeriodoEscolar.id#">
</cfif>

<cfoutput>
<form action="#action#" method="post" name="sql">
	<input name="modo" type="hidden" value="<cfif isdefined("modo")>#modo#</cfif>">
	<input name="modoDet" type="hidden" value="<cfif isdefined("modoDet")>#modoDet#</cfif>">
	<cfif modo EQ "CAMBIO">
		<input name="PEcodigo"  type="hidden" value="#Form.PEcodigo#">
		<input name="SPEcodigo"  type="hidden" value="<cfif isdefined("Form.btnAgregarE")>#Form.SPEcodigo_alta#<cfelse>#Form.SPEcodigo#</cfif>">
	</cfif>
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")>#Form.Pagina#</cfif>">
</form>
</cfoutput>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>
