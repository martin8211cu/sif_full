<cfinclude template="/edu/Utiles/general.cfm">
<!---
** Mantenimiento Materias Sustitutivas
** Hecho por: 		Rodolfo Jim�nez Jara
** Fecha: 			23-Diciembre-2002
** Comentarios: 
** Aqu� se relacionan las materias Electivas , con las materia ya asociados a los grados en grados sustitutivas.
--->
<!--- Consultas --->
<cfif isdefined("Url.Mconsecutivo") and not isdefined("Form.Mconsecutivo")>
	<cfparam name="Form.Mconsecutivo" default="#Url.Mconsecutivo#">
		
</cfif>
<cfif isdefined("Url.Mnombre") and not isdefined("Form.Mnombre")>
	<cfparam name="Form.Mnombre" default="#Url.Mnombre#">
</cfif>

<cfquery datasource="#Session.DSN#" name="rsMateria">
	select c.Mnombre, a.Ndescripcion, b.Gdescripcion ,
	       case c.Melectiva
		        when 'R' then 'Regular'
				when 'S' then 'Sustitutiva'
				when 'E' then 'Electiva'
				when 'C' then 'Complementaria'
				else ''
			end as Modalidad,
			d.MTdescripcion,
			c.Mconsecutivo
	from Nivel a, Grado b, Materia c, MateriaTipo d
	where a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
	  and c.Mconsecutivo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Mconsecutivo#">
	  and a.Ncodigo = b.Ncodigo 
	  and b.Ncodigo = c.Ncodigo 
	  and b.Gcodigo = c.Gcodigo 
	  and c.MTcodigo = d.MTcodigo
	 order by a.Norden, b.Gorden
</cfquery>


<cfif isdefined("Form.btnAplicar")>
	<cfquery name="ABC_MateriaElectiva" datasource="#Session.DSN#">
		set nocount on
		
		delete MateriaElectiva 
		where Mconsecutivo in  (#form.Cual_Grupo#)  
	  	  and Melectiva = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Mconsecutivo#">
		
		
		set nocount off
	</cfquery>
	<cfif isdefined("Form.Chk")>
		<cfset a=ListToArray(Form.Chk,',')>
		<cfloop index="i" from="1" to="#ArrayLen(a)#">
			<cfset b = ListToArray(a[i],'|')>
			 <cfset Melectiva = b[1]>
			<cfquery name="ABC_MateriaElectiva" datasource="#Session.DSN#">
					set nocount on
					insert MateriaElectiva ( Mconsecutivo, Melectiva)
					values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Melectiva#">,
							<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Mconsecutivo#">
								)
					set nocount off
			</cfquery>
		</cfloop>
	</cfif>
</cfif>
<link href="../../css/estilos.css" rel="stylesheet" type="text/css">
<!---------------------------------------------------------------------------------- --->

<form name="filtros" action="MateriasElectivas.cfm" method="post">
	<input name="Mnombre" type="hidden" id="Mnombre" value="<cfif isdefined("Form.Mnombre")><cfoutput>#Form.Mnombre#</cfoutput></cfif>">
		<table class="areaDatos" width="100%">
			<thead>
				<tr> 
					<td colspan="5">Datos de Materia</td>
				</tr>
			</thead>
			<tbody>
				<tr> 
					<td width="35%" rowspan="2" align="center" valign="middle" style="font-size: 13pt; font-weight: bold;" nowrap><cfoutput>#rsMateria.Mnombre#</cfoutput></td>
					<td nowrap><strong>Nivel:</strong> <cfoutput>#rsMateria.Ndescripcion#</cfoutput> </td>
					<td nowrap><strong>Tipo de Materia:</strong> <cfoutput>#rsMateria.MTdescripcion#</cfoutput></td>
				</tr>
				<tr> 
					<td nowrap> <strong>Grado:</strong> <cfoutput>#rsMateria.Gdescripcion#</cfoutput> </td>
					<td nowrap><strong>Modalidad:</strong> <cfoutput>#rsMateria.Modalidad#</cfoutput></td>
				</tr>
			</tbody>
		</table>
</form>
<tr> 
<td nowrap>
	<strong> &nbsp;&nbsp;&nbsp; 
	  <input name="chkTodos" type="checkbox" value="" border="1" onClick="javascript:Marcar(this);">
	  Seleccionar Todos</strong>
</td>
</tr>
<tr> 
	<td>
	<form name="lista" method="post" action="MateriasElectivas.cfm">
		<input type="hidden" name="Mconsecutivo" value="<cfif isdefined("Form.Mconsecutivo")><cfoutput>#Form.Mconsecutivo#</cfoutput></cfif>">
		<input name="Mnombre" type="hidden" id="Mnombre" value="<cfif isdefined("Form.Mnombre")><cfoutput>#Form.Mnombre#</cfoutput></cfif>">
		<input name="Cual_Grupo" type="hidden" id="Cual_Grupo" value="">
		<cfif isdefined("Form.Pagina") and Form.Pagina NEQ "">
			<cfset Pagenum_lista = #Form.Pagina#>
		</cfif> 
		<cfset navegacion = "Mconsecutivo=" & Form.Mconsecutivo>
		<cfset navegacion = navegacion & Iif(Len(Trim(navegacion)) NEQ 0, DE("&"), DE("")) & "Mnombre=" & Form.Mnombre>
		<cfinvoke 
			 component="edu.Componentes.pListas"
			 method="pListaEdu"
			 returnvariable="pListaEduRet">
				<cfinvokeargument name="tabla" value=" Materia a, MateriaTipo mt, MateriaElectiva me"/>
				<cfinvokeargument name="columnas" value=" convert(varchar, a.Mconsecutivo) as Mconsecutivo, convert(varchar, a.Melectiva) as Melectiva , 
										substring(a.Mnombre,1,50) as Mnombre, a.Mhoras, a.Mcreditos, convert(varchar, a.Ncodigo) as Ncodigo, 
										convert(varchar, a.Gcodigo) as Gcodigo, convert(varchar, me.Mconsecutivo) as checked"/>
				<cfinvokeargument name="desplegar" value="Mnombre, Mhoras, Mcreditos"/>
				<cfinvokeargument name="etiquetas" value="Descripci&oacute;n, Horas, Cr&eacute;ditos"/>
				<cfinvokeargument name="formatos" value=""/>
				<!--- <cfinvokeargument name="filtro" value="b.CEcodigo = #Session.CEcodigo# and a.Ncodigo = b.Ncodigo and a.Melectiva = 'R' and a.Mconsecutivo *= c.Mconsecutivo and a.Mconsecutivo not in(select Mconsecutivo from MateriaElectiva where Melectiva <> #form.Mconsecutivo# ) order by a.Mnombre"/> --->
				<cfinvokeargument name="filtro" value="a.Melectiva = 'S'
														and me.Melectiva = #form.Mconsecutivo# 
														and mt.CEcodigo = #Session.CEcodigo# 
														and a.Mconsecutivo in
														(select c.Mconsecutivo
															from GradoSustitutivas c, Materia b
															where c.Gcodigo = b.Gcodigo
															  and c.Ncodigo = b.Ncodigo
															  and b.Mconsecutivo = #form.Mconsecutivo# 
														)
														and a.Mactiva = 1
														and a.Mconsecutivo *= me.Mconsecutivo
														and a.MTcodigo = mt.MTcodigo"/>
				<cfinvokeargument name="align" value="left, left, left"/>
				<cfinvokeargument name="ajustar" value="N,N,N"/>
				<cfinvokeargument name="irA" value="MateriasElectivas.cfm"/>
				<cfinvokeargument name="botones" value=""/>
				<cfinvokeargument name="checkboxes" value="S"/>
				<cfinvokeargument name="debug" value="N"/>
				<cfinvokeargument name="botones" value="Aplicar"/>
				<cfinvokeargument name="incluyeForm" value="false"/>
				<cfinvokeargument name="formName" value="lista"/>
				<cfinvokeargument name="keys" value="Mconsecutivo"/>
				<cfinvokeargument name="checkedcol" value="checked"/>
				<cfinvokeargument name="navegacion" value="#navegacion#"/>
			</cfinvoke>
      <script language="JavaScript">
				if (document.lista.chk != null) {
					if (document.lista.chk.value != null) {// solo para uno
						if (document.lista.chk.checked) document.lista.chk.checked = true; else document.lista.chk.checked = false;
							var a = document.lista.chk.value.split("|");
							var Melectiva = a[0];
							document.lista.Cual_Grupo.value += Melectiva ;
					} else {
						for (var counter = 0; counter < document.lista.chk.length; counter++) {
							var a = document.lista.chk[counter].value.split("|");
							var Melectiva = a[0];
							//alert(Melectiva);
							document.lista.Cual_Grupo.value += Melectiva + ",";
						}
						if (document.lista.Cual_Grupo.value != "") {
							document.lista.Cual_Grupo.value = document.lista.Cual_Grupo.value.substring(0,document.lista.Cual_Grupo.value.length-1);
						}
					}
				}
			</script>
    </form>
	</td> 
</tr>
<script language="JavaScript1.2">
function Marcar(c) {
	if (document.lista.chk != null) { //existe?
		if (document.lista.chk.value != null) {// solo un check
			if (c.checked) document.lista.chk.checked = true; else document.lista.chk.checked = false;
		}
		else {
			if (c.checked) {
				for (var counter = 0; counter < document.lista.chk.length; counter++)
				{
					if ((!document.lista.chk[counter].checked) && (!document.lista.chk[counter].disabled))
						{  document.lista.chk[counter].checked = true;}
				}
				if ((counter==0)  && (!document.lista.chk.disabled)) {
					document.lista.chk.checked = true;
				}
			}
			else {
				for (var counter = 0; counter < document.lista.chk.length; counter++)

				{
					if ((document.lista.chk[counter].checked) && (!document.lista.chk[counter].disabled))
						{  document.lista.chk[counter].checked = false;}
				};
				if ((counter==0) && (!document.lista.chk.disabled)) {
					document.lista.chk.checked = false;
				}
			};
		}
	}
}
</script>
