<cfif not isdefined("Form.Nuevo")>
	<cftry>
		<cfif isdefined("Form.Alta")>
			<cfset promo = ListToArray(Form.GradoPromo,"|")>
			<cfquery name="ABC_Grado" datasource="#Session.DSN#">
				set nocount on
				if not exists ( select 1 from Grado a, Nivel b
					where a.Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
					  and b.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">
					  and rtrim(ltrim(a.Gdescripcion)) = <cfqueryparam value="#Form.Gdescripcion#" cfsqltype="cf_sql_varchar">
					  and a.Ncodigo = b.Ncodigo
				)
				begin
					declare @cont int
					select @cont = isnull(max(a.Gorden),0)+10 
					from Grado a, Nivel b
					where a.Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
					  and b.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">
					  and a.Ncodigo = b.Ncodigo
				
					insert into Grado (Ncodigo, Gdescripcion, Gorden, Gngrupos, Gnalumnos, Gtiponum, Gpromogrado, Gpromonivel)
					values
						(
							<cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">,
							<cfqueryparam value="#Form.Gdescripcion#" cfsqltype="cf_sql_varchar">,
							<!--- <cfqueryparam value="#Form.Ganual#" cfsqltype="cf_sql_smallint">, --->
							<cfif #len(trim(Form.Gorden))# NEQ 0 >
								<cfqueryparam value="#Form.Gorden#" cfsqltype="cf_sql_smallint">,
							<cfelse>
								@cont,	
							</cfif>
							<cfif isdefined("Form.Gngrupos") and Len(Trim(form.Gngrupos)) NEQ 0>
								<cfqueryparam value="#Form.Gngrupos#" cfsqltype="cf_sql_numeric">,
							<cfelse>
								0,
							</cfif>
							<cfif isdefined("Form.Gnalumnos") and Len(Trim(form.Gnalumnos)) NEQ 0>
								<cfqueryparam value="#Form.Gnalumnos#" cfsqltype="cf_sql_numeric">,
							<cfelse>
								0,
							</cfif>							
							<cfqueryparam value="#Form.Gtiponum#" cfsqltype="cf_sql_varchar">,
							<cfif Form.GradoPromo NEQ "|">
								<cfqueryparam value="#promo[2]#" cfsqltype="cf_sql_numeric">,
								<cfqueryparam value="#promo[1]#" cfsqltype="cf_sql_numeric">
							<cfelse>
								null,
								null
							</cfif>
						)
				end
				else 
					select 1
				set nocount off
			</cfquery>
			<cfset modo="ALTA">
		<cfelseif isdefined("Form.Baja")>
			<cfquery name="ABC_Grado" datasource="#Session.DSN#">
				set nocount on
				delete from Grado
				where Gcodigo = <cfqueryparam value="#Form.Gcodigo#" cfsqltype="cf_sql_numeric">
				  and Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
				set nocount off
			</cfquery>
			<cfset modo="ALTA">
		<cfelseif isdefined("Form.Cambio")>
			<cfset promo = ListToArray(Form.GradoPromo,"|")>
			<cfquery name="ABC_Grado" datasource="#Session.DSN#">
				set nocount on
				declare @cont int
				select @cont = isnull(max(a.Gorden),0)+10 
				from Grado a, Nivel b
				where a.Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
				  and b.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">
				  and a.Gcodigo  = <cfqueryparam value="#Form.Gcodigo#" cfsqltype="cf_sql_numeric">
				  and a.Ncodigo = b.Ncodigo

				if not exists ( select 1 from Grado a, Nivel b, Grupo c
						where a.Ncodigo = <cfqueryparam value="#Form._Ncodigo#" cfsqltype="cf_sql_numeric">
						  and b.CEcodigo =  <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">
						  and c.Gcodigo  = <cfqueryparam value="#Form.Gcodigo#" cfsqltype="cf_sql_numeric">
						  and a.Ncodigo = b.Ncodigo
						  and b.Ncodigo = c.Ncodigo
						  and a.Gcodigo = c.Gcodigo
					)
				begin
					if not exists ( select 1 from Materia 
									where Gcodigo = <cfqueryparam value="#Form.Gcodigo#" cfsqltype="cf_sql_numeric">	
					)
					begin
						if not exists ( select 1 from HorarioAplica  
										where Gcodigo = <cfqueryparam value="#Form.Gcodigo#" cfsqltype="cf_sql_numeric">	
						 )
						 begin
					     	update Grado set
								Gdescripcion = <cfqueryparam value="#Form.Gdescripcion#" cfsqltype="cf_sql_varchar">,
								Ganual = <cfqueryparam value="#Form.Ganual#" cfsqltype="cf_sql_smallint">,
								Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">,
								<cfif #len(trim(Form.Gorden))# NEQ 0 >
									Gorden = <cfqueryparam value="#Form.Gorden#" cfsqltype="cf_sql_smallint">,
								<cfelse>
									Gorden = @cont,	
								</cfif>
								<cfif isdefined("Form.Gngrupos") and Len(Trim(form.Gngrupos)) NEQ 0>
									Gngrupos=<cfqueryparam value="#Form.Gngrupos#" cfsqltype="cf_sql_numeric">,
								<cfelse>
									Gngrupos=0,
								</cfif>
								<cfif isdefined("Form.Gnalumnos") and Len(Trim(form.Gnalumnos)) NEQ 0>
									Gnalumnos=<cfqueryparam value="#Form.Gnalumnos#" cfsqltype="cf_sql_numeric">,
								<cfelse>
									Gnalumnos=0,
								</cfif>
								Gtiponum=<cfqueryparam value="#Form.Gtiponum#" cfsqltype="cf_sql_varchar">,
								<cfif Form.GradoPromo NEQ "|">
									Gpromogrado = <cfqueryparam value="#promo[2]#" cfsqltype="cf_sql_numeric">,
									Gpromonivel = <cfqueryparam value="#promo[1]#" cfsqltype="cf_sql_numeric">
								<cfelse>
									Gpromogrado = null,
									Gpromonivel = null
								</cfif>
							where Gcodigo = <cfqueryparam value="#Form.Gcodigo#" cfsqltype="cf_sql_numeric">
							  and Ncodigo = <cfqueryparam value="#Form._Ncodigo#" cfsqltype="cf_sql_numeric">
						    set nocount off
							select <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric"> as Ncodigo
						 end
						 else
						 begin
								update Grado set
									Gdescripcion = <cfqueryparam value="#Form.Gdescripcion#" cfsqltype="cf_sql_varchar">,
									Ganual = <cfqueryparam value="#Form.Ganual#" cfsqltype="cf_sql_smallint">,
									<cfif #len(trim(Form.Gorden))# NEQ 0 >
										Gorden = <cfqueryparam value="#Form.Gorden#" cfsqltype="cf_sql_smallint">,
									<cfelse>
										Gorden = @cont,	
									</cfif>
									<cfif isdefined("Form.Gngrupos") and Len(Trim(form.Gngrupos)) NEQ 0>
										Gngrupos=<cfqueryparam value="#Form.Gngrupos#" cfsqltype="cf_sql_numeric">,
									<cfelse>
										Gngrupos=0,
									</cfif>
									<cfif isdefined("Form.Gnalumnos") and Len(Trim(form.Gnalumnos)) NEQ 0>
										Gnalumnos=<cfqueryparam value="#Form.Gnalumnos#" cfsqltype="cf_sql_numeric">,
									<cfelse>
										Gnalumnos=0,
									</cfif>
									Gtiponum=<cfqueryparam value="#Form.Gtiponum#" cfsqltype="cf_sql_varchar">,
									<cfif Form.GradoPromo NEQ "|">
										Gpromogrado = <cfqueryparam value="#promo[2]#" cfsqltype="cf_sql_numeric">,
										Gpromonivel = <cfqueryparam value="#promo[1]#" cfsqltype="cf_sql_numeric">
									<cfelse>
										Gpromogrado = null,
										Gpromonivel = null
									</cfif>
								where Gcodigo = <cfqueryparam value="#Form.Gcodigo#" cfsqltype="cf_sql_numeric">
								  and Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">						 	
						   set nocount off
						   select <cfqueryparam value="#Form._Ncodigo#" cfsqltype="cf_sql_numeric"> as Ncodigo
						 end
					 end
					 else
					 begin
						update Grado set
							Gdescripcion = <cfqueryparam value="#Form.Gdescripcion#" cfsqltype="cf_sql_varchar">,
							Ganual = <cfqueryparam value="#Form.Ganual#" cfsqltype="cf_sql_smallint">,
							<cfif #len(trim(Form.Gorden))# NEQ 0 >
								Gorden = <cfqueryparam value="#Form.Gorden#" cfsqltype="cf_sql_smallint">,
							<cfelse>
								Gorden = @cont,	
							</cfif>
							<cfif isdefined("Form.Gngrupos") and Len(Trim(form.Gngrupos)) NEQ 0>
								Gngrupos=<cfqueryparam value="#Form.Gngrupos#" cfsqltype="cf_sql_numeric">,
							<cfelse>
								Gngrupos=0,
							</cfif>
							<cfif isdefined("Form.Gnalumnos") and Len(Trim(form.Gnalumnos)) NEQ 0>
								Gnalumnos=<cfqueryparam value="#Form.Gnalumnos#" cfsqltype="cf_sql_numeric">,
							<cfelse>
								Gnalumnos=0,
							</cfif>
							Gtiponum=<cfqueryparam value="#Form.Gtiponum#" cfsqltype="cf_sql_varchar">,
							<cfif Form.GradoPromo NEQ "|">
								Gpromogrado = <cfqueryparam value="#promo[2]#" cfsqltype="cf_sql_numeric">,
								Gpromonivel = <cfqueryparam value="#promo[1]#" cfsqltype="cf_sql_numeric">
							<cfelse>
								Gpromogrado = null,
								Gpromonivel = null
							</cfif>
						where Gcodigo = <cfqueryparam value="#Form.Gcodigo#" cfsqltype="cf_sql_numeric">
						  and Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
					    set nocount off
						select <cfqueryparam value="#Form._Ncodigo#" cfsqltype="cf_sql_numeric"> as Ncodigo
					 end
				end
				else
				begin
					update Grado set
						Gdescripcion = <cfqueryparam value="#Form.Gdescripcion#" cfsqltype="cf_sql_varchar">,
						Ganual = <cfqueryparam value="#Form.Ganual#" cfsqltype="cf_sql_smallint">,
						<cfif #len(trim(Form.Gorden))# NEQ 0 >
							Gorden = <cfqueryparam value="#Form.Gorden#" cfsqltype="cf_sql_smallint">,
						<cfelse>
							Gorden = @cont,	
						</cfif>
						<cfif isdefined("Form.Gngrupos") and Len(Trim(form.Gngrupos)) NEQ 0>
							Gngrupos=<cfqueryparam value="#Form.Gngrupos#" cfsqltype="cf_sql_numeric">,
						<cfelse>
							Gngrupos=0,
						</cfif>
						<cfif isdefined("Form.Gnalumnos") and Len(Trim(form.Gnalumnos)) NEQ 0>
							Gnalumnos=<cfqueryparam value="#Form.Gnalumnos#" cfsqltype="cf_sql_numeric">,
						<cfelse>
							Gnalumnos=0,
						</cfif>
						Gtiponum=<cfqueryparam value="#Form.Gtiponum#" cfsqltype="cf_sql_varchar">,
						<cfif Form.GradoPromo NEQ "|">
							Gpromogrado = <cfqueryparam value="#promo[2]#" cfsqltype="cf_sql_numeric">,
							Gpromonivel = <cfqueryparam value="#promo[1]#" cfsqltype="cf_sql_numeric">
						<cfelse>
							Gpromogrado = null,
							Gpromonivel = null
						</cfif>
					where Gcodigo = <cfqueryparam value="#Form.Gcodigo#" cfsqltype="cf_sql_numeric">
					  and Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
					set nocount off
					select <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric"> as Ncodigo
				end
				set nocount off
				</cfquery>
				<cfset modo="CAMBIO">
	</cfif>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>
</cfif>
<form action="Grado.cfm" method="post" name="sql">
	<input name="modo" type="hidden" value="<cfif isdefined("modo")><cfoutput>#modo#</cfoutput></cfif>">
	<input name="Ncodigo" type="hidden" value="<cfif isdefined("Form.Ncodigo")><cfoutput>#Form.Ncodigo#</cfoutput></cfif>">
	<input name="Gcodigo" type="hidden" value="<cfif isdefined("Form.Gcodigo")><cfoutput>#Form.Gcodigo#</cfoutput></cfif>">
</form>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>

