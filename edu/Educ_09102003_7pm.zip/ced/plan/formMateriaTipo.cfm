<!-- Establecimiento del modo -->
<cfif isdefined("form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("form.modo")>
		<cfset modo="ALTA">
	<cfelseif #form.modo# EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>

<!--- ==================== --->
<!---       Consultas      --->
<!--- ==================== --->
<!--- 1. Form --->
<cfquery name="rsForm" datasource="#session.DSN#">
	select convert(varchar,MTcodigo) as MTcodigo, substring(MTdescripcion,1,50) as MTdescripcion
	from MateriaTipo
	<cfif isdefined("form.MTcodigo") and form.MTcodigo neq "">
		where MTcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.MTcodigo#">
		  and CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#session.CEcodigo#">
	</cfif>	  
</cfquery>
<cfif modo NEQ "ALTA" and isdefined("Form.MTcodigo") and len(trim("Form.MTcodigo")) GT 0>
	<!--- 3. Validaciones de dependencias--->
	<!---  Rodolfo JImenez Jara, SOIN, 03/12/2002 --->
	<cfquery datasource="#Session.DSN#" name="rsHayMateria">
		select 1 from Materia
		where MTcodigo  = <cfqueryparam value="#Form.MTcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>
</cfif>	  
<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" type="text/JavaScript">
	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
	
</script>

<form action="SQLMateriaTipo.cfm" method="post" name="materiatipo">
  <cfoutput> 
    <!---  <table width="85%" height="56%" align="center">
	<tr>
	<a href="MateriaTipo.cfm?Ayuda=<cfif Session.Ayuda EQ 0>1<cfelse>0</cfif>"><img src="../../Imagenes/Help01_T.gif" alt="Ayuda del Portal"  border="0" align="baseline"> </a>
	<p>Usted podr� agregar las materias que son impartidas en el Centro Educativo. En esta ventana se mostrar� la opci�n 
	Agregar el Tipo de Materia.</p>
	<cfif Session.Ayuda EQ 0> 
		<cfif modo eq "ALTA">
			<td width="100%" height="50%" valign="top"><strong><font size="2">Agregar</font></strong>:<font size="1">
			  Al realizar un click sobre la opci&oacute;n de Agregar, grabar� los datos 
			  del Tipo de Materia ingresados por usted; tales como: &nbsp;&nbsp;<strong>&nbsp;Descripci&oacute;n 
			  del Tipo de Materia</strong> (Nombre del Tipo de Materia). </font><font size="2">&nbsp;</font> 
			  <p><font size="2"><strong>Limpiar:</strong> <font size="1">Al &nbsp; 
				realizar un click sobre la opci&oacute;n de <strong>Limpiar</strong> 
				desaparecer�n de la pantalla, todos aquellos datos digitados por usted en ese nuevo registro ,
				sin alterar la informaci�n del Portal.</font> </font></p>
				</td>
		<cfelse>
			<td width="100%" height="50%" valign="top"><strong><font size="2">Nuevo</font></strong>:<font size="1">Al 
			  realizar un click sobre la opci&oacute;n de Nuevo, usted podr&aacute; 
			  ingresar los datos del Tipo de Materia como:&nbsp;&nbsp;<strong>&nbsp;Descripci&oacute;n 
			  del Tipo de Materia</strong> (Nombre del Tipo de Materia). </font><font size="2">&nbsp;</font> 
			  <p><font size="2"><strong>Modificar:</strong> <font size="1">Al realizar 
				  un click sobre la opci&oacute;n de <strong>Modificar</strong> usted 
				  podr&aacute; modificar los siguientes datos : <strong>Descripci&oacute;n</strong> 
				  (Nombre del Tipo de Materia).</font></font></p>
				<p><font size="2"><strong>Eliminar</strong></font><font size="1">; Escoja 
				  el Tipo de Materia que desee eliminar y realice un click sobre la opci&oacute;n 
				  Borrar, el portal refrescar&aacute; la vista sin mostrar el &iacute;tem 
				  que se indic&oacute; anteriormente.</font></p></td>
			
		</cfif>
	</cfif> 
			  
    </tr>
  </table> --->
    <table width="100%" border="0" cellpadding="1" cellspacing="1">
      <!---
			<tr>
                  <td valign="top" bgcolor="##eeeeee" style="border:1px solid black" colspan="2" ><div align="left"> 
                      <strong>Tipos de Materia:</strong><br>
					  Los pasos para solicitud de pasaporte por medio del portal 
                      son:
                    </div></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			--->
      <tr> 
        <td class="tituloMantenimiento" colspan="2" align="center"><font size="3"> 
          <cfif modo eq "ALTA">
            Nuevo Tipo de Materia 
            <cfelse>
            Modificar Tipo de Materia 
          </cfif>
          </font></td>
      </tr>
      <tr> 
        <td align="right" valign="baseline">Descripci&oacute;n:</td>
        <td valign="baseline"><input name="MTdescripcion" type="text" size="50" maxlength="255" alt="El valor de la Descripci&oacute;n" value="<cfif modo NEQ "ALTA"><cfoutput>#rsForm.MTdescripcion#</cfoutput></cfif>"></td>
      </tr>
      <tr> 
        <td align="center" colspan="2"><cfinclude  template="../../portlets/pBotones.cfm"></td>
      </tr>
      <cfif modo neq 'ALTA'>
        <tr> 
          <td colspan="2">
		  	<input type="hidden" name="MTcodigo"  value="#rsForm.MTcodigo#">
			<input type="hidden" name="HayMateria"  value="#rsHayMateria.recordCount#">
		  </td>
        </tr>
      </cfif>
    </table>
	</cfoutput>
</form>

<script language="JavaScript">

	function deshabilitarValidacion() {
		objForm.MTdescripcion.required = false;
	}
	
	function habilitarValidacion() {
		objForm.MTdescripcion.required = true;
	}	
	
	// Se aplica la descripcion del Grado 
	function __isTieneDependencias() {
		if(btnSelected("Baja", this.obj.form)) {
				// Valida que el Grado no tenga dependencias con otros.
				var msg = "";
				//alert(new Number(this.obj.form.HayMateria.value)); 
				if (new Number(this.obj.form.HayMateria.value) > 0) {
					msg = msg + "materias"
				}
				if (msg != "")
				{
					this.error = "Usted no puede eliminar el Tipo de Materia '" + this.obj.form.MTdescripcion.value + "' porque �ste tiene asociado: " + msg + ".";
					this.obj.form.MTdescripcion.focus();
				}
		}
	}
	
	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isTieneDependencias", __isTieneDependencias);
	objForm = new qForm("materiatipo");
	
	<cfif modo EQ "ALTA">
		objForm.MTdescripcion.required = true;
		objForm.MTdescripcion.description = "Descripci�n";
	<cfelse>
		objForm.MTdescripcion.required = true;
		objForm.MTdescripcion.description = "Descripci�n";
	</cfif>
	
	objForm.MTdescripcion.validateTieneDependencias();
</script>

