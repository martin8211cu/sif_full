<!-- Establecimiento del modo -->
<cfif isdefined("form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("form.modo")>
		<cfset modo="ALTA">
	<cfelseif #form.modo# EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>

<!--- ==================== --->
<!---       Consultas      --->
<!--- ==================== --->
<!--- 1. Form --->
<cfquery name="rsForm" datasource="#session.DSN#">
	select convert(varchar,PEcodigo) as PEcodigo, convert(varchar,Ncodigo) as Ncodigo, substring(PEdescripcion,1,50) as PEdescripcion, PEorden, PEacumulativo
	from PeriodoEvaluacion
	<cfif isdefined("form.PEcodigo") and form.PEcodigo neq "">
		where PEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.PEcodigo#">
	</cfif>	  
</cfquery>

<!--- 2. Combo de Nivel --->
<cfquery name="rsNivel" datasource="#session.DSN#">
	select convert(varchar,Ncodigo) as Ncodigo, substring(Ndescripcion,1,50) as Ndescripcion
	from Nivel 
	where CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#session.CEcodigo#">
</cfquery>
<cfif modo NEQ "ALTA" and isdefined("Form.PEcodigo") and len(trim("Form.PEcodigo")) GT 0>
	<cfquery datasource="#Session.DSN#" name="rsHayEvaluacionConceptoMateria">
	select convert(varchar,a.Mconsecutivo) as Mconsecutivo, convert(varchar,b.PEcodigo) as PEcodigo, convert(varchar,a.ECcodigo) as ECcodigo, a.ECMporcentaje
	from EvaluacionConceptoMateria a, PeriodoEvaluacion b  
	where a.PEcodigo =  <cfqueryparam value="#Form.PEcodigo#" cfsqltype="cf_sql_numeric">
  	  and a.PEcodigo = b.PEcodigo
	</cfquery>
	
	<!--- 3. Validaciones de dependencias--->
	<!---  Rodolfo JImenez Jara, SOIN, 03/12/2002 --->
	<cfquery datasource="#Session.DSN#" name="rsHayEvaluacionConceptoMateria">
		select 1 from EvaluacionConceptoMateria
		where PEcodigo  = <cfqueryparam value="#Form.PEcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>

	<cfquery datasource="#Session.DSN#" name="rsHayAlumnoCalificacion">
		select 1 from AlumnoCalificacionPerEval
		where CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">
		  and PEcodigo  = <cfqueryparam value="#Form.PEcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>

	<cfquery datasource="#Session.DSN#" name="rsHayMateriaPrograma">
		select 1 from MateriaPrograma
		where PEcodigo  = <cfqueryparam value="#Form.PEcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>
	
	<cfquery datasource="#Session.DSN#" name="rsHayCursoPrograma">
		select 1 from CursoPrograma
		where PEcodigo  = <cfqueryparam value="#Form.PEcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>

	<cfquery datasource="#Session.DSN#" name="rsHayEvaluacionConceptoCurso">
		select 1 from EvaluacionConceptoCurso
		where PEcodigo  = <cfqueryparam value="#Form.PEcodigo#" cfsqltype="cf_sql_numeric">
	</cfquery>
	
</cfif>

<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" type="text/JavaScript">
<!--

// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
	
	function validaForm(f) {
		if (f.Ncodigo.obj.disabled) {
			f.Ncodigo.obj.disabled = false;
		}
		return true;
	}
	function qf(Obj){
		var VALOR=""
		var HILERA=""
		var CARACTER=""
		if(Obj.name)
		  VALOR=Obj.value
		else
		  VALOR=Obj
		
		for (var i=0; i<VALOR.length; i++) {	
		
			CARACTER =VALOR.substring(i,i+1);
			if (CARACTER=="," || CARACTER==" ") {
				CARACTER=""; //CAMBIA EL CARACTER POR BLANCO
			}  
			HILERA+=CARACTER;
		}
		return HILERA
	}
	
	function validaForm(f) {
		if (f.Ncodigo.obj.disabled) {
			f.Ncodigo.obj.disabled = false;
		}
		return true;
	}
	function crearNuevoNivel(c) {
		if (c.value == "0") {
			c.selectedIndex = 0;
			location.href='Nivel.cfm?RegresarURL=PeriodoEvaluacion.cfm';
		}
		else if (c.value == "") 
			c.selectedIndex = 0;
	}
<!--
//-->//-->
</script>



<form action="SQLPeriodoEvaluacion.cfm" method="post" name="periodoevaluacion" onSubmit="javascript:return validaForm(this);">
  <!--- <table width="85%" height="56%" align="center">
	<tr>
	<a href="PeriodoEvaluacion.cfm?Ayuda=<cfif Session.Ayuda EQ 0>1<cfelse>0</cfif>" ><img src="../../Imagenes/Help01_T.gif" alt="Ayuda del Portal"  border="0" align="baseline"> </a>
	<cfif Session.Ayuda EQ 0> 
	 		  La clasificaci�n de los per�odos de evaluaci�n depender�n de las pol�ticas de cada instituci�n, estas 
			  pueden ser: bimestrales, trimestrales y semestrales o la combinaci�n de varios rubros.<br>
		<cfif modo eq "ALTA">
			<td width="100%" height="50%" valign="top">
			  <p><strong><font size="2">Agregar</font></strong>:<font size="1">Al 
			  realizar un click sobre la opci&oacute;n de Agregar, grabar� los datos 
			  del ingresados por usted; tales como: &nbsp;&nbsp;<strong>&nbsp;Descripci&oacute;n 
			  del Periodo de Evaluaci�n </strong> (Nombre del Periodo), <strong>Nivel:&nbsp;</strong>(definidos 
			  por usted seg&uacute;n las politicas del Centro Educativo) &nbsp; y el <strong>Orden</strong> 
			  (Posici&oacute;n en que se mostrar&aacute; en el portal,en  m&uacute;ltiplos 
			  de 10), si deja este campo vac�o, el sistema le asignar� un valor automaticamente 
			  (el �ltimo orden definido por el usuario mas 10) . </font><font size="2">&nbsp;</font> </p>
			  <p><font size="2"><strong>Limpiar:</strong> <font size="1">Al &nbsp; 
				realizar un click sobre la opci&oacute;n de <strong>Limpiar</strong> 
				desaparecer�n de la pantalla, todos aquellos datos digitados por usted en ese nuevo registro ,
				sin alterar la informaci�n del Portal.</font> </font></p>
				<p>
				<cfif rsNivel.RecordCount eq 0>
					<font size="2"><strong>Agregar Nuevo Nivel:</strong><font size="1"> Esta opci�n aparece solo cuando no hay niveles 
					definidos para ese Centro Educativo, por lo que al realizar un click sobre esta opci�n, �sta lo llevar� al 
					Mantenimiento de Niveles para que defina por lo menos un nivel, y hac� pueda continuar el mantenimiento del Portal.
					As� mismo en la pantalla de Mantenimiento de Niveles, aparecer� un bot�n que lo regresar� al mantenimiento de Periodos 
					de Evaluaci�n cuando pulse click sobre �l.
					</font> </font>
				</cfif>
				</p>
				</td>
		<cfelse>
			<td width="100%" height="50%" valign="top"> 
			  <p><strong><font size="2">Nuevo</font></strong>:<font size="1">Al
			  realizar un click sobre la opci&oacute;n de Nuevo, usted podr&aacute; 
			  ingresar los datos del del Periodo de Evaluaci�n como:&nbsp;&nbsp;<strong>&nbsp;Descripci&oacute;n 
			  del Periodo</strong> (Nombre del Periodo), <strong>Nivel:&nbsp;</strong>(definidos 
			  por usted seg&uacute;n las politicas del Centro Educativo) &nbsp; y el <strong>Orden</strong> (Posici&oacute;n 
			  en que se mostrar&aacute; en el portal, m&uacute;ltiplos de 10) . </font><font size="2">&nbsp;</font> </p>
			  <p><font size="2"><strong>Modificar:</strong> <font size="1">Al realizar 
				  un click sobre la opci&oacute;n de <strong>Modificar</strong> usted 
				  podr&aacute; modificar los siguientes datos : <strong>Descripci&oacute;n</strong> 
				  (Nombre del Periodo),<strong> Nivel</strong>  (Si esta opci�n esta deshabilitada, no podr� realizar modificaciones al Periodo de Evaluaci�n, ya que hay grupos dependientes de este Periodo, si no esta deshabilitada, el Portal le permite cambiar el nivel de este Periodo.) y <strong>el 
				  Orden</strong> (Posici&oacute;n en que se mostrar&aacute; en el portal, 
				  m&uacute;ltiplos de 10), si deja este campo vac�o, el sistema le asignar� un valor automaticamente (el �ltimo orden definido por el usuario mas 10).</font> </font></p>
				<p><font size="2"><strong>Eliminar</strong></font><font size="1">; Escoja 
				  el Periodo que desee eliminar y realice un click sobre la opci&oacute;n 
				  Borrar, el portal refrescar&aacute; la vista sin mostrar el &iacute;tem 
				  que se indic&oacute; anteriormente.</font></p></td>
				
		</cfif>
	</cfif> 
			  
    </tr>
  </table> --->
  <table width="100%" border="0" cellpadding="1" cellspacing="1">
    <tr> 
      <td class="tituloMantenimiento" colspan="2" align="center"><font size="3"> 
        <cfif modo eq "ALTA">
          Nuevo Per&iacute;odo de Evaluaci&oacute;n 
          <cfelse>
          Modificar Per&iacute;odo de Evaluaci&oacute;n 
        </cfif>
        </font></td>
    </tr>
    <tr> 
      <td align="right" valign="baseline">Nivel:&nbsp;</td>
      <td valign="baseline"> 
	  <!--- <cfif rsNivel.RecordCount eq 0>
          <a href="Nivel.cfm?modulo=2" ><img src="../../Imagenes/Documentos2.gif" alt="Agregar Nivel en el Centro Educativo" border="0" align="baseline">&nbsp; 
          Agregar nuevo Nivel en el Centro Educativo</a> 
          <input name="Ncodigo" type="text" value="" size="50"  class="cajasinborde"  readonly="" maxlength="255" alt="El Nivel">
      <cfelse> --->
          <select name="Ncodigo"  onchange="javascript: crearNuevoNivel(this);" id="Ncodigo" <cfif modo NEQ "ALTA" and rsHayEvaluacionConceptoMateria.recordCount NEQ 0>disabled</cfif>>
            <cfoutput query="rsNivel"> 
              <option value="#rsNivel.Ncodigo#" <cfif (isDefined("rsForm.Ncodigo") AND #rsForm.Ncodigo# EQ #rsNivel.Ncodigo#)>selected</cfif>>#rsNivel.Ndescripcion# 
              </option>
            </cfoutput> 
         	<option value="">-------------------</option>
          	<option value="0">Crear Nuevo ...</option>
          </select>
     <!---  </cfif> --->
	  </td>
    </tr>
    <tr> 
      <td align="right" valign="baseline">Descripci&oacute;n:&nbsp;</td>
      <td valign="baseline"><input name="PEdescripcion" type="text" value="<cfif modo neq 'ALTA'><cfoutput>#rsForm.PEdescripcion#</cfoutput></cfif>" size="50" maxlength="255" alt="El valor de la Descripci�n" onfocus="javascript:this.select();"></td>
    </tr>
    <tr> 
      <td align="right"> 
        <!--- <input name="PEorden" type="hidden" value="<cfif modo neq 'ALTA'><cfoutput>#rsForm.PEorden#</cfoutput></cfif>" > ---></div> 
        Orden: </td>
      <td align="left"><input name="PEorden" align="left" type="text" id="PEorden" size="8" maxlength="8" value="<cfif modo NEQ "ALTA"><cfoutput>#rsForm.PEorden#</cfoutput></cfif>" onfocus="javascript:this.value=qf(this); this.select();" onblur="javascript:fm(this,0);"  onkeyup="javascript:if(snumber(this,event,0)){ if(Key(event)=='13') {this.blur();}}" ></td>
    </tr>
    <!--- Ronald me dijo que no capturara este campo, JGR 14/11/2002
            <tr> 
				<td>&nbsp;</td>
                <td align="right">Acumulativo:&nbsp;</td>


                <td align="left">
                        <input name="PEacumulativo" type="text" value="<cfif modo neq 'ALTA'><cfoutput>#rsForm.PEacumulativo#</cfoutput></cfif>" size="5" maxlength="1" onfocus="javascript:this.select();">
                </td>
            </tr>
			--->
    <tr> 
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
    </tr>
    <tr> 
      <td align="center" colspan="2"><cfinclude template="../../portlets/pBotones.cfm"></td>
    </tr>
    <cfif modo neq 'ALTA'>
      <tr> 
        <td colspan="2"> 
          <cfoutput> 
            <input type="hidden" name="PEcodigo"  value="#rsForm.PEcodigo#">
            <input type="hidden" name="HayEvaluacionConceptoMateria"  value="#rsHayEvaluacionConceptoMateria.recordCount#">
            <input type="hidden" name="HayAlumnoCalificacion"  value="#rsHayAlumnoCalificacion.recordCount#">
            <input type="hidden" name="HayMateriaPrograma"  value="#rsHayMateriaPrograma.recordCount#">
            <input type="hidden" name="HayCursoPrograma"  value="#rsHayCursoPrograma.recordCount#">
            <input type="hidden" name="HayEvaluacionConceptoCurso"  value="#rsHayEvaluacionConceptoCurso.recordCount#">
          </cfoutput> </td>
      </tr>
    </cfif>
  </table>

</form>
<script language="JavaScript">
	function deshabilitarValidacion() {
		objForm.PEdescripcion.required = false;
	}
	
	function habilitarValidacion() {
		objForm.PEdescripcion.required = true;
	}
		
	// Se aplica la descripcion del Grado 
	function __isTieneDependencias() {
		if(btnSelected("Baja", this.obj.form)) {
				// Valida que el Grado no tenga dependencias con otros.
				var msg = "";
				if (new Number(this.obj.form.HayEvaluacionConceptoMateria.value) > 0) {
					msg = msg + "conceptos de evaluacion de materias"
				}
				if (new Number(this.obj.form.HayAlumnoCalificacion.value) > 0) {
					if (msg != "") msg += ', ';
					msg = msg + "calificaciones de alumnos"
				}
				if (new Number(this.obj.form.HayMateriaPrograma.value) > 0) {
					if (msg != "") msg += ', ';
					msg = msg + "programas de materias"
				}
				if (new Number(this.obj.form.HayCursoPrograma.value) > 0) {
					if (msg != "") msg += ', ';
					msg = msg + "programas de cursos"
				}
				if (new Number(this.obj.form.HayEvaluacionConceptoCurso.value) > 0) {
					if (msg != "") msg += ', ';
					msg = msg + "conceptos de evaluacion de cursos"
				}
				if (msg != "")
				{
					this.error = "Usted no puede eliminar el Periodo " + this.obj.form.PEdescripcion.value + " porque �ste tiene asociado: " + msg + ".";
					this.obj.form.PEdescripcion.focus();
				}
		}
	}
	
	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isTieneDependencias", __isTieneDependencias);
	
	objForm = new qForm("periodoevaluacion");

	<cfif modo EQ "ALTA">
		objForm.PEdescripcion.required = true;
		objForm.PEdescripcion.description = "Periodo";
		objForm.Ncodigo.required = true;
		objForm.Ncodigo.description = "Nivel";
		objForm.PEorden.description = "Orden";
	<cfelseif modo EQ "CAMBIO">
		objForm.PEdescripcion.required = true;
		objForm.PEdescripcion.description = "Periodo";
		objForm.PEdescripcion.validateTieneDependencias();
	</cfif>
	objForm.Ncodigo.description = "El valor de Nivel";
</script>

