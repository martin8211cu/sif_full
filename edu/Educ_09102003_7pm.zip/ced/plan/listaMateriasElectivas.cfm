<cfinclude template="../../Utiles/general.cfm">
<html><!-- InstanceBegin template="/Templates/LMenuCED.dwt.cfm" codeOutsideHTMLIsLocked="false" -->
<head>
<title>Educaci&oacute;n</title>
<meta http-equiv="Expires" content="Fri, Jan 01 1970 08:20:00 GMT">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Pragma" content="no-cache">
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
<link href="../../css/portlets.css" rel="stylesheet" type="text/css">
<link href="../../css/edu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
<script language="JavaScript" src="../../js/DHTMLMenu/stm31.js"></script>
<script language="JavaScript" type="text/javascript">
	// Funciones para Manejo de Botones
	botonActual = "";

	function setBtn(obj) {
		botonActual = obj.name;
	}
	function btnSelected(name, f) {
		if (f != null) {
			return (f["botonSel"].value == name)
		} else {
			return (botonActual == name)
		}
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="154" rowspan="2" align="center" valign="top"><img src="../../Imagenes/logo.gif" width="154" height="62"></td>
    <td valign="bottom"> 
	  <!-- InstanceBeginEditable name="Ubica" --> 
      <cfinclude template="../../portlets/pubica.cfm">
      <!-- InstanceEndEditable --> </td>
  </tr>
  <tr> 
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr class="area"> 
          <td width="275" valign="middle">
		  	<cfset RolActual = 4>
			<cfset Session.RolActual = 4>
			<cfinclude template="../../portlets/pEmpresas2.cfm">
		  </td>
          <td nowrap> 
            <div align="center"><span class="superTitulo">
			<font size="5">
	  <!-- InstanceBeginEditable name="Titulo" --> 
              Administraci&oacute;n del Centro de Estudio 
      <!-- InstanceEndEditable -->	
			</font></span></div></td>
        </tr>
        <tr class="area" style="padding-bottom: 3px;"> 
		  <td nowrap style="padding-left: 10px;">
		  <cfinclude template="../../portlets/pminisitio.cfm">
		  </td>
          <td valign="top" nowrap> 
	  <!-- InstanceBeginEditable name="MenuJS" --> 
	  		<cfinclude template="../jsMenuCED.cfm">
      <!-- InstanceEndEditable -->	
		  </td>
        </tr>
      </table>
	</td>
  </tr>
</table>
  
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="left" valign="top" nowrap></td>
    <td width="100%" height="1" align="left" valign="top"><!-- InstanceBeginEditable name="Titulo2" -->
	<!-- InstanceEndEditable --></td>
  </tr>
  <tr> 
    <td valign="top" nowrap>
		<cfinclude template="/sif/menu.cfm">
	</td>
    <td valign="top" width="100%">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="2%"class="Titulo"><img  src="../../Imagenes/sp.gif" width="15" height="15" border="0"></td>
          <td width="3%" class="Titulo" >&nbsp;</td>
          <td width="94%" class="Titulo">
		  <!-- InstanceBeginEditable name="TituloPortlet" -->
		  	Lista de Materias Electivas
		  <!-- InstanceEndEditable -->
		  </td>
          <td width="1%" valign="top" nowrap bgcolor="#ADADCA"><img src="../../Imagenes/rt.gif"></td>
        </tr>
        <tr> 
          <td colspan="3" class="contenido-lbborder">
		  <!-- InstanceBeginEditable name="Mantenimiento2" -->
		  
		<cfif isdefined("Url.Mnombre") and not isdefined("Form.Mnombre")>
			<cfparam name="Form.Mnombre" default="#Url.Mnombre#">
		</cfif>
		<cfset Session.RegresarURL = "/cfmx/edu/ced/MenuCED.cfm">
		<cfinclude template="../../portlets/pNavegacionCED.cfm">
		<cfset Session.RegresarURL = "listaMateriasElectivas.cfm">
		<form name="filtroMateriasElectivas" method="post" action="listaMateriasElectivas.cfm">
			<table width="100%" border="0" class="areaFiltro" cellpadding="0" cellspacing="0">
			  <tr> 
				<td nowrap align="right">Materia Electiva</td>
				<td nowrap><input name="Mnombre" type="text" id="Mnombre" size="80" onFocus="this.select()" maxlength="80" value="<cfif isdefined("Form.Mnombre") AND Form.Mnombre NEQ ""><cfoutput>#Form.Mnombre#</cfoutput></cfif>"></td>
				<td align="center" nowrap><input name="btnFiltrar" type="submit" id="btnFiltrar" value="Buscar"></td>
			  </tr>
			</table>
		</form>
		<cfset filtro = "">
		<cfset navegacion = "">
		<cfif isdefined("Form.Mnombre") AND Form.Mnombre NEQ "">
			<cfset filtro = "and upper(rtrim(a.Mnombre)) like upper('%" & #Trim(Form.Mnombre)# & "%')">
			<cfset navegacion = "Mnombre=" & Form.Mnombre>
		</cfif>				
		<cfinvoke 
		 component="edu.Componentes.pListas"
		 method="pListaEdu"
		 returnvariable="pListaEduRet">
			<cfinvokeargument name="tabla" value="Materia a, Nivel b, Grado c"/>
			<cfinvokeargument name="columnas" value="convert(varchar, a.Mconsecutivo) as Mconsecutivo , substring(a.Mnombre,1,50) as Mnombre, substring(c.Gdescripcion,1,50) as Gdescripcion,  substring(b.Ndescripcion,1,50) as Ndescripcion,a.Mhoras, a.Mcreditos, convert(varchar, a.Ncodigo) as Ncodigo, convert(varchar, a.Gcodigo) as Gcodigo, b.Ndescripcion+': '+c.Gdescripcion as Grado "/>
			<cfinvokeargument name="desplegar" value="Mnombre, Mhoras, Mcreditos"/>
			<cfinvokeargument name="etiquetas" value="Descripci&oacute;n, Horas, Cr&eacute;ditos"/>
			<cfinvokeargument name="formatos" value=""/>
			<cfinvokeargument name="filtro" value="b.CEcodigo = #Session.CEcodigo# #filtro# and a.Ncodigo = b.Ncodigo and a.Ncodigo = c.Ncodigo and a.Gcodigo = c.Gcodigo  and b.Ncodigo = c.Ncodigo  and Melectiva = 'E' and a.Mactiva = 1 order by b.Norden, c.Gorden,a.Morden"/>
			<cfinvokeargument name="align" value="left, left, left"/>
			<cfinvokeargument name="ajustar" value="N,N,N"/>
			<cfinvokeargument name="irA" value="MateriasElectivas.cfm"/>
			<cfinvokeargument name="botones" value=""/>
			<cfinvokeargument name="cortes" value="Grado"/>
			<cfinvokeargument name="navegacion" value="#navegacion#"/>
			<cfinvokeargument name="debug" value="N"/>
			<!--- <cfinvokeargument name="maxrows" value="2"/>  --->
		</cfinvoke>
		

          <!-- InstanceEndEditable -->
		  </td>
          <td class="contenido-brborder">&nbsp;</td>
        </tr>
      </table>
	 </td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
