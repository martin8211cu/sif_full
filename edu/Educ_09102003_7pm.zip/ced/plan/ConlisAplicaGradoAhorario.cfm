<cfinclude template="/edu/Utiles/general.cfm">
<html>
<head>
<title>Aplicaci�n de Horario a Grados</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../../css/portlets.css" rel="stylesheet" type="text/css">
<link href="../../css/edu.css" rel="stylesheet" type="text/css">
</head>
<body>
<cfif isdefined("Url.Hcodigo") and not isdefined("Form.Hcodigo")>
	<cfset form.Hcodigo = Url.Hcodigo>
</cfif>

<cfif isdefined("Form.btnAplicar")>
	<cfquery name="rsDelete" datasource="#Session.DSN#">
		set nocount on
		delete HorarioAplica 
		where Hcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Hcodigo#">
		  and Gcodigo in (#form.Cual_Grupo#)  
		set nocount off
	</cfquery>
	<cfif isdefined("Form.Chk")>
		<cfset a=ListToArray(Form.Chk,',')>
		<cfloop index="i" from="1" to="#ArrayLen(a)#">
			<cfset b = ListToArray(a[i],'|')>
			 <cfset Gcodigo = b[1]>
			<cfset Ncodigo = b[2]>
			<cfquery name="ABC_HorarioAplica" datasource="#Session.DSN#">
				set nocount on
				insert HorarioAplica (Gcodigo, Ncodigo, Hcodigo)
				values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Gcodigo#">,
						<cfqueryparam cfsqltype="cf_sql_numeric" value="#Ncodigo#">,
						<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Hcodigo#">
							)
				set nocount off
			</cfquery>
		</cfloop>
		 <script language="JavaScript">
			window.close();
		</script>
		<cfabort>
	</cfif>
<cfelse>
	<cfquery name="rsHorario" datasource="#Session.DSN#">
		select Hnombre 
		from HorarioTipo
		where Hcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Hcodigo#">
	</cfquery>
</cfif>
     <table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <tr> 
    <td align="center"> 

      <form name="filtros" action="ConlisAplicaGradoAhorario.cfm" method="post">
	  	<p class="tituloAlterno">&nbsp; Horario: <cfoutput>#rsHorario.Hnombre#</cfoutput></p>
        <table width="100%" border="0" cellspacing="0" cellpadding="0" class="areaFiltro">
          <tr> 
            <td width="30%" align="right" style="padding-right: 10 px;"><strong>Grados</strong></td>
            <td width="30%"> 
              <cfquery datasource="#Session.DSN#" name="rsGrado">
              select convert(varchar, b.Gcodigo) as Codigo, b.Gdescripcion from 
              Nivel a, Grado b where a.CEcodigo = 
              <cfqueryparam cfsqltype="cf_sql_integer" value="#Session.CEcodigo#">
              and a.Ncodigo = b.Ncodigo order by a.Norden, b.Gorden 
              </cfquery>
              <select name="Gcodigo" id="Gcodigo" tabindex="1" >
                <option value="-1">Todos</option>
                <cfoutput query="rsGrado"> 
                  <option value="#Codigo#">#rsGrado.Gdescripcion#</option>
                </cfoutput> 
              </select>
            </td>
            <td width="40%"> 
            	<input name="Filtrar" type="submit" value="Filtrar">
            	<input name="Limpiar" type="button" value="Limpiar" onClick="javascript: LimpiarFiltros(this.form); ">
				<input name="Hcodigo" type="hidden" id="Hcodigo" value="<cfif isdefined("Form.Hcodigo")><cfoutput>#Form.Hcodigo#</cfoutput></cfif>">
            </td>
          </tr>
        </table>
        </form>
		</td>
              </tr>
              <tr> 
                <td><strong> &nbsp;&nbsp;&nbsp; 
                  <input name="chkTodos" type="checkbox" value="" border="1" onClick="javascript:Marcar(this);">
                  Seleccionar Todos</strong></td>
              </tr>
              <tr> 
                <td>
					<form name="lista" method="post" action="ConlisAplicaGradoAhorario.cfm">
					<input type="hidden" name="Hcodigo" value="<cfif isdefined("Form.Hcodigo")><cfoutput>#Form.Hcodigo#</cfoutput></cfif>">
					<input name="Cual_Grupo" type="hidden" id="Cual_Grupo" value="">

					<cfset navegacion = "">
					<cfset filtro = "">
					<cfif isdefined("Form.Pagina") and Form.Pagina NEQ "">
                    	<cfset Pagenum_lista = Form.Pagina>
                  	</cfif> 
					<cfif isdefined("Form.Gcodigo") and (Len(Trim(Form.Gcodigo)) NEQ 0) and (Form.Gcodigo NEQ "-1")>
						<cfset filtro = "and b.Gcodigo = "  & #Trim(Form.Gcodigo)# >
						<cfset navegacion = navegacion & Iif(Len(Trim(navegacion)) NEQ 0, DE("&"), DE("")) & "Gcodigo=" & Form.Gcodigo>
					</cfif>
					<cfif isdefined("Form.Hcodigo") and Form.Hcodigo NEQ ''>
						<cfset navegacion = navegacion & Iif(Len(Trim(navegacion)) NEQ 0, DE("&"), DE("")) & "Hcodigo=" & Form.Hcodigo>
					</cfif>
					<cfinvoke 
						 component="edu.Componentes.pListas"
						 method="pListaEdu"
						 returnvariable="pListaRet">
					<cfinvokeargument name="tabla" value="Grado b, Nivel a, HorarioAplica c"/>
						<cfinvokeargument name="columnas" value="convert(varchar, b.Gcodigo) as Gcodigo, convert(varchar, b.Ncodigo) as Ncodigo, substring(a.Ndescripcion,1,50) as Ndescripcion, b.Gdescripcion, convert(varchar, c.Gcodigo)+'|'+convert(varchar, c.Ncodigo) as checked"/>
						<cfinvokeargument name="desplegar" value="Gdescripcion"/>
						<cfinvokeargument name="etiquetas" value="Descripci�n"/>
						<cfinvokeargument name="formatos" value=""/>
						<cfinvokeargument name="filtro" value=" a.CEcodigo = #Session.CEcodigo# #filtro# and b.Gcodigo *= c.Gcodigo and b.Ncodigo *= c.Ncodigo and c.Hcodigo = #Form.Hcodigo# and a.Ncodigo = b.Ncodigo order by a.Norden, b.Gorden "/>
						<cfinvokeargument name="align" value="left"/>
						<cfinvokeargument name="ajustar" value="N"/>
						<cfinvokeargument name="irA" value="ConlisAplicaGradoAhorario.cfm"/>
						<cfinvokeargument name="cortes" value="Ndescripcion"/>
						<cfinvokeargument name="checkboxes" value="S"/>
						<cfinvokeargument name="debug" value="N"/>
						<cfinvokeargument name="maxrows" value="10"/>
						<cfinvokeargument name="incluyeForm" value="false"/>
						<cfinvokeargument name="formName" value="lista"/>
						<cfinvokeargument name="navegacion" value="#navegacion#"/>
						<cfinvokeargument name="keys" value="Gcodigo, Ncodigo "/>
						<cfinvokeargument name="checkedcol" value="checked"/>
						<cfinvokeargument name="botones" value="Aplicar"/>
					</cfinvoke>
					
						 <script language="JavaScript">
						 	if (document.lista.chk != null) {
								if (document.lista.chk.value != null) {
									if (document.lista.chk.checked) document.lista.chk.checked = true; else document.lista.chk.checked = false;
										var a = document.lista.chk.value.split("|");
										var Gcodigo = a[0];
										document.lista.Cual_Grupo.value += Gcodigo ;
								} else {
									for (var counter = 0; counter < document.lista.chk.length; counter++) {
										var a = document.lista.chk[counter].value.split("|");
										var Gcodigo = a[0];
										document.lista.Cual_Grupo.value += Gcodigo + ",";
									}
									if (document.lista.Cual_Grupo.value != "") {
										document.lista.Cual_Grupo.value = document.lista.Cual_Grupo.value.substring(0,document.lista.Cual_Grupo.value.length-1);
									}
								}
							}
						</script>
					</form>
				 </td>
              </tr>
            </table>
	  <script language="JavaScript1.2">
		function Marcar(c) {
			if (document.lista.chk != null) { //existe?
				if (document.lista.chk.value != null) {// solo un check
					if (c.checked) document.lista.chk.checked = true; else document.lista.chk.checked = false;
				}
				else {
					if (c.checked) {
						for (var counter = 0; counter < document.lista.chk.length; counter++)
						{
							if ((!document.lista.chk[counter].checked) && (!document.lista.chk[counter].disabled))
								{  document.lista.chk[counter].checked = true;}
						}
						if ((counter==0)  && (!document.lista.chk.disabled)) {
							document.lista.chk.checked = true;
						}
					}
					else {
						for (var counter = 0; counter < document.lista.chk.length; counter++)
						{
							if ((document.lista.chk[counter].checked) && (!document.lista.chk[counter].disabled))
								{  document.lista.chk[counter].checked = false;}
						};
						if ((counter==0) && (!document.lista.chk.disabled)) {
							document.lista.chk.checked = false;
						}
					};
				}
			}
		}

		function LimpiarFiltros(f) {
			f.Gcodigo.selectedIndex = 0;
		}
	
							  
	  </script>

</body>
</html>