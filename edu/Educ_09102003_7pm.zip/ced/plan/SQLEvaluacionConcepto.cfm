<cfif not isdefined("form.Nuevo")>

	<cfif form.ECorden eq "" and (isdefined("form.Alta") or isdefined("form.Cambio"))>
		<cfquery name="rsOrden" datasource="#session.DSN#">
			set nocount on
			select isnull(max(ECorden),0) + 10 as ECorden 
			from EvaluacionConcepto
			where CEcodigo=<cfqueryparam value="#session.CEcodigo#" cfsqltype="cf_sql_numeric">
			set nocount off
		</cfquery>
		<cfif rsOrden.RecordCount gt 0>
			<cfset form.ECorden = rsOrden.ECorden>
		<cfelse>
			<cfset form.ECorden = 1>
		</cfif>
	</cfif>
	
	<cftry>
		<cfquery name="abc_EvaluacionConcepto" datasource="#session.DSN#">
			set nocount on
			<cfif isdefined("form.Alta")>
				insert EvaluacionConcepto ( CEcodigo, ECnombre, ECorden )
							values( <cfqueryparam value="#session.CEcodigo#" cfsqltype="cf_sql_numeric">, 
									<cfqueryparam value="#form.ECnombre#"    cfsqltype="cf_sql_varchar">,
									<cfqueryparam value="#form.ECorden#"     cfsqltype="cf_sql_integer">
						  		  )

				<cfset modo="ALTA">
			<cfelseif isdefined("form.Baja")>
				if not exists ( select 1 from EvaluacionConceptoCurso
						where ECcodigo = <cfqueryparam value="#Form.ECcodigo#" cfsqltype="cf_sql_numeric">
					)
				begin			
					if not exists ( select 1 from EvaluacionConceptoMateria
						where ECcodigo = <cfqueryparam value="#Form.ECcodigo#" cfsqltype="cf_sql_numeric">
					)				
					begin
						if not exists ( select 1 from EvaluacionPlanConcepto
							where ECcodigo = <cfqueryparam value="#Form.ECcodigo#" cfsqltype="cf_sql_numeric">
						)				
						begin
					
							delete EvaluacionConcepto
							where ECcodigo = <cfqueryparam value="#form.ECcodigo#"    cfsqltype="cf_sql_numeric">
						end
						else
						begin
							select 1
						end
					end
					else
					begin
						select 1
					end
				end
				else
				begin
					select 1
				end	
			 	<cfset modo="ALTA">

			<cfelseif isdefined("form.Cambio")>

				 update EvaluacionConcepto 
				 set ECnombre      = <cfqueryparam value="#form.ECnombre#" cfsqltype="cf_sql_varchar">,
				 	 ECorden       = <cfqueryparam value="#form.ECorden#"  cfsqltype="cf_sql_integer">
				 where ECcodigo    = <cfqueryparam value="#form.ECcodigo#" cfsqltype="cf_sql_numeric">

				  <cfset modo="ALTA">
			</cfif>
			set nocount off
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>
</cfif>

<form action="EvaluacionConcepto.cfm" method="post" name="sql">
	<input name="modo"     type="hidden" value="<cfif isdefined("modo")><cfoutput>#modo#</cfoutput></cfif>">
	<input name="ECcodigo" type="hidden" value="<cfif isdefined("Form.ECcodigo")><cfoutput>#Form.ECcodigo#</cfoutput></cfif>">
	<input name="Pagina"   type="hidden" value="<cfif isdefined("Form.Pagina")><cfoutput>#Form.Pagina#</cfoutput></cfif>">	
</form>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>