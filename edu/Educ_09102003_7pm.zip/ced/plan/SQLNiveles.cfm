<cfif not isdefined("Form.Nuevo")>
	<cftry>
		<cfquery name="ABC_Nivel" datasource="#Session.DSN#">
			set nocount on
			<cfif isdefined("Form.Alta")>
				if not exists ( select 1 from Nivel 
					where CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
					  and Ndescripcion = <cfqueryparam value="#Form.Ndescripcion#" cfsqltype="cf_sql_varchar">
				)
				begin
					declare @cont int
					select @cont = isnull(max(Norden),0)+10 
					from Nivel 
					where CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
					insert into Nivel (CEcodigo, Ndescripcion, Nnotaminima, Norden )
					values(
						<cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">,
						<cfqueryparam value="#Form.Ndescripcion#" cfsqltype="cf_sql_varchar">,
						<cfqueryparam value="#Form.Nnotaminima#" cfsqltype="cf_sql_smallint">,
						<cfif len(trim(#Form.Norden#)) NEQ 0 >
							<cfqueryparam value="#Form.Norden#" cfsqltype="cf_sql_smallint" >
						<cfelse>
							@cont	
						</cfif>
						)
				end	
				else 
					select 1
				<cfset modo="ALTA">
			<cfelseif isdefined("Form.Baja")>
				if not exists (select 1 from Grado 
								where Ncodigo =  <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
				)
				begin
					delete from PeriodoVigente
					where Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
				
					delete from Nivel
					where CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">
					  and Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
				end
				else 
					select 1
				  <cfset modo="BAJA">
			<cfelseif isdefined("Form.Cambio")>
				declare @cont int
				select @cont = isnull(max(Norden),0)+10 
				from Nivel 
				where CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">			
				update Nivel set
					Ndescripcion = <cfqueryparam value="#Form.Ndescripcion#" cfsqltype="cf_sql_varchar">,
					Nnotaminima = <cfqueryparam value="#Form.Nnotaminima#" cfsqltype="cf_sql_smallint">,
					<cfif len(trim(#Form.Norden#)) NEQ 0 >
						Norden = <cfqueryparam value="#Form.Norden#" cfsqltype="cf_sql_smallint" >
					<cfelse>
						Norden = @cont	
					</cfif>
				where CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
				  and Ncodigo = <cfqueryparam value="#Form.Ncodigo#" cfsqltype="cf_sql_numeric">
				  <cfset modo="CAMBIO">
			</cfif>
			set nocount off
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>
</cfif>
<form action="Nivel.cfm" method="post" name="sql">
	<input name="modo" type="hidden" value="<cfif isdefined("modo")><cfoutput>#modo#</cfoutput></cfif>">
	<input name="Ncodigo" type="hidden" value="<cfif isdefined("Form.Ncodigo")><cfoutput>#Form.Ncodigo#</cfoutput></cfif>">
	<input name="modulo" type="hidden" value="<cfif isdefined("form.modulo")><cfoutput>#form.modulo#</cfoutput></cfif>">
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")><cfoutput>#Form.Pagina#</cfoutput></cfif>">
</form>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>


