<html>
<head>
<title>Listado Hist�rico de Notas Finales</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../../../css/edu.css" type="text/css">
</head>

<body>
	<cfinclude template="../formNotasFinalesHist.cfm">
</body>
</html>