<cfparam name="action" default="alumno.cfm">

<cfif isdefined("form.btnAgregar") or isdefined("form.btnCambiar") or isdefined("form.btnBorrar") or isdefined("form.btnAgregarEncar")>
	<cfset tmp = "" >		<!--- comtenido binario de la imagen --->
	<cfset ts = "null">
	<cfif isdefined("Form.Pfoto") and form.Pfoto NEQ "">
		<cftry>
			<!--- Seccion del Upload= Copia la imagen a un folder del servidor servidor --->
			<cffile action="Upload" fileField="form.Pfoto" destination="#GetTempDirectory()#" nameConflict="Overwrite" accept="image/*"> 
			<!--- lee la imagen de la carpeta del servidor y la almacena en la variable tmp --->
			<cffile action="readbinary"  file="#GetTempDirectory()##cffile.ClientFileName#.#cffile.ClientFileExt#" variable="tmp" > 
	
			<cffile action="delete" file="#GetTempDirectory()##cffile.ClientFileName#.#cffile.ClientFileExt#">
		
			<!--- Formato para sybase --->
				<cfset Hex=ListtoArray("0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F")>
		
				<cfif not isArray(tmp)>
					<cfset ts = "">
				</cfif>
				<cfset miarreglo=#ListtoArray(ArraytoList(#tmp#,","),",")#>
				<cfset miarreglo2=ArrayNew(1)>
				<cfset temp=ArraySet(miarreglo2,1,8,"")>
		
				<cfloop index="i" from="1" to=#ArrayLen(miarreglo)#>
					<cfif miarreglo[i] LT 0>
						<cfset miarreglo[i]=miarreglo[i]+256>
					</cfif>
				</cfloop>
		
				<cfloop index="i" from="1" to=#ArrayLen(miarreglo)#>
					<cfif miarreglo[i] LT 10>
						<cfset miarreglo2[i] = "0" & #toString(Hex[(miarreglo[i] MOD 16)+1])#>
					<cfelse>
						<cfset miarreglo2[i] = #trim(toString(Hex[(miarreglo[i] \ 16)+1]))# & #trim(toString(Hex[(miarreglo[i] MOD 16)+1]))#>
					</cfif>
				</cfloop>
				<cfset temp = #ArrayPrepend(miarreglo2,"0x")#>
				<cfset ts = #ArraytoList(miarreglo2,"")#>
		<cfcatch type="any">
 			<cfinclude template="/edu/errorPages/BDerror.cfm">
			<cfabort>
		</cfcatch>
		</cftry>		
	</cfif>		

	<cftry>
		<!--- Caso 1: Agregar --->
		<cfif isdefined("Form.btnAgregar")>
			
		
			<cfquery name="ABC_Alumno" datasource="#Session.DSN#">
				set nocount on
				declare @NuevaPersona numeric, @NuevoEstudiante numeric

				insert PersonaEducativo 
				(CEcodigo, Pnombre, Papellido1, Papellido2, Ppais, TIcodigo, Pid, Pnacimiento, Psexo, Pemail1, Pemail2, Pdireccion, Pcasa, Pfoto, Pemail1validado)
				values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pnombre#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Papellido1#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Papellido2#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppais#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.TIcodigo#">,							
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pid#">,
						convert( datetime, <cfqueryparam value="#form.Pnacimiento#" cfsqltype="cf_sql_varchar">, 103 ),																				
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Psexo#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pemail1#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pemail2#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pdireccion#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pcasa#">,
						#ts#,0)
						
				select @NuevaPersona = @@identity 
							
				<!--- Inserci�n en la tabla de Estudiante y Alumnos --->							
				insert Estudiante (persona, autorizado)
					values (@NuevaPersona,
							<cfif isdefined("Form.autorizado")>
								1
							<cfelse>
								0
							</cfif>
							)
					
				select @NuevoEstudiante = @@identity 

				insert Alumnos (CEcodigo, Ecodigo, persona, Aingreso, PRcodigo, Aretirado, CEcontrato)
				values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
						@NuevoEstudiante,
						@NuevaPersona,
						getDate(),
						<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.PRcodigo#">,
						<cfif isdefined("Form.Aretirado")>
							1,
						<cfelse>
							0,
						</cfif>
						null
						)							

				<!--- Inserci�n en la tabla de AlumnoRetirado si se inserta el alumno y se Retira de una vez --->							
				<cfif isdefined("Form.Aretirado")>
					insert AlumnoRetirado (CEcodigo, Ecodigo, ARfecha, ARalta)
					values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
							@NuevoEstudiante,
							getDate(),0)
				</cfif>							

				select convert(varchar, @NuevaPersona) as id, convert(varchar, @NuevoEstudiante) as num_ref
				set nocount off
			</cfquery>
			
			<cfset activacion = "0">
			<cfif isdefined("Form.autorizado")>
				<cfset activacion = "1">
			</cfif>

			<!--- Insercion del Usuario en el Framework --->
			<cfinvoke 
			 component="edu.Componentes.usuarios"
			 method="upd_usuario"
			 returnvariable="UsrInserted">
				<cfinvokeargument name="consecutivo" value="#Session.CEcodigo#"/>
				<cfinvokeargument name="sistema" value="edu"/>
				<cfinvokeargument name="referencias" value="#ABC_Alumno.num_ref#"/>
				<cfinvokeargument name="roles" value="edu.estudiante"/>
				<cfinvokeargument name="activacion" value="#activacion#"/>
				<cfinvokeargument name="Pnombre" value="#form.Pnombre#"/>
				<cfinvokeargument name="Papellido1" value="#form.Papellido1#"/>
				<cfinvokeargument name="Papellido2" value="#form.Papellido2#"/>
				<cfinvokeargument name="Ppais" value="#form.Ppais#"/>
				<cfinvokeargument name="TIcodigo" value="#form.TIcodigo#"/>
				<cfinvokeargument name="Pid" value="#form.Pid#"/>
				<cfinvokeargument name="Pnacimiento" value="#form.Pnacimiento#"/>
				<cfinvokeargument name="Psexo" value="#form.Psexo#"/>
				<cfinvokeargument name="Pemail1" value="#form.Pemail1#"/>
				<cfinvokeargument name="Pemail2" value="#form.Pemail2#"/>
				<cfinvokeargument name="Pdireccion" value="#form.Pdireccion#"/>
				<cfinvokeargument name="Pcasa" value="#form.Pcasa#"/>
				<cfif isdefined("Form.Pfoto") and form.Pfoto NEQ "">
					<cfinvokeargument name="Pfoto" value="#ts#"/>
				</cfif>
			</cfinvoke>

			<cfset form.fRHnombre = "#form.Pnombre#" & ' ' & "#form.Papellido1#" & ' ' & "#form.Papellido2#">
			<cfset action = "alumno.cfm">
			<cfset modo="CAMBIO">
				
		<!--- Caso 2: Cambio --->
		<cfelseif isdefined("Form.btnCambiar") and isdefined("form.persona") and form.persona NEQ "">
					<!--- Para definir nuevo contrato --->
			<cfif isdefined("form.CboCEcontrato") and form.CboCEcontrato EQ -1>
					<cfset ContratoNew = "">
					<cfset encontrado = false>
						<!---Ciclo que consulta si existe esta contrato, si no existe hace break y continua el script --->
						 <cfloop  condition="#encontrado# EQ false">
							<cfset ContratoNew = #Rand()#>
							<cfquery name="ABC_RH" datasource="#Session.DSN#">
									set nocount on
									if not exists ( select 1 from Alumnos
											where CEcontrato = <cfqueryparam value="#ContratoNew#" cfsqltype="cf_sql_char">
										)
										begin
											select 0 as existe
										end	
										else 
											select 1 as existe
										set nocount off
							</cfquery>			
							<cfif ABC_RH.existe EQ 0 >
								<cfset encontrado = true>
							</cfif>
						</cfloop> 
						<cfset CtaNueva = "">
						<cfset encontrado = false>
							<!---Ciclo que consulta si existe esta contrato, si no existe hace break y continua el script --->
							 <cfloop  condition="#encontrado# EQ false">
								<cfset CtaNueva = mid(#Rand()#,3,10)>
								<cfquery name="ABC_RH" datasource="#Session.DSN#">
										set nocount on
										if not exists ( select 1 from ContratoEdu
												where substring(CEcuenta,1,3) + substring(CEcuenta,5,8)  = <cfqueryparam value="#CtaNueva#" cfsqltype="cf_sql_char">
											)
											begin
												select 0 as existe
											end	
											else 
												select 1 as existe
											set nocount off
								</cfquery>			
								<cfif ABC_RH.existe EQ 0 >
									<cfset encontrado = true>
								</cfif>
							</cfloop> 

						
						<cfquery name="ABC_RH" datasource="#Session.DSN#">
							insert ContratoEdu (CEcontrato,CEcodigo,CEdescripcion,CEcuenta,CEtitular)
							values (substring('<cfoutput>#ContratoNew#</cfoutput>',3,10),
									<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
									'Contrato de ' + <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.nombre#">,
									substring('<cfoutput>#CtaNueva#</cfoutput>',1,3) + '-' + substring('<cfoutput>#CtaNueva#</cfoutput>',4,8),
									<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.nombre#" >
									)
						</cfquery>
				</cfif>
		
			<!--- Query para obtener la referencia que se puede utilizar para borrar un Usuario del Framework --->
			<cfquery name="refUser" datasource="#Session.DSN#">
				select convert(varchar, Ecodigo) as num_referencia, 'edu.estudiante' as rol
				from Estudiante
				where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
			</cfquery>
				
			<cfquery name="ABC_Alumno" datasource="#Session.DSN#">
				set nocount on
				declare @estaRetirado numeric
				select @estaRetirado = Aretirado from Alumnos
				where CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
					and persona= <cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">
				if @estaRetirado is null
					select @estaRetirado = 0
			
				update PersonaEducativo set
					Pnombre=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pnombre#">,
					Papellido1=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Papellido1#">,
					Papellido2=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Papellido2#">,
					Ppais=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppais#">,
					TIcodigo=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.TIcodigo#">,
					Pid=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pid#">,
					Pnacimiento=convert( datetime, <cfqueryparam value="#form.Pnacimiento#" cfsqltype="cf_sql_varchar">, 103 ),
					Psexo=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Psexo#">,
					Pemail1=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pemail1#">,
					Pemail2=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pemail2#">,
					Pdireccion=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pdireccion#">,
					Pcasa=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pcasa#">,
					<cfif isdefined("Form.Pfoto") and #form.Pfoto# NEQ "">
						Pfoto=#ts#,					
					</cfif>
					Pemail1validado = 0
				where persona= <cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">
				
				update Estudiante
				<cfif isdefined("Form.autorizado")>
				   set autorizado = 1
				<cfelse>
				   set autorizado = 0
				</cfif>
				where persona = <cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">

				update Alumnos set
					Aingreso=getDate(),
					PRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.PRcodigo#">,
					<cfif isdefined("Form.Aretirado")>
						Aretirado=1,
					<cfelse>
						Aretirado=0,
					</cfif>
					<cfif isdefined("Form.CboCEcontrato") and form.CboCEcontrato EQ 0>
						CEcontrato = null
					<cfelseif isdefined("Form.CboCEcontrato") and form.CboCEcontrato EQ -1>
						CEcontrato = substring('<cfoutput>#ContratoNew#</cfoutput>',3,10)
					<cfelse>
						CEcontrato = <cfqueryparam cfsqltype="cf_sql_char" value="#form.CboCEcontrato#">
					</cfif>
				where CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
					and persona= <cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">

				<!--- Inserci�n en la tabla de AlumnoRetirado si se inserta el alumno y se Retira de una vez --->							
				<cfif isdefined("Form.Aretirado")>
					<cfif isdefined('form.form_Ecodigo') and form.form_Ecodigo NEQ ''>
						if @estaRetirado = 0
						begin					
							insert into AlumnoRetirado (CEcodigo, Ecodigo, ARfecha, ARalta, 
								PRcodigo, PEcodigo, SPEcodigo, Ncodigo, Gcodigo)
							select a.CEcodigo, a.Ecodigo, getDate(), 0, 
								pr.PRcodigo, pr.PEcodigo, pr.SPEcodigo, pr.Ncodigo, pr.Gcodigo
							from Alumnos a, Promocion pr
							where a.PRcodigo = pr.PRcodigo
							and a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
							and a.Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.form_Ecodigo#">
							<!---
							declare @promocionAnterior numeric
							select @promocionAnterior = PRcodigo from Alumnos
								where Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.form_Ecodigo#">
							if @promocionAnterior is not null
								execute sp_Desmatricular
									@PRcodigo = @promocionAnterior,
									@Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.form_Ecodigo#">
							--->		
							update Alumnos set PRcodigo = null
							where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
							and Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.form_Ecodigo#">
						end
					</cfif>
				<cfelse>
					<cfif isdefined('form.form_Ecodigo') and form.form_Ecodigo NEQ ''>
						if @estaRetirado = 1
						begin
							insert into AlumnoRetirado (CEcodigo, Ecodigo, ARfecha, ARalta, 
								PRcodigo, PEcodigo, SPEcodigo, Ncodigo, Gcodigo)
							select a.CEcodigo, a.Ecodigo, getDate(), 1, 
								pr.PRcodigo, pr.PEcodigo, pr.SPEcodigo, pr.Ncodigo, pr.Gcodigo
							from Alumnos a, Promocion pr
							where a.PRcodigo = pr.PRcodigo
							and a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
							and a.Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.form_Ecodigo#">
						end
					</cfif>
				</cfif>
				
				set nocount off
			</cfquery>							

			<cfset activacion = "0">
			<cfif isdefined("Form.autorizado")>
				<cfset activacion = "1">
			</cfif>

			<!--- Actualizacion del Usuario en el Framework --->
			<cfinvoke 
			 component="edu.Componentes.usuarios"
			 method="upd_usuario"
			 returnvariable="UsrUpdated">
				<cfinvokeargument name="consecutivo" value="#Session.CEcodigo#"/>
				<cfinvokeargument name="sistema" value="edu"/>
				<cfinvokeargument name="referencias" value="#refUser.num_referencia#"/>
				<cfinvokeargument name="roles" value="#refUser.rol#"/>
				<cfinvokeargument name="activacion" value="#activacion#"/>
				<cfinvokeargument name="Pnombre" value="#form.Pnombre#"/>
				<cfinvokeargument name="Papellido1" value="#form.Papellido1#"/>
				<cfinvokeargument name="Papellido2" value="#form.Papellido2#"/>
				<cfinvokeargument name="Ppais" value="#form.Ppais#"/>
				<cfinvokeargument name="TIcodigo" value="#form.TIcodigo#"/>
				<cfinvokeargument name="Pid" value="#form.Pid#"/>
				<cfinvokeargument name="Pnacimiento" value="#form.Pnacimiento#"/>
				<cfinvokeargument name="Psexo" value="#form.Psexo#"/>
				<cfinvokeargument name="Pemail1" value="#form.Pemail1#"/>
				<cfinvokeargument name="Pemail2" value="#form.Pemail2#"/>
				<cfinvokeargument name="Pdireccion" value="#form.Pdireccion#"/>
				<cfinvokeargument name="Pcasa" value="#form.Pcasa#"/>
				<cfif isdefined("Form.Pfoto") and form.Pfoto NEQ "">
					<cfinvokeargument name="Pfoto" value="#ts#"/>
				</cfif>
				<cfinvokeargument name="upd_referencia" value="#refUser.num_referencia#"/>
				<cfinvokeargument name="upd_rol" value="#refUser.rol#"/>
				<cfinvokeargument name="dominio_roles" value="#refUser.rol#"/>
			</cfinvoke>
				
			<cfset action = "alumno.cfm">								
			<cfset modo="CAMBIO">

		<!--- Caso 3: Agregar un Encargado --->
		<cfelseif isdefined("Form.btnAgregarEncar") and isdefined("form.Ecodigo") AND form.Ecodigo NEQ "" >
			<cfquery name="ABC_Alumno" datasource="#Session.DSN#">
				insert EncargadoEstudiante (EEcodigo, CEcodigo, Ecodigo)
				values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.NuevoEEcodigo#">,
						<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
						<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Ecodigo#">)			
			</cfquery>

			<cfset action = "alumno.cfm">								
			<cfset modo="CAMBIO">								
			
		<!--- Caso 4: Borrar --->
		<cfelseif isdefined("Form.btnBorrar")>			
			<cfif isdefined("Form.persona") AND Form.persona NEQ "" >

				<!--- Query para obtener la referencia que se puede utilizar para borrar un Usuario del Framework --->
				<cfquery name="refUser" datasource="#Session.DSN#">
					select convert(varchar, Ecodigo) as num_referencia, 'edu.estudiante' as rol
					from Estudiante
					where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
				</cfquery>
				
				<cfinvoke 
				 component="edu.Componentes.usuarios"
				 method="del_usuario_by_ref"
				 returnvariable="UsrDeleted">
					<cfinvokeargument name="consecutivo" value="#Session.CEcodigo#"/>
					<cfinvokeargument name="sistema" value="edu"/>
					<cfinvokeargument name="referencia" value="#refUser.num_referencia#"/>
					<cfinvokeargument name="rol" value="#refUser.rol#"/>
				</cfinvoke>
				
				<cfquery name="ABC_Alumno" datasource="#Session.DSN#">
					set nocount on
					<!--- Borra todos los encargados asociados a �l como estudiante --->
					delete EncargadoEstudiante
					where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
					and Ecodigo in (select Ecodigo from Alumnos where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">) 

					<!--- Borrado de AlumnoRetirado --->
 					<cfif isdefined('form.form_Ecodigo') and form.form_Ecodigo NEQ ''>
						delete AlumnoRetirado
						where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
						  and Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.form_Ecodigo#">
					</cfif> 

					delete Alumnos 
					where  CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
						and persona=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
						
					delete Estudiante 
					where  persona=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
					
					<!--- Borrado de la persona --->					
					delete PersonaEducativo 
					where persona=<cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">				

					set nocount off
				</cfquery>
				
				<cfset modo="ALTA">
				<cfset form.fRHnombre = "">
			</cfif>								
		</cfif>
		
	<cfcatch type="any">
		<cfinclude template="/edu/errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>		
<cfelse> 
	<cfset action = "alumno.cfm" >
	<cfset modo   = "ALTA" >
</cfif>

<cfif isdefined("form.btnAgregar") or isdefined("form.btnCambiar")>
	<cfif isdefined("form.persona") AND form.persona EQ "">
		<cfset form.persona = ABC_Alumno.id>
	</cfif>		
</cfif>

<!--- Borrado de Encargados por estudiante --->
<cfif isdefined("form.EncargadoBajaEEcod") and form.EncargadoBajaEEcod NEQ "" and isdefined("form.EncargadoBajaEcod") and form.EncargadoBajaEcod NEQ "">
	<cftry>
		<cfquery name="BajaEncar" datasource="#Session.DSN#">
			delete EncargadoEstudiante
			where EEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.EncargadoBajaEEcod#">
			and CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
			and Ecodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.EncargadoBajaEcod#">
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="/edu/errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>
	
	<cfset action = "alumno.cfm" >
	<cfset modo   = "CAMBIO" >
</cfif>

<cfoutput>
<form action="#action#" method="post" name="sql">
	<input name="modo"   type="hidden" value="<cfif isdefined("modo")>#modo#</cfif>">
	<input name="persona"   type="hidden" value="<cfif isdefined("modo") and modo NEQ "ALTA" and isdefined("Form.persona") and form.persona NEQ "">#form.persona#</cfif>">
	<input name="o"   type="hidden" value="<cfif isdefined("form.o") and form.o NEQ "">#form.o#</cfif>">
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")>#Form.Pagina#</cfif>">
	<cfif isdefined("Form.fRHnombre")>
		<input type="hidden" name="fRHnombre" value="#Form.fRHnombre#">
	</cfif>		   
	<cfif isdefined("Form.FNcodigo")>
		<input type="hidden" name="FNcodigo" value="#Form.FNcodigo#">
	</cfif>		
	<cfif isdefined("Form.filtroRhPid")>
	 	<input type="hidden" name="filtroRhPid" value="#Form.filtroRhPid#">
	</cfif>		
	<cfif isdefined("Form.FGcodigo")>
		<input type="hidden" name="FGcodigo" value="#Form.FGcodigo#">
	</cfif>
	<cfif isdefined("Form.NoMatr")>
		<input type="hidden" name="NoMatr" value="#Form.NoMatr#">
	</cfif>		  		  
	<cfif isdefined("Form.FAretirado")>
		<input type="hidden" name="FAretirado" value="#Form.FAretirado#">
	</cfif>
	
	<!--- Campos para el boton de buscar --->
	<cfif isdefined("form.btnBuscar") > 
		<input name="Busca" type="hidden" value="1">
		<input name="Pnombre" type="hidden" value="<cfif isdefined("Form.Pnombre")>#Form.Pnombre#</cfif>">	
		<input name="Papellido1" type="hidden" value="<cfif isdefined("Form.Papellido1")>#Form.Papellido1#</cfif>">		
		<input name="Papellido2" type="hidden" value="<cfif isdefined("Form.Papellido2")>#Form.Papellido2#</cfif>">			
		<input name="Pid" type="hidden" value="<cfif isdefined("Form.Pid")>#Form.Pid#</cfif>">				
		<input name="Pdireccion" type="hidden" value="<cfif isdefined("Form.Pdireccion")>#Form.Pdireccion#</cfif>">					
		<input name="Pcasa" type="hidden" value="<cfif isdefined("Form.Pcasa")>#Form.Pcasa#</cfif>">							
		<input name="Pemail1" type="hidden" value="<cfif isdefined("Form.Pemail1")>#Form.Pemail1#</cfif>">																			
		<input name="Pemail2" type="hidden" value="<cfif isdefined("Form.Pemail2")>#Form.Pemail2#</cfif>">																			
	</cfif>		
</form>
</cfoutput>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>