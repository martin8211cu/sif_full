<cfinclude template="../../Utiles/general.cfm">
<html><!-- InstanceBegin template="/Templates/LMenuCED.dwt.cfm" codeOutsideHTMLIsLocked="false" -->
<head>
<title>Educaci&oacute;n</title>
<meta http-equiv="Expires" content="Fri, Jan 01 1970 08:20:00 GMT">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Pragma" content="no-cache">
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
<link href="../../css/portlets.css" rel="stylesheet" type="text/css">
<link href="../../css/edu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
<script language="JavaScript" src="../../js/DHTMLMenu/stm31.js"></script>
<script language="JavaScript" type="text/javascript">
	// Funciones para Manejo de Botones
	botonActual = "";

	function setBtn(obj) {
		botonActual = obj.name;
	}
	function btnSelected(name, f) {
		if (f != null) {
			return (f["botonSel"].value == name)
		} else {
			return (botonActual == name)
		}
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="154" rowspan="2" align="center" valign="top"><img src="../../Imagenes/logo.gif" width="154" height="62"></td>
    <td valign="bottom"> 
	  <!-- InstanceBeginEditable name="Ubica" --> 
      <cfinclude template="../../portlets/pubica.cfm">
      <!-- InstanceEndEditable --> </td>
  </tr>
  <tr> 
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr class="area"> 
          <td width="275" valign="middle">
		  	<cfset RolActual = 4>
			<cfset Session.RolActual = 4>
			<cfinclude template="../../portlets/pEmpresas2.cfm">
		  </td>
          <td nowrap> 
            <div align="center"><span class="superTitulo">
			<font size="5">
	  <!-- InstanceBeginEditable name="Titulo" --> 
              administracion del centro de estudios<!-- InstanceEndEditable -->	
			</font></span></div></td>
        </tr>
        <tr class="area" style="padding-bottom: 3px;"> 
		  <td nowrap style="padding-left: 10px;">
		  <cfinclude template="../../portlets/pminisitio.cfm">
		  </td>
          <td valign="top" nowrap> 
	  <!-- InstanceBeginEditable name="MenuJS" -->
	  <cfinclude template="../jsMenuCED.cfm"> 
      <!-- InstanceEndEditable -->	
		  </td>
        </tr>
      </table>
	</td>
  </tr>
</table>
  
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="left" valign="top" nowrap></td>
    <td width="100%" height="1" align="left" valign="top"><!-- InstanceBeginEditable name="Titulo2" --><!-- InstanceEndEditable --></td>
  </tr>
  <tr> 
    <td valign="top" nowrap>
		<cfinclude template="/sif/menu.cfm">
	</td>
    <td valign="top" width="100%">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="2%"class="Titulo"><img  src="../../Imagenes/sp.gif" width="15" height="15" border="0"></td>
          <td width="3%" class="Titulo" >&nbsp;</td>
          <td width="94%" class="Titulo">
		  <!-- InstanceBeginEditable name="TituloPortlet" --> 
            matricula extraordinaria<!-- InstanceEndEditable -->
		  </td>
          <td width="1%" valign="top" nowrap bgcolor="#ADADCA"><img src="../../Imagenes/rt.gif"></td>
        </tr>
        <tr> 
          <td colspan="3" class="contenido-lbborder">
		  <!-- InstanceBeginEditable name="Mantenimiento2" -->
		  <cfif isdefined("Form.checkAlumno")>
			<cfset indices = Replace(Form.checkAlumno,chr(44)," ","all")>
			<cfset codigos = Replace(Form.Ecodigo,chr(44)," ","all")>
			<cfif isdefined("Form.Csustituto")>
				<cfset codigosSustitutivos = Replace(Form.Csustituto,chr(44)," ","all")>
			</cfif>
			<cfset index = 1>
			<cfset codIndice = GetToken(indices,index)>
			<!---
			<cfoutput>codigos: #codigos#</cfoutput><br>
			<cfoutput>codIndice: #codIndice#</cfoutput><br>
			<cfoutput>indices: #indices#</cfoutput><br>
			--->
			<cfloop condition="codIndice NEQ ''">
			
				<cfset codEstudiante = GetToken(codigos,Val(codIndice))>
				<cfif isdefined("Form.CursoElectivo") and Form.CursoElectivo NEQ 0>
					<cfset codSustitutivo = GetToken(codigosSustitutivos,Val(codIndice))>
				</cfif>

				<cfquery datasource="#Session.DSN#" name="updMatriculaExt">
				set nocount on
				insert into AlumnoCalificacionCurso (CEcodigo,Ecodigo,Ccodigo,ACCelectiva)
				values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
				<cfqueryparam cfsqltype="cf_sql_numeric" value="#codEstudiante#">,
				<cfif isdefined("Form.CursoElectivo") and Form.CursoElectivo NEQ 0>
					<cfqueryparam cfsqltype="cf_sql_numeric" value="#codSustitutivo#">,
					<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Ccodigo#">)
				<cfelse>			
					<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Ccodigo#">,null)
				</cfif>
				set nocount off
				</cfquery>
				
				<!---
				<cfoutput>index: #index#</cfoutput>
				<cfoutput>codIndice: #codIndice#</cfoutput>
				<cfoutput>Estudiante: #codEstudiante#</cfoutput>
				<cfif isdefined("Form.CursoElectivo") and Form.CursoElectivo NEQ 0>
					<cfoutput>Curso: #codSustitutivo#</cfoutput>
					<cfoutput>ACCelectiva: #Form.Ccodigo#</cfoutput>
				<cfelse>			
					<cfoutput>Curso: #Form.Ccodigo#</cfoutput>
				</cfif>
				<br>
				--->
				
				<cfset index = index + 1>
				<cfset codIndice = GetToken(indices,index)>
			</cfloop>
		  </cfif>
		  
		  <table border="0" cellpadding="5" cellspacing="3">
		  <tr><td>
		  <!---
		  <cfif isdefined("Form.btnMatricular")> --->
		  Alumnos matriculados en forma exitosa
		  <!--- <cfelse>
		  Alumnos desmatriculados en forma exitosa
		  </cfif> --->
		  </td></tr>
		  <tr><td>
			<form name="formAceptar" action="MatriculaExtra.cfm" method="post">
			<cfif isdefined("Form.SPEcodigo")>
			<input type="hidden" name="SPEcodigo" value="<cfoutput>#Form.SPEcodigo#</cfoutput>">
			</cfif>
			<cfif isdefined("Form.Gcodigo")>
			<input type="hidden" name="Gcodigo" value="<cfoutput>#Form.Gcodigo#</cfoutput>">
			</cfif>
			<cfif isdefined("Form.GRcodigo")>
			<input type="hidden" name="GRcodigo" value="<cfoutput>#Form.GRcodigo#</cfoutput>">
			</cfif>
			<input type="hidden" name="Ccodigo" value="<cfoutput>#Form.Ccodigo#</cfoutput>">
			<input type="submit" name="btnAceptar" value="Aceptar">
		  </form></td></tr>
		  </table>
          <!-- InstanceEndEditable -->
		  </td>
          <td class="contenido-brborder">&nbsp;</td>
        </tr>
      </table>
	 </td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
