
	<cfif isdefined("Url.persona") and not isdefined("Form.persona")>
		<cfparam name="Form.persona" default="#Url.persona#">
	</cfif>
	<cfif isdefined("Url.o") and not isdefined("Form.o")>
		<cfparam name="Form.o" default="#Url.o#">
	</cfif>

<!--- Consulta de Encargados --->
	<cfquery name="EncarAsoc" datasource="#session.DSN#">
	select convert(varchar,a.EEcodigo) as EEcodigo, convert(varchar,e.persona) as persona , 
		convert(varchar,a.CEcodigo) as CEcodigo, 
		convert(varchar,a.Ecodigo) as Ecodigo,
		(Pnombre + ' ' + Papellido1 + ' ' + Papellido2) as Nombre,
		Pid
		from EncargadoEstudiante a, Alumnos b, Estudiante c, Encargado d, PersonaEducativo e
		where a.CEcodigo=#Session.CEcodigo#
			and b.persona=#form.persona#
			and a.CEcodigo=b.CEcodigo 
			and a.Ecodigo=b.Ecodigo 
			and b.Ecodigo=c.Ecodigo 
			and a.EEcodigo=d.EEcodigo 
			and d.persona=e.persona
	  order by Nombre
	</cfquery>  
  
	<cfquery datasource="#Session.DSN#" name="rsEcodigo">
		Select convert(varchar,a.Ecodigo) as Ecodigo
		from Alumnos a, Estudiante b
		where CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
			and a.persona=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
			and a.persona=b.persona
			and a.Ecodigo=b.Ecodigo
	</cfquery>  
  
  
	<cfset CurrentPage=GetFileFromPath(GetTemplatePath())>
	<cfparam name="PageNum_EncarAsoc" default="1">
	<cfset MaxRows_EncarAsoc=16>
	<cfset StartRow_EncarAsoc=Min((PageNum_EncarAsoc-1)*MaxRows_EncarAsoc+1,Max(EncarAsoc.RecordCount,1))>
	<cfset EndRow_EncarAsoc=Min(StartRow_EncarAsoc+MaxRows_EncarAsoc-1,EncarAsoc.RecordCount)>
	<cfset TotalPages_EncarAsoc=Ceiling(EncarAsoc.RecordCount/MaxRows_EncarAsoc)>
	<cfset QueryString_EncarAsoc=Iif(CGI.QUERY_STRING NEQ "",DE("&"&CGI.QUERY_STRING),DE(""))>
	<cfset tempPos=ListContainsNoCase(QueryString_EncarAsoc,"PageNum_EncarAsoc=","&")>
	<cfif tempPos NEQ 0>
	  <cfset QueryString_EncarAsoc=ListDeleteAt(QueryString_EncarAsoc,tempPos,"&")>
	</cfif>  

  
	<form action="SQLlistaEncarAsoc.cfm" method="post" name="formEncarAsoc">
		<input name="persona" id="persona" value="<cfif isdefined("Form.persona") and Form.persona NEQ ''><cfoutput>#Form.persona#</cfoutput></cfif>" type="hidden"> 	
		<input name="Ecodigo" id="Ecodigo" type="hidden" value="<cfoutput>#rsEcodigo.Ecodigo#</cfoutput>"> 	
		<input name="o" id="o" type="hidden" value="<cfif isdefined("Form.o") and Form.o NEQ ''><cfoutput>#form.o#</cfoutput></cfif>"> 	
	  	<input type="hidden" name="EncarBajaEEcod" id="EncarBajaEEcod" value="" >
	  	<input type="hidden" name="EncarBajaEcod" id="EncarBajaEcod" value="" >	 
		<!--- Campos del filtro para la lista de alumnos --->
		<cfset filtroUlr = "alumno.cfm?persona=#persona#&o=3">
		<cfif isdefined("Form.fRHnombre")>
			<input type="hidden" name="fRHnombre" value="<cfoutput>#Form.fRHnombre#</cfoutput>">
			<cfset filtroUlr = filtroUlr & Iif(Len(Trim(filtroUlr)) NEQ 0, DE("&"), DE("")) & "fRHnombre=" & Form.fRHnombre>						
		</cfif>		   
		<cfif isdefined("Form.FNcodigo")>
			 <input type="hidden" name="FNcodigo" value="<cfoutput>#Form.FNcodigo#</cfoutput>">
			 <cfset filtroUlr = filtroUlr & Iif(Len(Trim(filtroUlr)) NEQ 0, DE("&"), DE("")) & "FNcodigo=" & Form.FNcodigo>
		</cfif>		
		<cfif isdefined("Form.filtroRhPid")>
			 <input type="hidden" name="filtroRhPid" value="<cfoutput>#Form.filtroRhPid#</cfoutput>">
			 <cfset filtroUlr = filtroUlr & Iif(Len(Trim(filtroUlr)) NEQ 0, DE("&"), DE("")) & "filtroRhPid=" & Form.filtroRhPid>
		</cfif>		
		<cfif isdefined("Form.FGcodigo")>
			<input type="hidden" name="FGcodigo" value="<cfoutput>#Form.FGcodigo#</cfoutput>">
			<cfset filtroUlr = filtroUlr & Iif(Len(Trim(filtroUlr)) NEQ 0, DE("&"), DE("")) & "FGcodigo=" & Form.FGcodigo>
		</cfif>
		<cfif isdefined("Form.NoMatr")>
			<input type="hidden" name="NoMatr" value="<cfoutput>#Form.NoMatr#</cfoutput>">
			<cfset filtroUlr = filtroUlr & Iif(Len(Trim(filtroUlr)) NEQ 0, DE("&"), DE("")) & "NoMatr=" & Form.NoMatr>
		</cfif>		  		  
		<cfif isdefined("Form.FAretirado")>
			<input type="hidden" name="FAretirado" value="<cfoutput>#Form.FAretirado#</cfoutput>">
			<cfset filtroUlr = filtroUlr & Iif(Len(Trim(filtroUlr)) NEQ 0, DE("&"), DE("")) & "FAretirado=" & Form.FAretirado>
		</cfif>			 
	  
  <table width="100%" border="0" cellpadding="0" cellspacing="0">
    <tr class="tituloListas"> 
      <td width="4%">&nbsp;</td>
      <td width="55%">Nombre</td>
      <td width="20%">Identificaci&oacute;n</td>
      <td width="21%" align="center">Borrar</td>
    </tr>
	<cfif len(trim(filtroUlr)) neq 0 >
		<cfset session.RegresarURL = filtroUlr>
	</cfif>
    <cfoutput query="EncarAsoc" startRow="#StartRow_EncarAsoc#" maxRows="#MaxRows_EncarAsoc#"> 
      <cfset liga="encargados.cfm?EEcodigo=#EncarAsoc.EEcodigo#&personaEncar=#EncarAsoc.persona#&persona=#form.persona#&Ecodigo=#rsEcodigo.Ecodigo#">
      <tr class=<cfif #EncarAsoc.CurrentRow# MOD 2>"listaNon" <cfelse>"listaPar"</cfif> onmouseover="style.backgroundColor='##E4E8F3';" onmouseout="style.backgroundColor='<cfif #EncarAsoc.CurrentRow# MOD 2>##FFFFFF<cfelse>##FAFAFA</cfif>';">	
        <td>&nbsp; 
        </td>
        <td><a href="#liga#">#EncarAsoc.Nombre#</a></td>
        <td><a href="#liga#">#EncarAsoc.Pid#</a> </td>
        <td align="center"><a href="##"><img src="../../Imagenes/Stop01_T.gif" alt="Quitar este Encargado" name="imagen" width="18" height="14" border="0" align="absmiddle" onClick="javascript: setBtn(this); borraEncar(#EncarAsoc.EEcodigo#,#EncarAsoc.Ecodigo#)"></a></td>
      </tr>
    </cfoutput> 
    <tr> 
      <td colspan="4"> 
        <!--- Botones de la lista --->
        <table border="0" width="50%" align="center">
          <cfoutput> 
            <tr> 
              <td width="23%" align="center"> <cfif PageNum_EncarAsoc GT 1>
                  <a href="#CurrentPage#?PageNum_EncarAsoc=1#QueryString_EncarAsoc#"><img src="../../Imagenes/First.gif" border=0></a> 
                </cfif> </td>
              <td width="31%" align="center"> <cfif PageNum_EncarAsoc GT 1>
                  <a href="#CurrentPage#?PageNum_EncarAsoc=#Max(DecrementValue(PageNum_EncarAsoc),1)##QueryString_EncarAsoc#"><img src="../../Imagenes/Previous.gif" border=0></a> 
                </cfif> </td>
              <td width="23%" align="center"> <cfif PageNum_EncarAsoc LT TotalPages_EncarAsoc>
                  <a href="#CurrentPage#?PageNum_EncarAsoc=#Min(IncrementValue(PageNum_EncarAsoc),TotalPages_EncarAsoc)##QueryString_EncarAsoc#"><img src="../../Imagenes/Next.gif" border=0></a> 
                </cfif> </td>
              <td width="23%" align="center"> <cfif PageNum_EncarAsoc LT TotalPages_EncarAsoc>
                  <a href="#CurrentPage#?PageNum_EncarAsoc=#TotalPages_EncarAsoc##QueryString_EncarAsoc#"><img src="../../Imagenes/Last.gif" border=0></a> 
                </cfif> </td>
            </tr>
          </cfoutput> </table></td>
    </tr>
    <tr>
      <td colspan="4" align="center"><input name="btnNuevo" type="submit" id="btnNuevo" value="Nuevo Encargado" onClick="javascript: setBtn(this);"></td>
    </tr>
  </table>
	</form>  
  
  <script language="JavaScript" type="text/javascript">
  	function borraEncar(varEEcodigo, varEcodigo){
		var vEncarBajaEEcod = document.getElementById("EncarBajaEEcod");		
		var vEncarBajaEcod = document.getElementById("EncarBajaEcod");	

		if(confirm('Esta seguro(a) que desea borrar este encargado?')){
			vEncarBajaEEcod.value = varEEcodigo;
			vEncarBajaEcod.value = varEcodigo;		
			
//			alert("varEEcodigo >>" + varEEcodigo + " -- varEcodigo >>" + varEcodigo);

			document.forms['formEncarAsoc'].submit();
		}
	}
  </script>