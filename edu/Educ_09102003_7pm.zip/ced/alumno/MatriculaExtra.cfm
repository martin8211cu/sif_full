<cfinclude template="../../Utiles/general.cfm">
<html><!-- InstanceBegin template="/Templates/LMenuCED.dwt.cfm" codeOutsideHTMLIsLocked="false" -->
<head>
<title>Educaci&oacute;n</title>
<meta http-equiv="Expires" content="Fri, Jan 01 1970 08:20:00 GMT">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Pragma" content="no-cache">
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
<link href="../../css/portlets.css" rel="stylesheet" type="text/css">
<link href="../../css/edu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
<script language="JavaScript" src="../../js/DHTMLMenu/stm31.js"></script>
<script language="JavaScript" type="text/javascript">
	// Funciones para Manejo de Botones
	botonActual = "";

	function setBtn(obj) {
		botonActual = obj.name;
	}
	function btnSelected(name, f) {
		if (f != null) {
			return (f["botonSel"].value == name)
		} else {
			return (botonActual == name)
		}
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="154" rowspan="2" align="center" valign="top"><img src="../../Imagenes/logo.gif" width="154" height="62"></td>
    <td valign="bottom"> 
	  <!-- InstanceBeginEditable name="Ubica" --> 
      <cfinclude template="../../portlets/pubica.cfm">
      <!-- InstanceEndEditable --> </td>
  </tr>
  <tr> 
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr class="area"> 
          <td width="275" valign="middle">
		  	<cfset RolActual = 4>
			<cfset Session.RolActual = 4>
			<cfinclude template="../../portlets/pEmpresas2.cfm">
		  </td>
          <td nowrap> 
            <div align="center"><span class="superTitulo">
			<font size="5">
	  <!-- InstanceBeginEditable name="Titulo" -->administracion 
              del centro de estudios<!-- InstanceEndEditable -->	
			</font></span></div></td>
        </tr>
        <tr class="area" style="padding-bottom: 3px;"> 
		  <td nowrap style="padding-left: 10px;">
		  <cfinclude template="../../portlets/pminisitio.cfm">
		  </td>
          <td valign="top" nowrap> 
	  <!-- InstanceBeginEditable name="MenuJS" --> 
	  <cfinclude template="../jsMenuCED.cfm">
      <!-- InstanceEndEditable -->	
		  </td>
        </tr>
      </table>
	</td>
  </tr>
</table>
  
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="left" valign="top" nowrap></td>
    <td width="100%" height="1" align="left" valign="top"><!-- InstanceBeginEditable name="Titulo2" --><!-- InstanceEndEditable --></td>
  </tr>
  <tr> 
    <td valign="top" nowrap>
		<cfinclude template="/sif/menu.cfm">
	</td>
    <td valign="top" width="100%">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="2%"class="Titulo"><img  src="../../Imagenes/sp.gif" width="15" height="15" border="0"></td>
          <td width="3%" class="Titulo" >&nbsp;</td>
          <td width="94%" class="Titulo">
		  <!-- InstanceBeginEditable name="TituloPortlet" --> 
            matricula extraordinaria<!-- InstanceEndEditable -->
		  </td>
          <td width="1%" valign="top" nowrap bgcolor="#ADADCA"><img src="../../Imagenes/rt.gif"></td>
        </tr>
        <tr> 
          <td colspan="3" class="contenido-lbborder">
		  <!-- InstanceBeginEditable name="Mantenimiento2" -->
			<cfquery name="rsCursoLectivo" datasource="#Session.DSN#">
				set nocount on
				select convert(varchar, c.SPEcodigo) as Codigo,
					a.Ndescripcion + ' : ' + b.PEdescripcion + ' : ' + c.SPEdescripcion as Descripcion
				from Nivel a, PeriodoEscolar b, SubPeriodoEscolar c, PeriodoVigente d
				where a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and a.Ncodigo = b.Ncodigo
				and b.PEcodigo = c.PEcodigo
				and a.Ncodigo = d.Ncodigo
				and b.PEcodigo = d.PEcodigo
				and c.SPEcodigo = d.SPEcodigo
				order by a.Norden
				set nocount off
			</cfquery>
			<cfloop query="rsCursoLectivo">
				<cfset codCursoLectivo=#rsCursoLectivo.Codigo#>
				<cfbreak>
			</cfloop>
			<cfif isdefined("Form.SPEcodigo")>
				<cfset codCursoLectivo=#Form.SPEcodigo#>
			</cfif>

			<cfif isdefined("codCursoLectivo")>
				<cfquery datasource="#Session.DSN#" name="rsGrado">
					set nocount on
					select convert(varchar, b.Gcodigo) as Gcodigo, 
						   b.Gdescripcion
					from Nivel a, Grado b
					where a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
					and a.Ncodigo in (select Ncodigo from PeriodoVigente
						where SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#codCursoLectivo#">)
					and a.Ncodigo = b.Ncodigo 
					order by a.Norden, b.Gorden
					set nocount off
				</cfquery>
				<cfloop query="rsGrado">
					<cfset codGrado=#rsGrado.Gcodigo#>
					<cfbreak>
				</cfloop>
				<cfif isdefined("Form.Gcodigo") AND (NOT isdefined("Form.noGrado") OR Form.noGrado IS "0")>
					<cfset codGrado=#Form.Gcodigo#>
				</cfif>
			</cfif>

			<cfif isdefined("codCursoLectivo")>
				<cfif isdefined("codGrado")>
				<cfquery datasource="#Session.DSN#" name="rsGrupos">
				Set nocount on
				Select distinct GRcodigo=convert(varchar,gr.GRcodigo), gr.GRnombre
				from Grupo gr, Nivel n, Grado g
				where n.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and gr.SPEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codCursoLectivo#">
				and gr.Gcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codGrado#"> 
				and gr.Ncodigo = n.Ncodigo
				and gr.Gcodigo = g.Gcodigo
				order by GRnombre
				Set nocount off
				</cfquery>
				<cfloop query="rsGrupos">
					<cfset codGrupo=#rsGrupos.GRcodigo#>
					<cfbreak>
				</cfloop>								
				<cfif isdefined("Form.GRcodigo")
				AND (NOT isdefined("Form.noGrupo") OR Form.noGrupo IS "0")>
					<cfset codGrupo=#Form.GRcodigo#>
				</cfif>
				</cfif>

				<cfif isdefined("codGrupo")>
				<cfquery datasource="#Session.DSN#" name="rsCursos">
				Set nocount on
				Select distinct Ccodigo=convert(varchar,c.Ccodigo),
				Cnombre = m.Mnombre + ' - ' + gr.GRnombre, 
				Mconsecutivo=convert(varchar,m.Mconsecutivo), m.Mcodigo, m.Mnombre,
				electivo=case m.Melectiva when 'E' then 1 else 0 end
				from Curso c, Materia m, Grupo gr
				where c.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and c.SPEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codCursoLectivo#">
				and m.Gcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codGrado#">
				and c.GRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codGrupo#">
				and c.GRcodigo = gr.GRcodigo
				and c.Mconsecutivo = m.Mconsecutivo
				and m.Melectiva in ('R','C','E')
				order by Cnombre
				Set nocount off
				</cfquery>
				</cfif>
				
				<cfif isdefined("rsCursos")>
					<cfloop query="rsCursos">
						<cfset codCurso=#rsCursos.Ccodigo#>
						<cfset CursoElectivo=#rsCursos.electivo#>
						<cfbreak>
					</cfloop>								
					<cfif isdefined("Form.Ccodigo")
					AND (NOT isdefined("Form.noCurso") OR Form.noCurso IS "0")>
						<cfset codCurso=#Form.Ccodigo#>
						<cfloop query="rsCursos">
							<cfif rsCursos.Ccodigo EQ Form.Ccodigo>
								<cfset CursoElectivo=#rsCursos.electivo#>
								<cfbreak>
							</cfif>
						</cfloop>								
					</cfif>
				</cfif>
				
			</cfif>

			<cfif isdefined("codCurso")>
				<cfquery datasource="#Session.DSN#" name="rsCursosSustitutivos">
				Set nocount on
				Select distinct Ccodigo=convert(varchar,c.Ccodigo),
				Cnombre = c.Cnombre,
				Mconsecutivo=convert(varchar,m.Mconsecutivo), m.Mcodigo, m.Mnombre,
				a.Ecodigo, Cmatriculado=case when acc.Ccodigo is null then 0 else 1 end
				from Curso c, Materia m, Alumnos a, GrupoAlumno gra, AlumnoCalificacionCurso acc
				where c.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and c.SPEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codCursoLectivo#">
				and c.Mconsecutivo = m.Mconsecutivo
				and m.Melectiva = 'S'
				and m.Mconsecutivo in (select Mconsecutivo from MateriaElectiva where Melectiva =
					(select Mconsecutivo from Curso
					where Ccodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codCurso#">))
				and m.Mconsecutivo in (select Mconsecutivo from GradoSustitutivas
					where Gcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#codGrado#">)
				and gra.GRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codGrupo#">
				and a.Ecodigo = gra.Ecodigo
				and (not exists (select Ccodigo from AlumnoCalificacionCurso
					where Ecodigo = a.Ecodigo and Ccodigo = c.Ccodigo and CEcodigo = c.CEcodigo)
				or exists (select Ccodigo from AlumnoCalificacionCurso
					where Ecodigo = a.Ecodigo and CEcodigo = c.CEcodigo
					and ACCelectiva = <cfqueryparam cfsqltype="cf_sql_numeric" value="#codCurso#">))
				and a.Ecodigo *= acc.Ecodigo
				and c.CEcodigo *= acc.CEcodigo and c.Ccodigo *= acc.Ccodigo
				order by Ecodigo,Cnombre
				Set nocount off
				</cfquery>
				
				<cfquery datasource="#Session.DSN#" name="rsAlumnos">
				Set nocount on
				Select distinct Ecodigo=convert(varchar,a.Ecodigo), p.Pnombre, p.Papellido1, p.Papellido2,
				Cmatriculado=case when acc.Ccodigo is null then 0 else 1 end,
				Ccodigo=convert(varchar,acc.Ccodigo)
				from Alumnos a, PersonaEducativo p, AlumnoCalificacionCurso acc,Curso c,Materia m,
				GrupoAlumno gra
				where a.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and gra.GRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codGrupo#">
				and a.Ecodigo = gra.Ecodigo
				<cfif isdefined("CursoElectivo") AND CursoElectivo IS NOT 0>
				and acc.ACCelectiva=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codCurso#">
				<cfelse>
				and acc.Ccodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codCurso#">
				</cfif>
				and c.Ccodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codCurso#">
				and c.Mconsecutivo = m.Mconsecutivo
				and a.persona = p.persona
				and a.Ecodigo *= acc.Ecodigo
				and a.Aretirado = 0
				order by Papellido1,Papellido2,Pnombre
				Set nocount off
				</cfquery>
			</cfif>

		    <script language="JavaScript" type="text/JavaScript">
		    function valida(formulario) {
				
		        return true;
		    }
		    </script>
			
            <table width="100%" border="0" cellspacing="3" cellpadding="3">
			  <tr>
				<td>
					<cfinclude template="../../portlets/pNavegacionCED.cfm">				
				</td>
			  </tr>
		      <form name="formFiltro" method="post" action="MatriculaExtra.cfm">
			  <input type="hidden" name="noGrado" value="0">
			  <input type="hidden" name="noGrupo" value="0">
			  <input type="hidden" name="noCurso" value="0">
              <tr>
                <td>
				    <strong>Curso Lectivo</strong>&nbsp;
				    <select name="SPEcodigo" onChange="javascript:formFiltro.noGrado.value='1';formFiltro.noGrupo.value='1';formFiltro.noCurso.value='1';formFiltro.submit();">
	  	    		<cfoutput query="rsCursoLectivo">
						<option value="#rsCursoLectivo.Codigo#" 
						  <cfif isdefined("codCursoLectivo") AND codCursoLectivo 
							EQ rsCursoLectivo.Codigo>selected</cfif>>
						  #rsCursoLectivo.Descripcion#
						</option>
					</cfoutput>
					</select>&nbsp;
					
				    <strong>Grado</strong>&nbsp;
				    <select name="Gcodigo" onChange="javascript:formFiltro.noGrupo.value='1';formFiltro.noCurso.value='1';formFiltro.submit();">
					<cfif isdefined("rsGrado")>
	  	    		<cfoutput query="rsGrado">
						<option value="#rsGrado.Gcodigo#" 
						  <cfif isdefined("codGrado") AND codGrado EQ rsGrado.Gcodigo>selected</cfif>>
						  #rsGrado.Gdescripcion#
						</option>
					</cfoutput>
					</cfif>
					</select>&nbsp;
					
					<cfif isdefined("rsGrupos")>
						<strong>Grupo</strong>&nbsp;
						<select name="GRcodigo" onChange="javascript:formFiltro.noCurso.value='1';formFiltro.submit();">
						<cfoutput query="rsGrupos">
							<option value="#rsGrupos.GRcodigo#"
							<cfif isdefined("codGrupo") AND codGrupo EQ rsGrupos.GRcodigo>selected</cfif>>
								#rsGrupos.GRnombre#
							</option>
						</cfoutput>
						</select>
					</cfif>
                </td>
              </tr>			  
			  <cfif isdefined("codGrupo")>
			  <tr><td>
			  <strong>Curso</strong>&nbsp;
			  <select name="Ccodigo" onChange="javascript:formFiltro.submit();">
				<cfoutput query="rsCursos">
					<option value="#rsCursos.Ccodigo#"
						<cfif isdefined("codCurso") AND codCurso EQ rsCursos.Ccodigo>selected</cfif>>
						#rsCursos.Cnombre#
					</option>
				</cfoutput>
			  </select>
			  </td></tr>
			  </cfif>
			  </form>
			  
 			  <cfif isdefined("codCurso")>
	    	  <form name="formMatricula" method="post" action="SQLMatriculaExtra.cfm" onSubmit="return valida(this)">
              <tr><td><b>Alumnos</b></td></tr>
			  <tr><td><strong>
	<input name="chkTodos" type="checkbox" value="" border="1" onClick="javascript:Marcar(this);">
	Seleccionar Todos</strong></td></tr>
			  <tr><td>
			  	<table border="0" cellpadding="0" cellspacing="0" width="70%">
				<tr>
					<td class="tituloListas"><strong>&nbsp;</strong></td>
					<td class="tituloListas"><strong>Nombre</strong></td>
					<cfif isdefined("CursoElectivo") AND CursoElectivo IS NOT 0>
						<td class="tituloListas"><strong>Curso Sustituto</strong></td>
					</cfif>
				</tr>
				<cfset indiceAlumno = 1>
				<cfoutput query="rsAlumnos">
				<tr>
					<cfquery dbtype="query" name="detalleSustitutivos">
					select * from rsCursosSustitutivos
					where Ecodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#rsAlumnos.Ecodigo#">
					</cfquery>
					<td>
					<cfif (NOT isdefined("CursoElectivo") OR CursoElectivo IS 0
					OR detalleSustitutivos.RecordCount IS NOT 0) AND NOT rsAlumnos.Cmatriculado>
						<input name="Ecodigo" type="hidden" value="#rsAlumnos.Ecodigo#">
						<input name="checkAlumno" type="checkbox" value="#indiceAlumno#">
						<cfset indiceAlumno = indiceAlumno + 1>
					<cfelseif rsAlumnos.Cmatriculado>
						<a href="javascript:desmatricularAlumno(#rsAlumnos.Ecodigo#)">
						<img src="../../Imagenes/Cferror.gif" border="0" alt="Desmatricular">
						</a>
					</cfif>
					</td>
					<td>#rsAlumnos.Papellido1# #rsAlumnos.Papellido2# #rsAlumnos.Pnombre#</td>
					<cfif isdefined("CursoElectivo") AND CursoElectivo IS NOT 0>
					<td>
					<cfif detalleSustitutivos.RecordCount IS NOT 0 AND NOT rsAlumnos.Cmatriculado>
						<select name="Csustituto">
						<cfloop query="detalleSustitutivos">
						<option value="#detalleSustitutivos.Ccodigo#" <cfif detalleSustitutivos.Cmatriculado>selected</cfif>>#detalleSustitutivos.Cnombre#</option>
						</cfloop>
						</select>
					<cfelseif rsAlumnos.Cmatriculado>
						<cfloop query="detalleSustitutivos">
						<cfif detalleSustitutivos.Cmatriculado>#detalleSustitutivos.Cnombre#</cfif>
						</cfloop>
					</cfif>
					</td>
					</cfif>
				</tr>
				</cfoutput>
				</table>
			  </td></tr>
			  <tr><td>
			  Los alumnos seleccionados ser&aacute;n matriculados en el curso.
			  </td></tr>
			  <tr>
			    <td>
				<div style="text-align:center">
				<cfif isdefined("codCursoLectivo")>
				<input type="hidden" name="SPEcodigo" value="<cfoutput>#codCursoLectivo#</cfoutput>">
				</cfif>
				<cfif isdefined("codGrado")>
				<input type="hidden" name="Gcodigo" value="<cfoutput>#codGrado#</cfoutput>">
				</cfif>
				<cfif isdefined("codGrupo")>
				<input type="hidden" name="GRcodigo" value="<cfoutput>#codGrupo#</cfoutput>">
				</cfif>
				<cfif isdefined("CursoElectivo")>
				<input type="hidden" name="CursoElectivo" value="<cfoutput>#CursoElectivo#</cfoutput>">
				</cfif>
				<input type="hidden" name="Ccodigo" value="<cfoutput>#codCurso#</cfoutput>">
				<input type="submit" name="btnMatricular" value="Matricular" onClick="javascript:setBtn(this)">
				<!---
				<input type="submit" name="btnDesmatricular" value="Desmatricular" onClick="javascript:setBtn(this)">
				--->
				</div>
				</td>
			  </tr>
			  </form>				
			  <form action="SQLDesmatriculaExtra.cfm" method="post" name="formDesmatricular">
				<cfif isdefined("codCursoLectivo")>
				<input type="hidden" name="SPEcodigo" value="<cfoutput>#codCursoLectivo#</cfoutput>">
				</cfif>
				<cfif isdefined("codGrado")>
				<input type="hidden" name="Gcodigo" value="<cfoutput>#codGrado#</cfoutput>">
				</cfif>
				<cfif isdefined("codGrupo")>
				<input type="hidden" name="GRcodigo" value="<cfoutput>#codGrupo#</cfoutput>">
				</cfif>
				<cfif isdefined("CursoElectivo")>
				<input type="hidden" name="CursoElectivo" value="<cfoutput>#CursoElectivo#</cfoutput>">
				</cfif>
				<input type="hidden" name="Ccodigo" value="<cfoutput>#codCurso#</cfoutput>">
				<input type="hidden" name="Ecodigo" value="0">
			  </form>
			  </cfif>
            </table>
			<script type="text/javascript">
			function desmatricularAlumno(codigo) {
				formDesmatricular.Ecodigo.value = codigo;
				formDesmatricular.submit();
			}
			</script>
			<script language="JavaScript1.2">
				function Marcar(c) {
					if (document.formMatricula.checkAlumno != null) { //existe?
						if (document.formMatricula.checkAlumno.value != null) {// solo un check
							if (c.checked) document.formMatricula.checkAlumno.checked = true; else document.formMatricula.checkAlumno.checked = false;
						}
						else {
							if (c.checked) {
								for (var counter = 0; counter < document.formMatricula.checkAlumno.length; counter++)
								{
									if ((!document.formMatricula.checkAlumno[counter].checked) && (!document.formMatricula.checkAlumno[counter].disabled))
										{  document.formMatricula.checkAlumno[counter].checked = true;}
								}
								if ((counter==0)  && (!document.formMatricula.checkAlumno.disabled)) {
									document.formMatricula.checkAlumno.checked = true;
								}
							}
							else {
								for (var counter = 0; counter < document.formMatricula.checkAlumno.length; counter++)
				
								{
									if ((document.formMatricula.checkAlumno[counter].checked) && (!document.formMatricula.checkAlumno[counter].disabled))
										{  document.formMatricula.checkAlumno[counter].checked = false;}
								};
								if ((counter==0) && (!document.formMatricula.checkAlumno.disabled)) {
									document.formMatricula.checkAlumno.checked = false;
								}
							};
						}
					}
				}
			</script>
          <!-- InstanceEndEditable -->
		  </td>
          <td class="contenido-brborder">&nbsp;</td>
        </tr>
      </table>
	 </td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
