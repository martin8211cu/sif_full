<!--- Campos del filtro para la lista de alumnos --->
<cfset filtroTab = "">
<cfif isdefined("Form.fRHnombre")>
	<cfset filtroTab = filtroTab & Iif(Len(Trim(filtroTab)) NEQ 0, DE("&"), DE("")) & "fRHnombre=" & Form.fRHnombre>
</cfif>		   
<cfif isdefined("Form.FNcodigo")>
	<cfset filtroTab = filtroTab & Iif(Len(Trim(filtroTab)) NEQ 0, DE("&"), DE("")) & "FNcodigo=" & Form.FNcodigo>
</cfif>		
<cfif isdefined("Form.filtroRhPid")>
	<cfset filtroTab = filtroTab & Iif(Len(Trim(filtroTab)) NEQ 0, DE("&"), DE("")) & "filtroRhPid=" & Form.filtroRhPid>
</cfif>		
<cfif isdefined("Form.FGcodigo")>
	<cfset filtroTab = filtroTab & Iif(Len(Trim(filtroTab)) NEQ 0, DE("&"), DE("")) & "FGcodigo=" & Form.FGcodigo>
</cfif>
<cfif isdefined("Form.NoMatr")>
	<cfset filtroTab = filtroTab & Iif(Len(Trim(filtroTab)) NEQ 0, DE("&"), DE("")) & "NoMatr=" & Form.NoMatr>
</cfif>		  		  
<cfif isdefined("Form.FAretirado")>
	<cfset filtroTab = filtroTab & Iif(Len(Trim(filtroTab)) NEQ 0, DE("&"), DE("")) & "FAretirado=" & Form.FAretirado>
</cfif>			



<cfset tabChoice = 1>

<cfset tabNames = ArrayNew(1)>
<cfset tabNames[1] = "Datos Alumno">
<cfset tabNames[2] = "Expediente M�dico">
<cfset tabNames[3] = "Datos Encargado">
<cfset tabNames[4] = "Facturacion Conceptos">


<cfset tabLinks = ArrayNew(1)>
<!--- Se utiliza cuando el que consulta es el administrador --->
 <cfif isdefined("form.persona") and len(trim(form.persona)) neq 0> 
	<script language="JavaScript" type="text/javascript">
		function gotoTab(tab) {
			document.regAlum.o.value = tab;
			document.regAlum.persona.value = '<cfoutput>#form.persona#</cfoutput>';
			document.regAlum.submit();
		}
	</script>

	<cfset tabLinks[1] = "alumno.cfm?o=1&" & #filtroTab#>
	<cfset tabLinks[2] = "alumno.cfm?o=2&" & #filtroTab#>
	<cfset tabLinks[3] = "alumno.cfm?o=3&" & #filtroTab#>
	<cfset tabLinks[4] = "alumno.cfm?o=4&" & #filtroTab#>

<!--- Se utiliza cuando el que consulta es el empleado --->
<cfelse >
	<cfset tabLinks[1] = "alumno.cfm?o=1">
	<cfset tabLinks[2] = "alumno.cfm?o=2">
	<cfset tabLinks[3] = "alumno.cfm?o=3">
	<cfset tabLinks[4] = "alumno.cfm?o=4">
</cfif> 
<cfset tabStatusText = ArrayNew(1)>
<cfset tabStatusText[1] = "">
<cfset tabStatusText[2] = "">
<cfset tabStatusText[3] = "">
<cfset tabStatusText[4] = "">
<!--- <cfif Session.Params.ModoDespliegue EQ 1>
	<cfset tabStatusText[5] = "">
</cfif> --->

