<cfif isdefined("Url.persona") and not isdefined("Form.persona")>
	<cfparam name="Form.persona" default="#Url.persona#">
</cfif> 

<cfif isdefined("form.persona")>
	<cfparam name="Form.persona" default="#form.persona#">
</cfif> 
<cfif isdefined("Url.o") and not isdefined("Form.o")>
	<cfparam name="Form.o" default="#Url.o#">
</cfif> 


<script language="JavaScript" type="text/javascript" src="../../js/calendar.js" >//</script>
<script language="JavaScript" type="text/javascript" src="../../js/utilesMonto.js">//</script>
<script language="JavaScript" type="text/javascript" src="js/formAlumno.js">//</script> 
<script language="JavaScript" src="../../js/qForms/qforms.js">//</script>
<form action="SQLAgregaEncar.cfm" method="post" id="formAgregaEncar" name="formAgregaEncar">
    <input name="persona" id="persona" value="<cfif isdefined("Form.persona") and Form.persona NEQ ''><cfoutput>#Form.persona#</cfoutput></cfif>" type="hidden"> 
	<input name="EEcodigo" id="EEcodigo" type="hidden" value=""> 
	<input name="Ecodigo" id="Ecodigo" type="hidden" value=""> 
	<input type="hidden" name="o" value="<cfif isdefined("Form.o")><cfoutput>#Form.o#</cfoutput></cfif>">
	<!--- Campos del filtro para la lista de alumnos --->
	<cfif isdefined("Form.fRHnombre")>
		<input type="hidden" name="fRHnombre" value="<cfoutput>#Form.fRHnombre#</cfoutput>">
	</cfif>		   
	<cfif isdefined("Form.FNcodigo")>
		 <input type="hidden" name="FNcodigo" value="<cfoutput>#Form.FNcodigo#</cfoutput>">
	</cfif>		
	<cfif isdefined("Form.filtroRhPid")>
		 <input type="hidden" name="filtroRhPid" value="<cfoutput>#Form.filtroRhPid#</cfoutput>">
	</cfif>		
	<cfif isdefined("Form.FGcodigo")>
		<input type="hidden" name="FGcodigo" value="<cfoutput>#Form.FGcodigo#</cfoutput>">
	</cfif>
	<cfif isdefined("Form.NoMatr")>
		<input type="hidden" name="NoMatr" value="<cfoutput>#Form.NoMatr#</cfoutput>">
	</cfif>		  		  
	<cfif isdefined("Form.FAretirado")>
		<input type="hidden" name="FAretirado" value="<cfoutput>#Form.FAretirado#</cfoutput>">
	</cfif>			
								

  <table width="100%" border="0" cellpadding="0" cellspacing="0">
    <tr> 
		<cfif isdefined("form.persona") and form.persona NEQ "">
    	  	
        <td class="SubTitulo" align="center">&nbsp;	
        </td>
	      
        <td align="center" class="SubTitulo">Asociar 
          encargado </td>			
		<cfelse>
		   
        <td colspan="2" align="center" class="SubTitulo">Asociar 
          encargado </td>
		</cfif>	
    </tr>
    <tr> 
      <td width="28%">Nombre</td>
      <td width="72%"><div align="left">
          <input name="NombreEncar" readonly="true" type="text" id="NombreEncar" size="60" maxlength="80">
          <a href="#"><img src="../../Imagenes/Description.gif" alt="Lista de Encargados" name="imagen" width="18" height="14" border="0" align="absmiddle" onClick="javascript:doConlis();"></a></div></td>
    </tr>
    <tr> 
      <td>Direcci&oacute;n</td>
      <td><input name="PdireccionEncar" readonly="true" type="text" id="PdireccionEncar" size="60" maxlength="80"></td>
    </tr>
    <tr> 
      <td>Identificaci&oacute;n</td>
      <td><input name="PidEncar" readonly="true" type="text" id="PidEncar" size="50" maxlength="50"></td>
    </tr>
    <tr> 
      <td width="28%">Fecha de Nac.</td>
      <td><input name="FechaNacEncar" readonly="true" type="text" id="FechaNacEncar" size="25" maxlength="25"></td>
    </tr>
    <tr> 
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr> 
	  <cfif isdefined("form.persona") and form.persona NEQ "">
		<td colspan="2" align="center">
          <input name="btnAgregarAE" type="submit" id="btnAgregarAE" value="Agregar" onClick="javascript: setBtn(this);">
          <input name="btnLimpiar" type="button" id="btnLimpiar" value="Limpiar" onClick="javascript: LimpiaEncar();">
		  </td>
      <cfelse>
  		<td colspan="2" align="center" class="SubTitulo">
          ** Seleccione un alumno de la lista inferior ** 
	    </td>
	   </cfif> 
    </tr>
  </table>
</form>

<script language="JavaScript" type="text/javascript" >
	function LimpiaEncar(){
		var vNombreEncar = document.getElementById("NombreEncar"),
			vEEcodigo = document.getElementById("EEcodigo"),
			vPdireccionEncar = document.getElementById("PdireccionEncar"),			
			vPidEncar = document.getElementById("PidEncar"),
			vFechaNacEncar = document.getElementById("FechaNacEncar"),
			vEcodigo = document.getElementById("Ecodigo");

			vNombreEncar.value = "";
			vEEcodigo.value = "";			
			vPdireccionEncar.value = "";			
			vPidEncar.value = "";			
			vFechaNacEncar.value = "";
			vEcodigo.value = "";	
	}
//---------------------------------------------------------------------	
	function doConlis() {
		//var vPersona = document.getElementById("persona");
		//alert(vPersona);
		popUpWindow("conlisEncar.cfm?form=formAgregaEncar"
					+"&NombreEncar=NombreEncar"
					+"&EEcodigo=EEcodigo"
					//+"&persona=" + vPersona.value 
					+"&persona=" + document.formAgregaEncar.persona.value 
					+"&PdireccionEncar=PdireccionEncar"
					+"&PidEncar=PidEncar"
					+"&FechaNacEncar=FechaNacEncar"
					+"&Ecodigo=Ecodigo",250,200,650,350);
	} 
</script> 

