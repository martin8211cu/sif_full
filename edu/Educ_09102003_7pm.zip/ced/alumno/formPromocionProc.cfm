<!--- Consultas --->
<cfquery datasource="#Session.DSN#" name="rsPromoXAplicar">
	 select pr.PRcodigo, pr.PRdescripcion as Promocion, 
			pe.PEdescripcion+': '+spe.SPEdescripcion as Periodo, 
			n.Ndescripcion as Nivel, g.Gdescripcion as Grado, 
			isnull(sign.Ndescripcion,'null') as NivelProx, 
			isnull(sigg.Gdescripcion,'null') as GradoProx, 
			pv.SPEcodigo,
			sigpe.PEdescripcion + ': ' + sigspe.SPEdescripcion as PerVigente
	 from Promocion pr, Nivel n, Grado g, PeriodoEscolar pe, SubPeriodoEscolar spe,
		  PeriodoVigente pv, Nivel sign, Grado sigg, PeriodoEscolar sigpe, SubPeriodoEscolar sigspe
	 where n.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
	   and pr.PRactivo = 1
	   and pr.Ncodigo = n.Ncodigo
	   and pr.Gcodigo = g.Gcodigo
	   and pr.PEcodigo = pe.PEcodigo
	   and pr.SPEcodigo = spe.SPEcodigo
	   and g.Gpromonivel *= sign.Ncodigo
	   and g.Gpromogrado *= sigg.Gcodigo
	   and sign.Ncodigo *= pv.Ncodigo
	   and pv.PEcodigo *= sigpe.PEcodigo
	   and pv.SPEcodigo *= sigspe.SPEcodigo
	   and pr.SPEcodigo not in (select SPEcodigo from PeriodoVigente)
	 order by n.Norden, pe.PEorden, spe.SPEorden, g.Gorden
</cfquery>

<cfquery datasource="#Session.DSN#" name="rsPromoAplicadas">
	 select pr.PRcodigo, pr.PRdescripcion as Promocion, 
			pe.PEdescripcion+': '+spe.SPEdescripcion as Periodo, 
			n.Ndescripcion as Nivel, g.Gdescripcion as Grado
	 from Promocion pr, Nivel n, Grado g, PeriodoEscolar pe, SubPeriodoEscolar spe
	 where n.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
	   and pr.PRactivo = 1
	   and pr.Ncodigo = n.Ncodigo
	   and pr.Gcodigo = g.Gcodigo
	   and pr.PEcodigo = pe.PEcodigo
	   and pr.SPEcodigo = spe.SPEcodigo
	   and pr.SPEcodigo in (select SPEcodigo from PeriodoVigente)
	 order by n.Norden, pe.PEorden, spe.SPEorden, g.Gorden
</cfquery>

<form name="form1" method="post" action="SQLPromocionProc.cfm" onSubmit="javascript:return valida(this);">
	<input name="SPEcodigo" id="SPEcodigo" type="hidden" value="<cfoutput>#rsPromoXAplicar.SPEcodigo#</cfoutput>">
  <table width="100%" border="0" cellspacing="0" cellpadding="2">
    <tr class="encabReporte"> 
      <td colspan="6" nowrap>Promociones por Aplicar</td>
    </tr>
    <cfset corte = "">
    <cfloop query="rsPromoXAplicar">
      <cfoutput> 
        <cfif corte NEQ rsPromoXAplicar.Periodo>
          <cfset corte = rsPromoXAplicar.Periodo>
          <tr class="area"> 
            <td nowrap class="SubTitulo">&nbsp;</td>
            <td colspan="2" nowrap class="SubTitulo">#corte#</td>
            <td nowrap class="SubTitulo">&nbsp;</td>
            <td colspan="2" nowrap class="SubTitulo">#rsPromoXAplicar.PerVigente#</td>
          </tr>
          <tr> 
            <td nowrap class="SubTitulo">Promoci&oacute;n</td>
            <td nowrap class="SubTitulo">Nivel</td>
            <td nowrap class="SubTitulo">Grado</td>
            <td nowrap class="SubTitulo">&nbsp;</td>
            <td nowrap class="SubTitulo">Nivel</td>
            <td nowrap class="SubTitulo">Grado</td>
          </tr>
        </cfif>
        <tr> 
          <td nowrap><input name="ckPromo" type="checkbox" id="ckPromo" value="#rsPromoXAplicar.PRcodigo#"> 
            #rsPromoXAplicar.Promocion#</td>
          <td nowrap>#rsPromoXAplicar.Nivel#</td>
          <td nowrap>#rsPromoXAplicar.Grado#</td>
          <td align="center" nowrap><img src="../../Imagenes/forward.gif" width="22" height="18" border="0"></td>
          <cfif #rsPromoXAplicar.NivelProx# EQ "null" or #rsPromoXAplicar.GradoProx# EQ "null">
            <td colspan="2" align="center" nowrap><strong><em>** 
              Inactiva **</em></strong></td>
            <cfelse>
            <td nowrap>#rsPromoXAplicar.NivelProx#</td>
            <td>#rsPromoXAplicar.GradoProx#</td>
          </cfif>
        </tr>
      </cfoutput> 
    </cfloop>
    <tr> 
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
    </tr>
	<cfif rsPromoXAplicar.RecordCount IS NOT 0>
    <tr> 
      <td colspan="6" align="center" nowrap><input name="btnAplicar" type="submit" id="btnAplicar" value="Aplicar Promoci&oacute;n" onClick="javascript: setBtn(this);"></td>
    </tr>
	</cfif>
    <tr> 
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
    </tr>
    <tr class="encabReporte"> 
      <td colspan="6" nowrap>Promociones Aplicadas</td>
    </tr>
	<cfset corteAplic = "">
    <cfloop query="rsPromoAplicadas">
      <cfoutput> 
        <cfif corteAplic NEQ rsPromoAplicadas.Periodo>
          <cfset corteAplic = rsPromoAplicadas.Periodo>
			<tr class="area"> 
			  <td colspan="6" nowrap class="SubTitulo">#corteAplic#</td>
			</tr>
			<tr> 
			  <td nowrap class="SubTitulo">Promoci&oacute;n</td>
			  <td colspan="2" nowrap class="SubTitulo">Nivel</td>
			  <td colspan="3" nowrap class="SubTitulo">Grado</td>
			</tr>
		 </cfif>
        <tr> 
          <td nowrap><img src="../../Imagenes/educ/DSL_D.gif" width="16" height="14" border="0"> 
            #rsPromoAplicadas.Promocion#</td>
          <td colspan="2" nowrap>#rsPromoAplicadas.Nivel#</td>
          <td colspan="3" nowrap>#rsPromoAplicadas.Grado#</td>
        </tr>
      </cfoutput> 
    </cfloop>
    <tr> 
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
      <td nowrap>&nbsp;</td>
    </tr>
  </table>
</form>

<script type="text/javascript">
function valida(formulario) {
	for (var i=0; i<formulario.elements.length; i++) {
		if (formulario.elements[i].type == "checkbox"
		&& formulario.elements[i].name == "ckPromo"
		&& formulario.elements[i].checked) {
			return true;
		}
	}
	return false;
}
</script>