
<cfif isdefined("form.btnAplicar")>
	<cftry>
		<cfset promo = ListToArray(Form.ckPromo, ",")>
		<cfquery name="ABC_PromocionesProc" datasource="#Session.DSN#">
			set nocount on
    		<cfloop index="i" from=1 to=#ArrayLen(promo)#>
			if not exists(
				select 1
				from Grado sigg, Grado g, Promocion pr 
				where pr.PRcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#promo[i]#">
				and pr.Gcodigo = g.Gcodigo
				and g.Gpromogrado = sigg.Gcodigo
			)
			begin
				update Promocion
					set PRactivo = 0
		 		where PRcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#promo[i]#">
				<!--- Rodolfo Jimenez Jara, Soluciones Integrales S.A., Costa Rica, America Central, 07/03/2003
				si entra aqu� es porque no tiene siguiente grado, o sea se gradu�
				Tomar todos los alumnos de esa promoci�n, marcarlos como graduados en la tabla alumnos, 
				e ingresar un registro en AlumnoRetirado, indicando sus ultimos datos.  --->
				update Alumnos 
				   set Aretirado = 2
		 		where PRcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#promo[i]#">
				and Aretirado = 0
				
				insert AlumnoRetirado (CEcodigo, Ecodigo, ARfecha, PRcodigo, SPEcodigo, PEcodigo , Gcodigo , Ncodigo , ARalta)
				select a.CEcodigo, a.Ecodigo, getdate(), p.PRcodigo,  p.SPEcodigo, p.PEcodigo, p.Gcodigo , p.Ncodigo, 2
				from Promocion p, Alumnos a
				where a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				  and p.PRcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#promo[i]#">					
				  and p.PRcodigo = a.PRcodigo
				<!--- Hasta aqui, Rodolfo Jimenez Jara, 07/03/2003 --->
			end
			else begin
				update Promocion
					set pr.PEcodigo = pv.PEcodigo,
					pr.SPEcodigo = pv.SPEcodigo,
					pr.Ncodigo = g.Gpromonivel,
					pr.Gcodigo = g.Gpromogrado
				from Promocion pr, Grado g, PeriodoVigente pv
		 		where pr.PRcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#promo[i]#">
				and pr.Gcodigo = g.Gcodigo
				and g.Gpromonivel = pv.Ncodigo
			end
		    </cfloop>			
			set nocount off
		</cfquery>
		<cflocation url="PromocionProc.cfm">
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>		
<cfelse> 
	<cfset action = "PromocionProc.cfm" >
	<cfset modo   = "ALTA" >
</cfif>

<cfoutput>
<form action="#action#" method="post" name="sql">
	<input name="modo"   type="hidden" value="<cfif isdefined("modo")>#modo#</cfif>">
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")>#Form.Pagina#</cfif>">		
</form>
</cfoutput>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>