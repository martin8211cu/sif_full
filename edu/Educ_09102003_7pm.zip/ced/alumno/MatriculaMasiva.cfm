<cfinclude template="../../Utiles/general.cfm">
<html><!-- InstanceBegin template="/Templates/LMenuCED.dwt.cfm" codeOutsideHTMLIsLocked="false" -->
<head>
<title>Educaci&oacute;n</title>
<meta http-equiv="Expires" content="Fri, Jan 01 1970 08:20:00 GMT">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Pragma" content="no-cache">
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
<link href="../../css/portlets.css" rel="stylesheet" type="text/css">
<link href="../../css/edu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
<script language="JavaScript" src="../../js/DHTMLMenu/stm31.js"></script>
<script language="JavaScript" type="text/javascript">
	// Funciones para Manejo de Botones
	botonActual = "";

	function setBtn(obj) {
		botonActual = obj.name;
	}
	function btnSelected(name, f) {
		if (f != null) {
			return (f["botonSel"].value == name)
		} else {
			return (botonActual == name)
		}
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="154" rowspan="2" align="center" valign="top"><img src="../../Imagenes/logo.gif" width="154" height="62"></td>
    <td valign="bottom"> 
	  <!-- InstanceBeginEditable name="Ubica" --> 
      <cfinclude template="../../portlets/pubica.cfm">
      <!-- InstanceEndEditable --> </td>
  </tr>
  <tr> 
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr class="area"> 
          <td width="275" valign="middle">
		  	<cfset RolActual = 4>
			<cfset Session.RolActual = 4>
			<cfinclude template="../../portlets/pEmpresas2.cfm">
		  </td>
          <td nowrap> 
            <div align="center"><span class="superTitulo">
			<font size="5">
	  <!-- InstanceBeginEditable name="Titulo" -->ADMINISTRACION 
              DEL CENTRO DE ESTUDIO<!-- InstanceEndEditable -->	
			</font></span></div></td>
        </tr>
        <tr class="area" style="padding-bottom: 3px;"> 
		  <td nowrap style="padding-left: 10px;">
		  <cfinclude template="../../portlets/pminisitio.cfm">
		  </td>
          <td valign="top" nowrap> 
	  <!-- InstanceBeginEditable name="MenuJS" -->
	  <cfinclude template="../jsMenuCED.cfm"> 
      <!-- InstanceEndEditable -->	
		  </td>
        </tr>
      </table>
	</td>
  </tr>
</table>
  
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="left" valign="top" nowrap></td>
    <td width="100%" height="1" align="left" valign="top"><!-- InstanceBeginEditable name="Titulo2" --><!-- InstanceEndEditable --></td>
  </tr>
  <tr> 
    <td valign="top" nowrap>
		<cfinclude template="/sif/menu.cfm">
	</td>
    <td valign="top" width="100%">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="2%"class="Titulo"><img  src="../../Imagenes/sp.gif" width="15" height="15" border="0"></td>
          <td width="3%" class="Titulo" >&nbsp;</td>
          <td width="94%" class="Titulo">
		  <!-- InstanceBeginEditable name="TituloPortlet" -->
		  matricula masiva
		   <!-- InstanceEndEditable -->
		  </td>
          <td width="1%" valign="top" nowrap bgcolor="#ADADCA"><img src="../../Imagenes/rt.gif"></td>
        </tr>
        <tr> 
          <td colspan="3" class="contenido-lbborder">
		  <!-- InstanceBeginEditable name="Mantenimiento2" -->

			<!--- Consulta de promociones --->
			<cfquery datasource="#Session.DSN#" name="rsPromociones">
				Set nocount on
				Select distinct PRcodigo=convert(varchar,pr.PRcodigo),
				PRdescripcion= pr.PRdescripcion + ' : ' + g.Gdescripcion, 
				SPEcodigo=convert(varchar,pv.SPEcodigo), Gcodigo=convert(varchar,pr.Gcodigo), g.Gnalumnos,
				Gngrupos=(select count(GRcodigo) from Grupo where Gcodigo=pr.Gcodigo and SPEcodigo=pv.SPEcodigo ),
				PRalumnos=(select count(Ecodigo) from Alumnos where PRcodigo=pr.PRcodigo and CEcodigo=n.CEcodigo)
				from Promocion pr, Nivel n, PeriodoVigente pv, Grado g
				where n.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and pr.Ncodigo = n.Ncodigo
				and pr.Ncodigo = pv.Ncodigo
				and pr.PEcodigo = pv.PEcodigo
				and pr.Gcodigo = g.Gcodigo
				and pr.PRactivo = 1
				order by n.Norden,g.Gorden
				Set nocount off
			</cfquery>
			<cfloop query="rsPromociones">
				<cfset codPromocion=#rsPromociones.PRcodigo#>
				<cfbreak>
			</cfloop>
			<cfif isdefined("Form.PRcodigo")>
				<cfset codPromocion=#Form.PRcodigo#>
			</cfif>

			<cfif isdefined("codPromocion")>
			<!--- Consulta de grupos --->
			<cfquery datasource="#Session.DSN#" name="rsGruposAnteriores">
				Set nocount on
				Select distinct GRcodigo=convert(varchar,gr.GRcodigo),gr.GRnombre
				from Grupo gr, Grado g, Nivel n, Promocion pr, PeriodoVigente pv,SubPeriodoEscolar spe
				where n.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and pr.PRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codPromocion#">
				and pr.Ncodigo = n.Ncodigo
				and pr.Ncodigo = pv.Ncodigo
				and pr.PEcodigo = pv.PEcodigo
				and g.Gpromogrado = pr.Gcodigo
				and gr.Gcodigo = g.Gcodigo
				and spe.PEcodigo = gr.PEcodigo
				and spe.SPEcodigo = gr.SPEcodigo
				and spe.SPEorden < (select SPEorden from SubPeriodoEscolar
					where PEcodigo=pv.PEcodigo and SPEcodigo=pv.SPEcodigo)
				and not exists (select * from SubPeriodoEscolar spea
					where spea.PEcodigo = gr.PEcodigo
					and spe.SPEorden < spea.SPEorden
					and spea.SPEorden < (select SPEorden from SubPeriodoEscolar
						where PEcodigo=pv.PEcodigo and SPEcodigo=pv.SPEcodigo))
				order by GRcodigo
				Set nocount off
			</cfquery>

			<cfquery datasource="#Session.DSN#" name="rsGrupos">
				Set nocount on
				Select distinct GRcodigo=convert(varchar,gr.GRcodigo), gr.GRnombre
				from Grupo gr, Nivel n, Promocion pr, PeriodoVigente pv, GrupoAlumno gra, Alumnos a
				where n.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and pr.PRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codPromocion#">
				and a.PRcodigo = pr.PRcodigo
				and gra.Ecodigo=a.Ecodigo
				and gr.Ncodigo = n.Ncodigo
				and gr.Ncodigo = pr.Ncodigo
				and gr.Gcodigo = pr.Gcodigo
				and pr.Ncodigo = pv.Ncodigo
				and pr.PEcodigo = pv.PEcodigo
				and gr.PEcodigo = pv.PEcodigo
				and gr.SPEcodigo = pv.SPEcodigo
				and gr.GRcodigo = gra.GRcodigo
				order by GRnombre
				Set nocount off
			</cfquery>
			<cfset hayGrupos=false>
			<cfloop query="rsGrupos">
				<cfset hayGrupos=true>
				<cfbreak>
			</cfloop>
				
			<cfquery datasource="#Session.DSN#" name="rsCalificado">
				Set nocount on
				Select PEcodigo=convert(varchar,acpe.PEcodigo)
				from Curso c, Promocion pr, Nivel n, PeriodoVigente pv, Alumnos a,
				AlumnoCalificacionPerEval acpe
				where c.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and pr.PRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codPromocion#">
				and acpe.Ecodigo = a.Ecodigo
				and a.PRcodigo = pr.PRcodigo
				and c.SPEcodigo = pv.SPEcodigo
				and pr.Ncodigo = n.Ncodigo
				and pr.Ncodigo = pv.Ncodigo
				and pr.PEcodigo = pv.PEcodigo
				and c.Ccodigo = acpe.Ccodigo
				Set nocount off
			</cfquery>
			<cfset calificado=false>
			<cfloop query="rsCalificado">
				<cfset calificado=true>
				<cfbreak>
			</cfloop>
			</cfif>

		    <script language="JavaScript" type="text/JavaScript">
		    function valida(formulario) {
				
				if (formulario.calificado.value == "1") {
					if (!confirm("Se van a perder las notas de la promoci�n.  Desea continuar?")) {
						return false;
					}
				}
			
		        return true;
		    }
		    </script>
			
            <table width="100%" border="0" cellspacing="3" cellpadding="3">
			  <tr>
				<td>
					<cfinclude template="../../portlets/pNavegacionCED.cfm">				
				</td>
			  </tr>
              <tr>
                <td><b>Promoci&oacute;n</b>&nbsp;
                <form name="formPromocion" method="post" action="MatriculaMasiva.cfm">
				  <select name="PRcodigo" onChange="javascript:formPromocion.submit();">
	  	    		<cfoutput query="rsPromociones">
						<option value="#rsPromociones.PRcodigo#" 
						  <cfif isdefined("codPromocion") AND codPromocion EQ rsPromociones.PRcodigo>selected</cfif>>
						  #rsPromociones.PRdescripcion#
						</option>
					</cfoutput>
                  </select>
				 </form>
				</td>
			  </tr>
	  	      <cfoutput query="rsPromociones">
				<cfif isdefined("codPromocion") AND codPromocion EQ rsPromociones.PRcodigo>
				<cfif rsPromociones.Gngrupos IS 0>
				<tr><td><strong>ATENCION:</strong> No hay grupos en el curso lectivo actual
				para efectuar la matr&iacute;cula de esta promoci&oacute;n. Proceda a crear grupos.</td></tr>
				<cfelseif rsPromociones.PRalumnos IS 0>
				<tr><td>No hay estudiantes asociados a esta promoci&oacute;n.</td></tr>
				<cfelseif rsPromociones.PRalumnos / rsPromociones.Gngrupos
				GREATER THAN rsPromociones.Gnalumnos AND rsPromociones.Gnalumnos IS NOT 0>
				<tr><td><strong>ATENCION:</strong> Se va a exceder el m&aacute;ximo n&uacute;mero
				de estudiantes por grupo.  Se recomienda crear m&aacute;s grupos.</td></tr>
				</cfif>
				</cfif>
			  </cfoutput>
			  <cfif isdefined("hayGrupos") AND hayGrupos>
              <tr>
                <td>
				Ya hay alumnos de esta promoci&oacute;n matriculados en grupos.
				Si se corre la matr&iacute;cula se volver&aacute;n a matricular.
                </td>
              </tr>
			  </cfif>
			  <cfif isdefined("calificado") AND calificado>
              <tr>
                <td>
				<strong>ATENCION:</strong> Ya se han calificado alumnos de esta promoci&oacute;n.
				Si se ejecuta este proceso se perder&aacute;n las notas.
                </td>
              </tr>
			  </cfif>
			  <cfif isdefined("codPromocion")>
              <form name="formMatricula" method="post" action="SQLMatriculaMas.cfm" onSubmit="return valida(this)">
			  <cfif rsGruposAnteriores.RecordCount IS NOT 0>
			  <tr><td><b>Mantener grupos</b></td></tr>
	  	    	<cfoutput query="rsGruposAnteriores">
				  <tr><td>
					<input type="checkbox" name="GRcodigo" value="#rsGruposAnteriores.GRcodigo#" >
					#rsGruposAnteriores.GRnombre#
				  </td></tr>
				</cfoutput>
			  <tr><td><input type="checkbox" name="GRtodos" value="-1" onClick="javascript:checkTodos()">
			  	Todos</td></tr>
			  </cfif>
              <tr>
                <td>
				<div style="text-align:center">
				<input type="hidden" name="PRcodigo" value="<cfoutput>#codPromocion#</cfoutput>">
				<input type="submit" name="btnAceptar" value="Matricular" onClick="javascript:setBtn(this)">
				<cfif isdefined("hayGrupos") AND hayGrupos>
					<input type="submit" name="btnDesmatricular" value="Desmatricular" onClick="javascript:setBtn(this)">
				</cfif>
				<input type="hidden" name="calificado"
					value="<cfoutput><cfif isdefined('calificado') AND calificado>1
					<cfelse>0</cfif></cfoutput>">
				</div>
				</td>
              </tr>
              </form>
			  </cfif>
            </table>
			<script type="text/javascript">
			function checkTodos() {
				for (var i = 0; i < formMatricula.elements.length; ++i)
					if (formMatricula.elements[i].type == "checkbox"
					&& formMatricula.elements[i].name == "GRcodigo") {
							formMatricula.elements[i].checked = formMatricula.GRtodos.checked;
					}
			}
			</script>
            <!-- InstanceEndEditable -->
		  </td>
          <td class="contenido-brborder">&nbsp;</td>
        </tr>
      </table>
	 </td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
