<cfparam name="action" default="encargados.cfm">

<cfif isdefined("form.btnAgregar") or isdefined("form.btnCambiar")>
	<cfset tmp = "" >		<!--- comtenido binario de la imagen --->
	<cfset ts = "null">
	<cfif isdefined("Form.Pfoto") and form.Pfoto NEQ "">
		<cftry>
			<!--- Seccion del Upload= Copia la imagen a un folder del servidor servidor --->
			<cffile action="Upload" fileField="form.Pfoto" destination="#GetTempDirectory()#" nameConflict="Overwrite" accept="image/*"> 
			<!--- lee la imagen de la carpeta del servidor y la almacena en la variable tmp --->
			<cffile action="readbinary"  file="#GetTempDirectory()##cffile.ClientFileName#.#cffile.ClientFileExt#" variable="tmp" > 
	
			<cffile action="delete" file="#GetTempDirectory()##cffile.ClientFileName#.#cffile.ClientFileExt#">
		
			<!--- Formato para sybase --->
				<cfset Hex=ListtoArray("0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F")>
		
				<cfif not isArray(tmp)>
					<cfset ts = "">
				</cfif>
				<cfset miarreglo=#ListtoArray(ArraytoList(#tmp#,","),",")#>
				<cfset miarreglo2=ArrayNew(1)>
				<cfset temp=ArraySet(miarreglo2,1,8,"")>
		
				<cfloop index="i" from="1" to=#ArrayLen(miarreglo)#>
					<cfif miarreglo[i] LT 0>
						<cfset miarreglo[i]=miarreglo[i]+256>
					</cfif>
				</cfloop>
		
				<cfloop index="i" from="1" to=#ArrayLen(miarreglo)#>
					<cfif miarreglo[i] LT 10>
						<cfset miarreglo2[i] = "0" & #toString(Hex[(miarreglo[i] MOD 16)+1])#>
					<cfelse>
						<cfset miarreglo2[i] = #trim(toString(Hex[(miarreglo[i] \ 16)+1]))# & #trim(toString(Hex[(miarreglo[i] MOD 16)+1]))#>
					</cfif>
				</cfloop>
				<cfset temp = #ArrayPrepend(miarreglo2,"0x")#>
				<cfset ts = #ArraytoList(miarreglo2,"")#>

		<cfcatch type="any">
 			<cfinclude template="/edu/errorPages/BDerror.cfm">
			<cfabort>
		</cfcatch>
		</cftry>		
	</cfif>		

	<cftry>
		<!--- Caso 1: Agregar --->
		<cfif isdefined("Form.btnAgregar")>
			<cfquery name="ABC_Encargado" datasource="#Session.DSN#">
				set nocount on
				insert PersonaEducativo 
				(CEcodigo, Pnombre, Papellido1, Papellido2, Ppais, TIcodigo, Pid, Pnacimiento, Psexo, Pemail1, Pemail2, Pdireccion, Pcasa, Poficina, Pcelular, Pfax, Ppagertel, Ppagernum, Pfoto, Pemail1validado)
				values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pnombre#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Papellido1#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Papellido2#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppais#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.TIcodigo#">,							
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pid#">,
						convert( datetime, <cfqueryparam value="#form.Pnacimiento#" cfsqltype="cf_sql_varchar">, 103 ),																				
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Psexo#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pemail1#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pemail2#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pdireccion#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pcasa#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Poficina#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pcelular#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pfax#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppagertel#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppagernum#">,
						#ts#,0)							

				select @@identity as id
				set nocount off
			</cfquery>

			<cfset action = "encargados.cfm">
			<cfset modo="CAMBIO">
				
		<!--- Caso 2: Cambio --->
		<cfelseif isdefined("Form.btnCambiar") and isdefined("form.personaEncar") and form.personaEncar NEQ "">
			<cfquery name="ABC_Encargado" datasource="#Session.DSN#">
				update PersonaEducativo set
					CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
					Pnombre=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pnombre#">,
					Papellido1=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Papellido1#">,
					Papellido2=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Papellido2#">,
					Ppais=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppais#">,
					TIcodigo=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.TIcodigo#">,
					Pid=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pid#">,
					Pnacimiento=convert( datetime, <cfqueryparam value="#form.Pnacimiento#" cfsqltype="cf_sql_varchar">, 103 ),
					Psexo=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Psexo#">,
					Pemail1=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pemail1#">,
					Pemail2=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pemail2#">,
					Pdireccion=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pdireccion#">,
					Pcasa=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pcasa#">,
					Poficina=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Poficina#">,
					Pcelular=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pcelular#">,
					Pfax=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pfax#">,
					Ppagertel=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppagertel#">,
					Ppagernum=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppagernum#">,
					<cfif isdefined("Form.Pfoto") and #form.Pfoto# NEQ "">
						Pfoto=#ts#,
					</cfif>					
					Pemail1validado=0
				where persona= <cfqueryparam value="#form.personaEncar#" cfsqltype="cf_sql_numeric">
			</cfquery>

			<cfquery name="refUser" datasource="#Session.DSN#">
				select convert(varchar, EEcodigo) as num_referencia, 'edu.encargado' as rol
				from Encargado
				where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.personaEncar#">
			</cfquery>
				
			<!--- Actualizacion del Usuario en el Framework --->
			<cfinvoke 
			 component="edu.Componentes.usuarios"
			 method="upd_usuario"
			 returnvariable="UsrUpdated">
				<cfinvokeargument name="consecutivo" value="#Session.CEcodigo#"/>
				<cfinvokeargument name="sistema" value="edu"/>
				<cfinvokeargument name="referencias" value="#refUser.num_referencia#"/>
				<cfinvokeargument name="roles" value="#refUser.rol#"/>
				<cfinvokeargument name="activacion" value="1"/>
				<cfinvokeargument name="Pnombre" value="#form.Pnombre#"/>
				<cfinvokeargument name="Papellido1" value="#form.Papellido1#"/>
				<cfinvokeargument name="Papellido2" value="#form.Papellido2#"/>
				<cfinvokeargument name="Ppais" value="#form.Ppais#"/>
				<cfinvokeargument name="TIcodigo" value="#form.TIcodigo#"/>
				<cfinvokeargument name="Pid" value="#form.Pid#"/>
				<cfinvokeargument name="Pnacimiento" value="#form.Pnacimiento#"/>
				<cfinvokeargument name="Psexo" value="#form.Psexo#"/>
				<cfinvokeargument name="Pemail1" value="#form.Pemail1#"/>
				<cfinvokeargument name="Pemail2" value="#form.Pemail2#"/>
				<cfinvokeargument name="Pdireccion" value="#form.Pdireccion#"/>
				<cfinvokeargument name="Pcasa" value="#form.Pcasa#"/>
				<cfinvokeargument name="Poficina" value="#form.Poficina#"/>
				<cfinvokeargument name="Pcelular" value="#form.Pcelular#"/>
				<cfinvokeargument name="Pfax" value="#form.Pfax#"/>
				<cfinvokeargument name="Ppagertel" value="#form.Ppagertel#"/>
				<cfinvokeargument name="Ppagernum" value="#form.Ppagernum#"/>
				<cfif isdefined("Form.Pfoto") and form.Pfoto NEQ "">
					<cfinvokeargument name="Pfoto" value="#ts#"/>
				</cfif>
				<cfinvokeargument name="upd_referencia" value="#refUser.num_referencia#"/>
				<cfinvokeargument name="upd_rol" value="#refUser.rol#"/>
				<cfinvokeargument name="dominio_roles" value="#refUser.rol#"/>
			</cfinvoke>
				
			<cfset action = "encargados.cfm">								
			<cfset modo="CAMBIO">
		</cfif>					

	<cfcatch type="any">
		<cfinclude template="/edu/errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>		
<cfelseif isdefined("form.btnRegresa")> 
	<cfset action = "alumno.cfm" >
	<cfset modo   = "CAMBIO" >
<cfelseif isdefined("form.btnNuevo")>
	<cfset form.persona = "">
	<cfset action = "encargados.cfm" >
	<cfset modo   = "ALTA" >
</cfif>

<cfif isdefined("form.btnAgregar")>
	<cfif isdefined("form.personaEncar") AND form.personaEncar EQ "" >
		<cfset form.personaEncar = ABC_Encargado.id>
		<cftry>
			<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
				set nocount on
				declare @NuevoEncargado numeric
				
				insert Encargado (persona, autorizado)
				values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.personaEncar#">, 1)
				select @NuevoEncargado = @@identity

				insert EncargadoEstudiante (EEcodigo, CEcodigo, Ecodigo)
				values (@NuevoEncargado,
						<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
						<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Ecodigo#">)					
				
				select convert(varchar, @NuevoEncargado) as id
				set nocount off
			</cfquery>	

			<!--- Insercion del Usuario en el Framework --->
			<cfinvoke 
			 component="edu.Componentes.usuarios"
			 method="upd_usuario"
			 returnvariable="UsrInserted">
				<cfinvokeargument name="consecutivo" value="#Session.CEcodigo#"/>
				<cfinvokeargument name="sistema" value="edu"/>
				<cfinvokeargument name="referencias" value="#ABC_Relaciones.id#"/>
				<cfinvokeargument name="roles" value="edu.encargado"/>
				<cfinvokeargument name="activacion" value="1"/>
				<cfinvokeargument name="Pnombre" value="#form.Pnombre#"/>
				<cfinvokeargument name="Papellido1" value="#form.Papellido1#"/>
				<cfinvokeargument name="Papellido2" value="#form.Papellido2#"/>
				<cfinvokeargument name="Ppais" value="#form.Ppais#"/>
				<cfinvokeargument name="TIcodigo" value="#form.TIcodigo#"/>
				<cfinvokeargument name="Pid" value="#form.Pid#"/>
				<cfinvokeargument name="Pnacimiento" value="#form.Pnacimiento#"/>
				<cfinvokeargument name="Psexo" value="#form.Psexo#"/>
				<cfinvokeargument name="Pemail1" value="#form.Pemail1#"/>
				<cfinvokeargument name="Pemail2" value="#form.Pemail2#"/>
				<cfinvokeargument name="Pdireccion" value="#form.Pdireccion#"/>
				<cfinvokeargument name="Pcasa" value="#form.Pcasa#"/>
				<cfinvokeargument name="Poficina" value="#form.Poficina#"/>
				<cfinvokeargument name="Pcelular" value="#form.Pcelular#"/>
				<cfinvokeargument name="Pfax" value="#form.Pfax#"/>
				<cfinvokeargument name="Ppagertel" value="#form.Ppagertel#"/>
				<cfinvokeargument name="Ppagernum" value="#form.Ppagernum#"/>
				<cfif isdefined("Form.Pfoto") and form.Pfoto NEQ "">
					<cfinvokeargument name="Pfoto" value="#ts#"/>
				</cfif>
			</cfinvoke>

			<cfcatch type="any">
				<cfinclude template="/edu/errorPages/BDerror.cfm">
				<cfabort>
			</cfcatch>
		</cftry>
	</cfif>
</cfif>

<cfoutput>
<form action="#action#" method="post" name="sql">
	<input name="modo"   type="hidden" value="<cfif isdefined("modo")>#modo#</cfif>">
	<input name="personaEncar"   type="hidden" value="<cfif isdefined("Form.personaEncar")>#form.personaEncar#</cfif>">
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")>#Form.Pagina#</cfif>">	
    <input name="Ecodigo" id="Ecodigo" value="#form.Ecodigo#" type="hidden">    
	<input name="o" type="hidden" value="<cfif isdefined("Form.o")><cfoutput>#form.o#</cfoutput></cfif>"> 
	<input name="persona"   type="hidden" value="<cfif isdefined("Form.persona")>#form.persona#</cfif>">	
</form>
</cfoutput>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>