<cfparam name="action" default="promociones.cfm">

<cfif isdefined("form.btnAgregar") or isdefined("form.btnCambiar") or isdefined("form.btnBorrar")>
	<cftry>
		<cfif isdefined("form.btnAgregar") or isdefined("form.btnCambiar") >
			<cfquery datasource="#Session.DSN#" name="rsPEcodigo">
				select PEcodigo
				from SubPeriodoEscolar
				where SPEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.SPEcodigo#">
			</cfquery>
			<cfset varPEcodigo = rsPEcodigo.PEcodigo>
		</cfif>	
	

		<cfquery name="ABC_Promociones" datasource="#Session.DSN#">
			set nocount on
			
			<!--- Caso 1: Agregar --->
			<cfif isdefined("Form.btnAgregar")>
					if not exists ( select 1 from Promocion
									where Ncodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Ncodigo#">
									and Gcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Gcodigo#">
									and PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#varPEcodigo#">
									and SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.SPEcodigo#">
									and PRano = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.PRano#">
					)
					begin				
						insert Promocion (Gcodigo, Ncodigo, PRano, SPEcodigo, PEcodigo, PRdescripcion)
						values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Gcodigo#">,
								<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Ncodigo#">,
								<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.PRano#">,
								<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.SPEcodigo#">, 
								<cfqueryparam cfsqltype="cf_sql_numeric" value="#varPEcodigo#">,
								<cfif isdefined("form.PRdescripcion") and #form.PRdescripcion# NEQ "">
									<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.PRdescripcion#">)
								<cfelse>
									'Promoci�n #form.PRano#')											
								</cfif>

						select @@identity as id
						<cfset modo="CAMBIO">						
					end
					else 
					begin
						select -1 as id
						<cfset modo="ALTA">
					end
				
				<cfset action = "promociones.cfm">
				
			<!--- Caso 2: Cambio --->
			<cfelseif isdefined("Form.btnCambiar") and isdefined("form.PRcodigo") and #form.PRcodigo# NEQ "">
				if not exists ( select 1 from Promocion
								where Ncodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Ncodigo#">
								and Gcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Gcodigo#">
								and SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.SPEcodigo#">
								and PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#varPEcodigo#">								
								and PRano = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.PRano#">
								and PRcodigo != <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.PRcodigo#">
				)
				begin			
					update Promocion set
						Gcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Gcodigo#">,
						Ncodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Ncodigo#">,					
						PRano = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.PRano#">,
						SPEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.SPEcodigo#">,
 						PEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#varPEcodigo#">, 
						<cfif isdefined("form.PRdescripcion") and #form.PRdescripcion# NEQ "">
							PRdescripcion = <cfqueryparam cfsqltype="cf_sql_varchar" value="#form.PRdescripcion#">
						<cfelse>				
							PRdescripcion = 'Promoci�n #form.PRano#'
						</cfif>					
					where PRcodigo= <cfqueryparam value="#form.PRcodigo#" cfsqltype="cf_sql_numeric">
				end

				<cfset action = "promociones.cfm">								
				<cfset modo="ALTA">

			<!--- Caso 4: Borrar --->
			<cfelseif isdefined("Form.btnBorrar")>			
				<cfif isdefined("Form.PRcodigo") AND #Form.PRcodigo# NEQ "" >
					<!--- Borrado de la promocion --->					
					delete Promocion 
					where PRcodigo=<cfqueryparam value="#form.PRcodigo#" cfsqltype="cf_sql_numeric">				
					
					<cfset modo="ALTA">									
				</cfif>								
			</cfif>
			 
			set nocount off					
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>		
<cfelse> 
	<cfset action = "promociones.cfm" >
	<cfset modo   = "ALTA" >
</cfif>


<cfif isdefined("form.PRcodigo") AND #form.PRcodigo# EQ "" and isdefined("form.btnAgregar")>
	<cfset #form.PRcodigo# = "#ABC_Promociones.id#">
</cfif>		

<cfoutput>
<form action="#action#" method="post" name="sql">
	<input name="modo"   type="hidden" value="<cfif isdefined("modo")>#modo#</cfif>">
	<cfif isdefined("Form.PRcodigo") and form.PRcodigo NEQ "-1">
		<input name="PRcodigo"   type="hidden" value="#form.PRcodigo#">
	<cfelse>
		<script language="JavaScript" type="text/javascript">
			alert('Error, la promoci�n ya existe');
		</script>
	</cfif>
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")>#Form.Pagina#</cfif>">
	
	<!--- Campos para el boton de buscar --->
	<cfif isdefined("form.btnBuscar") > 
		<input name="Busca" type="hidden" value="1">
		<input name="PRano" type="hidden" value="<cfif isdefined("Form.PRano")>#Form.PRano#</cfif>">	
		<input name="PRdescripcion" type="hidden" value="<cfif isdefined("Form.PRdescripcion")>#Form.PRdescripcion#</cfif>">			
	</cfif>		
</form>
</cfoutput>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>