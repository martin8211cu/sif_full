<cfinclude template="../../Utiles/general.cfm">
<html><!-- InstanceBegin template="/Templates/LMenuCED.dwt.cfm" codeOutsideHTMLIsLocked="false" -->
<head>
<title>Educaci&oacute;n</title>
<meta http-equiv="Expires" content="Fri, Jan 01 1970 08:20:00 GMT">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Pragma" content="no-cache">
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
<link href="../../css/portlets.css" rel="stylesheet" type="text/css">
<link href="../../css/edu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
<script language="JavaScript" src="../../js/DHTMLMenu/stm31.js"></script>
<script language="JavaScript" type="text/javascript">
	// Funciones para Manejo de Botones
	botonActual = "";

	function setBtn(obj) {
		botonActual = obj.name;
	}
	function btnSelected(name, f) {
		if (f != null) {
			return (f["botonSel"].value == name)
		} else {
			return (botonActual == name)
		}
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="154" rowspan="2" align="center" valign="top"><img src="../../Imagenes/logo.gif" width="154" height="62"></td>
    <td valign="bottom"> 
	  <!-- InstanceBeginEditable name="Ubica" --> 
      <cfinclude template="../../portlets/pubica.cfm">
      <!-- InstanceEndEditable --> </td>
  </tr>
  <tr> 
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr class="area"> 
          <td width="275" valign="middle">
		  	<cfset RolActual = 4>
			<cfset Session.RolActual = 4>
			<cfinclude template="../../portlets/pEmpresas2.cfm">
		  </td>
          <td nowrap> 
            <div align="center"><span class="superTitulo">
			<font size="5">
	  <!-- InstanceBeginEditable name="Titulo" --> 
	  			ADMINISTRACION DEL CENTRO DE ESTUDIO
      <!-- InstanceEndEditable -->	
			</font></span></div></td>
        </tr>
        <tr class="area" style="padding-bottom: 3px;"> 
		  <td nowrap style="padding-left: 10px;">
		  <cfinclude template="../../portlets/pminisitio.cfm">
		  </td>
          <td valign="top" nowrap> 
	  <!-- InstanceBeginEditable name="MenuJS" -->
	  <cfinclude template="../jsMenuCED.cfm"> 
      <!-- InstanceEndEditable -->	
		  </td>
        </tr>
      </table>
	</td>
  </tr>
</table>
  
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="left" valign="top" nowrap></td>
    <td width="100%" height="1" align="left" valign="top"><!-- InstanceBeginEditable name="Titulo2" --><!-- InstanceEndEditable --></td>
  </tr>
  <tr> 
    <td valign="top" nowrap>
		<cfinclude template="/sif/menu.cfm">
	</td>
    <td valign="top" width="100%">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="2%"class="Titulo"><img  src="../../Imagenes/sp.gif" width="15" height="15" border="0"></td>
          <td width="3%" class="Titulo" >&nbsp;</td>
          <td width="94%" class="Titulo">
		  <!-- InstanceBeginEditable name="TituloPortlet" --> 
            matricula individual<!-- InstanceEndEditable -->
		  </td>
          <td width="1%" valign="top" nowrap bgcolor="#ADADCA"><img src="../../Imagenes/rt.gif"></td>
        </tr>
        <tr> 
          <td colspan="3" class="contenido-lbborder">
		  <!-- InstanceBeginEditable name="Mantenimiento2" -->
			<cfquery datasource="#Session.DSN#" name="rsPromociones">
				Set nocount on
				Select distinct PRcodigo=convert(varchar,pr.PRcodigo),
				PRdescripcion = pr.PRdescripcion + ' : ' + g.Gdescripcion, 
				SPEcodigo=convert(varchar,pv.SPEcodigo), convert(varchar,pr.Gcodigo)
				from Promocion pr, Nivel n, Grado g, PeriodoVigente pv
				where n.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and pr.Gcodigo = g.Gcodigo
				and pr.Ncodigo = n.Ncodigo
				and pr.Ncodigo = pv.Ncodigo
				and pr.PEcodigo = pv.PEcodigo
				and pr.PRactivo = 1
				order by n.Norden,g.Gorden
				Set nocount off
			</cfquery>
			<cfloop query="rsPromociones">
				<cfset codPromocion=#rsPromociones.PRcodigo#>
				<cfbreak>
			</cfloop>
			<cfif isdefined("Form.PRcodigo")>
				<cfset codPromocion=#Form.PRcodigo#>
			</cfif>
			
			<cfif isdefined("codPromocion")>
				<cfquery datasource="#Session.DSN#" name="rsAlumnos">
				Set nocount on
				Select distinct Ecodigo=convert(varchar,a.Ecodigo), p.Pnombre, p.Papellido1, p.Papellido2
				from Alumnos a, PersonaEducativo p
				where a.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and a.PRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codPromocion#">
				and a.persona = p.persona
				and a.Aretirado = 0
				order by Papellido1,Papellido2,Pnombre
				Set nocount off
				</cfquery>
				<cfloop query="rsAlumnos">
					<cfset codEstudiante=#rsAlumnos.Ecodigo#>
					<cfbreak>
				</cfloop>
				<cfif isdefined("Form.Ecodigo")
				AND (NOT isdefined("Form.noAlumn") OR Form.noAlumn IS "0")>
					<cfset codEstudiante=#Form.Ecodigo#>
				</cfif>
			</cfif>
			
			<cfif isdefined("codPromocion") AND isdefined("codEstudiante")>
				<cfquery datasource="#Session.DSN#" name="rsGrupos">
				Set nocount on
				Select distinct GRcodigo=convert(varchar,gr.GRcodigo), gr.GRnombre,
				GRactual=case when gra.GRcodigo is null then 0 else 1 end,g.Gnalumnos,
				GRnalumnos=(select count(Ecodigo) from GrupoAlumno where GRcodigo=gr.GRcodigo)
				from Grupo gr, Nivel n, Promocion pr, PeriodoVigente pv, GrupoAlumno gra, Grado g
				where n.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and pr.PRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codPromocion#">
				and gra.Ecodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codEstudiante#"> 
				and gr.Ncodigo = n.Ncodigo
				and gr.Ncodigo = pr.Ncodigo
				and gr.Gcodigo = pr.Gcodigo
				and pr.Ncodigo = pv.Ncodigo
				and pr.PEcodigo = pv.PEcodigo
				and gr.PEcodigo = pv.PEcodigo
				and gr.SPEcodigo = pv.SPEcodigo
				and gr.GRcodigo *= gra.GRcodigo
				and gr.Gcodigo = g.Gcodigo
				order by GRnombre
				Set nocount off
				</cfquery>
				<cfloop query="rsGrupos">
					<cfset codGrupo=#rsGrupos.GRcodigo#>
					<cfbreak>
				</cfloop>								
				<cfset codGrupoActual=0>
				<cfloop query="rsGrupos">
					<cfif rsGrupos.GRactual IS NOT 0>
					  <cfset codGrupo=#rsGrupos.GRcodigo#>
					  <cfset codGrupoActual=#rsGrupos.GRcodigo#>
					  <cfbreak>
					</cfif>
				</cfloop>			
				<cfif isdefined("Form.GRcodigo")
				AND (NOT isdefined("Form.noGroup") OR Form.noGroup IS "0")>
					<cfset codGrupo=#Form.GRcodigo#>
				</cfif>
				
				<cfif isdefined("codGrupo")>
				<cfquery datasource="#Session.DSN#" name="rsCursos">
				Set nocount on
				Select distinct Ccodigo=convert(varchar,c.Ccodigo),
				Cnombre = m.Mnombre + ' - ' + gr.GRnombre, 
				Mconsecutivo=convert(varchar,m.Mconsecutivo), m.Mcodigo, m.Mnombre,
				Cmatriculado=case when acc.Ccodigo is null then 0 else 1 end
				from Curso c, Materia m, Promocion pr, Nivel n, PeriodoVigente pv, 
				AlumnoCalificacionCurso acc, Grupo gr
				where c.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and pr.PRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codPromocion#">
				and c.GRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codGrupo#">
				and acc.Ecodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codEstudiante#">
				and c.GRcodigo = gr.GRcodigo
				and c.Mconsecutivo = m.Mconsecutivo
				and c.SPEcodigo = pv.SPEcodigo
				and pr.Ncodigo = n.Ncodigo
				and pr.Ncodigo = pv.Ncodigo
				and pr.PEcodigo = pv.PEcodigo
				and pr.Gcodigo = m.Gcodigo
				and c.Ccodigo *= acc.Ccodigo
				and (m.Melectiva = 'R' or m.Melectiva = 'C')
				order by Cnombre
				Set nocount off
				</cfquery>
				<cfquery datasource="#Session.DSN#" name="rsElectivas">
				Set nocount on
				Select distinct Ccodigo=convert(varchar,c.Ccodigo), c.Cnombre, 
				convert(varchar,cs.Ccodigo) as Scodigo, cs.Cnombre as Snombre,
				Cmatriculado=case when cae.Ccodigo is null then 0 else 1 end
				from Materia m, Promocion pr, Nivel n, PeriodoVigente pv, MateriaElectiva me, 
				Materia ms, Curso c, Curso cs, AlumnoCalificacionCurso accs, Curso cae
				where n.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and pr.PRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codPromocion#">
				and accs.Ecodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codEstudiante#">
				and c.GRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codGrupo#">
				and c.Mconsecutivo = m.Mconsecutivo
				and c.SPEcodigo = pv.SPEcodigo
				and pr.Ncodigo = n.Ncodigo
				and pr.Ncodigo = pv.Ncodigo
				and pr.PEcodigo = pv.PEcodigo
				and pr.Gcodigo = m.Gcodigo
				and m.Mconsecutivo = me.Melectiva
				and me.Mconsecutivo = ms.Mconsecutivo
				and cs.Mconsecutivo = ms.Mconsecutivo
				and cs.SPEcodigo = pv.SPEcodigo
				and cs.Ccodigo *= accs.Ccodigo
				and accs.ACCelectiva *= cae.Ccodigo
				and cae.GRcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#codGrupoActual#">
				and cae.Mconsecutivo =* c.Mconsecutivo
				and ms.Melectiva = 'S'
				and m.Melectiva = 'E'
				order by Cnombre
				Set nocount off
				</cfquery>
			    </cfif>

				<cfquery datasource="#Session.DSN#" name="rsCalificado">
				Set nocount on
				Select PEcodigo=convert(varchar,acpe.PEcodigo)
				from Curso c, Materia m, Promocion pr, Nivel n, PeriodoVigente pv, 
				AlumnoCalificacionPerEval acpe
				where c.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and pr.PRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codPromocion#">
				and acpe.Ecodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codEstudiante#">
				and c.Mconsecutivo = m.Mconsecutivo
				and c.SPEcodigo = pv.SPEcodigo
				and pr.Ncodigo = n.Ncodigo
				and pr.Ncodigo = pv.Ncodigo
				and pr.PEcodigo = pv.PEcodigo
				and pr.Gcodigo = m.Gcodigo
				and c.Ccodigo = acpe.Ccodigo
				and m.Melectiva = 'R'
				union
				Select PEcodigo=convert(varchar,acpe.PEcodigo)
				from Materia m, Promocion pr, Nivel n, PeriodoVigente pv, MateriaElectiva me, 
				Materia ms, Curso c, Curso cs, AlumnoCalificacionPerEval acpe
				where n.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				and pr.PRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codPromocion#">
				and acpe.Ecodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#codEstudiante#">
				and c.Mconsecutivo = m.Mconsecutivo
				and c.SPEcodigo = pv.SPEcodigo
				and pr.Ncodigo = n.Ncodigo
				and pr.Ncodigo = pv.Ncodigo
				and pr.PEcodigo = pv.PEcodigo
				and pr.Gcodigo = m.Gcodigo
				and m.Mconsecutivo = me.Melectiva
				and me.Mconsecutivo = ms.Mconsecutivo
				and cs.Mconsecutivo = ms.Mconsecutivo
				and cs.SPEcodigo = pv.SPEcodigo
				and cs.Ccodigo = acpe.Ccodigo
				and ms.Melectiva = 'S'
				and m.Melectiva = 'E'
				Set nocount off
				</cfquery>
				<cfset calificado=false>
				<cfloop query="rsCalificado">
					<cfset calificado=true>
					<cfbreak>
				</cfloop>
			</cfif>

		    <script language="JavaScript" type="text/JavaScript">
		    function valida(formulario) {
				
				if (btnSelected("btnAceptar"))
				for (var i=0; i<formulario.elements.length; i++) {
					if (formulario.elements[i].type == "select-one" &&
					formulario.elements[i].name == "Scodigo") {
						for (var j=i+1; j<formulario.elements.length; j++) {
							if (formulario.elements[j].type == "select-one" &&
							formulario.elements[j].name == "Scodigo") {
								if (formulario.elements[i].value == formulario.elements[j].value) {
									alert('No pueden seleccionarse dos cursos iguales');
									return false;
								}
							}
						}
					}
				}
				
				if (formulario.calificado.value == "1") {
					if (!confirm("Se van a perder las notas del alumno.  Desea continuar?")) {
						return false;
					}
				}
			
		        return true;
		    }
		    </script>
			
            <table width="100%" border="0" cellspacing="3" cellpadding="3">
			  <tr>
				<td>
					<cfinclude template="../../portlets/pNavegacionCED.cfm">				
				</td>
			  </tr>
		      <form name="formAlumno" method="post" action="MatriculaIndividual.cfm">
			  <input type="hidden" name="noGroup" value="0">
			  <input type="hidden" name="noAlumn" value="0">
              <tr>
                <td>
				    <strong>Promoci&oacute;n</strong>&nbsp;
				    <select name="PRcodigo" onChange="javascript:formAlumno.noGroup.value='1';formAlumno.noAlumn.value='1';formAlumno.submit();">
	  	    		<cfoutput query="rsPromociones">
						<option value="#rsPromociones.PRcodigo#" 
						  <cfif isdefined("codPromocion") AND codPromocion EQ rsPromociones.PRcodigo>selected</cfif>>
						  #rsPromociones.PRdescripcion#
						</option>
					</cfoutput>
					</select>&nbsp;
				    <strong>Alumno</strong>&nbsp;
				    <select name="Ecodigo" onChange="javascript:formAlumno.noGroup.value='1';formAlumno.submit();">
					<cfif isdefined("rsAlumnos")>
	  	    		<cfoutput query="rsAlumnos">
						<option value="#rsAlumnos.Ecodigo#" 
						  <cfif isdefined("codEstudiante") AND codEstudiante EQ rsAlumnos.Ecodigo>selected</cfif>>
						  #rsAlumnos.Papellido1# #rsAlumnos.Papellido2# #rsAlumnos.Pnombre#
						</option>
					</cfoutput>
					</cfif>
					</select>
				</td>
              </tr>
			  <cfif isdefined("rsGrupos")>
			  <cfoutput query="rsGrupos">
			    <cfif rsGrupos.GRactual IS NOT 0>
				<tr><td>El alumno ya se encuentra matriculado en el grupo
				"#rsGrupos.GRnombre#".
				Si ud. ejecuta la matr&iacute;cula el alumno va a ser matriculado de nuevo.</td></tr>
			    </cfif>
			  </cfoutput>
			  <cfif NOT isdefined("codGrupoActual") OR codGrupoActual IS 0>
				<tr><td>El alumno no se encuentra matriculado en ning&uacute;n grupo.</td></tr>
			  </cfif>
			  <cfoutput query="rsGrupos">
			    <cfif isdefined("codGrupo") AND codGrupo EQ rsGrupos.GRcodigo>
				<cfif (rsGrupos.GRnalumnos GREATER THAN OR EQUAL TO rsGrupos.Gnalumnos)
				AND (rsGrupos.Gnalumnos GREATER THAN 0)
				AND (rsGrupos.GRnalumnos GREATER THAN rsGrupos.Gnalumnos OR rsGrupos.GRactual IS 0)>
                <tr>
                  <td>
				  <strong>ATENCION:</strong> este grupo ya ha alcanzado el m&aacute;ximo 
				  n&uacute;mero de alumnos por grupo.
				  Se recomienda crear m&aacute;s grupos.
                  </td>
                </tr>
			    </cfif>
			    </cfif>
			  </cfoutput>
			  <cfif isdefined("calificado") AND calificado>
              <tr>
                <td>
				<strong>ATENCION:</strong> este alumno ya ha sido calificado.
				Si se corre este proceso se perder&aacute;n las notas.
                </td>
              </tr>
			  </cfif>
              <tr>
                <td>
				  <strong>Grupo</strong>&nbsp;
				  <select name="GRcodigo" onChange="javascript:formAlumno.submit();">
	  	    		<cfoutput query="rsGrupos">
					  <option value="#rsGrupos.GRcodigo#"
					  <cfif isdefined("codGrupo") AND codGrupo EQ rsGrupos.GRcodigo>selected</cfif>>
						#rsGrupos.GRnombre#
					  </option>
					</cfoutput>
				  </select>
                </td>
              </tr>
			  </cfif>
			  </form>
 			  <cfif isdefined("codPromocion") AND isdefined("codEstudiante") AND isdefined("codGrupo")>
              <tr><td><b>Cursos Regulares</b></td></tr>
              <tr>
                <td>
				  <table border="0" cellspacing="0" cellpadding="0" width="70%">
				    <tr>
					  <td class="tituloListas"><strong>Curso</strong></td>
					  <td class="tituloListas"><strong>Materia</strong></td>
					  <td class="tituloListas"><strong>&nbsp;</strong></td>
					</tr>
					<cfset elemPar = false>
	  	    		<cfoutput query="rsCursos">
					  <tr class="<cfif elemPar>listaPar<cfelse>listaNon</cfif>">
					    <td>#rsCursos.Cnombre#</td>
					    <td>#rsCursos.Mnombre#</td>
						<td>
						  <cfif rsCursos.Cmatriculado IS 0>
						    <img src="../../Imagenes/Cferror.gif" border="0">
						  <cfelse>
						    <img src="../../Imagenes/completa.gif" border="0">
						  </cfif>
						</td>
					  </tr>
					  <cfset elemPar = not elemPar>
					</cfoutput>
				  </table>
				</td>
              </tr>
	    	  <form name="formMatricula" method="post" action="SQLMatriculaInd.cfm" onSubmit="return valida(this)">
              <tr><td><b>Cursos Electivos</b></td></tr>
			  <tr>
			    <td>
				  <table border="0" cellspacing="0" cellpadding="0" width="70%">
				    <tr>
					  <td class="tituloListas"><strong>Electiva</strong></td>
					  <td class="tituloListas"><strong>Sustitutiva</strong></td>
					  <td class="tituloListas"><strong>&nbsp;</strong></td>
					</tr>
					<cfset elemPar = false>
					<cfset codCurso = 0>
					<cfset matriculado = false>
	  	    		<cfoutput query="rsElectivas">
					  <cfif rsElectivas.Ccodigo IS NOT codCurso>
					  <cfif codCurso IS NOT 0>
				  		</select>
						</td>
						<td>
						  <cfif matriculado>
						    <img src="../../Imagenes/completa.gif" border="0">
						  <cfelse>
						    <img src="../../Imagenes/Cferror.gif" border="0">
						  </cfif>
						</td>
					  </tr>
					  </cfif>
					  <cfset matriculado = false>
					  <cfif rsElectivas.Cmatriculado IS 1>
					  	<cfset matriculado = true>
					  </cfif>
					  <cfset codCurso = rsElectivas.Ccodigo>
					  <tr class="<cfif elemPar>listaPar<cfelse>listaNon</cfif>">
					    <input type="hidden" name="Ccodigo" value="#rsElectivas.Ccodigo#">
					    <td>#rsElectivas.Cnombre#</td>
					    <td>
				  		<select name="Scodigo">
					  	  <option value="#rsElectivas.Scodigo#"
					  	  <cfif rsElectivas.Cmatriculado IS 1>selected</cfif>>
						  #rsElectivas.Snombre#
					  	  </option>
					  <cfset elemPar = NOT elemPar>
					  <cfelse>
					  	<cfif rsElectivas.Cmatriculado IS 1>
					  		<cfset matriculado = true>
					  	</cfif>
					  	<option value="#rsElectivas.Scodigo#"
					  	<cfif rsElectivas.Cmatriculado IS 1>selected</cfif>>
						#rsElectivas.Snombre#
					  	</option>
					  </cfif>
					</cfoutput>
					<cfif rsElectivas.RecordCount IS NOT 0>
				  		</select>
						</td>
						<td>
						  <cfif matriculado>
						    <img src="../../Imagenes/completa.gif" border="0">
						  <cfelse>
						    <img src="../../Imagenes/Cferror.gif" border="0">
						  </cfif>
						</td>
					  </tr>
					</cfif>
				  </table>
				</td>
			  </tr>
			  <tr>
			    <td>
				<div style="text-align:center">
				<input type="hidden" name="PRcodigo" value="<cfoutput>#codPromocion#</cfoutput>">
				<input type="hidden" name="Ecodigo" value="<cfoutput>#codEstudiante#</cfoutput>">
				<input type="hidden" name="GRcodigo" value="<cfoutput>#codGrupo#</cfoutput>">
				<input type="submit" name="btnAceptar" value="Matricular" onClick="javascript:setBtn(this)">
				<cfif isdefined("codGrupoActual") AND codGrupoActual IS NOT 0>
					<input type="submit" name="btnDesmatricular" value="Desmatricular" onClick="javascript:setBtn(this)">
				</cfif>
				<input type="hidden" name="calificado"
					value="<cfoutput><cfif isdefined('calificado') AND calificado>1
					<cfelse>0</cfif></cfoutput>">
				</div>
				</td>
			  </tr>
			  </form>				
			  </cfif>
            </table>
          <!-- InstanceEndEditable -->
		  </td>
          <td class="contenido-brborder">&nbsp;</td>
        </tr>
      </table>
	 </td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
