	<cftry>
		<cfquery name="ABC_Nivel" datasource="#Session.DSN#">
			set nocount on		
			<cfif isdefined("Form.btnAgregarAE") and isdefined("form.Ecodigo") AND #form.Ecodigo# NEQ "" >
				insert EncargadoEstudiante (EEcodigo, CEcodigo, Ecodigo)
				values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.EEcodigo#">,
						<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
						<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Ecodigo#">)			

				<cfset action = "alumno.cfm">								
				<cfset modo="CAMBIO">
			</cfif>
			set nocount off
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>


<form action="alumno.cfm" method="post" name="sql">
	<input name="modo" type="hidden" value="<cfif isdefined("modo")><cfoutput>#modo#</cfoutput></cfif>">
	<input name="persona" type="hidden" value="<cfif isdefined("Form.persona")><cfoutput>#Form.persona#</cfoutput></cfif>">
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")><cfoutput>#Form.Pagina#</cfoutput></cfif>">
	<input name="o" type="hidden" value="<cfif isdefined("form.o") and form.o NEQ ""><cfoutput>#form.o#</cfoutput></cfif>">
	<!--- Campos del filtro para la lista de alumnos --->
	<cfif isdefined("Form.fRHnombre")>
		<input type="hidden" name="fRHnombre" value="<cfoutput>#Form.fRHnombre#</cfoutput>">
	</cfif>		   
	<cfif isdefined("Form.FNcodigo")>
		 <input type="hidden" name="FNcodigo" value="<cfoutput>#Form.FNcodigo#</cfoutput>">
	</cfif>		
	<cfif isdefined("Form.filtroRhPid")>
		 <input type="hidden" name="filtroRhPid" value="<cfoutput>#Form.filtroRhPid#</cfoutput>">
	</cfif>		
	<cfif isdefined("Form.FGcodigo")>
		<input type="hidden" name="FGcodigo" value="<cfoutput>#Form.FGcodigo#</cfoutput>">
	</cfif>
	<cfif isdefined("Form.NoMatr")>
		<input type="hidden" name="NoMatr" value="<cfoutput>#Form.NoMatr#</cfoutput>">
	</cfif>		  		  
	<cfif isdefined("Form.FAretirado")>
		<input type="hidden" name="FAretirado" value="<cfoutput>#Form.FAretirado#</cfoutput>">
	</cfif>	
		
</form>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>


