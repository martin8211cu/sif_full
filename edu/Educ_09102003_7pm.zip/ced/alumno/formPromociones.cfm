<!-- Establecimiento del modo -->
<cfif isdefined("Form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("Form.modo")>
		<cfset modo="ALTA">
	<cfelseif Form.modo EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>

<!--- Consultas  --->
	<cfif modo EQ "CAMBIO" >
		<cfquery datasource="#Session.DSN#" name="rsForm">
			Select convert(varchar,PRcodigo) as PRcodigo,convert(varchar,Gcodigo) as Gcodigo,convert(varchar,Ncodigo) as Ncodigo,convert(varchar,PRano) as PRano,convert(varchar,PEcodigo) as PEcodigo,convert(varchar,SPEcodigo) as SPEcodigo,PRdescripcion
			from Promocion
			where PRcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.PRcodigo#">
		</cfquery>	
		<cfquery datasource="#Session.DSN#" name="rsPromo">
			Select count(*) as CantAsoc
			from Promocion a, Alumnos b
			where a.PRcodigo=#rsForm.PRcodigo#
			and a.PRcodigo=b.PRcodigo		
		</cfquery>				
	</cfif>

	<cfquery datasource="#Session.DSN#" name="rsNiveles">
		select convert(varchar, Ncodigo) as Ncodigo, Ndescripcion from Nivel 
		where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
		order by Norden
	</cfquery>	
	
	<cfquery datasource="#Session.DSN#" name="rsSubPerEscolar">
		select (convert(varchar,a.Ncodigo) + '|' + convert(varchar,c.SPEcodigo)) as Cod, a.PEdescripcion + ' : ' + c.SPEdescripcion as SPEdescripcion
		from PeriodoEscolar a, Nivel b, SubPeriodoEscolar c
		where b.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
		and a.Ncodigo=b.Ncodigo
		and a.PEcodigo = c.PEcodigo
		order by b.Norden, a.PEorden, c.SPEorden desc
	</cfquery>
	
	<cfquery datasource="#Session.DSN#" name="rsGrado">
		select convert(varchar, b.Ncodigo)
			   + '|' + convert(varchar, b.Gcodigo) as Codigo, 
			   b.Gdescripcion
		from Nivel a, Grado b
		where a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
		and a.Ncodigo = b.Ncodigo 
		order by a.Norden, b.Gorden
	</cfquery>
	
<!--- Scrips --->	
	<script language="JavaScript" type="text/javascript">
		gradostext = new Array();
		grados = new Array();
		niveles = new Array();
		SubPerEscolarText = new Array();
		SubPerEscolar = new Array();
		nivelesSubPer = new Array();
			
		// Esta funci�n �nicamente debe ejecutarlo una vez
		function obtenerSubPerEscolar(f) {
			for(i=0; i<f.SPEcodigo.length; i++) {
				var Per = f.SPEcodigo.options[i].value.split("|");
				// C�digos de los detalles
				nivelesSubPer[i]= Per[0];
				SubPerEscolar[i] = Per[1];
				SubPerEscolarText[i] = f.SPEcodigo.options[i].text;
			}
		}
		
		function cargarSubPerEscolar(csource, ctarget, vdefault, t){
			// Limpiar Combo
			for (var i=ctarget.length-1; i >=0; i--) {
				ctarget.options[i]=null;
			}
			var k = csource.value;
			var j = 0;

			for (var i=0; i<SubPerEscolar.length; i++) {
				if (nivelesSubPer[i] == k) {
					nuevaOpcion = new Option(SubPerEscolarText[i],SubPerEscolar[i]);
					ctarget.options[j]=nuevaOpcion;
					if (vdefault != null && SubPerEscolar[i] == vdefault) {
						ctarget.selectedIndex = j;
					}
					j++;
				}
			}
		}		

		function obtenerGrados(f) {
			for(i=0; i<f.Gcodigo.length; i++) {
				var s = f.Gcodigo.options[i].value.split("|");
				// C�digos de los detalles
				niveles[i]= s[0];
				grados[i] = s[1];
				gradostext[i] = f.Gcodigo.options[i].text;
			}
		}
		
		function cargarGrados(csource, ctarget, vdefault, t){
			// Limpiar Combo
			for (var i=ctarget.length-1; i >=0; i--) {
				ctarget.options[i]=null;
			}
			var k = csource.value;
			var j = 0;

			for (var i=0; i<grados.length; i++) {
				if (niveles[i] == k) {
					nuevaOpcion = new Option(gradostext[i],grados[i]);
					ctarget.options[j]=nuevaOpcion;
					if (vdefault != null && grados[i] == vdefault) {
						ctarget.selectedIndex = j;
					}
					j++;
				}
			}
		}
	</script>
	
<!--- --------------------------------------------------------- --->	

<form name="formPromociones" method="post" action="SQLPromociones.cfm">
	<input name="PRcodigo" type="hidden" value="<cfif modo EQ "CAMBIO"><cfoutput>#rsForm.PRcodigo#</cfoutput></cfif>">
	<input name="HayDependencias" type="hidden" value="<cfif modo EQ "CAMBIO"><cfoutput>#rsPromo.CantAsoc#</cfoutput><cfelse>0</cfif>">	

	
  <table width="100%" border="0">
    <tr> 
      <td colspan="5" nowrap class="tituloAlterno"> 
        <cfif modo EQ 'CAMBIO'>
          Modificaci&oacute;n de Promoci&oacute;n 
          <cfelse>
          Ingreso de Promoci&oacute;n 
        </cfif>
      </td>
    </tr>
    <tr> 
      <td nowrap>Nivel</td>
      <td nowrap> 
        <select name="Ncodigo" id="Ncodigo" tabindex="5" onChange="javascript: cargarSubPerEscolar(this, this.form.SPEcodigo, '<cfif isdefined("Form.SPEcodigo")><cfoutput>#Form.SPEcodigo#</cfoutput></cfif>', true); cargarGrados(this, this.form.Gcodigo, '<cfif isdefined("Form.Gcodigo")><cfoutput>#Form.Gcodigo#</cfoutput></cfif>', true); ">
          <cfoutput query="rsNiveles"> 
            <option value="#Ncodigo#" <cfif modo EQ "CAMBIO" and (rsForm.Ncodigo EQ rsNiveles.Ncodigo)>selected</cfif>>#Ndescripcion#</option>
          </cfoutput> 
        </select>
      </td>
      <td nowrap>A&ntilde;o*</td>
      <td nowrap> 
        <input name="PRano" type="text" id="PRano" tabindex="3" size="6" maxlength="4" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.PRano#</cfoutput></cfif>" style="text-align: right;" onBlur="javascript:fm(this,-1) "  onFocus="javascript:this.value=qf(this); this.select();"  onKeyUp="javascript:if(snumber(this,event,-1)){ if(Key(event)=='13') {this.blur();}}">
	  </td>
      <td width="23%" rowspan="3" align="center" valign="middle" nowrap> 
        <cfif modo EQ 'ALTA'>
          <input type="reset"  name="btnLimpiar"  value="Limpiar" >
          <input name="btnAgregar" type="submit" id="btnAgregar" onClick="javascript: setBtn(this);" value="Agregar" >
          <input name="btnBuscar" type="submit" id="btnBuscar" value="Buscar" onClick="javascript: setBtn(this); deshabilitarValidacion()">
          <cfelse>
          <!-- Cambio -->
          <input type="submit" name="btnCambiar" id="btnCambiar"  value="Cambiar" onClick="javascript: setBtn(this); habilitarValidacion()" >
          <input type="submit" name="btnBorrar"   id="btnBorrar" value="Borrar" onClick="javascript: setBtn(this); habilitarValidacion(); return confirm('Esta seguro(a) que desea borrar esta promoci�n?')">
          <input name="btnNuevo" type="submit" id="btnNuevo" value="Nueva Promoci&oacute;n" onClick="javascript: setBtn(this); deshabilitarValidacion();">
        </cfif>
      </td>
    </tr>
    <tr> 
      <td width="18%" nowrap>Curso lectivo</td>
      <td width="15%" nowrap> 
        <select name="SPEcodigo" id="SPEcodigo">
          <cfoutput query="rsSubPerEscolar"> 
            <option value="#Cod#">#SPEdescripcion#</option>
          </cfoutput> 
        </select>
      </td>
      <td width="6%" nowrap>Grado</td>
      <td width="38%" nowrap> 
        <select name="Gcodigo" id="select2" tabindex="5">
          <cfoutput query="rsGrado"> 
            <option value="#Codigo#">#Gdescripcion#</option>
          </cfoutput> 
        </select>
      </td>
    </tr>
    <tr> 
      <td nowrap>Descripci&oacute;n*</td>
      <td colspan="3" nowrap> 
        <input name="PRdescripcion" type="text" id="PRdescripcion" value="<cfif modo EQ "CAMBIO"><cfoutput>#rsForm.PRdescripcion#</cfoutput></cfif>" size="80" maxlength="80">
      </td>
    </tr>
    <cfif modo EQ 'ALTA'>
      <tr> 
        <td colspan="5" align="center" nowrap class="subTitulo"> 
          Nota: Las b&uacute;squedas funcionan para campos con un (*) </td>
      </tr>
    </cfif>
  </table>
</form>

<script language="JavaScript" type="text/javascript" src="../../js/utilesMonto.js">//</script>
<script language="JavaScript" src="../../js/qForms/qforms.js">//</script>
<script language="JavaScript" type="text/JavaScript">
	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
</script> 


<script language="JavaScript" type="text/javascript" >
//------------------------------------------------------------------------------------------						
	//Para los tipos de cursos lectivos
	obtenerSubPerEscolar(document.formPromociones);
	cargarSubPerEscolar(document.formPromociones.Ncodigo, document.formPromociones.SPEcodigo, '<cfif modo EQ "CAMBIO"><cfoutput>#rsForm.SPEcodigo#</cfoutput></cfif>', true);	
	
	//Para los grados
	obtenerGrados(document.formPromociones);
	cargarGrados(document.formPromociones.Ncodigo, document.formPromociones.Gcodigo, '<cfif modo EQ "CAMBIO"><cfoutput>#rsForm.Gcodigo#</cfoutput></cfif>', true);
//------------------------------------------------------------------------------------------						
	function deshabilitarValidacion() {
		objForm.PRano.required = false;
		objForm.Ncodigo.required = false;	
		objForm.Gcodigo.required = false;
		objForm.SPEcodigo.required = false;
	}
	
//------------------------------------------------------------------------------------------						
	function habilitarValidacion() {
		objForm.PRano.required = true;
		objForm.Ncodigo.required = true;	
		objForm.Gcodigo.required = true;
		objForm.SPEcodigo.required = true;
	}	
//------------------------------------------------------------------------------------------							
	function __isTieneDependencias() {
		if (btnSelected("btnBorrar")) {
			// Valida que el Grado no tenga dependencias con otros.
			var msg = "";
			//alert(new Number(this.obj.form.HayHorarioGuia.value)); 
			if (new Number(this.obj.form.HayDependencias.value) > 0) {
				msg = msg + this.obj.form.HayDependencias.value + " alumno (s)"
			}
			if (msg != ""){
				this.error = "Usted no puede eliminar la promoci�n '" + this.obj.form.PRdescripcion.value + "' porque �sta tiene asociado (s): " + msg + ", si todav�a desea borrarla, borre primero las asociaciones";
				this.obj.form.PRdescripcion.focus();
			}
		}
	}	
//------------------------------------------------------------------------------------------						
	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isTieneDependencias", __isTieneDependencias);
	objForm = new qForm("formPromociones");	
//------------------------------------------------------------------------------------------					
	objForm.PRano.required = true;
	objForm.PRano.description = "a�o";
	objForm.Gcodigo.required = true;
	objForm.Gcodigo.description = "grado";	
	objForm.Ncodigo.required = true;
	objForm.Ncodigo.description = "nivel";	
	objForm.SPEcodigo.required = true;
	objForm.SPEcodigo.description = "Curso lectivo";		
	objForm.PRcodigo.validateTieneDependencias();
	
</script>
