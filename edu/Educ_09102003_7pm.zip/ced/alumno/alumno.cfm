<cfinclude template="../../Utiles/general.cfm">
<html><!-- InstanceBegin template="/Templates/LMenuAlum.dwt.cfm" codeOutsideHTMLIsLocked="false" -->
<head>
<title>Educaci&oacute;n</title>
<meta http-equiv="Expires" content="Fri, Jan 01 1970 08:20:00 GMT">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Pragma" content="no-cache">
<!-- InstanceBeginEditable name="head" -->
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
</script>
  <script language="JavaScript" type="text/javascript">
		function switchPages() {
			var DataPage = document.getElementById("TRDatosEmp");
			var ListPage = document.getElementById("TRBuscarEmp");
			if (DataPage.style.display == "") {
				DataPage.style.display = "none";
				ListPage.style.display = "";
			} else {
				DataPage.style.display = "";
				ListPage.style.display = "none";
			}
		}
  </script>
  <link id="webfx-tab-style-sheet" type="text/css" rel="stylesheet" href="../css/tab.webfx.css"/>
  <script type="text/javascript" src="../../js/tabpane/tabpane.js"></script>
<!-- InstanceEndEditable -->
<link href="../../css/portlets.css" rel="stylesheet" type="text/css">
<link href="../../css/edu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
<script language="JavaScript" src="../../js/DHTMLMenu/stm31.js"></script>
<script language="JavaScript" type="text/javascript">
	// Funciones para Manejo de Botones
	botonActual = "";

	function setBtn(obj) {
		botonActual = obj.name;
	}
	function btnSelected(name, f) {
		if (f != null) {
			return (f["botonSel"].value == name)
		} else {
			return (botonActual == name)
		}
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="154" rowspan="2" align="center" valign="top"><img src="../../Imagenes/logo.gif" width="154" height="62"></td>
    <td valign="bottom"> 
	  <!-- InstanceBeginEditable name="Ubica" --> 
      <cfinclude template="../../portlets/pubica.cfm">
      <!-- InstanceEndEditable --> </td>
  </tr>
  <tr> 
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr class="area"> 
          <td width="275" valign="middle">
		  	<cfset RolActual = 4>
			<cfset Session.RolActual = 4>
			<cfinclude template="../../portlets/pEmpresas2.cfm">
		  </td>
          <td nowrap> 
            <div align="center"><span class="superTitulo">
			<font size="5">
	  <!-- InstanceBeginEditable name="Titulo" --> 
	  					 Administraci&oacute;n del Centro de Estudio
      <!-- InstanceEndEditable -->	
			</font></span></div></td>
        </tr>
        <tr class="area" style="padding-bottom: 3px;"> 
		  <td nowrap style="padding-left: 10px;">
		  <cfinclude template="../../portlets/pminisitio.cfm">
		  </td>
          <td valign="top" nowrap> 
	  <!-- InstanceBeginEditable name="MenuJS" --> 
	  	<cfinclude template="../jsMenuCED.cfm">
      <!-- InstanceEndEditable -->	
		  </td>
        </tr>
      </table>
	</td>
  </tr>
</table>
  
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="left" valign="top" nowrap></td>
    <td width="100%" height="1" align="left" valign="top">
	<!-- InstanceBeginEditable name="Titulo2" --><!-- InstanceEndEditable -->
	</td>
  </tr>
  <tr> 
    <td valign="top" nowrap>
		<cfinclude template="/sif/menu.cfm"> 
	</td>
    <td valign="top" width="100%">
	  <!-- InstanceBeginEditable name="Mantenimiento2" -->
			<cfif isdefined("Url.persona") and not isdefined("Form.persona")>
				<cfparam name="Form.persona" default="#Url.persona#">
			</cfif> 
			<cfif isdefined("Url.o") and not isdefined("Form.o")> 
				<cfparam name="Form.o" default="#Url.o#">
			</cfif> 
			<cfif isdefined("form.persona")>
				<cfparam name="Form.persona" default="#form.persona#">
			</cfif> 

		
			<cfif isdefined("Url.fRHnombre") and not isdefined("Form.fRHnombre")>
				<cfparam name="Form.fRHnombre" default="#Url.fRHnombre#">
			</cfif> 
			<cfif isdefined("Url.filtroRhPid") and not isdefined("Form.filtroRhPid")>
				<cfparam name="Form.filtroRhPid" default="#Url.filtroRhPid#">
			</cfif> 
			<cfif isdefined("Url.FAretirado") and not isdefined("Form.FAretirado")>
				<cfparam name="Form.FAretirado" default="#Url.FAretirado#">
			</cfif> 
			<cfif isdefined("Url.NoMatr") and not isdefined("Form.NoMatr")>
				<cfparam name="Form.NoMatr" default="#Url.NoMatr#">
			</cfif> 
			<cfif isdefined("Url.FNcodigo") and not isdefined("Form.FNcodigo")>
				<cfparam name="Form.FNcodigo" default="#Url.FNcodigo#">
			</cfif> 
			<cfif isdefined("Url.FGcodigo") and not isdefined("Form.FGcodigo")>
				<cfparam name="Form.FGcodigo" default="#Url.FGcodigo#">
			</cfif> 

			<!--- Campos del filtro para la lista de alumnos --->
			<cfif isdefined("Form.fRHnombre")>
				<input type="hidden" name="fRHnombre" value="<cfoutput>#Form.fRHnombre#</cfoutput>">
			</cfif>		   
			<cfif isdefined("Form.FNcodigo")>
				 <input type="hidden" name="FNcodigo" value="<cfoutput>#Form.FNcodigo#</cfoutput>">
			</cfif>		
			<cfif isdefined("Form.filtroRhPid")>
				 <input type="hidden" name="filtroRhPid" value="<cfoutput>#Form.filtroRhPid#</cfoutput>">
			</cfif>		
			<cfif isdefined("Form.FGcodigo")>
				<input type="hidden" name="FGcodigo" value="<cfoutput>#Form.FGcodigo#</cfoutput>">
			</cfif>
			<cfif isdefined("Form.NoMatr")>
				<input type="hidden" name="NoMatr" value="<cfoutput>#Form.NoMatr#</cfoutput>">
			</cfif>		  		  
			<cfif isdefined("Form.FAretirado")>
				<input type="hidden" name="FAretirado" value="<cfoutput>#Form.FAretirado#</cfoutput>">
			</cfif>			

			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td>
						<form name="regAlum" action="alumno.cfm" method="post">
							<cfoutput>
				  				<input type="hidden" name="persona" value="<cfif isdefined("Form.persona")>#Form.persona#</cfif>">
								<input type="hidden" name="o" value="<cfif isdefined("Form.o")>#Form.o#</cfif>">

							</cfoutput>
						</form>
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<form name="formBuscar" method="post" action="">
								<tr>
									<td align="right" valign="middle">
										<a href="javascript: switchPages();">
										Seleccionar Alumno: <img src="../../Imagenes/find.small.png" name="imageBusca" id="imageBusca" border="0">
										</a>
									</td>
								</tr>
							</form>
						</table>
					</td>
				</tr>
				<tr id="TRDatosEmp">
					<td >
						<cfinclude template="frame-header.cfm">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<cfif isDefined("Form.persona") >
								<cfoutput>
								<form name="Regresar" method="post" action="alumno.cfm"> 
									<input type="hidden" name="persona" value="#Form.persona#">
									<input type="hidden" name="o" value="<cfif isdefined("Form.o")>#Form.o#</cfif>">
								</form>
								</cfoutput>
								<cfset regresar = "javascript: document.Regresar.submit();">
							</cfif>
							<tr>
								<td class="tabContent">
									<cfif tabChoice eq 1>
										<cfinclude template="formAlumno.cfm">
									<cfelseif tabChoice eq 2>
										<cfinclude template="formDatMed.cfm"> 
									<cfelseif tabChoice eq 3>
										<cfinclude template="formEncarg.cfm">
									<cfelseif tabChoice eq 4>
										<cfinclude template="formfactConAl.cfm"> 
									<cfelse>
										<div align="center">
										<b>Este m&oacute;dulo no est&aacute; disponible, por favor seleccione un alumno.</b>
										</div>
									</cfif>
								</td>
							</tr>
						</table>
						
					</td>
				</tr>
				<tr id="TRBuscarEmp" style="display: none">
					<td>
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr valign="top">
								<td colspan="3" >
									<cfinclude template="../../portlets/pNavegacionCED.cfm">
								</td>
							</tr>
							<tr valign="top"> 
								<td>&nbsp;</td>
							</tr>
							<tr valign="top"> 
								<td align="center">
									<cfinclude template="filtros/filtroAlumnoh.cfm"> 
										<!--- <cfif isdefined("form.btnFiltrar")> --->
											<cfinclude template="ListaAlumno.cfm">
										<!--- </cfif> --->
								</td>
							</tr>
							<tr valign="top"> 
								 <td >&nbsp;</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>



			<cfif isdefined("form.Busca") or isdefined("form.BtnFiltrar2") or isdefined("Url.filtroAlumno")>
				<script language="JavaScript" type="text/javascript">
					switchPages();
				</script>
			</cfif>
			<!-- InstanceEndEditable -->
	 </td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
