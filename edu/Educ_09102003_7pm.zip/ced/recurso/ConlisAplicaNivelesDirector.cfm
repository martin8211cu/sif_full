<cfinclude template="/edu/Utiles/general.cfm">
<html>
<head>
<title>Aplicaci�n de Niveles del Director </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../../css/portlets.css" rel="stylesheet" type="text/css">
<link href="../../css/edu.css" rel="stylesheet" type="text/css">
</head>
<body>

<cfif isdefined("Url.Dcodigo") and not isdefined("Form.Dcodigo")>
	<cfparam name="Form.Dcodigo" default="#Url.Dcodigo#">
<cfelse>
	
</cfif>

<cfif isdefined("Form.btnAplicar")>
	 <cfquery name="rsDelete" datasource="#Session.DSN#">
		set nocount on
		delete DirectorNivel 
		where Dcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Dcodigo#">
		  and Ncodigo in (#form.Cual_Nivel#)  
		set nocount off
	</cfquery> 
	<cfif isdefined("Form.Chk")>
		<cfset a=ListToArray(Form.Chk,',')>
		<cfloop index="i" from="1" to="#ArrayLen(a)#">
			<cfset b = ListToArray(a[i],'|')>
			 <!--- <cfset Dcodigo = b[0]> --->
			<cfset Ncodigo = b[1]>
			<cfquery name="ABC_NivelAplica" datasource="#Session.DSN#">
				set nocount on
				insert DirectorNivel (Dcodigo, Ncodigo)
				values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Dcodigo#">,
						<cfqueryparam cfsqltype="cf_sql_numeric" value="#Ncodigo#">
							)
				set nocount off
			</cfquery>
		</cfloop>
	</cfif>	
	<script language="JavaScript">
		window.close();
	</script>
</cfif>
     <table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <tr> 
    <td align="center"> 
     <!---  <form name="filtros" action="ConlisAplicaNivelesDirector.cfm" method="post">
	  	<p class="tituloAlterno"><!--- &nbsp; Horario: <cfoutput>#rsHorario.Hnombre#</cfoutput></p>
        <table width="100%" border="0" cellspacing="0" cellpadding="0" class="areaFiltro">
          <tr> 
            <td width="30%" align="right" style="padding-right: 10 px;"><strong>Grados</strong></td>
            <td width="30%"> 
              <cfquery datasource="#Session.DSN#" name="rsGrado">
              select convert(varchar, b.Dcodigo) as Codigo, b.Gdescripcion from 
              Nivel a, Grado b where a.CEcodigo = 
              <cfqueryparam cfsqltype="cf_sql_integer" value="#Session.CEcodigo#">
              and a.Ncodigo = b.Ncodigo order by a.Norden, b.Gorden 
              </cfquery>
              <select name="Dcodigo" id="Dcodigo" tabindex="1" >
                <option value="-1">Todos</option>
                <cfoutput query="rsGrado"> 
                  <option value="#Codigo#">#rsGrado.Gdescripcion#</option>
                </cfoutput> 
              </select>
            </td>
            <td width="40%"> 
              <input name="Filtrar" type="submit" value="Filtrar">
              <input name="Limpiar" type="button" value="Limpiar" onClick="javascript: LimpiarFiltros(this.form); ">
              <input name="Dcodigo" type="hidden" id="Dcodigo" value="<cfif isdefined("Form.Dcodigo")><cfoutput>#Form.Dcodigo#</cfoutput></cfif>">
            </td>
          </tr>
        </table> --->
        </form> --->
		</td>
              </tr>
		<form name="lista" method="post" action="ConlisAplicaNivelesDirector.cfm">
              <tr> 
                <td><strong> &nbsp;&nbsp;&nbsp; 
                  <input name="chkTodos" type="checkbox" value="" border="1" onClick="javascript:Marcar(this);">
                  Seleccionar Todos</strong></td>
              </tr>
              <tr> 
                <td>
					
					<input type="hidden" name="Dcodigo" value="<cfif isdefined("Form.Dcodigo")><cfoutput>#Form.Dcodigo#</cfoutput></cfif>">
					<input name="Cual_Nivel" type="hidden" id="Cual_Nivel" value="">
					<cfif isdefined("Form.Pagina") and Form.Pagina NEQ "">
                    	<cfset Pagenum_lista = #Form.Pagina#>
                  	</cfif> 
					<cfset filtro = "">
					<!--- <cfif isdefined("Form.Dcodigo") and (Len(Trim(Form.Gcodigo)) NEQ 0) and (Form.Gcodigo NEQ "-1")>
							<cfset filtro = "and b.Gcodigo = "  & #Trim(Form.Gcodigo)# >
					</cfif> --->

					 <cfinvoke 
						 component="edu.Componentes.pListas"
						 method="pListaEdu"
						 returnvariable="pListaRet">
					<cfinvokeargument name="tabla" value="Nivel a, DirectorNivel b, Director d"/>
						<cfinvokeargument name="columnas" value="convert(varchar, b.Dcodigo) as Dcodigo, convert(varchar, a.Ncodigo) as Ncodigo, substring(a.Ndescripcion,1,50) as Ndescripcion, convert(varchar, b.Ncodigo) as checked"/>
						<cfinvokeargument name="desplegar" value="Ndescripcion"/>
						<cfinvokeargument name="etiquetas" value="Descripci�n del Nivel"/>
						<cfinvokeargument name="formatos" value=""/>
						<cfinvokeargument name="filtro" value=" a.CEcodigo = #Session.CEcodigo# and b.Dcodigo = #Form.Dcodigo#  and b.Ncodigo =* a.Ncodigo 
																and d.Dcodigo =* b.Dcodigo order by a.Norden"/>
						<cfinvokeargument name="align" value="left"/>
						<cfinvokeargument name="ajustar" value="N"/>
						<cfinvokeargument name="irA" value="ConlisAplicaNivelesDirector.cfm"/>
						<cfinvokeargument name="checkboxes" value="S"/>
						<cfinvokeargument name="debug" value="N"/>
						<cfinvokeargument name="maxrows" value="10"/>
						<cfinvokeargument name="incluyeForm" value="false"/>
						<cfinvokeargument name="formName" value="lista"/>
						<cfinvokeargument name="keys" value="Ncodigo "/>
						<cfinvokeargument name="checkedcol" value="checked"/>
						<cfinvokeargument name="botones" value="Aplicar"/>
					</cfinvoke>
					
						 <script language="JavaScript">
						 	if (document.lista.chk != null) {
								if (document.lista.chk.value != null) {
									if (document.lista.chk.checked) document.lista.chk.checked = true; else document.lista.chk.checked = false;
										var a = document.lista.chk.value.split("|");
										var Ncodigo = a[0];
										//alert(a);
										document.lista.Cual_Nivel.value += Ncodigo ;
								} else {
									for (var counter = 0; counter < document.lista.chk.length; counter++) {
										var a = document.lista.chk[counter].value.split("|");
										var Ncodigo = a[0];
										//alert(a);
										document.lista.Cual_Nivel.value += Ncodigo + ",";
									}
									if (document.lista.Cual_Nivel.value != "") {
										document.lista.Cual_Nivel.value = document.lista.Cual_Nivel.value.substring(0,document.lista.Cual_Nivel.value.length-1);
									}
								}
							}
						</script>
						<!---  <input name="Limpiar" type="button" value="Limpiar" onClick="javascript: Limpiar(this); "> --->
					</form>
				 </td>
              </tr>
            </table>
	  <script language="JavaScript1.2">
		function Marcar(c) {
			if (document.lista.chk != null) { //existe?
				if (document.lista.chk.value != null) {// solo un check
					if (c.checked) document.lista.chk.checked = true; else document.lista.chk.checked = false;
				}
				else {
					if (c.checked) {
						for (var counter = 0; counter < document.lista.chk.length; counter++)
						{
							if ((!document.lista.chk[counter].checked) && (!document.lista.chk[counter].disabled))
								{  document.lista.chk[counter].checked = true;}
						}
						if ((counter==0)  && (!document.lista.chk.disabled)) {
							document.lista.chk.checked = true;
						}
					}
					else {
						for (var counter = 0; counter < document.lista.chk.length; counter++)
						{
							if ((document.lista.chk[counter].checked) && (!document.lista.chk[counter].disabled))
								{  document.lista.chk[counter].checked = false;}
						};
						if ((counter==0) && (!document.lista.chk.disabled)) {
							document.lista.chk.checked = false;
						}
					};
				}
			}
		}
	  </script>

</body>
</html>