<cfparam name="action" default="rh.cfm">
<cftransaction>
<cfif isdefined("form.btnAgregar") or isdefined("form.btnCambiar") or isdefined("form.btnBorrar") or isdefined("form.btnAgregarEncar")>
	<cfset tmp = "" >		<!--- contenido binario de la imagen --->
	<cfset ts = "null">
	<cfif isdefined("Form.Pfoto") and form.Pfoto NEQ "">
		<cftry>
			<!--- Seccion del Upload= Copia la imagen a un folder del servidor servidor --->
			<cffile action="Upload" fileField="form.Pfoto" destination="#GetTempDirectory()#" nameConflict="Overwrite" accept="image/*"> 
			<!--- lee la imagen de la carpeta del servidor y la almacena en la variable tmp --->
			<cffile action="readbinary"  file="#GetTempDirectory()##cffile.ClientFileName#.#cffile.ClientFileExt#" variable="tmp" > 
	
			<cffile action="delete" file="#GetTempDirectory()##cffile.ClientFileName#.#cffile.ClientFileExt#">
		
			<!--- Formato para sybase --->
			<cfset Hex=ListtoArray("0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F")>
	
			<cfif not isArray(tmp)>
				<cfset ts = "">
			</cfif>
			<cfset miarreglo=#ListtoArray(ArraytoList(#tmp#,","),",")#>
			<cfset miarreglo2=ArrayNew(1)>
			<cfset temp=ArraySet(miarreglo2,1,8,"")>
	
			<cfloop index="i" from="1" to=#ArrayLen(miarreglo)#>
				<cfif miarreglo[i] LT 0>
					<cfset miarreglo[i]=miarreglo[i]+256>
				</cfif>
			</cfloop>
	
			<cfloop index="i" from="1" to=#ArrayLen(miarreglo)#>
				<cfif miarreglo[i] LT 10>
					<cfset miarreglo2[i] = "0" & #toString(Hex[(miarreglo[i] MOD 16)+1])#>
				<cfelse>
					<cfset miarreglo2[i] = #trim(toString(Hex[(miarreglo[i] \ 16)+1]))# & #trim(toString(Hex[(miarreglo[i] MOD 16)+1]))#>
				</cfif>
			</cfloop>
			<cfset temp = #ArrayPrepend(miarreglo2,"0x")#>
			<cfset ts = #ArraytoList(miarreglo2,"")#>
		<cfcatch type="any">
			<cfinclude template="/edu/errorPages/BDerror.cfm">
			<cfabort>
		</cfcatch>
		</cftry>		
	</cfif>

	<cftry>
		<!--- Caso 1: Agregar --->
		<cfif isdefined("Form.btnAgregar")>
			<cfquery name="ABC_RH" datasource="#Session.DSN#">
				insert PersonaEducativo (CEcodigo, Pnombre, Papellido1, Papellido2, Ppais, TIcodigo, Pid, Pnacimiento, Psexo, Pemail1, Pemail2, Pdireccion, Pcasa, Poficina, Pcelular, Pfax, Ppagertel, Ppagernum, Pfoto, Pemail1validado)
				values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pnombre#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Papellido1#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Papellido2#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppais#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.TIcodigo#">,							
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pid#">,
						convert( datetime, <cfqueryparam value="#form.Pnacimiento#" cfsqltype="cf_sql_varchar">, 103 ),
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Psexo#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pemail1#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pemail2#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pdireccion#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pcasa#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Poficina#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pcelular#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pfax#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppagertel#">,
						<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppagernum#">,
						#ts#,0)							

				select @@identity as id
			</cfquery>

			<cfset form.fRHnombre = "#form.Pnombre#" & ' ' & "#form.Papellido1#" & ' ' & "#form.Papellido2#">
			<cfset action = "rh.cfm">
			<cfset modo="CAMBIO">
			
		<!--- Caso 2: Cambio --->
		<cfelseif isdefined("Form.btnCambiar") and isdefined("form.persona") and form.persona NEQ "">
			<cfquery name="ABC_RH" datasource="#Session.DSN#">
				update PersonaEducativo set
					CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
					Pnombre=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pnombre#">,
					Papellido1=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Papellido1#">,
					Papellido2=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Papellido2#">,
					Ppais=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppais#">,
					TIcodigo=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.TIcodigo#">,
					Pid=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pid#">,
					Pnacimiento=convert( datetime, <cfqueryparam value="#form.Pnacimiento#" cfsqltype="cf_sql_varchar">, 103 ),
					Psexo=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Psexo#">,
					Pemail1=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pemail1#">,
					Pemail2=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pemail2#">,
					Pdireccion=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pdireccion#">,
					Pcasa=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pcasa#">,
					Poficina=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Poficina#">,
					Pcelular=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pcelular#">,
					Pfax=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Pfax#">,
					Ppagertel=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppagertel#">,
					Ppagernum=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.Ppagernum#">,
					<cfif isdefined("Form.Pfoto") and form.Pfoto NEQ "">
						Pfoto=#ts#,					
					</cfif>
					Pemail1validado=0
				where persona= <cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">
			</cfquery>
			
			<cfset action = "rh.cfm">								
			<cfset modo="CAMBIO">
									
		<!--- Caso 3: Borrar --->
		<cfelseif isdefined("Form.btnBorrar")>			
			<cfif isdefined("Form.persona") AND Form.persona NEQ "">
				<!--- Query para obtener la referencia que se puede utilizar para borrar un Usuario del Framework --->
				<cfquery name="refUser" datasource="#Session.DSN#">
					select convert(varchar, Acodigo) as num_referencia, 'edu.asistente' as rol
					from Asistente
					where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
					union
					select convert(varchar, Splaza) as num_referencia, 'edu.docente' as rol
					from Staff
					where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
					union
					select convert(varchar, Dcodigo) as num_referencia, 'edu.director' as rol
					from Director
					where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
					union
					select convert(varchar, EEcodigo) as num_referencia, 'edu.encargado' as rol
					from Encargado
					where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
				</cfquery>
				
				<cfinvoke 
				 component="edu.Componentes.usuarios"
				 method="del_usuario_by_ref"
				 returnvariable="UsrDeleted">
					<cfinvokeargument name="consecutivo" value="#Session.CEcodigo#"/>
					<cfinvokeargument name="sistema" value="edu"/>
					<cfinvokeargument name="referencia" value="#refUser.num_referencia#"/>
					<cfinvokeargument name="rol" value="#refUser.rol#"/>
				</cfinvoke>
				
				<cfquery name="ABC_RH" datasource="#Session.DSN#">
					delete Asistente 
					where persona = <cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">					
					
					delete Staff 
					where persona = <cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">					

					delete DirectorNivel
					from DirectorNivel a, Director b 
					where b.persona = <cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">
					and a.Dcodigo = b.Dcodigo

					delete Director 
					where persona = <cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">					

					<!--- se borra como encargado de todas las relaciones de encargados por estudiante --->
					delete EncargadoEstudiante
					where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
					and EEcodigo in (Select EEcodigo from Encargado where persona=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">) 

					<!--- Borrado de Encargado --->
					delete Encargado 
					where persona=<cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">										
					
					<!--- Borrado de la persona --->					
					delete PersonaEducativo 
					where persona=<cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">
				</cfquery>

				<cfset modo="ALTA">
				<cfset form.fRHnombre = "">
			</cfif>								
		</cfif>

	<cfcatch type="any">
		<cfinclude template="/edu/errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>
			
<cfelse> 
	<cfset action = "rh.cfm" >
	<cfset modo   = "ALTA" >
</cfif>

<cfif isdefined("form.btnAgregar") or isdefined("form.btnCambiar")>
	<cfset referencias = "">
	<cfset roles = "">
	<cfset activacion = "">
	
	<!--- Modo ALTA --->
	<cfif isdefined("form.persona") AND form.persona EQ "">
		<cfset form.persona = ABC_RH.id>
		
		<cfif form.persona NEQ "" and (isdefined("form.Splaza") or isdefined("form.Acodigo") or isdefined("form.EEcodigo") or isdefined("form.Dcodigo"))>
			<!--- Control de tablas Director - Asistente - Staff - Encargado --->
			<cftry>
				<cfif isdefined("form.Splaza") >			<!--- ALTA de Staff --->
					<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
						insert Staff 
						(CEcodigo, persona, autorizado)
						values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
								<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">, 
								<cfif isdefined("form.autorizadodoc")>
									1
								<cfelse>
									0
								</cfif>)

						select convert(varchar, @@identity) as id
					</cfquery>
					<cfset referencias = referencias & Iif(referencias NEQ "",DE(","),DE("")) & ABC_Relaciones.id>
					<cfset roles = roles & Iif(roles NEQ "",DE(","),DE("")) & "edu.docente">
					<cfif isdefined("form.autorizadodoc")>
						<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "1">
					<cfelse>
						<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "0">
					</cfif>
				</cfif>
					
				<cfif isdefined("form.Acodigo") >			<!--- ALTA de Asistente --->
					<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
						insert Asistente 
						(CEcodigo, persona, autorizado)
						values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
								<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">,
								<cfif isdefined("form.autorizadoast")>
									1
								<cfelse>
									0
								</cfif>)

						select convert(varchar, @@identity) as id
					</cfquery>
					<cfset referencias = referencias & Iif(referencias NEQ "",DE(","),DE("")) & ABC_Relaciones.id>
					<cfset roles = roles & Iif(roles NEQ "",DE(","),DE("")) & "edu.asistente">
					<cfif isdefined("form.autorizadoast")>
						<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "1">
					<cfelse>
						<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "0">
					</cfif>
				</cfif>
					
				<cfif isdefined("form.EEcodigo") >			 <!--- ALTA de Encargado --->
					<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
						insert Encargado (persona, autorizado)
						values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">,
								<cfif isdefined("form.autorizadoenc")>
									1
								<cfelse>
									0
								</cfif>)					

						select convert(varchar, @@identity) as id
					</cfquery>
					<cfset referencias = referencias & Iif(referencias NEQ "",DE(","),DE("")) & ABC_Relaciones.id>
					<cfset roles = roles & Iif(roles NEQ "",DE(","),DE("")) & "edu.encargado">
					<cfif isdefined("form.autorizadoenc")>
						<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "1">
					<cfelse>
						<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "0">
					</cfif>
				</cfif>					
					
				<cfif isdefined("form.Dcodigo") >			<!--- ALTA de Director	---> 
					<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
						set nocount on
						declare @director numeric
						insert Director	(persona, Ncodigo, autorizado)
						values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">,
								<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Ncodigo#">,
								<cfif isdefined("form.autorizadodir")>
									1
								<cfelse>
									0
								</cfif>)
						select @director = @@identity

						insert DirectorNivel(Dcodigo, Ncodigo)
						values (@director, <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Ncodigo#">)

						select convert(varchar, @director) as id
						set nocount off
					</cfquery>
					<cfset referencias = referencias & Iif(referencias NEQ "",DE(","),DE("")) & ABC_Relaciones.id>
					<cfset roles = roles & Iif(roles NEQ "",DE(","),DE("")) & "edu.director">
					<cfif isdefined("form.autorizadodir")>
						<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "1">
					<cfelse>
						<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "0">
					</cfif>
				</cfif>
				
				<!--- Insercion del Usuario en el Framework --->
				<cfinvoke 
				 component="edu.Componentes.usuarios"
				 method="upd_usuario"
				 returnvariable="UsrInserted">
					<cfinvokeargument name="consecutivo" value="#Session.CEcodigo#"/>
					<cfinvokeargument name="sistema" value="edu"/>
					<cfinvokeargument name="referencias" value="#referencias#"/>
					<cfinvokeargument name="roles" value="#roles#"/>
					<cfinvokeargument name="activacion" value="#activacion#"/>
					<cfinvokeargument name="Pnombre" value="#form.Pnombre#"/>
					<cfinvokeargument name="Papellido1" value="#form.Papellido1#"/>
					<cfinvokeargument name="Papellido2" value="#form.Papellido2#"/>
					<cfinvokeargument name="Ppais" value="#form.Ppais#"/>
					<cfinvokeargument name="TIcodigo" value="#form.TIcodigo#"/>
					<cfinvokeargument name="Pid" value="#form.Pid#"/>
					<cfinvokeargument name="Pnacimiento" value="#form.Pnacimiento#"/>
					<cfinvokeargument name="Psexo" value="#form.Psexo#"/>
					<cfinvokeargument name="Pemail1" value="#form.Pemail1#"/>
					<cfinvokeargument name="Pemail2" value="#form.Pemail2#"/>
					<cfinvokeargument name="Pdireccion" value="#form.Pdireccion#"/>
					<cfinvokeargument name="Pcasa" value="#form.Pcasa#"/>
					<cfinvokeargument name="Poficina" value="#form.Poficina#"/>
					<cfinvokeargument name="Pcelular" value="#form.Pcelular#"/>
					<cfinvokeargument name="Pfax" value="#form.Pfax#"/>
					<cfinvokeargument name="Ppagertel" value="#form.Ppagertel#"/>
					<cfinvokeargument name="Ppagernum" value="#form.Ppagernum#"/>
					<cfif isdefined("Form.Pfoto") and form.Pfoto NEQ "">
						<cfinvokeargument name="Pfoto" value="#ts#"/>
					</cfif>
				</cfinvoke>
				
			<cfcatch type="any">
				<cfinclude template="/edu/errorPages/BDerror.cfm">
				<cfabort>
			</cfcatch>
			</cftry>
		</cfif>
	<cfelse>
		<!--- Control de tablas Director - Asistente - Staff - Encargado --->
		<cftry>
			<!--- Query para obtener la referencia que se puede utilizar para borrar un Usuario del Framework --->
			<cfquery name="refUser" datasource="#Session.DSN#">
				select convert(varchar, Acodigo) as num_referencia, 'edu.asistente' as rol
				from Asistente
				where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
				union
				select convert(varchar, Splaza) as num_referencia, 'edu.docente' as rol
				from Staff
				where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
				union
				select convert(varchar, Dcodigo) as num_referencia, 'edu.director' as rol
				from Director
				where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
				union
				select convert(varchar, EEcodigo) as num_referencia, 'edu.encargado' as rol
				from Encargado
				where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
			</cfquery>
			<cfset upd_referencia = refUser.num_referencia>
			<cfset upd_rol = refUser.rol>
			<cfset dominio_roles = "edu.asistente, edu.encargado, edu.director, edu.docente">

			<cfif isdefined("form.Splaza")>
				<cfif form.Splaza NEQ "">			<!--- CAMBIO de Staff --->
					<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
						update Staff 
						   set persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">,
						       autorizado = <cfif isdefined("form.autorizadodoc")>1<cfelse>0</cfif>
						where Splaza = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Splaza#">

						select convert(varchar, <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Splaza#">) as id
					</cfquery>
				<cfelse>							<!--- ALTA de Staff --->
					<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
						insert Staff (CEcodigo, persona, autorizado)
						values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
								<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">, 
								<cfif isdefined("form.autorizadodoc")>
									1
								<cfelse>
									0
								</cfif>)
						select convert(varchar, @@identity) as id
					</cfquery>
				</cfif>
				<cfset referencias = referencias & Iif(referencias NEQ "",DE(","),DE("")) & ABC_Relaciones.id>
				<cfset roles = roles & Iif(roles NEQ "",DE(","),DE("")) & "edu.docente">
				<cfif isdefined("form.autorizadodoc")>
					<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "1">
				<cfelse>
					<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "0">
				</cfif>
			<cfelse>									<!--- BAJA de Staff --->
				<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
					delete Staff 
					where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
						and persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
				</cfquery>
			</cfif>
				
			<cfif isdefined("form.Acodigo")>			
				<cfif form.Acodigo NEQ "">			<!--- CAMBIO de Asistente --->
					<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
						update Asistente set 
							persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">,
							autorizado = <cfif isdefined("form.autorizadoast")>1<cfelse>0</cfif>
						where Acodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Acodigo#">			

						select convert(varchar, <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Acodigo#">) as id
					</cfquery>
				<cfelse>							<!--- ALTA de Asistente --->
					<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
						insert Asistente (CEcodigo, persona, autorizado)
						values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">,
								<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">,
								<cfif isdefined("form.autorizadoast")>
									1
								<cfelse>
									0
								</cfif>)				
						select convert(varchar, @@identity) as id
					</cfquery>
				</cfif>			
				<cfset referencias = referencias & Iif(referencias NEQ "",DE(","),DE("")) & ABC_Relaciones.id>
				<cfset roles = roles & Iif(roles NEQ "",DE(","),DE("")) & "edu.asistente">
				<cfif isdefined("form.autorizadoast")>
					<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "1">
				<cfelse>
					<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "0">
				</cfif>
			<cfelse>								<!--- BAJA de Asistente --->
				<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
					delete Asistente 
					where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
						and persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
				</cfquery>
			</cfif>		

			<cfif isdefined("form.EEcodigo") >			 
				<cfif form.EEcodigo NEQ "">			<!--- CAMBIO de Encargado --->
					<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
						update Encargado 
						   set autorizado = <cfif isdefined("form.autorizadoenc")>1<cfelse>0</cfif>
						where EEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.EEcodigo#">
						
						select convert(varchar, <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.EEcodigo#">) as id
					</cfquery>
				<cfelse>								<!--- ALTA de Encargado --->
					<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
						insert Encargado (persona, autorizado)
						values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">,
								<cfif isdefined("form.autorizadoenc")>
									1
								<cfelse>
									0
								</cfif>)
						select convert(varchar, @@identity) as id
					</cfquery>
				</cfif>
				<cfset referencias = referencias & Iif(referencias NEQ "",DE(","),DE("")) & ABC_Relaciones.id>
				<cfset roles = roles & Iif(roles NEQ "",DE(","),DE("")) & "edu.encargado">
				<cfif isdefined("form.autorizadoenc")>
					<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "1">
				<cfelse>
					<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "0">
				</cfif>
			<cfelse>
				<!--- BAJA de Encargado --->
				<!--- se borra como encargado de todas las relaciones de encargados por estudiante --->
				<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
					set nocount on
					delete EncargadoEstudiante
					where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
					and EEcodigo in (Select EEcodigo from Encargado where persona=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">) 

					delete Encargado 
					where persona=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
					set nocount off
				</cfquery>
			</cfif>
				
			<cfif isdefined("form.Dcodigo") >
				<cfif form.Dcodigo NEQ "">			<!--- CAMBIO de Director --->
					<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
						update Director 
						   set autorizado = <cfif isdefined("form.autorizadodir")>1<cfelse>0</cfif>
						where Dcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Dcodigo#">
						
						select convert(varchar, <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Dcodigo#">) as id
					</cfquery>
				<cfelse> 								<!--- ALTA de Director --->
					<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
						set nocount on
						declare @director numeric
						insert Director	(persona, Ncodigo, autorizado)
						values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">,
								<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Ncodigo#">,
								<cfif isdefined("form.autorizadodir")>
									1
								<cfelse>
									0
								</cfif>)				
						select @director = @@identity

						insert DirectorNivel(Dcodigo, Ncodigo)
						values (@director, <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Ncodigo#">)

						select convert(varchar, @director) as id
						set nocount off
					</cfquery>
				</cfif>
				<cfset referencias = referencias & Iif(referencias NEQ "",DE(","),DE("")) & ABC_Relaciones.id>
				<cfset roles = roles & Iif(roles NEQ "",DE(","),DE("")) & "edu.director">
				<cfif isdefined("form.autorizadodir")>
					<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "1">
				<cfelse>
					<cfset activacion = activacion & Iif(activacion NEQ "",DE(","),DE("")) & "0">
				</cfif>
			<cfelse>
													<!--- BAJA de Director 	--->
				<cfquery name="ABC_Relaciones" datasource="#Session.DSN#">
					set nocount on
					delete DirectorNivel
					from DirectorNivel a, Director b 
					where b.persona = <cfqueryparam value="#form.persona#" cfsqltype="cf_sql_numeric">
					and a.Dcodigo = b.Dcodigo

					delete Director 
					where persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
					set nocount off
				</cfquery>
			</cfif>

			<!--- Actualizacion del Usuario en el Framework --->
			<cfinvoke 
			 component="edu.Componentes.usuarios"
			 method="upd_usuario"
			 returnvariable="UsrUpdated">
				<cfinvokeargument name="consecutivo" value="#Session.CEcodigo#"/>
				<cfinvokeargument name="sistema" value="edu"/>
				<cfinvokeargument name="referencias" value="#referencias#"/>
				<cfinvokeargument name="roles" value="#roles#"/>
				<cfinvokeargument name="activacion" value="#activacion#"/>
				<cfinvokeargument name="Pnombre" value="#form.Pnombre#"/>
				<cfinvokeargument name="Papellido1" value="#form.Papellido1#"/>
				<cfinvokeargument name="Papellido2" value="#form.Papellido2#"/>
				<cfinvokeargument name="Ppais" value="#form.Ppais#"/>
				<cfinvokeargument name="TIcodigo" value="#form.TIcodigo#"/>
				<cfinvokeargument name="Pid" value="#form.Pid#"/>
				<cfinvokeargument name="Pnacimiento" value="#form.Pnacimiento#"/>
				<cfinvokeargument name="Psexo" value="#form.Psexo#"/>
				<cfinvokeargument name="Pemail1" value="#form.Pemail1#"/>
				<cfinvokeargument name="Pemail2" value="#form.Pemail2#"/>
				<cfinvokeargument name="Pdireccion" value="#form.Pdireccion#"/>
				<cfinvokeargument name="Pcasa" value="#form.Pcasa#"/>
				<cfinvokeargument name="Poficina" value="#form.Poficina#"/>
				<cfinvokeargument name="Pcelular" value="#form.Pcelular#"/>
				<cfinvokeargument name="Pfax" value="#form.Pfax#"/>
				<cfinvokeargument name="Ppagertel" value="#form.Ppagertel#"/>
				<cfinvokeargument name="Ppagernum" value="#form.Ppagernum#"/>
				<cfif isdefined("Form.Pfoto") and form.Pfoto NEQ "">
					<cfinvokeargument name="Pfoto" value="#ts#"/>
				</cfif>
				<cfinvokeargument name="upd_referencia" value="#upd_referencia#"/>
				<cfinvokeargument name="upd_rol" value="#upd_rol#"/>
				<cfinvokeargument name="dominio_roles" value="#dominio_roles#"/>
			</cfinvoke>
				
		<cfcatch type="any">
			<cfinclude template="/edu/errorPages/BDerror.cfm">
			<cfabort>
		</cfcatch>
		</cftry>
	</cfif>
</cfif>
</cftransaction>

<cfoutput>
<form action="#action#" method="post" name="sql">
	<input name="modo"   type="hidden" value="<cfif isdefined("modo")>#modo#</cfif>">
	<input name="persona"   type="hidden" value="<cfif isdefined("Form.persona")>#form.persona#</cfif>">
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")>#Form.Pagina#</cfif>">
	
	<!--- Campos para el boton de buscar --->
	<cfif isdefined("form.btnBuscar")>
		<input name="Busca" type="hidden" value="1">
		<input name="Pnombre" type="hidden" value="<cfif isdefined("Form.Pnombre")>#Form.Pnombre#</cfif>">
		<input name="Papellido1" type="hidden" value="<cfif isdefined("Form.Papellido1")>#Form.Papellido1#</cfif>">
		<input name="Papellido2" type="hidden" value="<cfif isdefined("Form.Papellido2")>#Form.Papellido2#</cfif>">
		<input name="Pid" type="hidden" value="<cfif isdefined("Form.Pid")>#Form.Pid#</cfif>">
		<input name="Pdireccion" type="hidden" value="<cfif isdefined("Form.Pdireccion")>#Form.Pdireccion#</cfif>">
		<input name="Pcasa" type="hidden" value="<cfif isdefined("Form.Pcasa")>#Form.Pcasa#</cfif>">
		<input name="Poficina" type="hidden" value="<cfif isdefined("Form.Poficina")>#Form.Poficina#</cfif>">
		<input name="Pcelular" type="hidden" value="<cfif isdefined("Form.Pcelular")>#Form.Pcelular#</cfif>">
		<input name="Pfax" type="hidden" value="<cfif isdefined("Form.Pfax")>#Form.Pfax#</cfif>">
		<input name="Ppagertel" type="hidden" value="<cfif isdefined("Form.Ppagertel")>#Form.Ppagertel#</cfif>">
		<input name="Ppagernum" type="hidden" value="<cfif isdefined("Form.Ppagernum")>#Form.Ppagernum#</cfif>">
		<input name="Pemail1" type="hidden" value="<cfif isdefined("Form.Pemail1")>#Form.Pemail1#</cfif>">
		<input name="Pemail2" type="hidden" value="<cfif isdefined("Form.Pemail2")>#Form.Pemail2#</cfif>">
	<cfelse>
	  <cfif isdefined("Form.fRHnombre")>
		 <input type="hidden" name="fRHnombre" value="<cfoutput>#Form.fRHnombre#</cfoutput>">
	  </cfif>
	  <cfif isdefined("Form.filtroTipo")>
		 <input type="hidden" name="filtroTipo" value="<cfoutput>#Form.filtroTipo#</cfoutput>">
	  </cfif>
	  <cfif isdefined("Form.filtroRhPid")>
		 <input type="hidden" name="filtroRhPid" value="<cfoutput>#Form.filtroRhPid#</cfoutput>">
	  </cfif>
	</cfif>
</form>
</cfoutput>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>
