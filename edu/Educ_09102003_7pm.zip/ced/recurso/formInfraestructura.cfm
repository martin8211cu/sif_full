<cfif isdefined("Form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("Form.modo")>
		<cfset modo="ALTA">
	<cfelseif #Form.modo# EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>


<cfif modo NEQ "ALTA">
	<cfif isdefined("Form.Rconsecutivo") and len(trim("Form.Rconsecutivo")) NEQ 0>
		<cfquery datasource="#Session.DSN#" name="rsRecurso">
		 select convert(varchar,Rconsecutivo) as Rconsecutivo, convert(varchar,CEcodigo) as CEcodigo , Rcodigo , Rdescripcion, Robservacion, convert(varchar,Rcapacidad) as Rcapacidad
		 from Recurso
 		 where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
			  and Rconsecutivo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.Rconsecutivo#">
		</cfquery>
	</cfif>

</cfif>
<cfquery datasource="#Session.DSN#" name="rsCapacidad">
	select -1 as Rcapacidad , 'Todos'  as Capacidad
	union all
	select distinct Rcapacidad as Rcapacidad, convert(varchar,Rcapacidad) as Capacidad from Recurso
	where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
</cfquery>

<cfif modo NEQ "ALTA" and isdefined("Form.Rconsecutivo") and len(trim("Form.Rconsecutivo")) GT 0>
	<!--- 3. Validaciones de dependencias--->
	<!---  Rodolfo Jim�nez Jara, SOIN, 04/12/2002 --->
	<cfquery datasource="#Session.DSN#" name="rsHayHorarioGuia">
		select 1 from HorarioGuia
		where Rconsecutivo  = <cfqueryparam value="#Form.Rconsecutivo#" cfsqltype="cf_sql_numeric">
		 
	</cfquery>
</cfif>	  


<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" type="text/JavaScript">
// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
	
</script>
<form action="SQLInfraestructura.cfm" method="post" name="form1">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td class="tituloMantenimiento" colspan="6" align="center"><font size="3"> 
        <cfif modo eq "ALTA">
          Nuevo Recurso 
          <cfelse>
          Modificar Recurso 
        </cfif>
        </font></td>
    </tr>
    <tr> 
      <td width="17%" align="right">C&oacute;digo:</td>
      <td width="24%"><input name="Rcodigo" type="text" size="10" maxlength="10" tabindex="1" value="<cfif modo NEQ "ALTA"><cfoutput>#Trim(rsRecurso.Rcodigo)#</cfoutput></cfif>" onfocus="javascript:this.select();"></td>
      <td width="23%" align="right">Capacidad:</td>
      <td width="36%"><input name="Rcapacidad" type="text" size="10" maxlength="10" tabindex="3" style="text-align:right" value="<cfif modo NEQ "ALTA"><cfoutput>#Trim(rsRecurso.Rcapacidad)#</cfoutput></cfif>" onFocus="javascript:this.value=qf(this); this.select();" onBlur="javascript:fm(this,0);"  onKeyUp="javascript:if(snumber(this,event,0)){ if(Key(event)=='13') {this.blur();}}"></td>
    </tr>
    <tr> 
      <td align="right"> Descripci&oacute;n:</td>
      <td> 
        <textarea name="Rdescripcion" cols="30" rows="3" tabindex="2" onFocus="javascript:this.select();" ><cfif modo NEQ "ALTA"><cfoutput>#Trim(rsRecurso.Rdescripcion)#</cfoutput></cfif></textarea></td>
      <td align="right">Observaci&oacute;n:</td>
      <td> 
        <textarea name="Robservacion" cols="30" rows="3" tabindex="4" onfocus="javascript:this.select();"><cfif modo NEQ "ALTA"><cfoutput>#Trim(rsRecurso.Robservacion)#</cfoutput></cfif></textarea></td>
    </tr>
      <tr> 
      <td colspan="4" align="center" valign="baseline" nowrap> 
        <cfinclude template="../../portlets/pBotones.cfm">
        <cfif modo NEQ "ALTA">
          <input type="hidden" name="Rconsecutivo" value="<cfoutput>#rsRecurso.Rconsecutivo#</cfoutput>">
        </cfif>
		<input type="hidden" name="HayHorarioGuia" value="<cfif modo NEQ "ALTA"><cfoutput>#rsHayHorarioGuia.recordCount#</cfoutput></cfif>">
      </td>
    </tr>
  </table>
</form>
 <form action="Infraestructura.cfm" method="post" name="FiltroRecursos">
	<table class="areaFiltro" width="100%" border="0" cellpadding="0" cellspacing="0">
		<tr>
      <td>C&oacute;digo:</td>
			<td><input name="FRcodigo" type="text" size="10" maxlength="10" tabindex="5"  onfocus="javascript:this.select();" value="<cfif isdefined("Form.FRcodigo")><cfoutput>#Form.FRcodigo#</cfoutput></cfif>"></td>
      <td>Descripci&oacute;n:</td>
			<td><input name="FRdescripcion" type="text" tabindex="6" value="<cfif isdefined("Form.FRdescripcion")><cfoutput>#Form.FRdescripcion#</cfoutput></cfif>" size="30" maxlength="255" onfocus="javascript:this.select();"></td>
      <td>Capacidad:</td>
      <td><select name="FRcapacidad" id="FRcapacidad" >
          <cfoutput query="rsCapacidad"> 
            <option value="#rsCapacidad.Rcapacidad#" <cfif isdefined("form.FRcapacidad") AND form.FRcapacidad EQ rsCapacidad.Rcapacidad>selected</cfif>>#rsCapacidad.Capacidad# 
            </option>
          </cfoutput> 
        </select>
       <!---  <input name="FRcapacidad" type="text" size="10" maxlength="10" tabindex="7" value="<cfif isdefined("Form.FRcapacidad")><cfoutput>#Form.FRcapacidad#</cfoutput></cfif>" onfocus="javascript:this.value=qf(this); this.select();" onblur="javascript:fm(this,0);"  onkeyup="javascript:if(snumber(this,event,0)){ if(Key(event)=='13') {this.blur();}}">  --->
      </td>
			
      <td> Observaci&oacute;n:</td>
    		<td> <input name="FRobservacion" type="text" size="30" maxlength="10" tabindex="8" value="<cfif isdefined("Form.FRobservacion")><cfoutput>#Form.FRobservacion#</cfoutput></cfif>" onfocus="javascript:this.select();"></td>
			<td>
				<input type="submit" name="Filtrar" tabindex="9" value="Filtrar">
			</td>
		</tr>
	</table>
 </form>
 
<script language="JavaScript">
	// Se aplica la descripcion del Grado 
	
	function __isTieneDependencias() {
		if(btnSelected("Baja", this.obj.form)) {
				// Valida que el Grado no tenga dependencias con otros.
				var msg = "";
				//alert(new Number(this.obj.form.HayHorarioGuia.value)); 
				if (new Number(this.obj.form.HayHorarioGuia.value) > 0) {
					msg = msg + "horario de gu�a"
				}
				if (msg != "")
				{
					this.error = "Usted no puede eliminar el Tipo de Materia " + this.obj.form.Rdescripcion.value + " porque �ste tiene asociado: " + msg + ".";
					this.obj.form.Rdescripcion.focus();
				}
		}
	}
	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isTieneDependencias", __isTieneDependencias);
	objForm = new qForm("form1");
	

	objForm.Rdescripcion.required = true;
	objForm.Rdescripcion.description = "Descripci�n";
	objForm.Rdescripcion.validateTieneDependencias();
	objForm.Rcodigo.required = true;
	objForm.Rcodigo.description = "Codigo";
</script>

 <cfset filtro = "">
 <cfif isdefined("Form.FRcodigo") and len(trim(Form.FRcodigo)) NEQ 0>
 	<cfset filtro = filtro & " and Rcodigo  like '%" & Form.FRcodigo & "%'">
 </cfif>
 <cfif isdefined("Form.FRdescripcion") and len(trim(Form.FRdescripcion)) NEQ 0>
 	<cfset filtro = filtro & " and upper(Rdescripcion) like '%" & #UCase(Form.FRdescripcion)# & "%'">
 </cfif>
 <cfif isdefined("Form.FRcapacidad") and len(trim(Form.FRcapacidad)) NEQ 0 and Form.FRcapacidad NEQ -1>
 	<cfset filtro = filtro & " and Rcapacidad = " & Form.FRcapacidad>
 </cfif>
 <cfif isdefined("Form.FRobservacion") and len(trim(Form.FRobservacion)) NEQ 0>
 	<cfset filtro = filtro & " and upper(convert(varchar,Robservacion)) like '%" & #UCase(Form.FRobservacion)# & "%'">
 </cfif>
 

<cfinvoke component="edu.Componentes.pListas" method="pListaEdu" returnvariable="pListaRet">
	<cfinvokeargument name="tabla" value="Recurso"/>
	<cfinvokeargument name="columnas" value="convert(varchar, Rconsecutivo) as Rconsecutivo, convert(varchar, Rcodigo) as Rcodigo, convert(varchar,Rdescripcion,35) as Rdescripcion, convert(varchar, Rcapacidad) as Rcapacidad, convert(varchar,Robservacion,35) as Robservacion"/>
	<cfinvokeargument name="desplegar" value="Rcodigo, Rdescripcion, Rcapacidad"/>
	<cfinvokeargument name="etiquetas" value="Codigo, Descripci�n, Capacidad"/>
	<cfinvokeargument name="formatos" value=""/>
	<cfinvokeargument name="filtro" value=" CEcodigo = #Session.CEcodigo#  #filtro# order by Rdescripcion, Rcapacidad "/>
	<cfinvokeargument name="align" value="left,left,left"/>
	<cfinvokeargument name="ajustar" value="N,N,N"/>
	<cfinvokeargument name="irA" value="Infraestructura.cfm"/>
	<cfinvokeargument name="cortes" value=""/>
</cfinvoke>
