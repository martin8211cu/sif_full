<!-- Establecimiento del modo -->

<cfif isdefined("Form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("Form.modo")>
		<cfset modo="ALTA">
	<cfelseif Form.modo EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>


<!--- Consultas --->

<!--- 1. Form  --->
<cfif modo EQ "CAMBIO" >
	<cfquery datasource="#Session.DSN#" name="rsForm">
		Select convert(varchar,persona) as persona, convert(varchar,CEcodigo) as CEcodigo, a.Pnombre, Papellido1, Papellido2, a.Ppais, b.Pnombre, a.TIcodigo, TInombre, Pid, convert(varchar,Pnacimiento,103) Pnacimiento, Psexo, Pemail1, Pemail2, Pdireccion, Pcasa, Poficina, Pcelular, Pfax, Ppagertel, Ppagernum, Pfoto, PfotoType, PfotoName, Pemail1validado
		from PersonaEducativo a, Pais b, TipoIdentificacion c
		where CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
		and persona=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
		and a.Ppais=b.Ppais
		and a.TIcodigo=c.TIcodigo
	</cfquery>
	<!---  Para el check de Asistente  --->
	<cfquery datasource="#Session.DSN#" name="rsAsist">
		Select convert(varchar,Acodigo) as Acodigo, autorizado
		from Asistente
		where persona=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
			and CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
	</cfquery>	
	<!---  Para el check de Staff o Docente  --->
	<cfquery datasource="#Session.DSN#" name="rsStaff">
		Select convert(varchar,Splaza) as Splaza, autorizado, retirado
		from Staff
		where persona=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
			and CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
	</cfquery>
	<!---  Para el check de Encargado  --->
	<cfquery datasource="#Session.DSN#" name="rsEncar">
		Select convert(varchar,EEcodigo) as EEcodigo, autorizado
		from Encargado
		where persona=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
	</cfquery>
	<!---  Para el check de Director  --->
	<cfquery datasource="#Session.DSN#" name="rsDirec">
		Select convert(varchar,Dcodigo) as Dcodigo, convert(varchar,Ncodigo) as Ncodigo, autorizado
		from Director
		where persona=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
	</cfquery>

</cfif>

<!--- Para el combo de tipos de Identificacion  --->
<cfquery datasource="#Session.DSN#" name="rsTipoIdentif">
	select TIcodigo,TInombre from TipoIdentificacion
</cfquery>

<!---  Para el combo de paises  --->
<cfquery datasource="#Session.DSN#" name="rsPaises">
	select Ppais,Pnombre from Pais 
</cfquery>


<!---  Para el combo de Niveles  --->
<cfquery datasource="#Session.DSN#" name="rsNivel">
	select convert(varchar,Ncodigo) as Ncodigo,Ndescripcion
	from Nivel
	where CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
</cfquery>



<!--- ------------------------------------------------------------------------------- --->

<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" type="text/JavaScript">

	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
	
	var popUpWin=0; 
	function popUpWindow(URLStr, left, top, width, height)
	{
	  if(popUpWin)
	  {
		if(!popUpWin.closed) popUpWin.close();
	  }
	  popUpWin = open(URLStr, 'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=no,resizable=no,copyhistory=yes,width='+width+',height='+height+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
	}
		
	function doConlisAplicaNivelesDirector() {
		//alert(Hcodigo);
		popUpWindow("ConlisAplicaNivelesDirector.cfm?Dcodigo="+document.formRH.Dcodigo.value,250,100,650,500);
	}
	
	

</script>
<form action="SQLRh.cfm" method="post" enctype="multipart/form-data" id="formRH" name="formRH">
   <input name="persona" id="persona" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.persona#</cfoutput></cfif>" type="hidden"> 
   <input name="MODO" id="MODO" value="<cfoutput>#modo#</cfoutput>" type="hidden">    
   
	   <!--- Campos del filtro para la lista de Recursos Humanos --->
		  <cfif isdefined("Form.fRHnombre")>
			 <input type="hidden" name="fRHnombre" value="<cfoutput>#Form.fRHnombre#</cfoutput>">
		  </cfif>		   
		  <cfif isdefined("Form.filtroTipo")>
			 <input type="hidden" name="filtroTipo" value="<cfoutput>#Form.filtroTipo#</cfoutput>">
		  </cfif>		
		  <cfif isdefined("Form.filtroRhPid")>
			 <input type="hidden" name="filtroRhPid" value="<cfoutput>#Form.filtroRhPid#</cfoutput>">
		  </cfif>		
		 <!--- ----------------------------------------- --->   
   

  <table width="100%" border="0">
    <tr> 
      <td colspan="5" class="tituloAlterno"> <cfif modo EQ 'CAMBIO'>
          Modificacion de Recurso Humano 
          <cfelse>
          Ingreso de Recurso Humano </cfif> </td>
    </tr>
    <tr> 
      <td width="22%" rowspan="6" valign="middle" align="center"> <table width="108" height="159" border="1">
          <tr> 
            <td width="102" align="center" valign="middle"> <cfif modo NEQ 'ALTA'>
                <cfif Len(rsForm.Pfoto) EQ 0>
                  Fotograf&iacute;a no disponible 
                  <cfelse>
                  <!--- <img src="/Upload/DownloadServlet/PersonaEducacionFoto?persona=<cfoutput>#rsForm.persona#</cfoutput>" alt='<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Pnombre#  #rsForm.Papellido1#  #rsForm.Papellido2#</cfoutput></cfif>' align="middle" width="109" height="154" border="0">	 --->
				  <cf_LoadImage tabla="PersonaEducativo" columnas="Pfoto as contenido, persona as codigo" condicion="persona=#rsForm.persona#" imgname="Foto" width="109" height="154" alt="#rsForm.Pnombre#  #rsForm.Papellido1#  #rsForm.Papellido2#">
                </cfif>
                <cfelse>
                Fotograf&iacute;a </cfif> 
			</td>
          </tr>
        </table></td>
      <td width="15%" class="subTitulo">Nombre*</td>
      <td width="18%" class="subTitulo">Primer Apellido *</td>
      <td width="25%" class="subTitulo">Segundo Apellido*</td>
      <td width="20%" rowspan="5" align="center" valign="top"> <table width="100%" border="0">
          <tr> 
            <td colspan="2" align="center" class="subTitulo">Tipos</td>
            <td align="center" class="subTitulo">Autorizado</td>
          </tr>
          <tr> 
            <td> <input name="Acodigo" type="checkbox" id="Acodigo" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsAsist.Acodigo#</cfoutput></cfif>"  <cfif modo NEQ 'ALTA' and #rsAsist.Acodigo# NEQ "">checked</cfif> onClick="javascript: this.form.autorizadoast.checked = this.checked;"> 
            </td>
            <td>Asistente</td>
            <td align="center"> <input name="autorizadoast" type="checkbox" id="autorizadoast" <cfif modo NEQ 'ALTA' and #rsAsist.autorizado# EQ 1>checked</cfif>> 
            </td>
          </tr>
          <tr> 
            <td> <input name="EEcodigo" type="checkbox" id="EEcodigo" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsEncar.EEcodigo#</cfoutput></cfif>" <cfif modo NEQ 'ALTA' and #rsEncar.EEcodigo# NEQ "">checked</cfif> onClick="javascript: this.form.autorizadoenc.checked = this.checked;"> 
            </td>
            <td>Encargado</td>
            <td align="center"> <input name="autorizadoenc" type="checkbox" id="autorizadoenc" <cfif modo NEQ 'ALTA' and #rsEncar.autorizado# EQ 1>checked</cfif>> 
            </td>
          </tr>
          <tr> 
            <td> <input name="Splaza" type="checkbox" id="Splaza" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsStaff.Splaza#</cfoutput></cfif>" <cfif modo NEQ 'ALTA' and #rsStaff.Splaza# NEQ "">checked</cfif> onClick="javascript: this.form.autorizadodoc.checked = this.checked;"> 
            </td>
            <td>Docente </td>
            <td width="33%" align="center"> <input name="autorizadodoc" type="checkbox" id="autorizadodoc" <cfif modo NEQ 'ALTA' and #rsStaff.autorizado# EQ 1>checked</cfif>> 
            </td>
          </tr>
          <tr> 
            <td width="11%"> <input name="Dcodigo" type="checkbox" id="Dcodigo" onClick="javascript: Nivel(this); this.form.autorizadodir.checked = this.checked;" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsDirec.Dcodigo#</cfoutput></cfif>" <cfif modo NEQ 'ALTA' and #rsDirec.Dcodigo# NEQ "">checked</cfif>> 
            </td>
            <td> Director</td>
            <td width="33%" align="center"> <input name="autorizadodir" type="checkbox" id="autorizadodir" <cfif modo NEQ 'ALTA' and #rsDirec.autorizado# EQ 1>checked</cfif>> 
            </td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td colspan="2"> <div style="display: ;" id="verNiveles"> 
                <table width="100%" border="0">
                  <cfif modo EQ 'ALTA' >
                    <tr class="subTitulo"> 
                      <td class="subTitulo">Nivel</td>
                    </tr>
                    <tr> 
                      <td> 
                        <select name="Ncodigo" id="Ncodigo">
                          <cfoutput query="rsNivel"> 
                            <cfif modo NEQ 'ALTA' >
                              <cfif #rsDirec.Ncodigo# EQ #rsNivel.Ncodigo#>
                                <option value="#rsNivel.Ncodigo#" selected>#rsNivel.Ndescripcion#</option>
                                <cfelse>
                                <option value="#rsNivel.Ncodigo#">#rsNivel.Ndescripcion#</option>
                              </cfif>
                              <cfelse>
                              <option value="#rsNivel.Ncodigo#">#rsNivel.Ndescripcion#</option>
                            </cfif>
                          </cfoutput> </select> </td>
                    </tr>
                    <cfelse>
						<cfif rsDirec.Dcodigo NEQ "">	<!--- Es un director --->
							<tr> 
							  <td>&nbsp;</td>
							</tr>
							<tr> 
							  <td> 
								<input name="btnNivelesAplica" type="button" value="Asociar a Niveles" onClick="javascript:doConlisAplicaNivelesDirector();"> 
							  </td>
							</tr>						
						<cfelse>
							<tr class="subTitulo"> 
							  <td class="subTitulo">Nivel</td>
							</tr>
							<tr> 
							  <td> 
								<select name="Ncodigo" id="Ncodigo">
								  <cfoutput query="rsNivel"> 
									<cfif modo NEQ 'ALTA' >
									  <cfif #rsDirec.Ncodigo# EQ #rsNivel.Ncodigo#>
										<option value="#rsNivel.Ncodigo#" selected>#rsNivel.Ndescripcion#</option>
										<cfelse>
										<option value="#rsNivel.Ncodigo#">#rsNivel.Ndescripcion#</option>
									  </cfif>
									  <cfelse>
									  <option value="#rsNivel.Ncodigo#">#rsNivel.Ndescripcion#</option>
									</cfif>
								  </cfoutput> </select> </td>
							</tr>						
						</cfif>					
                  </cfif>
                </table>
              </div></td>
          </tr>
        </table></td>
    </tr>
    <tr> 
      <td> <input name="Pnombre" type="text" id="Pnombre" onFocus="this.select()" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Pnombre#</cfoutput></cfif>"> 
      </td>
      <td> <input name="Papellido1" type="text" id="Papellido1" onFocus="this.select()" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Papellido1#</cfoutput></cfif>"> 
      </td>
      <td> <input name="Papellido2" type="text" id="Papellido2" onFocus="this.select()" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Papellido2#</cfoutput></cfif>"> 
      </td>
    </tr>
    <tr> 
      <td class="subTitulo">Identificaci&oacute;n*</td>
      <td class="subTitulo">Tipo Identificaci&oacute;n</td>
      <td class="subTitulo">Sexo</td>
    </tr>
    <tr> 
      <td> <input name="Pid" type="text" id="Pid" onFocus="this.select()" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Pid#</cfoutput></cfif>"> 
      </td>
      <td> <select name="TIcodigo" id="TIcodigo">
          <cfoutput query="rsTipoIdentif"> 
            <cfif modo EQ 'CAMBIO' and #rsForm.TIcodigo# EQ #rsTipoIdentif.TIcodigo#>
              <option value="#rsTipoIdentif.TIcodigo#" selected>#rsTipoIdentif.TInombre#</option>
              <cfelse>
              <option value="#rsTipoIdentif.TIcodigo#">#rsTipoIdentif.TInombre#</option>
            </cfif>
          </cfoutput> </select> </td>
      <td> <select name="Psexo" id="Psexo">
          <cfif modo EQ 'CAMBIO' and #rsForm.Psexo# EQ 'M'>
            <option value="M" selected>Masculino</option>
            <cfelse>
            <option value="M">Masculino</option>
          </cfif>
          <cfif modo EQ 'CAMBIO' and #rsForm.Psexo# EQ 'F'>
            <option value="F" selected>Femenino</option>
            <cfelse>
            <option value="F">Femenino</option>
          </cfif>
        </select> </td>
    </tr>
    <tr> 
      <td class="subTitulo">Fecha de Nacimiento</td>
      <td class="subTitulo">Direcci&oacute;n*</td>
      <td class="subTitulo">&nbsp;</td>
    </tr>
    <tr> 
      <td valign="top"> <a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Calendar1','','/cfmx/edu/Imagenes/date_d.gif',1)"> 
        <input name="Pnacimiento" onFocus="this.select()" type="text" onBlur="javascript: onblurdatetime(this)" value="<cfif isdefined("form.Pnacimiento")><cfoutput>#rsForm.Pnacimiento#</cfoutput><cfelse><cfoutput>#DateFormat(Now(),'DD/MM/YYYY')#</cfoutput></cfif>" size="12" maxlength="10" >
        <img src="/cfmx/edu/Imagenes/date_d.gif" alt="Calendario" name="Calendar1" width="11" height="11" border="0" id="Calendar1" onClick="javascript:showCalendar('document.formRH.Pnacimiento');"> 
        </a> </td>
      <td valign="top" colspan="2"><textarea name="Pdireccion" id="Pdireccion2" onFocus="this.select()" style="width: 100%"><cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Pdireccion#</cfoutput></cfif></textarea></td>
      <td valign="top" style="padding-left: 4px;">
	  <!---
	  	<cfif modo NEQ "ALTA" and isdefined("rsStaff") and rsStaff.recordCount GT 0 and rsStaff.Splaza NEQ "">
		<input type="checkbox" name="retirado" value="1" <cfif rsStaff.retirado EQ 1>checked</cfif>> Retirado como Docente
		<cfelse>
		&nbsp;
		</cfif>
	   --->&nbsp;
	  </td>
    </tr>
    <tr> 
      <td class="subTitulo">Ruta de Imagen</td>
      <td class="subTitulo">Tel&eacute;fono Casa*</td>
      <td class="subTitulo">Tel&eacute;fono Oficina*</td>
      <td class="subTitulo">Tel&eacute;fono Celular*</td>
      <td class="subTitulo">Fax*</td>
    </tr>
    <tr> 
      <td> <input type="file" name="Pfoto" > </td>
      <td> <input name="Pcasa" type="text" id="Pcasa" onFocus="this.select()" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Pcasa#</cfoutput></cfif>"> 
      </td>
      <td> <input name="Poficina" type="text" id="Poficina" onFocus="this.select()" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Poficina#</cfoutput></cfif>"> 
      </td>
      <td> <input name="Pcelular" src="../../Imagenes/delete.small.png" type="text" onFocus="this.select()" id="Pcelular" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Pcelular#</cfoutput></cfif>"> 
      </td>
      <td valign="top"> <input name="Pfax" type="text" id="Pfax2" onFocus="this.select()" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Pfax#</cfoutput></cfif>"> 
      </td>
    </tr>
    <tr> 
      <td class="subTitulo">Tel&eacute;fono Pager*</td>
      <td class="subTitulo">N&uacute;mero Pager*</td>
      <td class="subTitulo">Mail Principal*</td>
      <td class="subTitulo">Mail Secundario*</td>
      <td class="subTitulo">Pa&iacute;s</td>
    </tr>
    <tr> 
      <td> <input name="Ppagertel" type="text" id="Ppagertel"  onFocus="this.select()" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Ppagertel#</cfoutput></cfif>"> 
      </td>
      <td> <input name="Ppagernum" type="text" onFocus="this.select()" id="Ppagernum" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Ppagernum#</cfoutput></cfif>"> 
      </td>
      <td> <input name="Pemail1" type="text" id="Pemail1"  onFocus="this.select()" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Pemail1#</cfoutput></cfif>" size="30"> 
      </td>
      <td> <input name="Pemail2" type="text" id="Pemail2"  onFocus="this.select()" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.Pemail2#</cfoutput></cfif>" size="30"> 
      </td>
      <td valign="top"> <select name="Ppais" id="select">
          <cfoutput query="rsPaises"> 
            <cfif modo EQ 'CAMBIO' and #rsForm.Ppais# EQ #rsPaises.Ppais#>
              <option value="#rsPaises.Ppais#" selected>#rsPaises.Pnombre#</option>
              <cfelse>
              <cfif #rsPaises.Ppais# EQ 'CR'>
                <option value="#rsPaises.Ppais#" selected>#rsPaises.Pnombre#</option>
                <cfelse>
                <option value="#rsPaises.Ppais#">#rsPaises.Pnombre#</option>
              </cfif>
            </cfif>
          </cfoutput> </select> </td>
    </tr> 
    <tr> 
      <td colspan="5" align="center"> 
        <!-- Alta -->
        <cfif modo EQ 'ALTA'>
          <input type="button"  name="btnLimpiar"  value="Limpiar" onClick="javascript: limpiar()" >
          <input name="btnAgregar" type="submit" id="btnAgregar" onClick="javascript: setBtn(this);" value="Agregar" >
          <input name="btnBuscar" type="submit" id="btnBuscar" value="Buscar" onClick="javascript: setBtn(this); deshabilitarValidacion()">
          <cfelse>
          <!-- Cambio -->
          <input type="submit" name="btnCambiar" id="btnCambiar"  value="Cambiar" onClick="javascript: setBtn(this); habilitarValidacion()" >
          <input type="submit" name="btnBorrar"   id="btnBorrar" value="Borrar" onClick="javascript: setBtn(this); deshabilitarValidacion(); return confirm('Esta seguro(a) que desea borrar esta persona?')" >
          <input type="submit" name="btnNuevo"   id="btnNuevo" value="Nueva Persona" onClick="javascript: setBtn(this);deshabilitarValidacion()" >
          <input type="button"  name="btnLimpiar"   value="Limpiar"  onClick="javascript: limpiar()" >
        </cfif> </td>
    </tr>
    <tr> 
      <td colspan="5" align="center" class="subTitulo"> <cfif modo EQ 'ALTA'>
          Nota: Las b&uacute;squedas funcionan para campos con un (*) 
          <cfelse>
          &nbsp; </cfif> </td>
    </tr>
  </table>  
 </form>
 
<script language="JavaScript" type="text/javascript" src="../../js/calendar.js" >//</script>
<script language="JavaScript" type="text/javascript" src="../../js/utilesMonto.js">//</script>
<script language="JavaScript" type="text/javascript" src="js/formRh.js">//</script> 
<script language="JavaScript" src="../../js/qForms/qforms.js">//</script>
<script language="JavaScript" type="text/JavaScript">
	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
</script> 
 
 
<script language="JavaScript" type="text/javascript" >
//------------------------------------------------------------------------------------------						
	function deshabilitarValidacion() {
		objForm.Pnombre.required = false;
		<cfif modo EQ "ALTA">
			objForm.Ncodigo.required = false;
		</cfif>
		objForm.Pid.required = false;
		objForm.Papellido1.required = false;								
		objForm.Ppais.required = false;			
	}
//------------------------------------------------------------------------------------------						
	function habilitarValidacion() {
		objForm.Pnombre.required = true;
		<cfif modo EQ "ALTA">
			if (objForm.Dcodigo.obj.checked) {
				//objForm.Ncodigo.required = true;
				objForm.Ncodigo.required = false; //Para que no valide el combo, solo el conlis puede cambiar los niveles del Director
			}
		</cfif>
		objForm.Pid.required = true;
		objForm.Papellido1.required = true;								
		objForm.Ppais.required = true;			
			
	}	
//------------------------------------------------------------------------------------------							
	function __isTieneTipo() {
		// Valida que por lo menos se seleccione un tipo
		var bandera = false;
		
		if (btnSelected("btnAgregar") || btnSelected("btnCambiar")) {
			if (this.obj.form.Acodigo.checked) {
				bandera = true;
			}else{
				if (this.obj.form.EEcodigo.checked) {
					bandera = true;
				}else{
					if (this.obj.form.Splaza.checked) {
						bandera = true;
					}else{
						if (this.obj.form.Dcodigo.checked) {
							bandera = true;
						}					
					}				
				}			
			}
			
			if (!bandera){
				this.error = "Error, debe seleccional al menos uno de los tipos para el recurso humano";
				this.obj.form.Acodigo.focus();
			}
		}
	}	
//------------------------------------------------------------------------------------------						
	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isTieneTipo", __isTieneTipo);
	objForm = new qForm("formRH");
//------------------------------------------------------------------------------------------					
	<cfif modo EQ "ALTA">
		objForm.Pnombre.required = true;
		objForm.Pnombre.description = "nombre";
		objForm.Ncodigo.required = true;
		objForm.Ncodigo.description = "nivel";								
		objForm.Pid.required = true;
		objForm.Pid.description = "Identificaci�n";		
		objForm.Papellido1.required = true;
		objForm.Papellido1.description = "Primer Apellido";
		objForm.Ppais.required = true;
		objForm.Ppais.description = "Pa�s";		
	<cfelse>
		objForm.Pnombre.required = true;
		objForm.Pnombre.description = "nombre";								
		//objForm.Ncodigo.required = true;
		//objForm.Ncodigo.description = "nivel";		
		objForm.Pid.required = true;
		objForm.Pid.description = "Identificaci�n";		
		objForm.Papellido1.required = true;
		objForm.Papellido1.description = "Primer Apellido";
		objForm.Ppais.required = true;
		objForm.Ppais.description = "Pa�s";		
	</cfif> 
	
	objForm.Pnombre.validateTieneTipo();
//------------------------------------------------------------------------------------------		
	inicio();
</script>
