<!-- Establecimiento del modo -->

<cfif isdefined("Form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("Form.modo")>
		<cfset modo="ALTA">
	<cfelseif Form.modo EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>


<!--- Consultas --->
<!--- 1. Ccodigo del Calendario  --->
<cfif modo EQ "ALTA" >
	<cfquery datasource="#Session.DSN#" name="rsCalendario">
		Select convert(varchar,Ccodigo) as Ccodigo 
		from CentroEducativo 
		where CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
	</cfquery>
</cfif>

<!--- 1. Form  --->
<cfif modo EQ "CAMBIO" >
	<cfquery datasource="sdc" name="rsForm">
		select convert(varchar,Ccodigo) as Ccodigo,convert(varchar,CDcodigo) as CDcodigo,CDtitulo,CDdescripcion,convert(varchar,CDfecha,103) as CDfecha,CDferiado,CDabsoluto
		from CalendarioDia
		where CDcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.CDcodigo#">
	</cfquery>
</cfif>

<form name="formCalendario" id="formCalendario" method="post" action="SQLCalendario.cfm"> 
	<input name="Ccodigo" id="Ccodigo" type="hidden" value="<cfif modo EQ "ALTA"><cfoutput>#rsCalendario.Ccodigo#</cfoutput><cfelse><cfoutput>#rsForm.Ccodigo#</cfoutput></cfif>" >
	<input name="CDcodigo" id="CDcodigo" type="hidden" value="<cfif modo EQ "CAMBIO"><cfoutput>#rsForm.CDcodigo#</cfoutput></cfif>">
	
  <table width="100%" border="0">
    <tr> 
      <td colspan="2" align="center" class="tituloAlterno"> <cfif modo EQ 'CAMBIO'>
          Modificacion de Calendario 
          <cfelse>
          Ingreso de Calendario </cfif> </td>
    </tr>
    <tr> 
      <td width="10%">Nombre</td>
      <td width="90%"><input name="CDtitulo" type="text" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.CDtitulo#</cfoutput></cfif>" id="CDtitulo" size="50" maxlength="80"></td>
    </tr>
    <tr> 
      <td>Descripci&oacute;n</td>
      <td><textarea name="CDdescripcion" cols="40" id="CDdescripcion"><cfif modo NEQ 'ALTA'><cfoutput>#rsForm.CDdescripcion#</cfoutput></cfif></textarea></td>
    </tr>
    <tr> 
      <td>Fecha</td>
      <td> <a href="#"> 
        <input name="CDfecha" onFocus="this.select()" type="text" onBlur="javascript: onblurdatetime(this)" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsForm.CDfecha#</cfoutput></cfif>" size="12" maxlength="10" >
        <img src="/cfmx/edu/Imagenes/date_d.gif" alt="Calendario" name="Calendar1" width="11" height="11" border="0" id="Calendar1" onClick="javascript:showCalendar('document.formCalendario.CDfecha');"> 
        </a> </td>
    </tr>
    <tr> 
      <td><div align="center"> 
          <input name="CDabsoluto" type="checkbox" id="CDabsoluto" value="1" <cfif modo NEQ 'ALTA' and #rsForm.CDabsoluto# EQ "1">checked</cfif>>
        </div></td>
      <td>Solamente ocurre este a&ntilde;o</td>
    </tr>
    <tr> 
      <td><div align="center"> 
          <input name="CDferiado" type="checkbox" id="CDferiado" value="1" <cfif modo NEQ 'ALTA' and #rsForm.CDferiado# EQ "1">checked</cfif>>
        </div></td>
      <td>Es feriado</td>
    </tr>
    <tr> 
      <td colspan="2" align="center"> 
        <!-- Alta -->
        <cfif modo EQ 'ALTA'>
          <input name="btnAgregar" type="submit" id="btnAgregar" onClick="javascript: setBtn(this); habilitarValidacion();" value="Agregar" >
		  <!--- <input name="btnLimpiaCalendario" type="submit" id="btnLimpiaCalendario" onClick="javascript: setBtn(this); deshabilitarValidacion(); return confirm('Esta seguro(a) que desea limpiar el calendario?')" value="Limpiar Calendario" > --->
          <cfelse>
          <!-- Cambio -->
          <input type="submit" name="btnCambiar" id="btnCambiar"  value="Cambiar" onClick="javascript: setBtn(this); habilitarValidacion()" >
          <input type="submit" name="btnBorrar"   id="btnBorrar" value="Borrar" onClick="javascript: setBtn(this); deshabilitarValidacion(); return confirm('Esta seguro(a) que desea borrar este calendario?')" >
          <input type="submit" name="btnNuevo"   id="btnNuevo" value="Nuevo Calendario" onClick="javascript: setBtn(this);deshabilitarValidacion()" >
        </cfif> </td>
    </tr>
  </table>
  </form>

<script language="JavaScript" src="../../js/qForms/qforms.js">//</script>
<script language="JavaScript" type="text/JavaScript">
	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
</script> 


<script language="JavaScript" type="text/javascript" >
//------------------------------------------------------------------------------------------						
	function deshabilitarValidacion() {
		objForm.CDtitulo.required = false;
		objForm.CDfecha.required = false;		
	}
//------------------------------------------------------------------------------------------						
	function habilitarValidacion() {
		objForm.CDtitulo.required = true;
		objForm.CDfecha.required = true;		
	}	
//------------------------------------------------------------------------------------------						
	qFormAPI.errorColor = "#FFFFCC";
	objForm = new qForm("formCalendario");
//------------------------------------------------------------------------------------------					
	objForm.CDtitulo.required = true;
	objForm.CDtitulo.description = "nombre";
	objForm.CDfecha.required = true;
	objForm.CDfecha.description = "fecha";		
//------------------------------------------------------------------------------------------		
</script>