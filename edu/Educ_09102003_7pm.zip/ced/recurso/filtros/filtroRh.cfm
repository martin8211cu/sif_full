<cfform action="" name="" >
  <table width="100%" border="0" class="areaFiltro">
    <tr> 
      <td width="5%" class="subTitulo">Nombre </td>
      <td width="48%" class="subTitulo"><input name="fRHnombre" type="text" id="fRHnombre" size="80" onFocus="this.select()" maxlength="80" value="<cfif isdefined("Form.fRHnombre") AND #Form.fRHnombre# NEQ "" ><cfoutput>#Form.fRHnombre#</cfoutput></cfif>"></td>
      <td width="8%" class="subTitulo">Identificaci&oacute;n </td>
      <td width="15%" class="subTitulo"><input name="filtroRhPid" type="text" size="25" onFocus="this.select()" maxlength="60" value="<cfif isdefined("Form.filtroRhPid") AND #Form.filtroRhPid# NEQ "" ><cfoutput>#Form.filtroRhPid#</cfoutput></cfif>"></td>
      <td width="2%" align="center" class="subTitulo">Tipo</td>
      <td width="5%" align="center" class="subTitulo"><select name="filtroTipo" tabindex="5">
          <option value="-1" <cfif isdefined('form.filtroTipo') and form.filtroTipo EQ '-1'>selected</cfif>>Todos</option>
          <option value="A" <cfif isdefined('form.filtroTipo') and form.filtroTipo EQ 'A'>selected</cfif>>Asistente</option>
          <option value="E" <cfif isdefined('form.filtroTipo') and form.filtroTipo EQ 'E'>selected</cfif>>Encargado</option>
          <option value="D" <cfif isdefined('form.filtroTipo') and form.filtroTipo EQ 'D'>selected</cfif>>Docente</option>
          <option value="DR" <cfif isdefined('form.filtroTipo') and form.filtroTipo EQ 'DR'>selected</cfif>>Director</option>
        </select></td>
      <td width="17%" align="center" class="subTitulo"><input name="btnFiltrar" type="submit" id="btnFiltrar" value="Filtrar" ></td>
    </tr>
  </table>
</cfform>
