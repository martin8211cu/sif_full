<!-- Rodolfo Jimenez Jara, Soluciones Integrales S.A., Costa Rica, America Central, 21/04/2003 -->
<cfif isdefined("Form.tipo")>
	<cfset Form.id_tipo = Form.tipo>
</cfif>

<cfif isdefined("Url.id_tipo") and not isdefined("Form.id_tipo")>
	<cfset Form.id_tipo = Url.id_tipo>
</cfif>
<!--- <cfif isdefined("Url.id_tipo") and not isdefined("Form.id_tipo")>
	<cfset Form.id_tipo = Url.id_tipo>
</cfif> --->

<cfif isdefined("Form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("Form.modo")>
		<cfset modo="ALTA">
	<cfelseif Form.modo EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>

<cfif not isdefined("Form.modoDet")>
	<cfset modoDet = "ALTA">
</cfif>

<!-- modo para el detalle -->
<cfif isdefined("Form.id_tipo")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfset modo="ALTA">
	<cfset modoDet="ALTA">
</cfif>

<cfif isdefined("Form.id_atributo")>
	<cfset modoDet="CAMBIO">
<cfelse>
	<cfset modoDet="ALTA">
</cfif>  

<cfif isdefined("Form.btnNuevo")>
	<cfset modo="ALTA">
	<cfset modoDet="ALTA">
</cfif>

<!--- Consultas --->

<!--- 1. Form Encabezado --->
<cfquery datasource="#Session.DSN#" name="rsBibliotecas">
		set nocount on
		declare @id numeric
		if not exists ( select 1 from BibliotecaCentroE BCE, MABiblioteca MAB
			where BCE.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">
			  and MAB.id_biblioteca = BCE.id_biblioteca
		)
		begin
			insert into MABiblioteca (nombre_biblio)
			values('Biblioteca')
		
			select @id = @@identity
			
			insert into BibliotecaCentroE (CEcodigo, id_biblioteca)
			values(<cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">,@id)
		end
		else  
			select 1
		set nocount off
</cfquery>
<cfquery datasource="#Session.DSN#" name="rsMABiblioteca">
	select convert(varchar,a.id_biblioteca) as id_biblioteca , a.nombre_biblio 
	from MABiblioteca a, BibliotecaCentroE b
	where a.id_biblioteca = b.id_biblioteca
	  and b.CEcodigo =  <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
</cfquery>
<!--- Seccion del detalle --->
<cfif modoDet NEQ 'ALTA'>
	<cfif isdefined("Form.id_atributo") and Form.id_atributo NEQ ""  >
		<!--- 1. Form --->	
		<cfquery datasource="#Session.DSN#" name="rsMAAtributo">
			select convert(varchar,b.id_atributo) as  id_atributo,  substring(nombre_atributo,1,35) as nombre_atributo, orden_atributo , tipo_atributo
			from MATipoDocumento a, MAAtributo b 
			where b.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
			  and a.id_tipo = b.id_tipo
			<cfif isdefined("Form.id_tipo") AND Form.id_tipo NEQ "" >
			  and b.id_tipo =<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.id_tipo#">
			</cfif>
			<cfif isdefined("Form.id_atributo") AND Form.id_atributo NEQ "" >
			  and b.id_atributo =<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.id_atributo#">
			</cfif>
		</cfquery>
	</cfif>
</cfif>

<cfif modo NEQ 'ALTA' and isdefined("Form.id_tipo") and Form.id_tipo NEQ "">
	<cfquery datasource="#Session.DSN#" name="rsMAtipoDocumento">
		select nombre_tipo, convert(varchar,id_tipo) from MATipoDocumento 
		where id_tipo =<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.id_tipo#">
	</cfquery>
	<cfquery datasource="#Session.DSN#" name="rsHayMADocumento">
		<!--- Existen dependencias con MADocumento --->
		select 1 from MADocumento a, MATipoDocumento b
		where a.id_tipo= <cfqueryparam value="#form.id_tipo#" cfsqltype="cf_sql_numeric">
		  and a.id_tipo = b.id_tipo
		 <!---  and b.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">  --->
	</cfquery> 
	 <cfif modoDet NEQ 'ALTA' and isdefined("Form.tipo") >
		<cfquery datasource="#Session.DSN#" name="rsHayMAAtributoDocumento">
			<!--- Existen dependencias con MAAtributoDocumento--->
			select isnull(1,0) from MAAtributoDocumento a, MAAtributo b
			where a.id_atributo= <cfqueryparam value="#form.id_atributo#" cfsqltype="cf_sql_numeric">
			  and b.id_tipo= <cfqueryparam value="#form.tipo#" cfsqltype="cf_sql_numeric">
			  and b.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#"> 
		</cfquery> 
		
	</cfif>
</cfif>	

<!---------------------------------------------------------------------------------- --->

<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" type="text/JavaScript">

	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
	
	var popUpWin=0; 
	function popUpWindow(URLStr, left, top, width, height)
	{
	  if(popUpWin)
	  {
		if(!popUpWin.closed) popUpWin.close();
	  }
	  popUpWin = open(URLStr, 'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=no,resizable=no,copyhistory=yes,width='+width+',height='+height+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
	}
		
	function doConlisMantValores() {
		//alert(document.form1.id_atributo2.value);
		popUpWindow("ConlisValores.cfm?id_tipo="+document.form1.id_atributo2.value+"&nombre="+document.form1.nombre_atributo.value,250,100,650,500);
	}
	
	function irALista() {
		location.href = "listaBiblioteca.cfm";
	}
	
</script>

<form name="form1" method="post" action="SQLBiblioteca.cfm">
  <input name="id_tipo" id="id_tipo" value="<cfif modo NEQ "ALTA"><cfoutput>#Form.id_tipo#</cfoutput></cfif>" type="hidden">
  <table width="100%" border="0">
    <tr> 
      <td <cfif modo NEQ "ALTA">colspan="2" </cfif>class="tituloMantenimiento"><cfif modo EQ "ALTA">
          Nuevo 
          <cfelse>
          Modificar 
        </cfif>
        Tipo de Documento</td>
    </tr>
    <cfoutput> 
      <tr> 
        <td <cfif modo NEQ "ALTA">colspan="2" </cfif>valign="top"> <table width="100%" cellpadding="2" cellspacing="2" border="0">
            <tr> 
              <td align="right" nowrap>Descripci&oacute;n</td>
              <td nowrap><input name="nombre_tipo" type="text" id="nombre_tipo2" size="80" tabindex="1" maxlength="100" onFocus="javascript:this.select();" value="<cfif modo NEQ 'ALTA'>#rsMAtipoDocumento.nombre_tipo#</cfif>"></td>
            </tr>
            <tr> 
              <td align="right" nowrap>Biblioteca</td>
              <td width="70%" nowrap><select name="id_biblioteca" id="id_biblioteca">
                  <option value="#rsMABiblioteca.id_biblioteca#" <cfif (isDefined("form.id_biblioteca") AND #form.id_biblioteca# EQ #rsMABiblioteca.id_biblioteca#)>selected</cfif>>#rsMABiblioteca.nombre_biblio# 
                  </option>
                </select></td>
              <cfif modo NEQ "ALTA" and isdefined("Form.id_tipo")>
                <input type="hidden" name="HayMADocumento" value="#rsHayMADocumento.recordCount#" >
              </cfif>
            </tr>
          </table>
          <cfif modoDet NEQ 'ALTA' and isdefined("Form.tipo")>
            <input type="hidden" name="HayMAAtributoDocumento" value="<cfif #rsHayMAAtributoDocumento.recordCount# GT 0>#rsHayMAAtributoDocumento.recordCount#<cfelse>0</cfif>">
          </cfif>
		 
		  
		  
		  </td>
      </tr>
    </cfoutput> 
    <tr> 
      <td nowrap <cfif modo NEQ "ALTA">colspan="2" </cfif>align="center"> <cfif modo EQ "ALTA">
          <input type="submit" name="btnAgregarE" tabindex="1" value="Agregar" onClick="javascript: setBtn(this);">
          <cfelseif modo NEQ "ALTA">
          <input type="submit" name="btnCambiarE" tabindex="1" value="Modificar Documento" onClick="javascript: setBtn(this); deshabilitarDetalle(); habilitarValidacion();" >
          <input type="submit" name="btnBorrarE" tabindex="1" value="Borrar Documento" onClick="javascript: setBtn(this); deshabilitarValidacion(); deshabilitarDetalle(); return confirm('�Esta seguro(a) que desea borrar este Documento?');" >
          <input type="submit" name="btnNuevoE" tabindex="1" value="Nuevo Documento" onClick="javascript: setBtn(this); deshabilitarDetalle(); deshabilitarValidacion();" >
        </cfif> <input type="button" name="btnLista" tabindex="1" value="Lista Tipo de Documento" onClick="javascript: irALista();"> 
      </td>
    </tr>
    <cfif modo NEQ "ALTA">
      <tr> 
        <td colspan="2"><hr></td>
      </tr>
      <tr> 
        <td width="50%" valign="top"> 
          <cfinvoke 
			 component="edu.Componentes.pListas"
			 method="pListaEdu"
			 returnvariable="pListaPlanEvalDet">
            <cfinvokeargument name="tabla" value="MATipoDocumento a,  MAAtributo b"/>
            <cfinvokeargument name="columnas" value=" convert(varchar,b.id_tipo) as tipo, convert(varchar,b.id_atributo) as id_atributo, b.nombre_atributo as nombre_atr, (case b.tipo_atributo when 'N' then 'Num�rico' when 'T' then 'Texto' when 'F' then 'Fecha' when 'V' then 'Valores' else 'No definido' end) as TipoAtr"/>
            <cfinvokeargument name="desplegar" value="nombre_atr, TipoAtr"/>
            <cfinvokeargument name="etiquetas" value="Nombre Atributo,Tipo"/>
            <cfinvokeargument name="formatos" value=""/>
            <cfinvokeargument name="filtro" value=" b.CEcodigo = #Session.CEcodigo# and a.id_tipo = #form.id_tipo# and a.id_tipo = b.id_tipo order by b.orden_atributo, b.nombre_atributo"/>
            <cfinvokeargument name="align" value="left,right"/>
            <cfinvokeargument name="ajustar" value="N,N"/>
            , 
            <cfinvokeargument name="irA" value="Biblioteca.cfm"/>
            <cfinvokeargument name="incluyeForm" value="false"/>
            <cfinvokeargument name="formName" value="form1"/>
          </cfinvoke> </td>
        <td width="50%" valign="top" style="padding-left: 10px"> 
          <cfif modoDet NEQ "ALTA">
            <input type="hidden" name="id_atributo2" id="id_atributo2" value="<cfoutput>#Form.id_atributo#</cfoutput>">
          </cfif> <table border="0" width="100%" cellpadding="2" cellspacing="2">
            <tr> 
              <td align="right" nowrap>Nombre</td>
              <td nowrap><input name="nombre_atributo" type="text" id="nombre_atributo" tabindex="1" size="30" maxlength="80" onfocus="javascript:this.select();" value="<cfif modoDet NEQ 'ALTA'><cfoutput>#rsMAAtributo.nombre_atributo#</cfoutput></cfif>"></td>
            </tr>
            <tr> 
            	<td align="right" nowrap>Tipo</td>
              	<td nowrap> 
						<!--- <cfif modoDet NEQ 'ALTA' and #rsHayMAAtributoDocumento.recordCount# GT 0> --->
						<cfif 	isdefined("Form.id_atributo") and  #rsMAAtributo.RecordCount# GT 0>
							<input type="hidden" name="tipo_atributo_ant" value="<cfif #rsMAAtributo.RecordCount# GT 0><cfoutput>#rsMAAtributo.tipo_atributo#</cfoutput></cfif>">
						</cfif>
					
					<select name="tipo_atributo" id="tipo_atributo" tabindex="1" >
						<option value="N" <cfif modoDet NEQ 'ALTA' and #rsMAAtributo.tipo_atributo# EQ "N">selected</cfif>>Num�rico</option>
						<option value="T" <cfif modoDet NEQ 'ALTA' and #rsMAAtributo.tipo_atributo# EQ "T">selected</cfif>>Text</option>
						<option value="F" <cfif modoDet NEQ 'ALTA' and #rsMAAtributo.tipo_atributo# EQ "F">selected</cfif>>Fecha</option>
						<!--- <cfif modoDet NEQ "ALTA"> --->
							<option value="V" <cfif modoDet NEQ 'ALTA' and  #rsMAAtributo.tipo_atributo# EQ "V">selected</cfif>>Valores</option>
						<!--- </cfif> --->
					</select> </td>
            </tr>
            <tr> 
              <td align="right" nowrap>Orden</td>
              <td nowrap> <cfoutput> 
                  <input name="orden_atributo" align="left" type="text" id="orden_atributo" size="8" maxlength="8" value="<cfif modoDet NEQ "ALTA">#rsMAAtributo.orden_atributo#</cfif>" onfocus="this.value=qf(this); this.select();" onblur="fm(this,0);"  onkeyup="if(snumber(this,event,0)){ if(Key(event)=='13') {this.blur();}}" >
                </cfoutput> </td>
            </tr>
            <tr> 
              <td align="right" nowrap>&nbsp;</td>
              <td nowrap> <cfoutput> </cfoutput> </td>
            </tr>
            <tr align="center"> 
              <td colspan="2"> 
<!--- 			  	<div id="valor">
	                <input name="btnValores" type="button" value="Valores" onClick="javascript:doConlisMantValores();">
				</div> --->
				<cfif modoDet NEQ "ALTA" and #rsMAAtributo.tipo_atributo# EQ "V">
	                <input name="btnValores" type="button" value="Valores" onClick="javascript:doConlisMantValores();">
				<cfelse>
					&nbsp;
				</cfif>
              </td>
            </tr>
            <tr> 
              <td colspan="2" align="center"> <cfif modoDet EQ "ALTA">
                  <input type="submit" name="btnAgregarD" tabindex="4" value="Agregar Atributo" onClick="javascript: setBtn(this); habilitarDetalle(); habilitarValidacion(); " >
                  <cfelseif modoDet NEQ "ALTA">
                  <input type="submit" name="btnCambiarD" tabindex="4" value="Modificar Atributo" onClick="javascript: setBtn(this); habilitarDetalle(); habilitarValidacion(); " >
                  <input type="submit" name="btnBorrarD" tabindex="4" value="Borrar Atributo" onClick="javascript: setBtn(this); deshabilitarValidacion(); deshabilitarDetalle(); return confirm('�Esta seguro(a) que desea borrar este tipo?')" >
                  <input type="submit" name="btnNuevoD" tabindex="4" value="Nuevo Atributo" onClick="javascript: setBtn(this); deshabilitarValidacion(); deshabilitarDetalle();" >
                </cfif> </td>
            </tr>
          </table></td>
      </tr>
    </cfif>
  </table>
  </form>


<script language="JavaScript">
	function deshabilitarValidacion() {
		objForm.nombre_tipo.required = false;
	}
	
	function habilitarValidacion() {
		objForm.nombre_tipo.required = true;
		objForm.nombre_tipo.description = "Descripci�n";
	}	
	
	function deshabilitarDetalle() {
		objForm.nombre_atributo.required = false;
	}

	function habilitarDetalle() {
		objForm.nombre_atributo.required = true;
		objForm.nombre_atributo.description = "nombre del atributo";
	}
	
	function __isValida() {
		if(btnSelected("btnBorrarE")) {
			//Rodolfo Jimenez Jara, 10/12/2002
			// Valida que la Tabla de Tipo de Documento no tenga dependencias con otros.
			var msg = "";
			//alert(new Number(this.obj.form.HayMADocumento.value)); 
			if (new Number(this.obj.form.HayMADocumento.value) > 0) {
				msg = msg + " Cursos "
			}
			//alert(new Number(this.obj.form.HayHorarioAplica.value)); 
			/*if (new Number(this.obj.form.HayHorarioAplica.value) > 0) {
				msg = msg + " horarios "
			}*/
			if (msg != "")
			{
				this.error = "Usted no puede eliminar el tipo de documento '" + this.obj.form.nombre_tipo.value + "' porque �ste tiene asociado: " + msg + ".";
				//this.obj.form.nombre_tipo.focus();
			}
		}
	}
	function __isValidaDetalle() {
		if(btnSelected("btnBorrarD")) {
			//Rodolfo Jimenez Jara, 10/12/2002
			// Valida que la Tabla de Tipo de Documento no tenga dependencias con otros.
			var msg = "";
			//alert(new Number(this.obj.form.HayMAAtributoDocumento.value)); 
			if (new Number(this.obj.form.HayMAAtributoDocumento.value) > 0) {
				msg = msg + " Documentos "
			}
			if (msg != "")
			{
				this.error = "Usted no puede eliminar el Atributo '" + this.obj.form.nombre_atributo.value + "' porque �ste ya tiene asociado: " + msg + ".";
				//this.obj.form.nombre_atributo.focus();
			}
		}
		if(btnSelected("btnCambiarD")) {
			//Rodolfo Jimenez Jara, 10/12/2002
			// Valida que la Tabla de Tipo de Documento no tenga dependencias con otros.
			var msg = "";
			//alert(new Number(this.obj.form.HayMAAtributoDocumento.value)); 
			if (this.obj.form.tipo_atributo_ant.value != this.obj.form.tipo_atributo.value) {
				msg = msg + " Documentos "
			}
			if (msg != "")
			{
				this.error = "Usted no puede cambiar el tipo de Atributo '" + this.obj.form.nombre_atributo.value + "' porque �ste ya tiene asociado: " + msg + ".";
				//this.obj.form.nombre_atributo.focus();
			}
		}				
	}
	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isValida", __isValida);
	_addValidator("isValidaDetalle", __isValidaDetalle);
	objForm = new qForm("form1");
				

	

	<cfif modoDet EQ "ALTA">
		objForm.nombre_tipo.required = true;
		objForm.nombre_tipo.description = "Descripci�n";	
	<cfelse>
		objForm.nombre_tipo.required = true;
		objForm.nombre_tipo.description = "Descripci�n";	
		objForm.nombre_tipo.validateValida();
		<cfif modoDet EQ "ALTA">
			objForm.nombre_atributo.required = true;
			objForm.nombre_atributo.description = "Nombre del Atributo";
		<cfelse>
			objForm.nombre_atributo.required = true;
			objForm.nombre_atributo.description = "Nombre del Atributo";
			objForm.nombre_atributo.validateValidaDetalle();
			//objForm.nombre_atributo.validateValida();			
		</cfif>
	</cfif>	
			
</script>