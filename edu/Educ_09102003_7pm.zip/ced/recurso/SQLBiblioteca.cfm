<cfset action = "Biblioteca.cfm">
<!--- Rodolfo Jimenez Jara, Soluciones Integrales S.A., Costa Rica, America Central, 21/04/2003 --->
<cfif not isdefined("form.btnNuevoD") and  not isdefined("form.btnNuevoE")>
	<cftry>
		<cfset modo="CAMBIO">
		<cfquery name="ABC_Biblioteca" datasource="#Session.DSN#">
			set nocount on
			
			<!--- Caso 1: Agregar Encabezado --->
			<cfif isdefined("Form.btnAgregarE")>
				set nocount on
				if not exists ( select 1 from MATipoDocumento a
					where a.id_biblioteca = <cfqueryparam value="#Form.id_biblioteca#" cfsqltype="cf_sql_numeric">
					  and rtrim(ltrim(a.nombre_tipo)) = <cfqueryparam value="#Form.nombre_tipo#" cfsqltype="cf_sql_varchar">
				)
				begin
					insert MATipoDocumento (id_biblioteca, nombre_tipo)
						values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.id_biblioteca#">,
								<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.nombre_tipo#">
								)
					select @@identity as id
					set nocount off
				end
				else
					select 1
					<cfset modoDet="ALTA">
				
			<!--- Caso 1.1: Cambia Encabezado --->
			<cfelseif isdefined("Form.btnCambiarE")>
				update MATipoDocumento
				set nombre_tipo = <cfqueryparam value="#form.nombre_tipo#" cfsqltype="cf_sql_varchar">
				where id_tipo = <cfqueryparam value="#form.id_tipo#" cfsqltype="cf_sql_numeric">
				  and id_biblioteca=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.id_biblioteca#">
				  
				<cfset modoDet="ALTA">
				
			<!--- Caso 2: Borrar un Encabezado del Tipo de MAAtributo --->
			<cfelseif isdefined("Form.btnBorrarE")>			
				<cfif isdefined("Form.id_tipo") AND Form.id_tipo NEQ "" >
					delete MAAtributo 
					from  MAAtributo a , MATipoDocumento b
					where a.id_tipo=<cfqueryparam value="#form.id_tipo#" cfsqltype="cf_sql_numeric">				
					  and a.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
					  and a.id_tipo = b.id_tipo 
						 
					delete MATipoDocumento
					where id_tipo=<cfqueryparam value="#form.id_tipo#" cfsqltype="cf_sql_numeric">
					  
					<cfset action = "listaBiblioteca.cfm">
					<cfset modo = "ALTA">
					<cfset modoDet="ALTA">
				</cfif>

			<!--- Caso 3: Agregar Detalle de MAAtributo y opcionalmente modificar el encabezado --->
			<cfelseif isdefined("Form.btnAgregarD")>
				<cfif isdefined("Form.id_tipo") AND Form.id_tipo NEQ "" >
					if not exists ( select 1 from MAAtributo a
					where a.id_tipo = <cfqueryparam value="#Form.id_tipo#" cfsqltype="cf_sql_numeric">
					  and a.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
					  and rtrim(ltrim(a.nombre_atributo)) = <cfqueryparam value="#Form.nombre_atributo#" cfsqltype="cf_sql_varchar">
					)
					begin
						declare @cont int
						select @cont = isnull(max(a.orden_atributo),0)+10 
						from MAAtributo a
						where a.id_tipo = <cfqueryparam value="#Form.id_tipo#" cfsqltype="cf_sql_numeric">
						  and a.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
						  
						insert MAAtributo 
						(id_tipo, CEcodigo, nombre_atributo, orden_atributo, tipo_atributo)
						values (<cfqueryparam value="#form.id_tipo#" cfsqltype="cf_sql_numeric">,
								<cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">,
								<cfqueryparam value="#form.nombre_atributo#" cfsqltype="cf_sql_varchar">,
								<cfif len(trim(#Form.orden_atributo#)) NEQ 0 >
									<cfqueryparam value="#Form.orden_atributo#" cfsqltype="cf_sql_integer">,
								<cfelse>
									@cont,	
								</cfif>
								<cfqueryparam value="#form.tipo_atributo#" cfsqltype="cf_sql_char">)			
					
						<!--- Modificar Encabezado --->
						update MATipoDocumento
						set nombre_tipo = <cfqueryparam value="#form.nombre_tipo#" cfsqltype="cf_sql_varchar">
						where id_tipo = <cfqueryparam value="#form.id_tipo#" cfsqltype="cf_sql_numeric">
						  and id_biblioteca=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.id_biblioteca#">
					end
					else
						select 1
						<cfset modoDet="ALTA">
				</cfif>
				
			<!--- Caso 4: Modificar Detalle de Tabla de Evaluacion y modificar el encabezado --->			
			<cfelseif isdefined("Form.btnCambiarD")>
				if exists ( select 1 from MAAtributo a
					where a.id_atributo = <cfqueryparam value="#Form.id_atributo2#" cfsqltype="cf_sql_numeric">
					  and a.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
					  <!--- and rtrim(ltrim(a.nombre_atributo)) = <cfqueryparam value="#Form.nombre_atributo#" cfsqltype="cf_sql_varchar"> --->
					)
					begin
						declare @cont int
						select @cont = isnull(max(a.orden_atributo),0)+10 
						from MAAtributo a
						where a.id_atributo = <cfqueryparam value="#Form.id_atributo2#" cfsqltype="cf_sql_numeric">
						  and a.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
						  and id_atributo != <cfqueryparam value="#form.id_atributo2#" cfsqltype="cf_sql_numeric">
						  
						update MAAtributo
						set	nombre_atributo = <cfqueryparam value="#form.nombre_atributo#" cfsqltype="cf_sql_varchar">,
						
							<cfif len(trim(#Form.orden_atributo#)) NEQ 0 >
								orden_atributo = <cfqueryparam value="#form.orden_atributo#" cfsqltype="cf_sql_integer">,
							<cfelse>
								orden_atributo = @cont,	
							</cfif>
							tipo_atributo  = <cfqueryparam value="#form.tipo_atributo#" cfsqltype="cf_sql_char">
						from MAAtributo a , MATipoDocumento b					
						where a.id_tipo = <cfqueryparam value="#form.id_tipo#" cfsqltype="cf_sql_numeric">
						  and id_atributo = <cfqueryparam value="#form.id_atributo2#" cfsqltype="cf_sql_numeric">
						  and a.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
						  and a.id_tipo = b.id_tipo 
		
						<!--- Modificar Encabezado --->
						update MATipoDocumento
							set nombre_tipo = <cfqueryparam value="#form.nombre_tipo#" cfsqltype="cf_sql_varchar">
							where id_tipo = <cfqueryparam value="#form.id_tipo#" cfsqltype="cf_sql_numeric">
							  and id_biblioteca=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.id_biblioteca#">
					end
					else
						select 1				
					<cfset modoDet="CAMBIO">
				
			<!--- Caso 5: Borrar detalle de tabla de Evaluacion --->
			<cfelseif isdefined("Form.btnBorrarD")>
				delete MAAtributo 
				from MAAtributo a , MATipoDocumento b					
				where a.id_tipo = <cfqueryparam value="#form.id_tipo#" cfsqltype="cf_sql_numeric">
				  and id_atributo = <cfqueryparam value="#form.id_atributo2#" cfsqltype="cf_sql_numeric">
				  and a.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
				  and a.id_tipo = b.id_tipo 

								
				<cfset modoDet="ALTA">
			</cfif>
			
			set nocount off					
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>		
<cfelseif isdefined("form.btnNuevoD") and not  isdefined("form.btnNuevoE")>
		<cfset modo    = "CAMBIO">
		<cfset modoDet = "CAMBIO">
<cfelseif isdefined("form.btnNuevoE")>
  		<cfset modo    = "ALTA">
		<cfset modoDet = "ALTA">
</cfif>

<cfif isdefined("Form.btnAgregarE")>
	<cfset form.id_tipo = "#ABC_Biblioteca.id#">
</cfif>

<cfoutput>
<form action="#action#" method="post" name="sql">
	<input name="modo" type="hidden" value="<cfif isdefined("modo")>#modo#</cfif>">
	<input name="modoDet" type="hidden" value="<cfif isdefined("modoDet")>#modoDet#</cfif>">
	<cfif modo EQ "CAMBIO">
		<input name="id_tipo"   type="hidden" value="<cfif modo EQ "CAMBIO">#Form.id_tipo#</cfif>">
	</cfif>
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")>#Form.Pagina#</cfif>">
</form>
</cfoutput>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>
