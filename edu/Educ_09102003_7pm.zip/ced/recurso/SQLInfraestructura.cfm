<cfif not isdefined("Form.Nuevo")>
	<cftry>
		<cfquery name="ABC_Recurso" datasource="#Session.DSN#">
			set nocount on
			
			<cfif isdefined("Form.Alta")>
					insert into Recurso (CEcodigo, Rcodigo, Rdescripcion, Robservacion, Rcapacidad)
					values(
						<cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_numeric">,
						<cfqueryparam value="#Form.Rcodigo#" cfsqltype="cf_sql_varchar">,
						<cfqueryparam value="#Form.Rdescripcion#" cfsqltype="cf_sql_varchar">,
						<cfqueryparam value="#Form.Robservacion#" cfsqltype="cf_sql_text">,
						<cfif len(trim(Form.Rcapacidad)) NEQ 0>
							<cfqueryparam value="#Form.Rcapacidad#" cfsqltype="cf_sql_numeric">
						<cfelse>
							0	
						</cfif>
						)
					<cfset modo="ALTA">
			<cfelseif isdefined("Form.Baja")>
				if not exists (select 1 from HorarioGuia  
								where Rconsecutivo =  <cfqueryparam value="#Form.Rconsecutivo#" cfsqltype="cf_sql_numeric">
				)
				begin
					delete from Recurso
					where Rconsecutivo = <cfqueryparam value="#Form.Rconsecutivo#" cfsqltype="cf_sql_numeric">
				end
				else 
					select 1
				  <cfset modo="BAJA">
			<cfelseif isdefined("Form.Cambio")>
					update Recurso set
						Rcodigo	= <cfqueryparam value="#Form.Rcodigo#" cfsqltype="cf_sql_varchar">,
						Rdescripcion = ltrim(rtrim(<cfqueryparam value="#Form.Rdescripcion#" cfsqltype="cf_sql_varchar">)),
						Robservacion = ltrim(rtrim(<cfqueryparam value="#Form.Robservacion#" cfsqltype="cf_sql_text">)),
						<cfif len(trim(Form.Rcapacidad)) NEQ 0>
							Rcapacidad = <cfqueryparam value="#Form.Rcapacidad#" cfsqltype="cf_sql_numeric">
						<cfelse>
							Rcapacidad = 0	
						</cfif>	
					where Rconsecutivo = <cfqueryparam value="#Form.Rconsecutivo#" cfsqltype="cf_sql_numeric">
				  <cfset modo="CAMBIO">
			</cfif>
			set nocount off
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>
</cfif>
<form action="Infraestructura.cfm" method="post" name="sql">
	<input name="modo" type="hidden" value="<cfif isdefined("modo")><cfoutput>#modo#</cfoutput></cfif>">
	<input name="Rconsecutivo" type="hidden" value="<cfif isdefined("Form.Rconsecutivo")><cfoutput>#Form.Rconsecutivo#</cfoutput></cfif>">
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")><cfoutput>#Form.Pagina#</cfoutput></cfif>">
</form>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>
