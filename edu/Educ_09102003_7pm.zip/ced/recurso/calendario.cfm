<cfinclude template="../../Utiles/general.cfm">
<html><!-- InstanceBegin template="/Templates/LMenuCED.dwt.cfm" codeOutsideHTMLIsLocked="false" -->
<head>
<title>Educaci&oacute;n</title>
<meta http-equiv="Expires" content="Fri, Jan 01 1970 08:20:00 GMT">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Pragma" content="no-cache">
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
<link href="../../css/portlets.css" rel="stylesheet" type="text/css">
<link href="../../css/edu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
<script language="JavaScript" src="../../js/DHTMLMenu/stm31.js"></script>
<script language="JavaScript" type="text/javascript">
	// Funciones para Manejo de Botones
	botonActual = "";

	function setBtn(obj) {
		botonActual = obj.name;
	}
	function btnSelected(name, f) {
		if (f != null) {
			return (f["botonSel"].value == name)
		} else {
			return (botonActual == name)
		}
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="154" rowspan="2" align="center" valign="top"><img src="../../Imagenes/logo.gif" width="154" height="62"></td>
    <td valign="bottom"> 
	  <!-- InstanceBeginEditable name="Ubica" --> 
      <cfinclude template="../../portlets/pubica.cfm">
      <!-- InstanceEndEditable --> </td>
  </tr>
  <tr> 
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr class="area"> 
          <td width="275" valign="middle">
		  	<cfset RolActual = 4>
			<cfset Session.RolActual = 4>
			<cfinclude template="../../portlets/pEmpresas2.cfm">
		  </td>
          <td nowrap> 
            <div align="center"><span class="superTitulo">
			<font size="5">
	  <!-- InstanceBeginEditable name="Titulo" --> 
              Administraci&oacute;n del Centro de Estudio<!-- InstanceEndEditable -->	
			</font></span></div></td>
        </tr>
        <tr class="area" style="padding-bottom: 3px;"> 
		  <td nowrap style="padding-left: 10px;">
		  <cfinclude template="../../portlets/pminisitio.cfm">
		  </td>
          <td valign="top" nowrap> 
	  <!-- InstanceBeginEditable name="MenuJS" -->
	  		<cfinclude template="../jsMenuCED.cfm">
      <!-- InstanceEndEditable -->	
		  </td>
        </tr>
      </table>
	</td>
  </tr>
</table>
  
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="left" valign="top" nowrap></td>
    <td width="100%" height="1" align="left" valign="top"><!-- InstanceBeginEditable name="Titulo2" --><!-- InstanceEndEditable --></td>
  </tr>
  <tr> 
    <td valign="top" nowrap>
		<cfinclude template="/sif/menu.cfm">
	</td>
    <td valign="top" width="100%">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="2%"class="Titulo"><img  src="../../Imagenes/sp.gif" width="15" height="15" border="0"></td>
          <td width="3%" class="Titulo" >&nbsp;</td>
          <td width="94%" class="Titulo">
		  <!-- InstanceBeginEditable name="TituloPortlet" --> 
            Calendario Escolar<!-- InstanceEndEditable -->
		  </td>
          <td width="1%" valign="top" nowrap bgcolor="#ADADCA"><img src="../../Imagenes/rt.gif"></td>
        </tr>
        <tr> 
          <td colspan="3" class="contenido-lbborder">
		  <!-- InstanceBeginEditable name="Mantenimiento2" --> 
		  
			<cfif isdefined("Url.FechaIni") and not isdefined("Form.FechaIni")>
				<cfparam name="Form.FechaIni" default="#Url.FechaIni#">
			</cfif>
			<cfif isdefined("Url.FechaFin") and not isdefined("Form.FechaFin")>
				<cfparam name="Form.FechaFin" default="#Url.FechaFin#">
			</cfif>
			<cfif isdefined("Url.dia") and not isdefined("Form.dia")>
				<cfparam name="Form.dia" default="#Url.dia#">
			</cfif>
			<cfif isdefined("Url.anio") and not isdefined("Form.anio")>
				<cfparam name="Form.anio" default="#Url.anio#">
			</cfif>
            <!--- Consultas --->
            <cfquery datasource="#Session.DSN#" name="rsCalendario">
            	Select convert(varchar,Ccodigo) as Ccodigo from CentroEducativo where CEcodigo=
            	<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
            </cfquery>
			<cfinclude template="../../portlets/pNavegacionCED.cfm">
            <table width="100%" border="0">
              <tr> 
                <td valign="top"><table width="100%" border="0">
                    <tr> 
                      <td> <cfinclude template="filtros/filtroCalendario.cfm"> </td>
                    </tr>
                  </table>
                  <form name="formLimpiaCalendario" method="post" action="SQLCalendario.cfm">
                    <p> 
                      <input name="LimpiaCcodigo" id="LimpiaCcodigo" type="hidden" value="<cfoutput>#rsCalendario.Ccodigo#</cfoutput>" >
                    </p>
                    <table width="100%" border="1" cellspacing="1" cellpadding="1">				
                      <tr> 
                        <td>
							<table width="100%" border="0" cellspacing="0" cellpadding="0" class="area">
                            <tr> 
                              <td colspan="3" align="center" class="SubTitulo">Limpiado de Calendario</td>
                            </tr>
                            <tr> 
                              <td width="22%" align="center">A&ntilde;o</td>
                              <td width="37%"> <select name="LimpiAnio" id="LimpiAnio">
                                  <cfif isdefined("form.LimpiAnio") and #form.LimpiAnio# EQ "-1">
                                    <option value="-1" selected>-- Todos --</option>
                                    <cfelse>
                                    <option value="-1">-- Todos --</option>
                                  </cfif>
                                  <cfoutput query="rsAnio"> 
                                    <cfif isdefined("form.LimpiAnio") and #form.LimpiAnio# EQ #rsAnio.anio#>
                                      <option value="#rsAnio.anio#" selected>#rsAnio.anio#</option>
                                      <cfelseif not isdefined("form.LimpiAnio") and #rsAnio.anio# EQ Year(Now())>
                                      <option value="#rsAnio.anio#" selected>#rsAnio.anio#</option>
                                      <cfelse>
                                      <option value="#rsAnio.anio#">#rsAnio.anio#</option>
                                    </cfif>
                                  </cfoutput> </select> </td>
                              <td width="41%" align="center"><input name="btnLimpiaCalendario" type="submit" id="btnLimpiaCalendario" onClick="javascript: setBtn(this); return confirm('Esta seguro(a) que desea limpiar el calendario para el a�o seleccionado ?')" value="Limpiar"></td>
                            </tr>
                          </table></td>
                      </tr>
                    </table>
                    </form>
                  <table width="100%" border="0">
                    <tr> 
                      <td> 
					  	<cfset filtro = "">
						<cfset camposNav = ""> 
					  	<cfset navegacion = ""> 
					  
					  	<cfif isdefined("Form.FechaIni") AND #Form.FechaIni# NEQ "" >
                          <cfset filtro = #filtro# & " and CDfecha >= convert(datetime,'" & #form.FechaIni# &"',103)">
						  <cfset camposNav = #camposNav# & ",FechaIni='" & #form.FechaIni# & "'">
						  <cfset navegacion = navegacion & "&FechaIni=" & Form.FechaIni>
                        </cfif> 
						
						<cfif isdefined("Form.FechaFin") AND #Form.FechaFin# NEQ "" >
                          <cfset filtro = #filtro# & " and CDfecha <= convert(datetime,'" & #form.FechaFin# &"',103)">
						  <cfset camposNav = #camposNav# & ",FechaFin='" & #form.FechaFin# & "'">
						  <cfset navegacion = navegacion & "&FechaFin=" & Form.FechaFin>
                        </cfif> 
						
						<cfif isdefined("Form.dia") AND #Form.dia# NEQ "" AND #Form.dia# NEQ "-1">
                          <cfset filtro = #filtro# & " and CDferiado=" & #form.dia#>
                           <cfset camposNav = #camposNav# & ",dia=" & #form.dia#>						  
						  <cfset navegacion = navegacion & "&dia=" & Form.dia>
                        </cfif> 

						<cfif isdefined("Form.anio") AND #Form.anio# NEQ "" AND #Form.anio# NEQ "-1">
                          <!--- <cfset filtro = #filtro# & " and Datepart(yy,CDfecha) =" & #form.anio#> --->
						  <cfset filtro = #filtro# & " and (case CDabsoluto when 0 then datepart(yy,getDate()) else datepart(yy,CDfecha) end) = " & #Form.anio#>
                           <cfset camposNav = #camposNav# & ",anio=" & #form.anio#>
						  <cfset navegacion = navegacion & "&anio=" & Form.anio>
						<cfelseif not isdefined("Form.anio")>
						  <cfset filtro = #filtro# & " and (case CDabsoluto when 0 then datepart(yy,getDate()) else datepart(yy,CDfecha) end) = " & #Year(Now())#>
                           <cfset camposNav = #camposNav# & ",anio=" & #Year(Now())#>
						  <cfset navegacion = navegacion & "&anio=" & #Year(Now())#>
                        </cfif> 						
						<cfinvoke 
							 component="edu.Componentes.pListas"
							 method="pListaEdu"
							 returnvariable="pListaCalendarioDia">
                          <cfinvokeargument name="tabla" value="CalendarioDia"/>
                          <!--- <cfinvokeargument name="columnas" value="convert(varchar,CDcodigo) as CDcodigo,case CDabsoluto when 1 then '<img border=''0'' src=''../../Imagenes/educ/DSL_D.gif''>' when 0 then '' else '' end as CDabsoluto, case CDferiado when 1 then '<img border=''0'' src=''../../Imagenes/educ/DSL_D.gif''>' when 0 then '' else '' end as CDferiado,case when CDabsoluto=1 then convert(varchar,CDfecha,3) else convert(varchar,datepart(dd,CDfecha)) + ' de ' + substring('Enero    Febrero  Marzo    Abril    Mayo     Junio    Julio    Agosto   SetiembreOctubre  NoviembreDiciembre',(datepart(mm,CDfecha)-1)*9+1,9) end as Fecha,CDtitulo #camposNav#"/> --->
						  <cfinvokeargument name="columnas" value="convert(varchar,CDcodigo) as CDcodigo,case CDabsoluto when 1 then '<img border=''0'' src=''../../Imagenes/educ/DSL_D.gif''>' when 0 then '' else '' end as CDabsoluto, 
																	case CDferiado when 1 then '<img border=''0'' src=''../../Imagenes/educ/DSL_D.gif''>' when 0 then '' else '' end as CDferiado, 
																	case when CDabsoluto = 1 
																		then convert(varchar,datepart(dd,CDfecha)) + ' de ' + substring('Enero    Febrero  Marzo    Abril    Mayo     Junio    Julio    Agosto   SetiembreOctubre  NoviembreDiciembre',(datepart(mm,CDfecha)-1)*9+1,9) +  ' del ' + convert(varchar,datepart(yy,CDfecha)) 
																		else convert(varchar,datepart(dd,CDfecha)) + ' de ' + substring('Enero    Febrero  Marzo    Abril    Mayo     Junio    Julio    Agosto   SetiembreOctubre  NoviembreDiciembre',(datepart(mm,CDfecha)-1)*9+1,9) end as Fecha,
																	CDtitulo, datepart(dd,CDfecha) as DiaOrden, datepart(mm,CDfecha) as MesOrden, 
																	case CDabsoluto when 0 then datepart(yy,getDate()) else datepart(yy,CDfecha) end as AnoOrden #camposNav#"/>
						  <cfinvokeargument name="desplegar" value="Fecha,CDtitulo,CDferiado,CDabsoluto"/>
                          <cfinvokeargument name="etiquetas" value="Fecha,T&iacute;tulo,Feriado, Este A&ntilde;o"/>
                          <cfinvokeargument name="formatos" value=""/>
                          <cfinvokeargument name="filtro" value="Ccodigo = #rsCalendario.Ccodigo# #filtro# order by AnoOrden, MesOrden, DiaOrden" />
                          <cfinvokeargument name="align" value="left,left,center,center"/>
                          <cfinvokeargument name="ajustar" value="N"/>
                          <cfinvokeargument name="irA" value="calendario.cfm"/>
						  <cfinvokeargument name="navegacion" value="#navegacion#"/>
						  <cfinvokeargument name="debug" value="N"/>
                        </cfinvoke>
					   </td>
                    </tr>					
                  </table>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p></td>
                <td valign="top"> <cfinclude template="formCalendario.cfm"> </td>
              </tr>
            </table>
            <p>&nbsp;</p>
            <!-- InstanceEndEditable -->
		  </td>
          <td class="contenido-brborder">&nbsp;</td>
        </tr>
      </table>
	 </td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
