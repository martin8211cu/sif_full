<cfinclude template="/edu/Utiles/general.cfm">
<html><!-- InstanceBegin template="/Templates/LMenuCED.dwt.cfm" codeOutsideHTMLIsLocked="false" -->
<head>
<title>Educaci&oacute;n</title>
<meta http-equiv="Expires" content="Fri, Jan 01 1970 08:20:00 GMT">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Pragma" content="no-cache">
<!-- InstanceBeginEditable name="head" -->
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script><!-- InstanceEndEditable -->
<link href="../../css/portlets.css" rel="stylesheet" type="text/css">
<link href="../../css/edu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
<script language="JavaScript" src="../../js/DHTMLMenu/stm31.js"></script>
<script language="JavaScript" type="text/javascript">
	// Funciones para Manejo de Botones
	botonActual = "";

	function setBtn(obj) {
		botonActual = obj.name;
	}
	function btnSelected(name, f) {
		if (f != null) {
			return (f["botonSel"].value == name)
		} else {
			return (botonActual == name)
		}
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="154" rowspan="2" align="center" valign="top"><img src="../../Imagenes/logo.gif" width="154" height="62"></td>
    <td valign="bottom"> 
	  <!-- InstanceBeginEditable name="Ubica" --> 
      <cfinclude template="../../portlets/pubica.cfm">
      <!-- InstanceEndEditable --> </td>
  </tr>
  <tr> 
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr class="area"> 
          <td width="275" valign="middle">
		  	<cfset RolActual = 4>
			<cfset Session.RolActual = 4>
			<cfinclude template="../../portlets/pEmpresas2.cfm">
		  </td>
          <td nowrap> 
            <div align="center"><span class="superTitulo">
			<font size="5">
	  <!-- InstanceBeginEditable name="Titulo" --> 
              Administraci&oacute;n del Centro de Estudio<!-- InstanceEndEditable -->	
			</font></span></div></td>
        </tr>
        <tr class="area" style="padding-bottom: 3px;"> 
		  <td nowrap style="padding-left: 10px;">
		  <cfinclude template="../../portlets/pminisitio.cfm">
		  </td>
          <td valign="top" nowrap> 
	  <!-- InstanceBeginEditable name="MenuJS" -->
	  		<cfinclude template="../jsMenuCED.cfm">
      <!-- InstanceEndEditable -->	
		  </td>
        </tr>
      </table>
	</td>
  </tr>
</table>
  
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="left" valign="top" nowrap></td>
    <td width="100%" height="1" align="left" valign="top"><!-- InstanceBeginEditable name="Titulo2" --><!-- InstanceEndEditable --></td>
  </tr>
  <tr> 
    <td valign="top" nowrap>
		<cfinclude template="/sif/menu.cfm">
	</td>
    <td valign="top" width="100%">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="2%"class="Titulo"><img  src="../../Imagenes/sp.gif" width="15" height="15" border="0"></td>
          <td width="3%" class="Titulo" >&nbsp;</td>
          <td width="94%" class="Titulo">
		  <!-- InstanceBeginEditable name="TituloPortlet" -->Recurso 
            Humano <!-- InstanceEndEditable -->
		  </td>
          <td width="1%" valign="top" nowrap bgcolor="#ADADCA"><img src="../../Imagenes/rt.gif"></td>
        </tr>
        <tr> 
          <td colspan="3" class="contenido-lbborder">
		  <!-- InstanceBeginEditable name="Mantenimiento2" -->
			<table width="100%" border="0">
			  <tr>
				<td>
					<cfinclude template="../../portlets/pNavegacionCED.cfm">				
				</td>
			  </tr>
			  <tr>
				<td>
					<cfinclude template="formRh.cfm">
				</td>
			  </tr>
			  <tr>
				<td>
					<cfinclude template="filtros/filtroRh.cfm">
				</td>
			  </tr>
			  
						<!--- ============================================================== --->
						<!---  Creacion del filtro --->
						<!--- ============================================================== --->
 
						 <cfset f1 = "">
						 <cfset f2 = "">
						 <cfset f3 = "-1">
						 <cfset filtro = "">
						 <cfset navegacion = "">

						<cfif isdefined("Form.filtroTipo") AND #Form.filtroTipo# NEQ "-1" >
							<cfif #form.filtroTipo# EQ 'A'> <!--- Asistente --->
								<cfset tablas = "PersonaEducativo a, Pais b, Asistente c">
							<cfelseif #form.filtroTipo# EQ 'D'>	<!--- Staff - Docente --->
								<cfset tablas = "PersonaEducativo a, Pais b, Staff c">
							<cfelseif #form.filtroTipo# EQ 'E'>	<!--- Encargado --->
								<cfset tablas = "PersonaEducativo a, Pais b, Encargado c">
							<cfelseif #form.filtroTipo# EQ 'DR'>	<!--- Director --->
								<cfset tablas = "PersonaEducativo a, Pais b, Director c">
							</cfif>
							<cfset filtroTipo = " and a.persona=c.persona">							
							<cfset f3 = Form.filtroTipo>
							<cfset navegacion = "filtroTipo=" & Form.filtroTipo>							
						<cfelse>						
							<cfset f3 = '-1'>
							<cfset navegacion = "filtroTipo=-1">													
							<cfset tablas = "PersonaEducativo a, Pais b, Staff s">
							<cfset filtroTipo = "">
						</cfif>
												
						<cfset alumnos = "	select persona from Alumnos
											where CEcodigo=#Session.CEcodigo# 
											and persona not in (select persona from Asistente where CEcodigo = #Session.CEcodigo# )
											and persona not in (select persona from Staff where CEcodigo = #Session.CEcodigo# )
											and persona not in (select a.persona from Encargado a, PersonaEducativo b
												where CEcodigo=#Session.CEcodigo# 
												and a.persona=b.persona)
											and persona not in (select a.persona from Director  a, PersonaEducativo b
												where CEcodigo=#Session.CEcodigo# 
												and a.persona=b.persona)">						
												
<!--- 							<cfset navegacion = navegacion & Iif(Len(Trim(navegacion)) NEQ 0, DE("&"), DE("")) & "FNcodigo=" & Form.FNcodigo>						 --->																			
												
						<cfif isdefined("Form.fRHnombre") AND #Form.fRHnombre# NEQ "" >
							<cfset filtro = #filtro# &" and upper((a.Pnombre + ' ' + Papellido1 + ' ' + Papellido2)) like upper('%" & #Form.fRHnombre# & "%')">							
							<cfset f1 = Form.fRHnombre>
							<cfset navegacion = "fRHnombre=" & Form.fRHnombre>														
						</cfif>							
						<cfif isdefined("Form.filtroRhPid") AND #Form.filtroRhPid# NEQ "">
							<cfset filtro = #filtro# &" and upper(Pid) like upper('%" & #Form.filtroRhPid# & "%')">
							<cfset f2 = Form.filtroRhPid>
							<cfset navegacion = "filtroRhPid=" & Form.filtroRhPid>																					
						</cfif>

						<cfif isdefined("Form.Busca") AND #Form.Busca# NEQ "">  <!--- Parametros pasados cuando se busca desde el mantenimiento --->								
							<cfif isdefined("Form.Pnombre") AND #Form.Pnombre# NEQ "">
								<cfset filtro = #filtro# &" and upper(a.Pnombre) like upper('%" & #Form.Pnombre# & "%')">														
							</cfif>
							<cfif isdefined("Form.Papellido1") AND #Form.Papellido1# NEQ "">
								<cfset filtro = #filtro# &" and upper(Papellido1) like upper('%" & #Form.Papellido1# & "%')">																					
							</cfif>								
							<cfif isdefined("Form.Papellido2") AND #Form.Papellido2# NEQ "">
								<cfset filtro = #filtro# &" and upper(Papellido2) like upper('%" & #Form.Papellido2# & "%')">																												
							</cfif>
							<cfif isdefined("Form.Pid") AND #Form.Pid# NEQ "">
								<cfset filtro = #filtro# &" and upper(Pid) like upper('%" & #Form.Pid# & "%')">							
							</cfif>
							<cfif isdefined("Form.Pdireccion") AND #Form.Pdireccion# NEQ "">
								<cfset filtro = #filtro# &" and upper(Pdireccion) like upper('%" & #Form.Pdireccion# & "%')">															
							</cfif>
							<cfif isdefined("Form.Pcasa") AND #Form.Pcasa# NEQ "">
								<cfset filtro = #filtro# &" and upper(Pcasa) like upper('%" & #Form.Pcasa# & "%')">																							
							</cfif>
							<cfif isdefined("Form.Poficina") AND #Form.Poficina# NEQ "">
								<cfset filtro = #filtro# &" and upper(Poficina) like upper('%" & #Form.Poficina# & "%')">																															
							</cfif>
							<cfif isdefined("Form.Pcelular") AND #Form.Pcelular# NEQ "">
								<cfset filtro = #filtro# &" and upper(Pcelular) like upper('%" & #Form.Pcelular# & "%')">																																							
							</cfif>
							<cfif isdefined("Form.Pfax") AND #Form.Pfax# NEQ "">
								<cfset filtro = #filtro# &" and upper(Pfax) like upper('%" & #Form.Pfax# & "%')">																																															
							</cfif>
							<cfif isdefined("Form.Ppagertel") AND #Form.Ppagertel# NEQ "">
								<cfset filtro = #filtro# &" and upper(Ppagertel) like upper('%" & #Form.Ppagertel# & "%')">																																																							
							</cfif>
							<cfif isdefined("Form.Ppagernum") AND #Form.Ppagernum# NEQ "">
								<cfset filtro = #filtro# &" and upper(Ppagernum) like upper('%" & #Form.Ppagernum# & "%')">																																																															
							</cfif>
							<cfif isdefined("Form.Pemail1") AND #Form.Pemail1# NEQ "">
								<cfset filtro = #filtro# &" and upper(Pemail1) like upper('%" & #Form.Pemail1# & "%')">																																																							
							</cfif>
							<cfif isdefined("Form.Pemail2") AND #Form.Pemail2# NEQ "">
								<cfset filtro = #filtro# &" and upper(Pemail2) like upper('%" & #Form.Pemail2# & "%')">																																																																							
							</cfif>
						</cfif>							
						<!--- ============================================================== --->
			  <tr>
				<td>
				
											
				<cfif  isdefined("Form.filtroTipo") and #Form.filtroTipo# NEQ "-1">
					<cfinvoke 
					 component="edu.Componentes.pListas"
					 method="pListaEdu"
					 returnvariable="pListaPlanEvalDet">
						<cfinvokeargument name="tabla" value="#tablas#"/>
 						<cfinvokeargument name="columnas" value="distinct rtrim('#f1#') as fRHnombre,rtrim('#f2#') as filtroRhPid,'#f3#' as filtroTipo,a.persona,( Papellido1 + ' ' + Papellido2 + ' ' + a.Pnombre  ) as nombre,b.Pnombre,convert(varchar,Pnacimiento,103) as Pnacimiento, Pid, 'Docente' as Rol"/> 
						<cfinvokeargument name="desplegar" value="nombre,Pnombre, Pid, Pnacimiento"/>
						<cfinvokeargument name="etiquetas" value="Nombre,Pa&iacute;s,N. Identificaci&oacute;n,Fecha de Nacimiento"/>
						<cfinvokeargument name="formatos" value="V,V,V,V"/>
						<cfinvokeargument name="filtro" value="a.CEcodigo = #Session.CEcodigo# 
						                                   and a.Ppais=b.Ppais 
														   #filtroTipo# 
														   and a.persona not in 
														   (#alumnos#) 
														   #filtro# 
														   order by nombre" />
						<cfinvokeargument name="align" value="left,center,center,center"/>
						<cfinvokeargument name="ajustar" value="N"/>
						<cfinvokeargument name="checkboxes" value="n"/>
						<cfinvokeargument name="irA" value="rh.cfm"/>
						<cfinvokeargument name="navegacion" value="#navegacion#"/>
						<cfinvokeargument name="debug" value="N"/>
					</cfinvoke>	
					
				<cfelse>
					<cfset filtroTipo = "">
					<cfset cols = "rtrim('#f1#') as fRHnombre,rtrim('#f2#') as filtroRhPid,'#f3#' as filtroTipo,a.persona,( Papellido1 + ' ' + Papellido2 + ' ' + a.Pnombre  ) as nombre,b.Pnombre,convert(varchar,Pnacimiento,103) as Pnacimiento, Pid">
					<cfset filtroDocente = "">
					<cfset RolDocente   = ' select distinct ' & #cols#  & ", 'Docente'   as Rol ">
					<cfset filtroAsistente = "">
					<cfset RolAsistente = ' select distinct ' & #cols#  & ", 'Asistente' as Rol ">
					<cfset filtroAsistente = "  from PersonaEducativo a, Pais b, Asistente asist 
												where a.CEcodigo = #Session.CEcodigo# 
						                                   and a.Ppais=b.Ppais 
														   and a.persona = asist.persona														   
														   #filtroTipo# 
														   and a.persona not in 
														   (#alumnos#) 
														   #filtro#  ">
														   
					<cfset RolDirector = ' select distinct ' & #cols#  & ", 'Director' as Rol ">
					<cfset filtroDirector = "  from PersonaEducativo a, Pais b, Director dir 
												where a.CEcodigo = #Session.CEcodigo# 
						                                   and a.Ppais=b.Ppais 
														   and a.persona = dir.persona														   
														   #filtroTipo# 
														   and a.persona not in 
														   (#alumnos#) 
														   #filtro#  ">
				<cfset RolEncargado = ' select distinct ' & #cols#  & ", 'Encargado' as Rol ">
					<cfset filtroEncargado = "  from PersonaEducativo a, Pais b, Encargado e 
												where a.CEcodigo = #Session.CEcodigo# 
						                                   and a.Ppais=b.Ppais 
														   and a.persona = e.persona														   
														   #filtroTipo# 
														   and a.persona not in 
														   (#alumnos#) 
														   #filtro#  ">														   
					
					<!--- Muestra la columna rol --->
					<cfinvoke 
					 component="edu.Componentes.pListas"
					 method="pListaEdu"
					 returnvariable="pListaPlanEvalDet">
						<cfinvokeargument name="tabla" value="#tablas#"/>
 						<cfinvokeargument name="columnas" value="distinct #cols#, 'Docente' as Rol"/> 
						<cfinvokeargument name="desplegar" value="nombre,Pnombre, Pid, Pnacimiento "/>
						<cfinvokeargument name="etiquetas" value="Nombre,Pa&iacute;s,N. Identificaci&oacute;n,Fecha de Nacimiento"/>
						<cfinvokeargument name="formatos" value="V,V,V,V"/>
						<cfinvokeargument name="filtro" value="  a.CEcodigo = #Session.CEcodigo# 
						                                   and a.Ppais=b.Ppais 
														   and a.persona = s.persona														   
														   #filtroTipo# 
														   and a.persona not in 
														   (#alumnos#) 
														   #filtro#  
														   union all
														   #RolAsistente#
														   #filtroAsistente#
														   union all
														   #RolDirector#
														   #filtroDirector#
														   union all
														   #RolEncargado#
														   #filtroEncargado#
														 
														   order by Rol ,nombre" />
						<cfinvokeargument name="align" value="left,center,center,center"/>
						<cfinvokeargument name="ajustar" value="N"/>
						<cfinvokeargument name="checkboxes" value="n"/>
						<cfinvokeargument name="irA" value="rh.cfm"/>
						<cfinvokeargument name="navegacion" value="#navegacion#"/>
						<cfinvokeargument name="debug" value="N"/>
						<cfinvokeargument name="Cortes" value="Rol"/>						
					</cfinvoke>	
					 <!---  --->
				</cfif>						
						

				</td>
			  </tr>
			</table>
          <!-- InstanceEndEditable -->
		  </td>
          <td class="contenido-brborder">&nbsp;</td>
        </tr>
      </table>
	 </td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
