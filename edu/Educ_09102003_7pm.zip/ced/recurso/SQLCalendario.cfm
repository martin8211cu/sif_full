<cfparam name="action" default="calendario.cfm">

<cfif isdefined("form.btnAgregar") or isdefined("form.btnCambiar") or isdefined("form.btnBorrar") or isdefined("form.btnLimpiaCalendario")>
	<cftry>
		<cfquery name="ABC_Calendario" datasource="sdc">
			set nocount on
			
			<!--- Caso 1: Agregar --->
			<cfif isdefined("Form.btnAgregar")>
					insert CalendarioDia 
						(Ccodigo, CDferiado, CDfecha, CDtitulo, CDdescripcion, CDabsoluto)
					values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.Ccodigo#">,
							<cfif isdefined("form.CDferiado") and #form.CDferiado# NEQ "">
								<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.CDferiado#">,
							<cfelse>
								0,
							</cfif>
							convert( datetime, <cfqueryparam value="#form.CDfecha#" cfsqltype="cf_sql_varchar">, 103 ),																									
							<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.CDtitulo#">,
							<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.CDdescripcion#">,
							<cfif isdefined("form.CDabsoluto") and #form.CDabsoluto# NEQ "">
								<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.CDabsoluto#">)							
							<cfelse>
								0)
							</cfif>								
							
					select convert(varchar,@@identity) as id						
				<cfset action = "calendario.cfm">
				<cfset modo="CAMBIO">
				
			<!--- Caso 2: Cambio --->
			<cfelseif isdefined("Form.btnCambiar") and isdefined("form.CDcodigo") and #form.CDcodigo# NEQ "">
				update CalendarioDia set 
					CDferiado=
								<cfif isdefined("form.CDferiado") and #form.CDferiado# NEQ "">
									<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.CDferiado#">,
								<cfelse>
									0,
								</cfif>
					CDfecha=convert( datetime, <cfqueryparam value="#form.CDfecha#" cfsqltype="cf_sql_varchar">, 103 ),
					CDtitulo=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.CDtitulo#">,
					CDdescripcion=<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.CDdescripcion#">,
					CDabsoluto=
								<cfif isdefined("form.CDabsoluto") and #form.CDabsoluto# NEQ "">
									<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.CDabsoluto#">							
								<cfelse>
									0
								</cfif>	
				where CDcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.CDcodigo#">			
			
				<cfset action = "calendario.cfm">								
				<cfset modo="CAMBIO">
				
			<!--- Caso 4: Borrar --->
			<cfelseif isdefined("Form.btnBorrar")>			
				<cfif isdefined("Form.CDcodigo") AND #Form.CDcodigo# NEQ "" >
					delete CalendarioDia 
					where CDcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.CDcodigo#">				
					
					<cfset modo="ALTA">									
				</cfif>
				
			<!--- Caso 5: Limpiar Calendario del form = formLimpiaCalendario--->
			<cfelseif isdefined("Form.btnLimpiaCalendario")>			
				<cfif isdefined("Form.LimpiaCcodigo") AND #Form.LimpiaCcodigo# NEQ "" >
					delete CalendarioDia
					where CDabsoluto=1
						and Ccodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.LimpiaCcodigo#">				
						<cfif isdefined("Form.LimpiAnio") AND #Form.LimpiAnio# NEQ "-1" >
							and datepart(yy,CDfecha) = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.LimpiAnio#">
						</cfif>
						
					<cfset modo="ALTA">									
				</cfif>												
			</cfif>
			
			set nocount off					
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>		
<cfelse> 
	<cfset action = "calendario.cfm" >
	<cfset modo   = "ALTA" >
</cfif>

<cfif isdefined("form.CDcodigo") AND #form.CDcodigo# EQ "" and isdefined("form.btnAgregar")>
	<cfset #form.CDcodigo# = "#ABC_Calendario.id#">
</cfif>

<cfoutput>
<form action="#action#" method="post" name="sql">
	<input name="modo"   type="hidden" value="<cfif isdefined("modo")>#modo#</cfif>">
	<input name="CDcodigo"   type="hidden" value="<cfif isdefined("Form.CDcodigo")>#form.CDcodigo#</cfif>">
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")>#Form.Pagina#</cfif>">		
</form>
</cfoutput>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>