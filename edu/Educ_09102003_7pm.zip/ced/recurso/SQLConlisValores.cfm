<cfset action = "ConlisValores.cfm">
<!--- Rodolfo Jimenez Jara, Soluciones Integrales S.A., Costa Rica, America Central, 22/04/2003 --->
<cfif not isdefined("form.btnNuevo")>
	<cftry>
		<cfset modo="CAMBIO">
		<cfquery name="ABC_Valores" datasource="#Session.DSN#">
			set nocount on
			
			<!--- Caso 1: Agregar Encabezado --->
			<cfif isdefined("Form.btnAgregar")>
				set nocount on
				if not exists ( select 1 from MAValorAtributo a
					where a.id_atributo = <cfqueryparam value="#Form.id_tipo2#" cfsqltype="cf_sql_numeric">
					  and rtrim(ltrim(a.contenido)) = <cfqueryparam value="#Form.contenido#" cfsqltype="cf_sql_varchar">
				)
				begin
					declare @cont int
					select @cont = isnull(max(a.orden_valor),0)+10 
					from MAValorAtributo a, MAAtributo b
					where a.id_atributo = <cfqueryparam value="#Form.id_tipo2#" cfsqltype="cf_sql_numeric">
					  and b.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
					  and a.id_atributo = b.id_atributo 
					  
					insert MAValorAtributo (id_atributo, contenido, orden_valor)
						values (<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.id_tipo2#">,
								<cfqueryparam cfsqltype="cf_sql_varchar" value="#form.contenido#">,
								<cfif len(trim(#Form.orden_valor#)) NEQ 0 >
									<cfqueryparam value="#Form.orden_valor#" cfsqltype="cf_sql_integer">
								<cfelse>
									@cont	
								</cfif>
								)
					select @@identity as id
					set nocount off
				end
				else
					select 1
					<cfset modo="ALTA">
				
			<!--- Caso 1.1: Cambia Encabezado --->
			<cfelseif isdefined("Form.btnCambiar")>
				declare @cont int
				select @cont = isnull(max(a.orden_valor),0)+10 
				from MAValorAtributo a, MAAtributo b
				where a.id_atributo = <cfqueryparam value="#Form.id_tipo2#" cfsqltype="cf_sql_numeric">
				  and b.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
				  and id_valor != <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.id_valor2#">
				  and a.id_atributo = b.id_atributo 
				  
				update MAValorAtributo
				set contenido = <cfqueryparam value="#form.contenido#" cfsqltype="cf_sql_varchar">,
					<cfif len(trim(#Form.orden_valor#)) NEQ 0 >
						orden_valor = <cfqueryparam value="#Form.orden_valor#" cfsqltype="cf_sql_integer">
					<cfelse>
						orden_valor = @cont	
					</cfif>
				where id_atributo = <cfqueryparam value="#form.id_tipo2#" cfsqltype="cf_sql_numeric">
				  and id_valor=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.id_valor2#">
				  
			 	update MAAtributoDocumento
				set valor = <cfqueryparam value="#form.contenido#" cfsqltype="cf_sql_varchar">
				where id_atributo = <cfqueryparam value="#form.id_tipo2#" cfsqltype="cf_sql_numeric">
				  and id_valor=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.id_valor2#">
				  
				<cfset modo="ALTA">
				
			<!--- Caso 2: Borrar un Encabezado del Tipo de MAAtributo --->
			<cfelseif isdefined("Form.btnBorrar")>			
				<cfif isdefined("Form.id_tipo2") AND Form.id_tipo2 NEQ "" >
					delete MAValorAtributo 
					where id_atributo = <cfqueryparam value="#form.id_tipo2#" cfsqltype="cf_sql_numeric">
				  	  and id_valor=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.id_valor2#">
					  
					<cfset action = "ConlisValores.cfm">
					<cfset modo = "ALTA">
					
				</cfif>
			</cfif>
			set nocount off					
		</cfquery>
	<cfcatch type="any">
		<cfinclude template="../../errorPages/BDerror.cfm">
		<cfabort>
	</cfcatch>
	</cftry>		
<cfelse> 
	<cfset modo = "ALTA">
</cfif>

<cfif isdefined("Form.btnAgregar")>
	<cfset form.id_tipo = "#ABC_Valores.id#">
</cfif>

<cfoutput>
<form action="#action#" method="post" name="sql">
	<input name="modo" type="hidden" value="<cfif isdefined("modo")>#modo#</cfif>">
	<input name="id_tipo"   type="hidden" value="#Form.id_tipo2#">
	<input name="nombre"   type="hidden" value="#Form.nombre#">
	<cfif modo EQ "CAMBIO">
		<input name="id_valor" type="hidden" value="#Form.id_valor2#">
	</cfif> 
	<input name="Pagina" type="hidden" value="<cfif isdefined("Form.Pagina")>#Form.Pagina#</cfif>">
</form>
</cfoutput>

<HTML>
<head>
</head>
<body>
<script language="JavaScript1.2" type="text/javascript">document.forms[0].submit();</script>
</body>
</HTML>
