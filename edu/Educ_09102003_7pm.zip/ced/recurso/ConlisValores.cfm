<?xml version="1.0" encoding="iso-8859-1"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Mantenimiento de Valores de Atributos</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<!--- Rodolfo Jimenez Jara, Soluciones Integrales S.A., Costa Rica, America Central, 22/04/2003 --->
<cfif isdefined("Form.id_valor")>
	<cfset Form.id_valor = Form.id_valor>
</cfif>
<cfif isdefined("Form.id_valor")>
	<cfset Form.id_valor2 = Form.id_valor>
</cfif>
<cfif isdefined("Form.id_atrib")>
	<cfset Form.id_atrib = Form.id_atrib>
	<cfset Form.id_tipo = Form.id_atrib>
</cfif>

<cfif isdefined("Url.id_tipo") and not isdefined("Form.id_tipo")>
	<cfset Form.id_tipo = Url.id_tipo>
</cfif>
<cfif isdefined("Url.id_valor") and not isdefined("Form.id_valor")>
	<cfset Form.id_valor = Url.id_valor>
</cfif>

<cfif isdefined("Url.nombre") and not isdefined("Form.nombre")>
	<cfset Form.nombre = Url.nombre>
</cfif>

<cfif isdefined("Form.Cambio")>
	<cfset modo="CAMBIO">
<cfelse>
	<cfif not isdefined("Form.modo")>
		<cfset modo="ALTA">
	<cfelseif Form.modo EQ "CAMBIO">
		<cfset modo="CAMBIO">
	<cfelse>
		<cfset modo="ALTA">
	</cfif>
</cfif>
	<cfif modo NEQ 'ALTA' and isdefined("Form.id_valor") >
		<!--- 1. Form --->	
		<cfquery datasource="#Session.DSN#" name="rsMAValorAtributo">
			select convert(varchar,b.id_atributo) as  id_atributo,  substring(contenido,1,35) as contenido, orden_valor 
			from MAValorAtributo a, MAAtributo b
			where  b.CEcodigo = <cfqueryparam value="#Session.CEcodigo#" cfsqltype="cf_sql_integer">
			  and a.id_atributo = b.id_atributo 
				<cfif isdefined("Form.id_valor") AND Form.id_valor NEQ "" >
				  and a.id_valor =<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.id_valor#">
				</cfif>
				<cfif isdefined("Form.id_atrib") AND Form.id_atrib NEQ "" >
				  and a.id_atributo =<cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.id_atrib#">
				</cfif>
		</cfquery>
	
		<cfquery datasource="#Session.DSN#" name="rsHayMAAtributoDocumento">
			<!--- Existen dependencias con MAAtributoDocumento--->
			select isnull(1,0) from MAAtributoDocumento a, MAValorAtributo b
			where a.id_atributo= <cfqueryparam value="#form.id_tipo#" cfsqltype="cf_sql_numeric">
			  <cfif isdefined("Form.id_valor") AND Form.id_valor NEQ "" >
			    and b.id_valor= <cfqueryparam value="#form.id_valor#" cfsqltype="cf_sql_numeric">
			  </cfif>
			  and a.id_valor = b.id_valor 
		</cfquery> 
	</cfif>
	<script language="JavaScript" type="text/javascript">
		// Funciones para Manejo de Botones
		botonActual = "";
	
		function setBtn(obj) {
			botonActual = obj.name;
		}
		function btnSelected(name, f) {
			if (f != null) {
				return (f["botonSel"].value == name)
			} else {
				return (botonActual == name)
			}
		}
	</script>
	
<script language="JavaScript1.4" type="text/javascript" src="../../js/utilesMonto.js" >//</script>
<script language="JavaScript" src="../../js/qForms/qforms.js"></script>
<script language="JavaScript" type="text/JavaScript">

	// specify the path where the "/qforms/" subfolder is located
	qFormAPI.setLibraryPath("../../js/qForms/");
	// loads all default libraries
	qFormAPI.include("*");
</script>	

<form name="form1" method="post" action="SQLConlisValores.cfm">
 <cfoutput> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr align="center" class="subTitulo"> 
      <td colspan="6" class="tituloAlterno" style="background-color: ##F5F5F5; font-weight: bold"> 
	  
	  	<strong>Nombre del Atributo: #Form.nombre#</strong>
		<input name="nombre" id="nombre" value="#Form.nombre#" type="hidden" />
	  </td>
    </tr>
	<tr>
		<td colspan="6">&nbsp;
			
		</td>
	</tr>
    <tr> 
      <td colspan="2" rowspan="4"> 
          <cfif isdefined("Form.id_tipo")  >
            <input name="id_tipo2" id="id_tipo2" value="#Form.id_tipo#" type="hidden" />
            <cfelseif isdefined("Form.id_atrib")>
            <input name="id_tipo22" id="id_tipo2" value="#Form.id_atrib#" type="hidden" />
          </cfif>
          <cfif modo NEQ 'ALTA' and isdefined("Form.id_valor")>
            <input type="hidden" name="HayMAAtributoDocumento" value="<cfif #rsHayMAAtributoDocumento.recordCount# GT 0>#rsHayMAAtributoDocumento.recordCount#<cfelse>0</cfif>" />
          </cfif>
	   	<cfif modo NEQ 'ALTA' and isdefined("Form.id_valor")>
            <input name="id_valor2" id="id_valor2" value="#Form.id_valor#" type="hidden" />
        </cfif>
         
        </cfoutput> <cfinvoke 
			 component="edu.Componentes.pListas"
			 method="pListaEdu"
			 returnvariable="pListaPlanEvalDet">
          <cfinvokeargument name="tabla" value="MAValorAtributo a,  MAAtributo b"/>
          <cfinvokeargument name="columnas" value=" convert(varchar,a.id_valor) as id_valor, convert(varchar,a.id_atributo) as id_atrib, substring(a.contenido,1,35) as contenido2, a.orden_valor as orden_val"/>
          <cfinvokeargument name="desplegar" value="contenido2, orden_val"/>
          <cfinvokeargument name="etiquetas" value="Contenido, Orden"/>
          <cfinvokeargument name="formatos" value=""/>
          <cfinvokeargument name="filtro" value=" b.CEcodigo = #Session.CEcodigo# and a.id_atributo = #form.id_tipo# and a.id_atributo = b.id_atributo order by a.orden_valor, a.contenido"/>
          <cfinvokeargument name="align" value="left,right"/>
          <cfinvokeargument name="ajustar" value="N,N"/>
          , 
          <cfinvokeargument name="irA" value="ConlisValores.cfm"/>
          <cfinvokeargument name="incluyeForm" value="false"/>
          <cfinvokeargument name="formName" value="form1"/>
        </cfinvoke></td>
      <td width="15%" align="right" nowrap>Contenido &nbsp </td>
      <td colspan="3"> <input name="contenido" type="text" id="contenido" tabindex="1" size="30" maxlength="80" onfocus="javascript:this.select();" value="<cfif modo NEQ 'ALTA'><cfoutput>#rsMAValorAtributo.contenido#</cfoutput></cfif>" /></td>
    </tr>
    <tr> 
      <td align="right" nowrap>Orden &nbsp </td>
      <td colspan="3" nowrap> <cfoutput> 
          <input name="orden_valor" align="left" tabindex="1" type="text" id="orden_valor" size="8" maxlength="8" value="<cfif modo NEQ "ALTA">#rsMAValorAtributo.orden_valor#</cfif>" onfocus="this.value=qf(this); this.select();" onblur="fm(this,0);"  onkeyup="if(snumber(this,event,0)){ if(Key(event)=='13') {this.blur();}}" />
        </cfoutput> </td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td width="14%">&nbsp;</td>
      <td width="14%">&nbsp;</td>
      <td width="17%">&nbsp;</td>
    </tr>
    <tr> 
      <td colspan="4" align="center"> <cfif modo EQ "ALTA">
          <input type="submit" name="btnAgregar" tabindex="1" value="Agregar" onclick="javascript: setBtn(this);" />
          <cfelseif modo NEQ "ALTA">
          <input type="submit" name="btnCambiar" tabindex="1" value="Modificar Valor" onclick="javascript: setBtn(this);  habilitarValidacion();" />
          <input type="submit" name="btnBorrar" tabindex="1" value="Borrar Valor" onclick="javascript: setBtn(this); deshabilitarValidacion();  return confirm('�Esta seguro(a) que desea borrar este Valor?');" />
          <input type="submit" name="btnNuevo" tabindex="1" value="Nuevo Valor" onclick="javascript: setBtn(this);  deshabilitarValidacion();" />
        </cfif> <input type="button" name="btnSalir" tabindex="1" value="    Salir    " onclick="javascript: window.close();" /> 
      </td>
    </tr>
  </table>
</form>
<script language="JavaScript">
	function deshabilitarValidacion() {
		objForm.contenido.required = false;
	}
	
	function habilitarValidacion() {
		objForm.contenido.required = true;
		objForm.contenido.description = "Contenido";
	}	
	
	
	function __isValida() {
		if(btnSelected("btnBorrar")) {
			//Rodolfo Jimenez Jara, 22/04/2003, SOIN Central America.
			// Valida que la Tabla de MAValorAtributo tenga dependencias con otros.
			var msg = "";
			//alert(new Number(this.obj.form.HayMADocumento.value)); 
			if (new Number(this.obj.form.HayMAAtributoDocumento.value) > 0) {
				msg = msg + " Documentos "
			}
			//alert(new Number(this.obj.form.HayHorarioAplica.value)); 
			/*if (new Number(this.obj.form.HayHorarioAplica.value) > 0) {
				msg = msg + " horarios "
			}*/
			if (msg != "")
			{
				this.error = "Usted no puede eliminar el atributo '" + this.obj.form.contenido.value + "' porque �ste tiene asociado: " + msg + ".";
				//this.obj.form.contenido.focus();
			}
		}
	}
	
	qFormAPI.errorColor = "#FFFFCC";
	_addValidator("isValida", __isValida);
	
	objForm = new qForm("form1");
				
	objForm.contenido.validateValida();
	
	<cfif modo EQ "ALTA">
		objForm.contenido.required = true;
		objForm.contenido.description = "Contenido";	
	<cfelseif modo EQ "CAMBIO">
		objForm.contenido.required = true;
		objForm.contenido.description = "Contenido";	
	<cfelse>
		objForm.contenido.required = false;
	</cfif>	

</script>
</body>
</html>