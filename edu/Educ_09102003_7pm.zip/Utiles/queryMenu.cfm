<cfquery name="rsMenuPrincipal" datasource="sdc">
<!---
set nocount on
select distinct
s.Snombre,
rtrim (s.Sproceso) as Sproceso,
s.Scodigo, s.STcodigo, s.Stipo, s.Suri
from UsuarioRole ur, ServicioRol sr, Servicio s
where s.Smenu = 'S'
  and s.STcodigo=6
  and s.Sactivo = 1
  and ur.Usucodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.Usucodigo#">
  and ur.Ulocalizacion = <cfqueryparam cfsqltype="cf_sql_char" value="#Session.Ulocalizacion#">
  and sr.Rolcod = ur.Rolcod
  and s.Scodigo = sr.Scodigo
  and ((SRagregacion = '2' and not exists (select * from UsuarioServicio us1
where us1.Scodigo = s.Scodigo
  and us1.Usucodigo = ur.Usucodigo
  and us1.Ulocalizacion = ur.Ulocalizacion
  and us1.USactivo = 0))
   or (SRagregacion = '0' and exists (select * from UsuarioServicio us1
	where us1.Scodigo = s.Scodigo
	  and us1.Usucodigo = ur.Usucodigo
	  and us1.Ulocalizacion = ur.Ulocalizacion
	  and us1.USactivo = 1))
   or (SRagregacion = '1'))
order by s.Sorden, s.Snombre, s.Scodigo
set nocount off
--->
select distinct
 st.nombre as STdescripcion,
 s.nombre as Snombre,
 s.servicio as Scodigo, 
 st.sistema as STcodigo, 
 s.home_tipo as Stipo, 
 s.home_uri as Suri,
 s.modulo as Sproceso
from UsuarioPermiso ur, ServiciosRol sr, Servicios s, Modulo m, Sistema st
where s.menu = 1
  and s.activo = 1
  and ur.Usucodigo = #Session.Usucodigo#
  and ur.Ulocalizacion = '#Session.Ulocalizacion#'
  and (sr.rol = ur.rol or sr.rol = 'sys.public')
  and s.servicio = sr.servicio
  and m.sistema = st.sistema
  and s.modulo = m.modulo
order by st.orden, st.sistema, m.orden, m.nombre, s.orden, s.nombre
</cfquery>
<script type="text/javascript">
	var menuPrincipalOptions = new Array (
<cfoutput query="rsMenuPrincipal">
	new Array('#rsMenuPrincipal.Snombre#','#rsMenuPrincipal.Suri#'),
</cfoutput>
	new Array('','')
	);
</script>
