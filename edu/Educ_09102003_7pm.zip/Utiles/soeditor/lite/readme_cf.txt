���������������������������������
�                               �
�  version: soEditor Lite 2.5   �
�  released: Dec.02.2002        �
�  � 2002 SiteObjects, Inc.     �
�                               �
�  http://www.siteobjects.com/  �
�                               �
���������������������������������


QUICK INSTALLATION NOTES
=-=-=-=-=-=-=-=-=-=-=-=-=
� Extract this package into the root of your web server or into the root of the 
  web site that you wish to install soEditor in.

� If you plan to call soEditor as a custom tag then you must copy soeditor_lite.cfm 
  into a custom tag directory.
  (e.g. <cf_soeditor_lite
          field="fieldName"
          form="formName"
          scriptpath="/siteobjects/soeditor/pro/">)
  
� Alternatively you can call soeditor_lite.cfm via cfmodule
  (e.g. <cfmodule 
          template="/siteobjects/soeditor/lite/soeditor_lite.cfm"
          field="fieldName"
          form="formName"
          scriptpath="/siteobjects/soeditor/lite/">)

� To test your installation, open IE and access the example applications at:
  http://{www.yoursite.com}/siteobjects/soeditor/lite/examples/index.cfm
          
� If you extract the package into an alternative directory, you must change the 
  templatepath and scriptpath variables in examples/Application.cfm to point to the 
  new location in order for the examples to work correctly.

� Apache Users You will need to add the following line to your httpd.conf file "AddType
  text/x-component .htc" without quotes, make sure to restart the Apache daemon. 
  
� Online help documentation is also available at:
  http://{www.yoursite.com}/siteobjects/soeditor/lite/docs/cf/index.html
=-=-=-=-=-=-=-=-=-=-=-=-=


SUPPORT
=-=-=-=-=-=-=-=-=-=-=-=-=
� http://www.siteobjects.com/pages/support.cfm
