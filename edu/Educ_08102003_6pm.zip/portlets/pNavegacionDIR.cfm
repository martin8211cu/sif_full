<cfoutput>
<table width="100%" border="0" cellpadding="4" cellspacing="0" class="areaMenu">
  <tr align="left"> 
	<td><a href="/cfmx/edu" tabindex="-1">Educaci&oacute;n</a></td>
	<td>|</td>
	<td nowrap><a href="/cfmx/edu/director/consultas/consultarActividadesDIR.cfm" tabindex="-1">Rendimiento Acad&eacute;mico</a></td>
	<td>|</td>
	<td width="100%"><a href="<cfoutput>#Session.RegresarURL#</cfoutput>" tabindex="-1">Regresar</a></td>
  </tr>
</table>
</cfoutput>