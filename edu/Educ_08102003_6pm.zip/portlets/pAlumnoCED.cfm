<cfif isdefined("Url.o") and not isdefined("Form.o")>
	<cfparam name="Form.o" default="#Url.o#">
</cfif>
<cfif isdefined("Url.persona") and not isdefined("Form.persona")>
	<cfset Form.persona = Url.persona>
</cfif>
<cfif isdefined("form.persona")>
	<cfparam name="Form.persona" default="#form.persona#">
</cfif> 

<cfif  isdefined("form.persona") and len(trim(form.persona)) neq 0 >
	<cfquery datasource="#Session.DSN#" name="rsDatosEstud">
	select c.Ndescripcion, d.Gdescripcion, e.SPEdescripcion, f.GRnombre,
	convert(varchar,f.GRcodigo) as GRcodigo, 
	convert(varchar,e.SPEcodigo) as SPEcodigo,
	convert(varchar,e.PEcodigo) as PEcodigo
		from Alumnos a, Promocion b, 
		Grado d, 
		Nivel c, 
		PersonaEducativo pe, 
		SubPeriodoEscolar e, 
		Grupo f ,
		PeriodoVigente pv
		where  a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
		   and a.persona = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.persona#">
		   and a.PRcodigo = b.PRcodigo
		   and b.Gcodigo = d.Gcodigo
		   and b.Ncodigo = d.Ncodigo
		   and d.Ncodigo = c.Ncodigo
		   and a.persona = pe.persona
		   and a.CEcodigo = pe.CEcodigo
		   and b.PEcodigo = e.PEcodigo 
 		   and b.SPEcodigo = e.SPEcodigo 
		   and b.Ncodigo = f.Ncodigo 
		   and b.Gcodigo = f.Gcodigo 
		   and b.PEcodigo = f.PEcodigo 
		   and b.SPEcodigo = f.SPEcodigo 
		   and b.PEcodigo = pv.PEcodigo
		   and b.SPEcodigo = pv.SPEcodigo 
	</cfquery>

	<cfquery datasource="#Session.DSN#" name="rsAlumnoCED">
		Select convert(varchar,a.persona) as persona, 
		       convert(varchar,a.CEcodigo) as CEcodigo, 
			   Papellido1 + ' ' + Papellido2 + ',' + a.Pnombre as nombre,
			   a.Ppais, 
			   Papellido1,
			   Papellido2,
			   b.Pnombre, 
			   a.TIcodigo, 
			   TInombre, 
			   Pid, 
			   convert(varchar,Pnacimiento,103) as Pnacimiento, 
			   Psexo, 
			   Pemail1, 
			   Pemail2, 
			   Pdireccion, 
			   Pcasa, 
			   Pfoto, 
			   PfotoType, 
			   PfotoName, 
			   Pemail1validado, 
			   convert(varchar,d.PRcodigo) as PRcodigo, 
			   Aretirado,
			   d.CEcontrato,
			   isnull(Gdescripcion,'sin grado asociado') as Gdescripcion,
			   e.autorizado
		from PersonaEducativo a, Pais b, TipoIdentificacion c, Alumnos d, Estudiante e, Promocion f, Grado g
		where a.CEcodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
			and a.CEcodigo=d.CEcodigo
			and a.persona=<cfqueryparam cfsqltype="cf_sql_numeric" value="#form.persona#">
			and a.Ppais=b.Ppais
			and a.TIcodigo=c.TIcodigo
			and a.persona=d.persona
			and d.Ecodigo=e.Ecodigo
			and d.PRcodigo=f.PRcodigo
			and f.Gcodigo=g.Gcodigo		
	</cfquery>
</cfif>

<cfoutput>
<!--- <link href="../css/edu.css" rel="stylesheet" type="text/css"> --->
<table width="100%" border="0" cellpadding="4" cellspacing="0" class="areaMenu">
  <tr align="right">
	<cfif form.o NEQ 1>
	
		<td width="15%" align="center">
			<table width="54" height="79" border="1">
				<tr> 
					<td width="51" align="center" valign="middle">
						<cfif rsAlumnoCED.RecordCount neq 0>
							<cfif Len(rsAlumnoCED.Pfoto) EQ 0>
								Fotograf&iacute;a no disponible 
							<cfelse>
								<cf_LoadImage tabla="PersonaEducativo" columnas="Pfoto as contenido, persona as codigo" condicion="persona=#Form.persona#" imgname="Foto" width="54" height="77" alt="#rsAlumnoCED.Pnombre#  #rsAlumnoCED.Papellido1#  #rsAlumnoCED.Papellido2#">
							</cfif>
						<cfelse>
							Fotograf&iacute;a 
						</cfif> 
					</td>
				</tr>
			</table>
		</td>
	
	</cfif> 
	<td width="85%" align="left">
		<table width="100%" border="0">
        <tr>
			<td align="left" nowrap> <strong>Nombre:</strong>&nbsp; <cfoutput>#rsAlumnoCED.nombre#</cfoutput>
			</td>
		</tr>
		<cfif rsDatosEstud.RecordCount NEQ 0>
			<tr>
				<td width="40%"> 
					<input type="hidden" name="GRcodigo" value="<cfoutput>#rsDatosEstud.GRcodigo#</cfoutput>"> 
				</td>
				<td width="68%">&nbsp;</td>
			</tr>
			<tr>
				<td nowrap><strong>Nivel:</strong><cfoutput>#rsDatosEstud.Ndescripcion#</cfoutput></td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td nowrap><strong>Grado:</strong><cfoutput>#rsDatosEstud.Gdescripcion#</cfoutput></td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td nowrap><strong>Grupo:</strong><cfoutput> #rsDatosEstud.GRnombre# 
				</cfoutput></td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td nowrap>
					<strong>
						Curso Lectivo:
					</strong>
					<cfoutput> 
						#rsDatosEstud.SPEdescripcion# 
					</cfoutput>
				</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
		</cfif>
     </table>
	
	</td> 
</table>
</cfoutput>
<!---
<input name="persona" type="hidden" value="<cfif isdefined("form.persona")><cfoutput>#form.persona#</cfoutput></cfif>"> 
<input name="o" type="hidden" value="<cfif isdefined("Form.o")><cfoutput>#form.o#</cfoutput></cfif>"> 
--->
