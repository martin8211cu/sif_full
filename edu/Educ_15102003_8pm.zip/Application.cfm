<cfapplication name="SIF_ASP" 
sessionmanagement="Yes"
clientmanagement="Yes"
setclientcookies="Yes"
sessiontimeout=#CreateTimeSpan(0,10,0,0)#>
<cfset res = setLocale("English (Canadian)")>
<cfcontent type="text/html; charset=UTF-8">
<cfparam name="Session.Ayuda" default ="1">
<cfparam name="Session.RegresarURL" default="javascript: history.back();">
<cfparam name="Session.Idioma" default="ES_CR">
<cfinclude template="/edu/Utiles/SIFfunciones.cfm">
<!---
<cferror type="request" exception="any" template="/sif/errorPages/sitewide.cfm">
<cfscript>
	SetEncoding("form", "UTF-8");
	SetEncoding("url", "UTF-8");
</cfscript>
--->
<!---
<cflogin>
	<cfparam name="GetSessionRet" default="">
	<cfparam name="url.sess_pk" default="">
	<cfparam name="url.uid" default="">
	<cfinvoke 
	 component="sif.Componentes.sEP"
	 method="GetSession"
	 returnvariable="GetSessionRet">
		<cfinvokeargument name="sid" value="#url.sess_pk#"/>
		<cfinvokeargument name="uid" value="#url.uid#"/>
		<cfinvokeargument name="debug" value="false"/>
	</cfinvoke>
	<cfif len (GetSessionRet.Usucodigo) GT 0 >
		<cfloginuser name="#GetSessionRet.Usulogin#" password="#GetSessionRet.Usucodigo#" roles="" >
		<cfset SESSION.logoninfo = GetSessionRet >
		<cfset SESSION.sess_pk = #url.sess_pk# >
	</cfif>
</cflogin>

<cfif isdefined('GetSessionRet.Usulogin')>
	<cfparam name="Session.Usuario" default="#GetSessionRet.Usulogin#">
	<cfparam name="Session.Usucodigo" default="#GetSessionRet.Usucodigo#">
	<cfparam name="Session.Ulocalizacion" default="#GetSessionRet.Ulocalizacion#">
</cfif>
--->
<cfinclude template="/sif/logout/login-check.cfm">
<cfinclude template="/sif/seguridad/seguridad.cfm">


<cfparam name="Session.Preferences.Skin" default="purprd">
<cfparam name="Session.Preferences.SkinMenu" default="purprd">
<cfset Session.Preferences.Skin = "ocean">
<cfset Session.Preferences.SkinMenu = "ocean">

<cfset Session.PROVIDER_URL = "iiop://localhost:9000">
<cfset Session.SECURITY_PRINCIPAL = "jagadmin">
<cfset Session.SECURITY_CREDENTIALS = "">
