<cfif isdefined("Session.RolActual") and Session.RolActual eq 6>
	<cfset monitoreo_modulo="EDU EST">
	<cfinclude template="../monitoreo.cfm">
<cfelseif isdefined("Session.RolActual") and Session.RolActual eq 7>
	<cfset monitoreo_modulo="EDU RES">
	<cfinclude template="../monitoreo.cfm">
</cfif>

<cfinclude template="/edu/responsable/commonDocencia.cfm"> 

<cfset GvarBuscarFeriados=true>
<cffunction name="fnEsLeccion" returntype="boolean">
   <cfargument name="LprmFecha" required="true" type="date">
   <cfargument name="LprmBuscarFeriados" required="true" type="boolean" default="true">
  <cfset LvarDW = datepart("w", LprmFecha)>
  <cfif Find("*" & LvarDW & "*", GvarHorarios) eq 0>
    <cfreturn false>
  <cfelse>
    <cfif LprmBuscarFeriados>
	  <cfreturn (not fnEsFeriado(LprmFecha))>
    <cfelse>
	  <cfreturn true>
	</cfif>
  </cfif>
</cffunction>
<cffunction name="fnEsFeriado" returntype="boolean">
           <cfargument name="LprmFecha" required="true" type="date">
    <cfquery dbtype="query" name="qryCalendarioDia">
	  select Descripcion, 
	         'LprmFecha' as Fecha, 
	         Feriado 
	    from qryCalendario 
	   where Fecha = '#datepart("yyyy",LprmFecha)#-#datepart("m",LprmFecha)#-#datepart("d",LprmFecha)#' 
	      or Fecha = '2000-#datepart("m",LprmFecha)#-#datepart("d",LprmFecha)#'
	</cfquery>
    <cfquery dbtype="query" name="qryFeriado">
	  select Descripcion, 
	         Fecha
		from qryCalendarioDia 
	   where Feriado = 1
	</cfquery>
    <cfreturn (qryFeriado.Fecha neq "")>
</cffunction>

<cfscript>
  sbInitFromSession("cboAlumno", "-999",false);
  sbInitFromSession("cboCurso", "-1",false);
  sbInitFromSession("cboPeriodo", "-999",false);
</cfscript>
<cfparam name="form.hdnTipoOperacion" default="">
<cfparam name="form.hdnTipoActividad" default="">
<cfparam name="form.hdnCodigo" default="">
<cfparam name="form.hdnFecha" default="#lsdateformat(Now(),'DD/MM/YYYY')#">
<cfparam name="form.hdnFechaFinal" default="">

<cfinclude template="/edu/responsable/qrysAlumnoCursoPeriodo.cfm">

<cfif qryAlumnos.recordCount EQ 0>
	<table width="95%" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td align="center">&nbsp;
			
		</td>
	  </tr>
	  <tr>
		<td align="center">
			<strong>Usted no tiene alumnos matriculados por el momento</strong>
		</td>
	  </tr>
	  <tr>
		<td align="center">&nbsp;
			
		</td>
	  </tr>
	</table>
</cfif>

<cfif qryAlumnos.recordCount NEQ 0>
	<cfif not (#form.cboAlumno# eq "-999" or #form.cboCurso# eq "-999" or #form.cboPeriodo# eq "-999")>
	  <cfquery datasource="#Session.DSN#" name="qryHorarios">
		select distinct convert(int,HRdia)+2 as HRdia
		  from HorarioGuia h
		 where #fnCursoEscogido("h.Ccodigo")#
	  </cfquery>
	  <cfset GvarHorarios="*">
	  <cfloop query="qryHorarios">
		<cfif HRdia eq 8>
		  <cfset GvarHorarios = GvarHorarios & "1*">
		<cfelse>
		  <cfset GvarHorarios = GvarHorarios & HRdia & "*">
		</cfif>
	  </cfloop>
	  <cfquery datasource="#Session.DSN#" name="qryLimitesPeriodoActividades">
		select 'E' as Tipo, min(e.ECplaneada) as Inicial, max(e.ECplaneada) as Final
		  from EvaluacionCurso e
		 where #fnCursoEscogido("e.Ccodigo")#
		   and e.PEcodigo   = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
	  UNION
		select 'T', min(t.CPfecha) as Inicial, max(t.CPfecha) as Final
		  from CursoPrograma t
		 where #fnCursoEscogido("t.Ccodigo")#
		   and t.PEcodigo   = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
	  UNION
		select 'P', POfechainicio as Inicial, POfechafin as Final
		  from PeriodoOcurrencia p, Curso c
		 where #fnCursoEscogido("c.Ccodigo")#
		   and p.PEcodigo     = c.PEcodigo 
		   and p.SPEcodigo    = c.SPEcodigo 
		   and p.PEevaluacion = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
	  </cfquery>
	
	  <cfquery dbtype="query" name="qryLimite">
		select min(Inicial) as Inicial, max(Final) as Final
		  from qryLimitesPeriodoActividades
	  </cfquery>
	  
	  <cfquery dbtype="query" name="qryLimitePeriodo">
		select Inicial, Final
		  from qryLimitesPeriodoActividades
		 where Tipo='P'
	  </cfquery>
	  <cfif GvarBuscarFeriados or (isDefined("form.btnRecalendarizar") and form.cboTipoRecal eq "Correr")>
		<cfquery datasource="#Session.DSN#" name="qryCalendarioCod">
		  select Ccodigo
			from CentroEducativo 
		   where CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
		</cfquery>
		<cfquery datasource="#Session.DSN#" name="qryCalendario">
		  select convert(datetime, convert(varchar,CDfecha,112)) as Fecha, 
				 CDtitulo as Descripcion,
				 CDferiado as Feriado
			from CalendarioDia 
		   where Ccodigo= <cfqueryparam cfsqltype="cf_sql_numeric" value="#qryCalendarioCod.Ccodigo#">
			 and CDabsoluto=1
			 and CDfecha between '#lsDateFormat(qryLimite.Inicial,"YYYYMMDD")#' and '#lsDateFormat(qryLimite.Final,"YYYYMMDD")#'
		UNION
		  select convert(datetime, '2000' + substring(convert(varchar,CDfecha,112),5,8)), 
				 CDtitulo,
				 CDferiado
			from CalendarioDia 
		   where Ccodigo=<cfqueryparam cfsqltype="cf_sql_numeric" value="#qryCalendarioCod.Ccodigo#">
			 and CDabsoluto=0
		</cfquery>
	  </cfif>
	
	  <cfif form.hdnTipoOperacion eq "R">
	  <cfquery datasource="#Session.DSN#" name="qryLimitesPeriodoActividades">
		select 'E' as Tipo, min(e.ECplaneada) as Inicial, max(e.ECplaneada) as Final
		  from EvaluacionCurso e
		 where #fnCursoEscogido("e.Ccodigo")#
		   and e.PEcodigo   = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
	  UNION
		select 'T', min(t.CPfecha), max(t.CPfecha)
		  from CursoPrograma t
		 where #fnCursoEscogido("t.Ccodigo")#
		   and t.PEcodigo   = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
	  UNION
		select 'P', POfechainicio, POfechafin
		  from PeriodoOcurrencia p, Curso c
		 where #fnCursoEscogido("c.Ccodigo")#
		   and p.PEcodigo     = c.PEcodigo 
		   and p.SPEcodigo    = c.SPEcodigo 
		   and p.PEevaluacion = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
	  </cfquery>
	
	  <cfquery dbtype="query" name="qryLimite">
		select min(Inicial) as Inicial, max(Final) as Final
		  from qryLimitesPeriodoActividades
	  </cfquery>
	  <cfquery dbtype="query" name="qryLimitePeriodo">
		select Inicial, Final
		  from qryLimitesPeriodoActividades
		 where Tipo='P'
	  </cfquery>
	  </cfif>
	  <cfquery datasource="#Session.DSN#" name="qryActividades">
		select 'Evaluaciones' as tipo, '2' as orden, 'E' as TipoOperacion, 
			   ECplaneada as fecha, count(*) as Cantidad
		  from EvaluacionCurso e
		 where PEcodigo   = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
		   and #fnCursoEscogido("e.Ccodigo")#
		 group by ECplaneada
	  UNION
		select 'Temas', '1', 'T', CPfecha, count(*)
		  from CursoPrograma t
		 where #fnCursoEscogido("t.Ccodigo")#
		   and PEcodigo   = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
		 group by CPfecha
	  UNION
		select 'Observaciones', '3', 'O', ACOfecha, count(*)
		  from AlumnoCursoObservacion o
		 where #fnCursoEscogido("o.Ccodigo")#
		   and PEcodigo   = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
		   and o.Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboAlumno#"> 
		 group by ACOfecha
	  UNION
		select 'Asistencia', '4', 'A', ACAfecha, count(*)
		  from AlumnoCursoAsistencia a
		 where #fnCursoEscogido("a.Ccodigo")#
		   and PEcodigo   = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
		   and a.Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboAlumno#"> 
		 group by ACAfecha
	  order by fecha, orden
	  </cfquery>
	
	  <cfset LvarIni=qryLimite.Inicial>
	  <cfset LvarFin=qryLimite.Final>
	</cfif>
	<style type="text/css">
	<!--
	.TxtNormal {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 11;
		margin: 0px;
		padding: 1px;
	}
	.BoxNormal {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 11;
		margin: 0px;
		padding: 1px;
		background-color: #E6E6E6;
	}
	.HdrNormal {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 11;
		margin: 0px;
		padding: 0px;
		border: 0px solid;
	}
	.CeldaTxt {
		text-indent: -9;
		margin-left: 12;
		margin-right: -4;
		margin-top: 0;
		margin-bottom: 0;
	}
	.CeldaHdr {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 14;
		font-weight:bold;
		color: #E6E6E6;
		background-color: #666666;
		vertical-align: middle;
		border-right: 1px solid;
		border-top: 1px solid;
		margin: 0px;
		padding: 1px;
		text-align: center;
	}
	.CeldaHorario {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 14;
		font-weight:bold;
		color: #E6E6E6;
		background-color: #003399;
		vertical-align: middle;
		border-right: 1px solid;
		border-top: 1px solid;
		margin: 0px;
		padding: 1px;
		text-align: center;
	}
	.CeldaNoCurso {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 10px;
		font-weight: normal;
		background-color: #E6E6E6;
		vertical-align: top;
		border-right: 1px solid;
		border-top: 1px solid;
		margin: 0px;
		padding: 1px;
	}
	.CeldaCurso {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 10px;
		font-weight: normal;
		background-color: #C0C0C0;
		vertical-align: top;
		border-right: 1px solid;
		border-top: 1px solid;
		margin: 0px;
		padding: 1px;
	}
	.CeldaFeriado {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 10px;
		font-weight: normal;
		background-color: #E6E6E6;
		vertical-align: top;
		border-right: 1px solid;
		border-top: 1px solid;
		margin: 0px;
		padding: 1px;
		color: #CC0000;
	}
	.CeldaRef {
		text-decoration:none; 
		color:#000000; 
		font-size: 10px;
		font-weight: normal;
	}
	.CeldaRefTema {
		text-decoration:none; 
		color:#003399; 
		font-size: 10px;
		font-weight: normal;
	}
	.CeldaRefEval {
		text-decoration:none; 
		color:#FF6633; 
		font-size: 10px;
		font-weight: normal;
	}
	.CeldaFechaRef {
		text-decoration:none; 
		color:#000000; 
		font-size: 11px;
		font-weight: normal;
	}
	.LinPar {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 10px;
		font-weight: normal;
		background-color: #E6E6E6;
		text-align: left;
		vertical-align: top;
		border: 0px;
		margin: 0px;
		padding: 1px;
	} 
	.LinImpar {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 10px;
		font-weight: normal;
		background-color: #C0C0C0;
		text-align: left;
		vertical-align: top;
		border: 0px;
		margin: 0px;
		padding: 1px;
	}
	-->
	</style>
	<cfquery datasource="#Session.DSN#" name="rsDatosEstud">
		select c.Ndescripcion, d.Gdescripcion, e.SPEdescripcion, f.GRnombre,
		convert(varchar,f.GRcodigo) as GRcodigo, 
		convert(varchar,e.SPEcodigo) as SPEcodigo,
		convert(varchar,e.PEcodigo) as PEcodigo
		from Alumnos a, Promocion b, Nivel c, Grado d, SubPeriodoEscolar e, Grupo f 
		where a.Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Form.cboAlumno#">
			and a.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
			and a.PRcodigo = b.PRcodigo and b.Ncodigo = c.Ncodigo and b.Ncodigo = d.Ncodigo 
			and b.Gcodigo = d.Gcodigo and b.PEcodigo = e.PEcodigo and b.SPEcodigo = e.SPEcodigo 
			and b.Ncodigo = f.Ncodigo and b.Gcodigo = f.Gcodigo and b.PEcodigo = f.PEcodigo 
			and b.SPEcodigo = f.SPEcodigo 
	</cfquery>
	<!--- <cfif rsDatosEstud.recordCount NEQ 0> --->
		<cfquery datasource="#Session.DSN#" name="qryPublicacionNotas">
			if not exists ( select 1 from PublicacionNotas 
				where SPEcodigo = <cfqueryparam value="#rsDatosEstud.SPEcodigo#" cfsqltype="cf_sql_numeric">
				  and PEcodigo = <cfqueryparam value="#rsDatosEstud.PEcodigo#" cfsqltype="cf_sql_numeric">
				  and convert(datetime, convert(varchar, getdate(), 103), 103) between PNfechaInicio and PNfechaFin 
			)
			begin
				select 0 as Encontrado
			end	
			else 
				select 1 as Encontrado
		 </cfquery>
		
	<!--- 	 <cfif qryPublicacionNotas.recordCount EQ 0>
			<cfset form.Encontrado = 1>
		<cfelse>
			<cfset form.Encontrado = qryPublicacionNotas.Encontrado>	
		</cfif>
	<cfelse>
		<cfset form.Encontrado = 1> 
	</cfif>
	 --->
	 <script language="JavaScript1.2" >
		function VerNotasProgreso(){
			<cfoutput>
				<cfif qryPublicacionNotas.Encontrado NEQ 1>
					window.open('/cfmx/edu/responsable/reporteProgreso.cfm?N=4&E=#trim(form.cboAlumno)#&C=#trim(form.cboCurso)#&P=#trim(form.cboPeriodo)#', 'ReporteProgreso','left=50,top=10,scrollbars=yes,resiable=yes,width=700,height=550,alwaysRaised=yes');		
				<cfelse>
					//alert(' No se pueden mostrar las notas de progreso en este Periodo, por favor contacte al administrador.');
					alert('La Instituci�n decidi� no publicar las notas de progreso en este d�a, consulte luego o consulte al administrador');	
				</cfif>
			</cfoutput>
		}
		function VerNotasFinales(){
			<cfoutput>
				<cfif qryPublicacionNotas.Encontrado NEQ 1>
					fnConsultarNotas(document.frmActividades.cboCurso.value);		
				<cfelse>
					//alert(' No se pueden mostrar las notas finales en este Periodo, por favor contacte al administrador.');	
					alert('La Instituci�n decidi� no publicar las notas finales en este d�a, consulte luego o consulte al administrador');	
				</cfif>
			</cfoutput>
		}
		
	</script>
	<form name="frmActividades" method="POST" action="" style="font:10px Verdana, Arial, Helvetica, sans-serif;">
	  <table border="0" cellspacing="0" cellpadding="3" width="100%">
		<tr> 
		  <td colspan="3" class="areaFiltro" nowrap>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
			  <tr> 
				<td width="35%" nowrap>Alumno: 
			<select name="cboAlumno"
					style="font:10px Verdana, Arial, Helvetica, sans-serif;"
					onChange="fnReLoad();">
			  <cfset LvarSelected="0">
			  <cfset LvarFirst="">
			  <cfoutput query="qryAlumnos"> 
				<cfif currentRow eq 1>
				  <cfset LvarFirst=Codigo>
				  <cfset LvarPersonaAlumno="#Persona#">
				</cfif>
				<option value="#Codigo#"
		  <cfif #form.cboAlumno# eq #Codigo#> selected<cfset LvarSelected="1"><cfset LvarPersonaAlumno="#Persona#">
		  </cfif>>#Descripcion#</option>
			  </cfoutput> 
			  <cfif #LvarSelected# eq "0">
				<cfif LvarFirst neq "">
				  <cfset form.cboAlumno=LvarFirst>
				  <cfelse>
				  <cfset form.cboAlumno="-999">
				  <cfset LvarPersonaAlumno="-999">
				</cfif>
			  </cfif>
			</select>
			</td>
				<td width="35%" nowrap>Curso: 
				  <select name="cboCurso" 
					style="font:10px Verdana, Arial, Helvetica, sans-serif;"
					onChange='if (this.value != "-999") fnReLoad();'>
					<option value="-1">* * TODOS LOS CURSOS * *</option>
					<cfset LvarSelected="0">
					<cfoutput query="qryCursos"> 
					  <option value="#Codigo#"<cfif #form.cboCurso# eq #Codigo#> selected<cfset LvarSelected="1"></cfif>>#Descripcion#</option>
					</cfoutput> 
					<cfif #LvarSelected# eq "0" and form.cboCurso neq "-1">
					  <cfset form.cboCurso="-1">
					</cfif>
				  </select>
				</td>
				<td width="30%" nowrap>Per�odo: 
				  <select name="cboPeriodo" 
				style="font:10px Verdana, Arial, Helvetica, sans-serif;"
				onChange="fnReLoad();">
					<cfoutput query="qryPeriodos"> 
					  <option value="#Codigo#"<cfif (#form.cboPeriodo# eq #Codigo#) > selected<cfset LvarSelected="1"></cfif>>#Descripcion#</option>
					</cfoutput> 
					</select>
					<cfoutput>
						<input type="hidden" name="SPEcodigo" value="#rsDatosEstud.SPEcodigo#">
						<input type="hidden" name="PEcodigo" value="#rsDatosEstud.PEcodigo#">
					</cfoutput>
				</td>
			  </tr>
			</table>
		  </td>
		</tr>
		<tr> 
		  <td width="10%" rowspan="6" align="right" valign="middle" style="padding-left: 10px; padding-right: 10px" nowrap> 
			<table border="1">
			  <tr> 
				<td align="right">
					<!--- <cf_Educleerimagen Tabla="PersonaEducativo" ruta="/cfmx/edu/Utiles/sifleerimagencont.cfm" Campo="Pfoto" Condicion="persona=#LvarPersonaAlumno#" Conexion="#Session.DSN#" autosize="false" width="85" height="113">  --->
					<cf_LoadImage tabla="PersonaEducativo" columnas="Pfoto as contenido, persona as codigo" condicion="persona=#LvarPersonaAlumno#" imgname="Foto" width="85" height="113">
				</td>
			  </tr>
			</table>
		  </td>
		  <td width="40%">
				<input type="hidden" name="GRcodigo" value="<cfoutput>#rsDatosEstud.GRcodigo#</cfoutput>">
			</td>
		  <td width="60%" rowspan="6" valign="top" nowrap><cfoutput> 
			  <table width="100%" border="0" cellspacing="0" cellpadding="2">
				<tr> 
				  <td colspan="4" align="center" class="tituloAlterno" style="border-bottom: solid ##000000 1px; border-top: solid ##000000 1px;">
					Opciones de Men&uacute;</td>
				</tr>
				<tr> 
				  <td style="padding-right: 5px;"> <a href="javascript:VerNotasProgreso();"><img src="/cfmx/edu/Imagenes/evaluaciones2.gif" border="0" title="Reporte de Progreso del Curso"></a> 
				  </td>
				  <td nowrap style="padding-right: 10px;"><font size="2"><a href="javascript:VerNotasProgreso();">Notas 
					de Progreso</a></font></td>
				 <!---  <td style="padding-right: 5px;"> <a href="javascript: newWindow=window.open('/cfmx/edu/responsable/comunicadoAlProfesor.cfm?Tipo=M0&Codigo=#trim(form.cboAlumno)#&Periodo=#trim(form.cboPeriodo)#&C=#trim(form.cboCurso)#', 'ComunicadosAlProfesor','left=50,top=10,scrollbars=yes,resiable=yes,width=500,height=350,alwaysRaised=yes','Comunicados al Profesor');newWindow.focus();"><img src="/cfmx/edu/Imagenes/comunicado.gif" border="0" title="Comunicados al Profesor"></a> 
				  </td> --->
				  <td style="padding-right: 5px;"> 
					<!--- <a href="javascript: newWindow=window.open('/cfmx/edu/responsable/comunicados.cfm', 'Comunicados','left=50,top=10,scrollbars=yes,resiable=yes,width=500,height=350,alwaysRaised=yes','Comunicados del encargado');newWindow.focus();"><img src="/cfmx/edu/Imagenes/comunicado.gif" border="0" title="Comunicados al Profesor"></a> --->
					<a href="/cfmx/edu/buzon/index.cfm?a=#LSDateFormat(Now(), 'ddmmyyyy')##LSTimeFormat(Now(),'hhmmss')#"><img src="/cfmx/edu/Imagenes/comunicado.gif" border="0" title="Comunicados al Profesor"></a> 
				  </td>
				  <td nowrap style="padding-right: 10px;"><font size="2">
					<!--- <a href="javascript: newWindow=window.open('/cfmx/edu/responsable/comunicados.cfm', 'Comunicados','left=50,top=10,scrollbars=yes,resiable=yes,width=500,height=350,alwaysRaised=yes','Comunicados al Profesor');newWindow.focus();">Comunicados</a> --->
					<a href="/cfmx/edu/buzon/index.cfm?a=#LSDateFormat(Now(), 'ddmmyyyy')##LSTimeFormat(Now(),'hhmmss')#">Comunicados</a>
				  </font></td>
				</tr>
				<tr> 
				  <td> <a href="javascript:fnConsultarCursoDet('T',document.frmActividades.cboCurso.value);"><img src="/cfmx/edu/Imagenes/tema.gif" border="0" title="Temarios"></a> 
				  </td>
				  <td nowrap style="padding-right: 10px;"><font size="2"><a href="javascript:fnConsultarCursoDet('T',document.frmActividades.cboCurso.value);">Temarios</a></font></td>
				  <td><a href="javascript:fnConsultarCursoDet('E',document.frmActividades.cboCurso.value);"><img src="/cfmx/edu/Imagenes/evaluaciones.gif" border="0" title="Plan de Evaluaciones"></a></td>
				  <td nowrap style="padding-right: 10px;"><font size="2"><a href="javascript:fnConsultarCursoDet('E',document.frmActividades.cboCurso.value);">Plan 
					de Evaluaciones</a></font></td>
				</tr>
				<tr> 
				  <td><a href="javascript:fnConsultarCursoDet('O',document.frmActividades.cboCurso.value);"><img src="/cfmx/edu/Imagenes/observaciones.gif" border="0" title="Observaciones y Anotaciones"></a></td>
				  <td nowrap style="padding-right: 10px;"><font size="2"><a href="javascript:fnConsultarCursoDet('O',document.frmActividades.cboCurso.value);">Observaciones 
					y Anotaciones</a></font></td>
				  <td><a href="javascript:fnConsultarCursoDet('A',document.frmActividades.cboCurso.value);"><img src="/cfmx/edu/Imagenes/asistencia.gif" border="0" title="Control de Asistencia"></a></td>
				  <td nowrap style="padding-right: 10px;"><font size="2"><a href="javascript:fnConsultarCursoDet('A',document.frmActividades.cboCurso.value);">Control 
					de Asistencia</a></font></td>
				</tr>
				<tr> 
				  <td><a href="javascript:fnConsultarMaterial('O',document.frmActividades.cboCurso.value);"><img src="/cfmx/edu/Imagenes/books.gif" border="0" title="Observaciones y Anotaciones"></a></td>
				  <td nowrap style="padding-right: 10px;"><font size="2"><a href="javascript:fnConsultarMaterial(document.frmActividades.cboCurso.value);">Material 
					Did&aacute;ctico </a></font></td>
				  <td><a href="javascript: VerNotasFinales();"><img src="../Imagenes/CxP02_T.gif" border="0" title="Observaciones y Anotaciones"></a></td>
				  <td nowrap style="padding-right: 10px;"><font size="2"><a href="javascript: VerNotasFinales();">Notas 
					Finales</a></font></td>
				</tr>
			  </table>
			</cfoutput></td>
		</tr>
		<tr> 
		  <td nowrap><strong>Nivel:</strong><cfoutput>#rsDatosEstud.Ndescripcion#</cfoutput></td>
		</tr>
		<cfif #form.cboAlumno# eq "-999" or #form.cboCurso# eq "-999" or #form.cboPeriodo# eq "-999">
		  
		  
		  
		  <cfabort>
		</cfif>
		<tr> 
		  <td nowrap><strong>Grado:</strong><cfoutput>#rsDatosEstud.Gdescripcion#</cfoutput></td>
		</tr>
		<tr> 
		  <td nowrap><strong>Grupo:</strong><cfoutput> #rsDatosEstud.GRnombre# </cfoutput></td>
		</tr>
		<tr> 
		  <td nowrap><strong>Curso Lectivo:</strong><cfoutput> #rsDatosEstud.SPEdescripcion# 
			</cfoutput></td>
		</tr>
		<tr>
		  <td>&nbsp;</td>
		</tr>
	  </table>
		  
		<table width="100%" border="0" cellpading="0" cellspacing="0" style="background-color: #E6E6E6;">
		<tr><td valign="top">
		  <cfoutput>
		  <table width="100%" border="0" cellpading="-1" cellspacing="-1" style="border-bottom: 1px solid ##FFFFFF;">
			<tr> 
			  <td class="CeldaHdr"><div style="width:20px;font:9px;">Semana&nbsp;</div></td>
			  <td class="CeldaHdr"><div style="width:60px;">Domingo</div></td>
			  <td class="CeldaHdr"><div style="width:60px;">Lunes</div></td>
			  <td class="CeldaHdr"><div style="width:60px;">Martes</div></td>
			  <td class="CeldaHdr"><div style="width:60px;">Miercoles</div></td>
			  <td class="CeldaHdr"><div style="width:60px;">Jueves</div></td>
			  <td class="CeldaHdr"><div style="width:60px;">Viernes</div></td>
			  <td class="CeldaHdr"><div style="width:60px;">Sabado</div></td>
			</tr>
			<cfset LvarSem = 1>
			<tr> 
			  <td class="CeldaHdr">
				<cfset LvarDW = datepart("w", LvarIni)-1>
				<cfset LvarFecha1 = dateadd("D",-LvarDW,LvarIni)> 
				<cfset LvarFecha2 = dateadd("D",6,LvarFecha1)> 
				<!--- <a href="javascript:fnConsultarActividades('','#lsdateformat(LvarIni,"DD/MM/YYYY")#','#lsdateformat(LvarFecha2,"DD/MM/YYYY")#');" class="CeldaHdr" style="border:0;">1</a> --->
				<cfinvoke 
				 component="edu.Componentes.windowHints"
				 method="wHint"
				 returnvariable="wHintRet">
					<cfinvokeargument name="ref" value="1"/>
					<cfinvokeargument name="mensaje" value="Haga click aqu� para ver actividades de la semana"/>
					<cfinvokeargument name="funcion" value="fnConsultarActividades('','#lsdateformat(LvarIni,"DD/MM/YYYY")#','#lsdateformat(LvarFecha2,"DD/MM/YYYY")#');" />
					<cfinvokeargument name="linkAttr" value='class="CeldaHdr" style="border:0;"'/>
				</cfinvoke>
				<cfif form.hdnFecha eq "">
				  
				  <cfset form.hdnFecha=#lsdateformat(LvarIni,"DD/MM/YYYY")#>
				  <cfset form.hdnFechaFinal=#lsdateformat(LvarFecha2,"DD/MM/YYYY")#>
				</cfif>
			  </td>
			<!--- Llena las celdas anteriores al inicio --->
			<cfset LvarDW = datepart("w", LvarIni)-1>
			<cfloop from="1" to="#LvarDW#" index="LvarCol">
			  <td class="CeldaNoCurso">&nbsp;</td>
			</cfloop>
			<!--- Llena la primera celda anteriores al inicio --->
			  <cfif fnEsLeccion(LvarIni, false)>
				
				
				
				<cfif fnEsFeriado(LvarIni)>
				  
				  
				  
				<cfset LvarCeldaCurso="CeldaFeriado">
			  <cfelse>
				<cfset LvarCeldaCurso="CeldaCurso">
			  </cfif>
			<cfelse>
			  <cfset LvarCeldaCurso="CeldaNoCurso">
			</cfif>
			<cfset LvarFecha=LvarIni>
			  <td class="#LvarCeldaCurso#">
				<a href="javascript:fnConsultarActividades('','#lsdateformat(LvarFecha,"DD/MM/YYYY")#');" class="CeldaFechaRef">
				<div style="width=100%;cursor:hand;">
				  <a href="javascript:fnConsultarActividades('','#lsdateformat(LvarFecha,"DD/MM/YYYY")#');" class="CeldaFechaRef">
					<b>#lsdateformat(LvarFecha,"D MMM YY")#</b>
				  </a>
				</div></a>
				<cfif LvarFecha eq qryLimitePeriodo.Inicial><span class="celdaHdr" style="text-align:left; border=0px; font:11px; cursor:default;">INICIO PERIODO</span></cfif>
				<cfif LvarCeldaCurso neq "CeldaNoCurso">
				  <cfloop query="qryCalendarioDia">
					<span>#Descripcion#</span>
				  </cfloop>
				</cfif>
			<!--- Recorre todos las Actividades --->
			<cfloop query="qryActividades"> 
			  <!--- Llena las celdas anteriores al siguiente Actividad --->
			  <cfloop condition="LvarFecha lt Fecha"> 
				<cfif LvarFecha eq qryLimitePeriodo.Final><p class="CeldaTxt" align="right"><span class="CeldaHdr" style="border=0px; font:11px; cursor:default;">FINAL PERIODO&nbsp;</span></p></cfif>
				</td>
				<cfset LvarFecha = dateadd("D",1,LvarFecha)> 
				<cfset LvarDW = datepart("w",LvarFecha)> 
				<cfif LvarDW eq 1>
				  <cfset LvarSem = LvarSem + 1 >
				  </tr><tr>
			  <td class="CeldaHdr">
					<cfset LvarFecha2 = dateadd("D",6,LvarFecha)>
					<cfinvoke 
					 component="edu.Componentes.windowHints"
					 method="wHint"
					 returnvariable="wHintRet">
						<cfinvokeargument name="ref" value="#LvarSem#"/>
						<cfinvokeargument name="mensaje" value="Haga click aqu� para ver actividades de la semana"/>
						<cfinvokeargument name="funcion" value="fnConsultarActividades('','#lsdateformat(LvarFecha,"DD/MM/YYYY")#','#lsdateformat(LvarFecha2,"DD/MM/YYYY")#');" />
						<cfinvokeargument name="linkAttr" value='class="CeldaHdr" style="border:0;"'/>
					</cfinvoke>
					<!--- <a href="javascript:fnConsultarActividades('','#lsdateformat(LvarFecha,"DD/MM/YYYY")#','#lsdateformat(LvarFecha2,"DD/MM/YYYY")#');" class="CeldaHdr" style="border:0;">#LvarSem#</a> --->
				  </td>
				</cfif>
			  <cfif fnEsLeccion(LvarFecha, false)>
				<cfif fnEsFeriado(LvarFecha)>
	
					<cfset LvarCeldaCurso="CeldaFeriado">
				  <cfelse>
					<cfset LvarCeldaCurso="CeldaCurso">
				  </cfif>
				<cfelse>
				  <cfset LvarCeldaCurso="CeldaNoCurso">
				</cfif>
				<td class="#LvarCeldaCurso#">
				  <a href="javascript:fnConsultarActividades('','#lsdateformat(LvarFecha,"DD/MM/YYYY")#');" class="CeldaFechaRef">
				  <div style="width=100%;cursor:hand;">
					<a href="javascript:fnConsultarActividades('','#lsdateformat(LvarFecha,"DD/MM/YYYY")#');" class="CeldaFechaRef">
					  <cfif datepart("d",LvarFecha) eq 1><B>#lsdateformat(LvarFecha,"D MMM YY")#</B><cfelse>#lsdateformat(LvarFecha,"D MMM")#</cfif> 
					</a>
				  </div></a>
				<cfif LvarFecha eq qryLimitePeriodo.Inicial><span class="celdaHdr" style="text-align:left; border=0px; font:11px; cursor:default;">INICIO PERIODO</span></cfif>
				<cfif LvarCeldaCurso neq "CeldaNoCurso">
				  <cfloop query="qryCalendarioDia">
					<span>#Descripcion#</span>
				  </cfloop>
				</cfif>
			  </cfloop>
			  <cfif Fecha eq LvarFecha>
				<p class="CeldaTxt"><a href="javascript:fnConsultarActividades('#TipoOperacion#', '#lsdateformat(LvarFecha,"DD/MM/YYYY")#');" class="<cfif TipoOperacion eq 'T'>celdaRefTema<cfelseif TipoOperacion eq 'E'>celdaRefEval<cfelse>celdaRef</cfif>">
				  #Tipo#
				</a></p>
			  </cfif>
			</cfloop> 
			<!--- Llena las celdas anteriores al final (en caso de que el final del periodo sea posterior al ultimo Actividad) --->
			<cfloop condition="LvarFecha lt LvarFin"> 
			  <cfif LvarFecha eq qryLimitePeriodo.Final><p class="CeldaTxt" align="right"><span class="CeldaHdr" style="border=0px; font:11px; cursor:default;">FINAL PERIODO&nbsp;</span></p></cfif>
			  <cfset LvarFecha = dateadd("d",1,LvarFecha)>
			  <cfset LvarDW = datepart("w",LvarFecha)>
			  <cfif LvarDW eq "1">
				<cfset LvarSem = LvarSem + 1 >
				</td></tr>
				<tr><td class="CeldaHdr">
					#LvarSem#
				</td>
			  </cfif>
			  <cfif fnEsLeccion(LvarFecha, false)>
				
				
				
				<cfif fnEsFeriado(LvarFecha)>
				  
				  
				  
				  <cfset LvarCeldaCurso="CeldaFeriado">
				<cfelse>
				  <cfset LvarCeldaCurso="CeldaCurso">
				</cfif>
			  <cfelse>
				<cfset LvarCeldaCurso="CeldaNoCurso">
			  </cfif>
			  <td class="#LvarCeldaCurso#">
				<a href="javascript:fnConsultarActividades('','#lsdateformat(LvarFecha,"DD/MM/YYYY")#');" class="CeldaFechaRef">
				<div style="width=100%;cursor:hand;">
				  <a href="javascript:fnConsultarActividades('','#lsdateformat(LvarFecha,"DD/MM/YYYY")#');" class="CeldaFechaRef">
					<cfif lsdateformat(LvarFecha,"DD") eq "1"><B>#lsdateformat(LvarFecha,"D MMM YY")#</B><cfelse>#lsdateformat(LvarFecha,"D")#</cfif>
				  </a>
				</div></a>
				<cfif LvarFecha eq qryLimitePeriodo.Inicial><span class="celdaHdr" style="text-align:left; border=0px; font:11px; cursor:default;">INICIO PERIODO</span></cfif>
				<cfif LvarCeldaCurso neq "CeldaNoCurso">
				  <cfloop query="qryCalendarioDia">
					<span>#Descripcion#</span>
				  </cfloop>
				</cfif>
			</cfloop> 
			<cfset LvarDW = datepart("w",LvarFin)+1> 
			<cfif LvarFecha eq qryLimitePeriodo.Final><p class="CeldaTxt" align="right"><span class="CeldaHdr" style="border=0px; font:11px; cursor:default;">FINAL PERIODO&nbsp;</span></p></cfif>
			</td>
			<!--- Llena las celdas posteriores al final --->
			<cfloop from="#LvarDW#" to="7" index="LvarCol"> 
			  <td class="CeldaNoCurso">&nbsp;</td>
			</cfloop></td></tr>
		  </table>
		  </cfoutput>
		</td>
		
		<td width="20" valign="top" class="HdrNormal" style="background-color: #E6E6E6;">
		  <div style="border-top:1px solid #FFFFFF;">
		  <div class="CeldaHdr" style="border-right:0px;border-top:1px solid #E6E6E6;">&nbsp;</div></div><br>
		</td>
		
		<td valign="top" class="HdrNormal" style="background-color: #E6E6E6;">
		<cfoutput>
		<div style="border-top:1px solid ##FFFFFF;">
		<div class="CeldaHdr" style="border-top:1px solid ##E6E6E6;">LISTA DE ACTIVIDADES</div></div><br>
		</cfoutput>
		<div style="width:250px;">&nbsp;</div>
		<cfif form.hdnFecha neq "">
			<table border="0" width="100%" cellspacing="0" cellpadding="0">
			<cfset LvarFecha=lsParseDatetime(form.hdnFecha)>
	
			<cfif form.hdnFechaFinal neq "">
			  
			  
			  
			  <cfset LvarFechaFin=lsParseDatetime(form.hdnFechaFinal)>
			<cfelse>
			  <cfset LvarFechaFin = LvarFecha>
			</cfif>
			<cfquery datasource="#Session.DSN#" name="qryActividades">
			  <cfset LvarFechaI = LvarFecha>
			  <cfloop condition="lsDateFormat(LvarFechaI,'YYYYMMDD') lte lsDateFormat(LvarFechaFin,'YYYYMMDD')">
				select convert(datetime,'#lsDateFormat(LvarFechaI,"YYYYMMDD")#') as Fecha,
					   c.Ccodigo     as Curso,
					   m.Mnombre     as CursoNombre,
					   'HORARIO'     as Tipo, 
					   'H'           as TipoOperacion, 
					   0             as Codigo,
					   (case when Hentrada >= 10 then ltrim(str(Hentrada,5,2)) else '0'+ltrim(str(Hentrada,5,2)) end) + ' - ' + (case when Hsalida >= 10 then ltrim(str(Hsalida,5,2)) else '0'+ltrim(str(Hsalida,5,2)) end) as Nombre,
					   ''            as Realizado,
					   1             as Orden
				  from HorarioGuia h, Horario hh, Curso c, Materia m
				 where h.Hcodigo = hh.Hcodigo
				   and h.Hbloque = hh.Hbloque
				   and #fnCursoEscogido("h.Ccodigo")#
				   and h.Ccodigo = c.Ccodigo
				   and m.Mconsecutivo = c.Mconsecutivo
				   <cfset LvarDW = datepart("w", LvarFechaI)-2>
				   
			  <cfif LvarDW eq -1>
				<cfset LvarDW = 8>
			  </cfif>
				   and convert(int,h.HRdia) = #LvarDW#
				<cfset LvarFechaI = dateadd("D",1,LvarFechaI)>
			  UNION
			  </cfloop>
			  <cfif form.hdnTipoOperacion eq "" or form.hdnTipoOperacion eq "E">
				select ECplaneada,
					   c.Ccodigo,
					   m.Mnombre,
					   'EVALUACION', 
					   'E', 
					   ECcomponente,
					   ECnombre,
					   isnull((select str(n.ACnota,6,2) from AlumnoCalificacion n 
						 where n.Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboAlumno#">
						   and n.CEcodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.CEcodigo#">
						   and n.Ccodigo = ec.Ccodigo
						   and n.ECcomponente = ec.ECcomponente),
						 isnull(ECevaluado,'N')),
					   2
				  from EvaluacionCurso ec, Curso c, Materia m
				 where ec.Ccodigo = c.Ccodigo
				   and m.Mconsecutivo = c.Mconsecutivo
				   and #fnCursoEscogido("ec.Ccodigo")#
				   and ec.PEcodigo= <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
				   and ECplaneada <cfif LvarFechaFin eq "">= '#lsDateFormat(LvarFecha,"YYYYMMDD")#'
				   <cfelse>between '#lsDateFormat(LvarFecha,"YYYYMMDD")#' and '#lsDateFormat(LvarFechaFin,"YYYYMMDD")#'
				   </cfif>
			  </cfif>
			  <cfif form.hdnTipoOperacion eq "">
			  UNION
			  </cfif>
			  <cfif form.hdnTipoOperacion eq "" or form.hdnTipoOperacion eq "T">
				select CPfecha,
					   c.Ccodigo,
					   m.Mnombre,
					   'TEMA', 
					   'T', 
					   CPcodigo,
					   CPnombre,
					   CPcubierto,
					   3
				  from CursoPrograma cp, Curso c, Materia m
				 where cp.Ccodigo = c.Ccodigo
				   and m.Mconsecutivo = c.Mconsecutivo
				   and #fnCursoEscogido("cp.Ccodigo")#
				   and cp.PEcodigo= <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
				   and CPfecha <cfif LvarFechaFin eq "">= '#lsDateFormat(LvarFecha,"YYYYMMDD")#'
				   <cfelse>between '#lsDateFormat(LvarFecha,"YYYYMMDD")#' and '#lsDateFormat(LvarFechaFin,"YYYYMMDD")#'</cfif>
			  </cfif>
			  <cfif form.hdnTipoOperacion eq "">
			  UNION
			  </cfif>
			  <cfif form.hdnTipoOperacion eq "" or form.hdnTipoOperacion eq "O">
				select ACOfecha,
					   c.Ccodigo,
					   m.Mnombre,
					   'OBSERVACION', 
					   'O', 
					   ACOcodigo,
					   case ACOtipo when 'A' then 'Advertencia' when 'P' then 'Reforzamiento' else 'Llamada Atenci�n' end,
					   'N',
					   4
				  from AlumnoCursoObservacion ao, Curso c, Materia m
				 where ao.Ccodigo = c.Ccodigo
				   and m.Mconsecutivo = c.Mconsecutivo
				   and #fnCursoEscogido("ao.Ccodigo")#
				   and ao.PEcodigo= <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
				   and ao.Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboAlumno#"> 
				   and ACOfecha <cfif LvarFechaFin eq "">= '#lsDateFormat(LvarFecha,"YYYYMMDD")#'
				   <cfelse>between '#lsDateFormat(LvarFecha,"YYYYMMDD")#' and '#lsDateFormat(LvarFechaFin,"YYYYMMDD")#'</cfif>
			  </cfif>
			  <cfif form.hdnTipoOperacion eq "">
			  UNION
			  </cfif>
			  <cfif form.hdnTipoOperacion eq "" or form.hdnTipoOperacion eq "A">
				select ACAfecha,
					   c.Ccodigo,
					   m.Mnombre,
					   'ASISTENCIA', 
					   'A', 
					   ACAcodigo,
					   case ACAtipo when 'A' then 'Ausencia' when 'T' then 'Llegada Tard�a' else 'Salida Temprano' end
					   + case when ACAjustificado='S' then ' Justificada' else ' Injustificada' end,
					   'N',
					   5
				  from AlumnoCursoAsistencia aa, Curso c, Materia m
				 where aa.Ccodigo = c.Ccodigo
				   and m.Mconsecutivo = c.Mconsecutivo
				   and #fnCursoEscogido("aa.Ccodigo")#
				   and aa.Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboAlumno#"> 
				   and aa.PEcodigo= <cfqueryparam cfsqltype="cf_sql_numeric" value="#form.cboPeriodo#">
				   and ACAfecha <cfif LvarFechaFin eq "">= '#lsDateFormat(LvarFecha,"YYYYMMDD")#'
				   <cfelse>between '#lsDateFormat(LvarFecha,"YYYYMMDD")#' and '#lsDateFormat(LvarFechaFin,"YYYYMMDD")#'</cfif>
			  </cfif>
			  order by Fecha, Curso, Orden
			</cfquery>
			<cfset LvarFecha = "">
			<cfset LvarCurso = "">
			<cfset LvarLinPar = "Impar">
			<cfif qryActividades.recordCount eq 0>
			  <tr>
				<td colspan="3" class="LinPar" style="font-size:16"><b><cfoutput>#lsDateFormat(form.hdnFecha,"Long")#</cfoutput></b></td>
			  </tr>
			</cfif>
			<cfoutput query="qryActividades">
			  <cfif LvarFecha neq Fecha>
				<cfset LvarFecha = Fecha>
				<cfset LvarCurso = "">
				<cfif currentRow gt 1>
			  <tr><td colspan="3">&nbsp;</td></tr>
				</cfif>
				<cfset LvarFeriado = fnEsFeriado(Fecha)>
			  <tr>
				<td colspan="3" class="<cfif LvarFeriado>CeldaFeriado<cfelse>LinPar</cfif>" style="font-size:16">
					<cfif currentRow NEQ 1><hr></cfif>
					<b>#lsDateFormat(Fecha,"Long")#</b>
					<cfquery name="rsHorariosDia" dbtype="query">
						select *
						from qryActividades
						where TipoOperacion = 'H'
						and Fecha = '#lsDateFormat(LvarFecha,"YYYY-MM-DD")#'
						order by Fecha, Nombre
					</cfquery>
					<cfif rsHorariosDia.recordCount GT 0>
						<cfset LvarLinPar = "Impar">
						<tr>
						<td colspan="3" align="center">
						<table width="100%" cellpadding="0" cellspacing="0">
							<tr>
								<td colspan="2" class="CeldaHorario"><b>Horario</b></td>
							</tr>
						<cfloop query="rsHorariosDia">
							
						<cfif LvarLinPar neq "Par">
						  
						  
						  <cfset LvarLinPar="Par"><cfelse><cfset LvarLinPar="Impar"></cfif>
							<tr>
							<td nowrap class="Lin#LvarLinPar#">#rsHorariosDia.Nombre#</td>
							<td nowrap class="Lin#LvarLinPar#">#rsHorariosDia.CursoNombre#</td>
							</tr>
						</cfloop>
						</table>
						</td>
						</tr>
					</cfif>
				</td>
			  </tr>
				<cfif Fecha eq qryLimitePeriodo.Inicial>
			  <tr>
				<td colspan="3" class="CeldaFeriado" style="border=0px">INICIO DEL PERIODO EVALUACION</td>
			  </tr>
				</cfif>
				<cfif Fecha eq qryLimitePeriodo.Final>
			  <tr>
				<td colspan="3" class="CeldaFeriado" style="border=0px">FINAL DEL PERIODO EVALUACION</td>
			  </tr>
				</cfif>
				<cfif LvarFeriado>
			  <tr>
				<td colspan="3" class="CeldaFeriado" style="border=0px">DIA FERIADO</td>
			  </tr>
				</cfif>
				<cfloop query="qryCalendarioDia">
			  <tr>
				<td>CALENDARIO ESCOLAR</td>
				<td>#Descripcion#</td>
			  </tr>
				</cfloop>
			  </cfif>
			  <cfif LvarCurso neq Curso and not (LvarFeriado and TipoOperacion eq "H")>
				<cfset LvarCurso = Curso>
				<cfset LvarLinPar = "Par">
				<cfset LvarHorario = "Horario">
			  <tr>
				<td class="CeldaHdr" colspan="2">
					#CursoNombre#
					<!--- <a href="javascript:fnConsultarCurso('C',#Curso#);" class="CeldaHdr" style="border:0px">#CursoNombre#</a> --->
				</td>
				  <td class="CeldaHdr" align="center" width="1%">
					<cfinvoke 
					 component="edu.Componentes.windowHints"
					 method="wHint"
					 returnvariable="wHintRet">
						<cfinvokeargument name="ref" value="/cfmx/edu/Imagenes/TBP_0105.JPG"/>
						<cfinvokeargument name="mensaje" value="Haga click aqu� para ver datos del Curso"/>
						<cfinvokeargument name="imagen" value="true"/>
						<cfinvokeargument name="funcion" value="fnConsultarCurso('C',#Curso#);"/>
						<cfinvokeargument name="linkAttr" value='class="CeldaHdr" style="border:0px"'/>
					</cfinvoke>
				</td>
			  </tr>
			  </cfif>
			  <cfif not (LvarFeriado and TipoOperacion eq "H")>
			  <tr>
				<!---
				<cfif TipoOperacion eq "H">
				<td style="text-align:center;" width="100">#LvarHorario#</td><cfset LvarHorario="">
				<td>#Nombre#</td>
				<td></td>
				<cfelse>
				--->
				<cfif TipoOperacion neq "H">
					<td align="center" width="10%" class="Lin#LvarLinPar#"><a href="javascript:fnConsultarCurso('#TipoOperacion#',#Codigo#);" <cfif TipoOperacion EQ 'T'>class="CeldaRefTema"<cfelseif TipoOperacion EQ 'E'>class="CeldaRefEval"</cfif>>#Tipo#</a></td>
					<td class="Lin#LvarLinPar#">#Nombre#</td>
					<td align="center" class="Lin#LvarLinPar#">
					<cfif qryPublicacionNotas.Encontrado EQ 1>
						&nbsp;
					<cfelse>	
						<cfif Realizado eq "S" >
							<img src="/cfmx/edu/responsable/realizado.gif">
						<cfelseif Realizado neq "N">
							#Realizado#
						</cfif>
					</cfif>
					</td>
					<cfif LvarLinPar neq "Par">
						<cfset LvarLinPar="Par">
					<cfelse>
						<cfset LvarLinPar="Impar">
					</cfif>
				</cfif>
			  </tr>
			  </cfif>
			</cfoutput>
			</table>
		</cfif>
				
		</td></tr>
		</table>
		<cfoutput>
		<input type="hidden" name="hdnFecha" id="hdnFecha" value="#Form.hdnFecha#">
		<input type="hidden" name="hdnFechaFinal" id="hdnFechaFinal" value="#Form.hdnFechaFinal#">
		<input type="hidden" name="hdnTipoOperacion" id="hdnTipoOperacion" value="#Form.hdnTipoOperacion#">
		<input type="hidden" name="hdnTipoActividad" id="hdnTipoActividad" value="#Form.hdnTipoActividad#">
		<input type="hidden" name="hdnCodigo" id="hdnCodigo" value="#Form.hdnCodigo#">
		<input type="hidden" name="Encontrado" id="Encontrado" value="#qryPublicacionNotas.Encontrado#">
		</cfoutput>
	  </form>
</cfif>  <!--- qryAlumnos.recordCount NEQ 0 --->