function ValidaBuscar(formulario){
    if (formulario.busqueda.value=="") {
        alert("Debe proporcionar alg�n criterio para la B�squeda");
        formulario.busqueda.focus();
        return false;
    }
    return true
}