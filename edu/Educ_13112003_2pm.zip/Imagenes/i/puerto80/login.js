//------------------------------------------ Los cookies ------------------------------------------------------

function getCookieVal (offset) {
    var endstr = document.cookie.indexOf (";", offset);
    if (endstr == -1)
        endstr = document.cookie.length;
    return unescape(document.cookie.substring(offset, endstr));
}

function GetCookie (name) {
    var arg = name + "=";
    var alen = arg.length;
    var clen = document.cookie.length;
    var i = 0;
    while (i < clen) {
        var j = i + alen;
        if (document.cookie.substring(i, j) == arg)
            return getCookieVal (j);
        i = document.cookie.indexOf(" ", i) + 1;
        if (i == 0) break; 
    }
    return null;
}

function SetCookie (name, value) {
    var argv = SetCookie.arguments;
    var argc = SetCookie.arguments.length;
    var expires = (argc > 2) ? argv[2] : null;
    var path = (argc > 3) ? argv[3] : null;
    var domain = (argc > 4) ? argv[4] : null;
    var secure = (argc > 5) ? argv[5] : false;
    document.cookie = name + "=" + escape (value) +
        ((expires == null) ? "" : ("; expires=" + expires.toGMTString())) +
        ((path == null) ? "" : ("; path=" + path)) +
        ((domain == null) ? "" : ("; domain=" + domain)) +
        ((secure == true) ? "; secure" : "");
}

function llenarLogin() {
    var user = GetCookie("sdcuser")
    if (user==null) return
    var uspass = user.split(":")
    if (uspass==null) return;
    if (uspass.length > 0) {
        document.login.usu.value = uspass[0];
    }
    if (uspass.length > 1) {
        document.login.pwd.value = uspass[1];
        if (uspass[1].length != "") {
            document.login.recordar.checked = true;
        }
    }
}

function validarLogin() {
    // recuerda la contrasena por un mes
    
    if (document.login.usu.value == "")
    {
        alert("Digite el usuario");
        document.login.usu.focus();
        return false;
    }
    if (document.login.usu.value.indexOf(" ") != -1)
    {
        alert("El usuario no puede contener espacios");
        document.login.usu.select();
        document.login.usu.focus();
        return false;
    }
    if (document.login.pwd.value == "")
    {
        alert("Digite su contrase�a.");
        document.login.pwd.focus();
        return false;
    }
    
    if (document.login.recordar.checked) {
        var expdate = new Date ();
        expdate.setTime (expdate.getTime() + (24 * 60 * 60 * 1000 * 31));
        SetCookie("sdcuser", (document.login.usu.value + ":" + document.login.pwd.value), expdate)
    } else {
        SetCookie("sdcuser", ":")
    }
    return true;
}

function validarNuevoUsuario() {
    // recuerda la contrasena por un mes
    
    if (document.login.nusu.value == "")
    {
        alert("Digite el nombre solicitado para su usuario");
        document.login.nusu.focus();
        return false;
    }
    if (document.login.nusu.value.indexOf(" ") != -1)
    {
        alert("El usuario no puede contener espacios");
        document.login.nusu.select();
        document.login.nusu.focus();
        return false;
    }
    if (document.login.npwd.value == "")
    {
        alert("Seleccione la nueva contrase�a.");
        document.login.npwd.focus();
        return false;
    }
    if (document.login.npwd2.value == "")
    {
        alert("Confirme la nueva contrase�a.");
        document.login.npwd2.focus();
        return false;
    }
    if (document.login.npwd.value != document.login.npwd2.value)
    {
        alert("La contrase�a debe coincidir en ambos valores.");
        document.login.npwd.focus();
        document.login.npwd.value = "";
        document.login.npwd2.value = "";
        return false;
    }
    
    if (document.login.recordar.checked) {
        var expdate = new Date ();
        expdate.setTime (expdate.getTime() + (24 * 60 * 60 * 1000 * 31));
        SetCookie("sdcuser", (document.login.nusu.value + ":" + document.login.npwd.value), expdate)
    } else {
        SetCookie("sdcuser", ":")
    }
    return true;
}

function UsulistChange(c)
{
    document.login.nusu.value = document.login.usulist.value;
    document.login.usuck[0].checked = true;
}

function UsutextChange(c)
{
    document.login.usuck[1].checked = true;
    document.login.usulist.value = "";
}
