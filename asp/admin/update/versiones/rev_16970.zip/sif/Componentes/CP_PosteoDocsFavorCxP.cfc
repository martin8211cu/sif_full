﻿<!--- Posteo de Documentos a Favor de CxP
Creador por: Marcel de M.
 Fecha: 12 Febrero de 2002
Migrado a componete por GustavoF/MauricioE.
 Fecha: 25-3-2008

DAmontodoc 		= Monto a Aplicar al Documento en moneda Documento
DAmonto			= Monto a Aplicar al Documento en moneda Pago

"DAtotaldoc" 	= Total a Pagar en moneda Documento = DAmontodoc - Rmontodoc
DAtotal			= Total a Pagar en moneda Pago

------------------------------------------------------------------------------------------------------------------------------------------------------------------
Modificado Por: Eduardo González Sarabia (APH)
         Fecha: 13/01/2017
		Cambio: Se modifica la funcion CP_PosteoDocsFavorCxP, para poder realizar el descuento de la
		        nota de credito hacia la factura, por linea.
--->



<cfcomponent>
	<cffunction name="CP_PosteoDocsFavorCxP" access="public" output="false" returntype="string">
		<cfargument name='ID' 		type='numeric' 	required='true' 		hint="ID del Documento">
		<cfargument name='Ecodigo'		type='numeric' 	required='true' 	hint="Codigo empresa">
		<cfargument name='CPTcodigo'	type='string' 	required='true' 	hint="Código de la Transacción">
		<cfargument name='Ddocumento'	type='string' 	required='true' 	hint="Número del documento">
		<cfargument name='usuario' 		type='string' 	required='false'	hint="Login del usuario">
		<cfargument name='Usucodigo'	type='numeric' 	required='true' 	hint="Codigo del usuario">
		<cfargument name='fechaDoc' 	type='string' 	required='true' 	hint="Usar Fecha del Documento">
		<cfargument name='debug' 		type='string' 	required='false' 	default="N" hint="Ejecuta el debug S= si  N= no">
		<cfargument name='Conexion' 	type='string' 	required='false' 	default="#Session.DSN#">

		<cfset LvarGblConexion = Arguments.Conexion>
		<cfset LvarGblID       = Arguments.ID>

		<!--- Consulta de lineas para afectacion por linea --->
		<cfquery name="rsConsultaRelaciones" datasource="#Session.dsn#">
			SELECT * FROM CPrelacionLineasNcFc
			WHERE MovAplicacion = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Arguments.ID#">
			AND Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.Ecodigo#">
		</cfquery>
		<cfif rsConsultaRelaciones.recordCount GT 0>
			<cfset LvarPorLinea = true>
		<cfelse>
			<cfset LvarPorLinea = false>
		</cfif>

		<!--- Consulta de lineas para afectacion por linea --->
		<cfquery name="rsConsultaAfectIVA" datasource="#Session.dsn#">
			SELECT dd.Icodigo
			FROM CPrelacionLineasNcFc r
			INNER JOIN DDocumentosCP dd ON r.FCId = dd.DDlinea
			AND r.Ecodigo = dd.Ecodigo
			AND r.MovAplicacion = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Arguments.ID#">
			AND dd.Icodigo = 'IVA16'
			AND dd.Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.Ecodigo#">
		</cfquery>
		<cfif rsConsultaAfectIVA.recordCount GT 0>
			<cfset LvarAfectIVA = true>
		<cfelse>
			<cfset LvarAfectIVA = false>
		</cfif>

		<!--- Validaciones Preposteo --->
		<cfquery name="rsValida" datasource="#LvarGblConexion#">
			select count(1) as cantidad
			from EAplicacionCP
			where ID = #LvarGblID#
		</cfquery>
		<cfif rsValida.cantidad eq 0>
			<cf_errorCode	code = "50990" msg = "El documento a Favor indicado no existe! Proceso Cancelado!.">
		</cfif>

		<cfquery name="rsValida" datasource="#LvarGblConexion#">
			select count(1) as cantidad
			from DAplicacionCP
			where ID = #LvarGblID#
		</cfquery>

		<cfif rsValida.cantidad eq 0>
			<cf_errorCode	code = "50992" msg = "El documento a Favor indicado no tiene detalles! Proceso Cancelado!.">
		</cfif>

		<cfquery name="rsSQL" datasource="#LvarGblConexion#">
			select Pvalor as Periodo
			from Parametros
			where Ecodigo = #Arguments.Ecodigo#
			  and Mcodigo = 'GN'
			  and Pcodigo = 50
		</cfquery>
		<cfif rsSQL.recordcount NEQ 1 or len(trim(rsSQL.Periodo)) EQ 0>
			<cf_errorCode	code = "51146" msg = "No se ha definido el periodo de Auxiliares! Proceso Cancelado!.">
		</cfif>
		<cfset LvarPeriodo = rsSQL.Periodo>

		<cfquery name="rsSQL" datasource="#LvarGblConexion#">
			select Pvalor as Mes
			from Parametros
			where Ecodigo = #Arguments.Ecodigo#
			  and Mcodigo = 'GN'
			  and Pcodigo = 60
		</cfquery>

		<cfif rsSQL.recordcount NEQ 1 or len(trim(rsSQL.Mes)) EQ 0>
			<cf_errorCode	code = "51147" msg = "No se ha definido el Mes de Auxiliares! Proceso Cancelado!.">
		</cfif>

		<cfset LvarMes = rsSQL.Mes>

		<cfquery name="rsSQL" datasource="#LvarGblConexion#">
			select Pvalor as CtaPuente
			from Parametros
			where Ecodigo = #Arguments.Ecodigo#
			  and Pcodigo = 200
			  and Mcodigo = 'CG'
		</cfquery>

		<cfif rsSQL.recordcount NEQ 1 or len(trim(rsSQL.CtaPuente)) EQ 0>
			<cf_errorCode	code = "51148" msg = "No se ha definido la cuenta contable de trabajo! Proceso Cancelado!.">
		</cfif>

		<cfset LvarCuentaPuente = rsSQL.CtaPuente>

		<cfquery name="rsSQL" datasource="#LvarGblConexion#">
			select p.Pvalor
			from Parametros p
			where Ecodigo = #Arguments.Ecodigo#
			and Pcodigo = 130
		</cfquery>
		<cfif rsSQL.recordcount NEQ 1 or len(trim(rsSQL.Pvalor)) EQ 0>
			<cf_errorCode	code = "51149" msg = "No se ha definido la cuenta contable de ingreso por diferencial cambiario! Proceso Cancelado!.">
		</cfif>

		<cfset LvarCuentaIngDifCam = rsSql.Pvalor>

		<cfquery name="rsSQL" datasource="#LvarGblConexion#">
			select p.Pvalor
			from Parametros p
			where Ecodigo = #Arguments.Ecodigo#
			and Pcodigo = 140
		</cfquery>
		<cfif rsSQL.recordcount NEQ 1 or len(trim(rsSQL.Pvalor)) EQ 0>
			<cf_errorCode	code = "51150" msg = "No se ha definido la cuenta contable de Gasto por diferencial cambiario! Proceso Cancelado!.">
		</cfif>

		<cfset LvarCuentaGasDifCam = rsSql.Pvalor>

		<cfquery name="rsSQL" datasource="#LvarGblConexion#">
			select p.Pvalor
			from Parametros p
			where Ecodigo = #Arguments.Ecodigo#
			and Pcodigo = 200
		</cfquery>
		<cfif rsSQL.recordcount NEQ 1 or len(trim(rsSQL.Pvalor)) EQ 0>
			<cf_errorCode	code = "51151" msg = "No se ha definido la cuenta contable de Balance Multimoneda! Proceso Cancelado!.">
		</cfif>

		<cfset LvarCuentabalancemultimoneda = rsSql.Pvalor>

		<cfquery name="rsSQL" datasource="#LvarGblConexion#">
			select Mcodigo
			from Empresas
			where Ecodigo = #Arguments.Ecodigo#
		</cfquery>

		<cfif rsSQL.recordcount NEQ 1 or len(trim(rsSQL.Mcodigo)) EQ 0>
			<cf_errorCode	code = "51152" msg = "No se ha definido la Moneda Local de la Empresa! Proceso Cancelado!.">
		</cfif>

		<cfset LvarMonLocal = rsSQL.Mcodigo>

		<cfquery name="rsSQL" datasource="#LvarGblConexion#">
			select a.EAfecha, a.Mcodigo, a.SNcodigo, a.CPTcodigo, a.Ddocumento
			from EAplicacionCP a
			where a.ID = #LvarGblID#
		</cfquery>

		<cfset LvarFecha = now()>
		<cfset LvarEAfecha = createodbcdate(rsSQL.EAfecha)>
		<cfset LvarfechaChar = datepart('YYYY', LvarEAfecha) & datepart('M', LvarEAfecha) & datepart('D', LvarEAfecha)>
		<cfset LvarMonedaNC = rsSQL.Mcodigo>
		<cfset LvarSNcodigo = rsSQL.SNcodigo>
		<cfset LvarCPTcodigo = rsSQL.CPTcodigo>
		<cfset LvarDdocumento = rsSQL.Ddocumento>
		<cfset LvarDescripcion = "Aplicación de Doc. Favor CxP: " & LvarCPTcodigo & "-" & LvarDdocumento>

		<cfquery datasource="#LvarGblConexion#" name="rsSQL">
			select sum(DAmonto) as EAmonto
			  from DAplicacionCP b
			 where b.ID = #LvarGblID#
		</cfquery>
		<cfset LvarEAmonto = rsSQL.EAmonto>

		<cfquery name="rsSQL" datasource="#LvarGblConexion#">
			select b.Ocodigo
			from EDocumentosCP b
			where b.IDdocumento = #LvarGblID#
		</cfquery>

		<cfset LvarOcodigo = rsSQL.Ocodigo>

		<cfinvoke component="sif.Componentes.CG_GeneraAsiento" method="CreaIntarc" returnvariable="INTARC">
		<cfinvoke component="IETU" method="IETU_CreaTablas" conexion="#Arguments.Conexion#"></cfinvoke>

		<cftransaction>

       		<!---- Control  de Eventos----->
            <cfinvoke component="sif.Componentes.CG_ControlEvento"
                method	 ="ValidaEvento"
                Origen	 ="CPAP"
                Transaccion="#Arguments.CPTcodigo#"
                Conexion	="#Arguments.conexion#"
                Ecodigo		="#Arguments.Ecodigo#"
                returnvariable	= "varValidaEvento"
            />
            <cfset varNumeroEvento = "">
			<cfif varValidaEvento GT 0>
                <cfinvoke component="sif.Componentes.CG_ControlEvento"
                    method		= "CG_GeneraEvento"
                    Origen		= "CPAP"
                    Transaccion	= "#Arguments.CPTcodigo#"
                    Documento 	= "#Arguments.Ddocumento#"
                    SocioCodigo = "#LvarSNcodigo#"
                    Conexion	= "#Arguments.Conexion#"
                    Ecodigo		= "#Arguments.Ecodigo#"
                    returnvariable	= "arNumeroEvento"/>
                <cfif arNumeroEvento[3] EQ "">
                    <cfthrow message="ERROR CONTROL EVENTO: No se obtuvo un control de evento valido para la operación">
                </cfif>
                <cfset varNumeroEvento = arNumeroEvento[3]>
				<cfset varIDEvento = arNumeroEvento[4]>
              	<!--- Genera la relacion con la Nota de Credito Aplicada --->
                <cfquery name="rsNotaAplica" datasource="#LvarGblConexion#">
                	select ID, Ecodigo, CPTcodigo, Ddocumento, SNcodigo
                    from EAplicacionCP
                    where ID = #LvarGblID#
                </cfquery>
                <cfinvoke component="sif.Componentes.CG_ControlEvento"
                    method="CG_RelacionaEvento"
                    IDNEvento="#varIDEvento#"
                    Origen="CPFC"
                    Transaccion="#rsNotaAplica.CPTcodigo#"
                    Documento="#rsNotaAplica.Ddocumento#"
                    SocioCodigo="#rsNotaAplica.SNcodigo#"
                    Conexion="#LvarGblConexion#"
                    Ecodigo="#rsNotaAplica.Ecodigo#"
                    returnvariable="arRelacionEvento"
                />
                <cfif isdefined("arRelacionEvento") and arRelacionEvento[1]>
                    <cfset varNumeroEvento = arRelacionEvento[4]>
                </cfif>
				<!--- Genera la relacion con las Facturas Aplicadas --->
                <cfquery name="rsDocumentoAplica" datasource="#LvarGblConexion#">
                	select ID, DAlinea, Ecodigo,DAtransref, DAdocref, SNcodigo
                    from DAplicacionCP
                    where ID = #LvarGblID#
                </cfquery>
                <cfloop query="rsDocumentoAplica">
                    <cfinvoke component="sif.Componentes.CG_ControlEvento"
                        method="CG_RelacionaEvento"
                        IDNEvento="#varIDEvento#"
                        Origen="CPFC"
                        Transaccion="#rsDocumentoAplica.DAtransref#"
                        Documento="#rsDocumentoAplica.DAdocref#"
                        SocioCodigo="#rsDocumentoAplica.SNcodigo#"
                        Conexion="#LvarGblConexion#"
                        Ecodigo="#rsDocumentoAplica.Ecodigo#"
                        returnvariable="arRelacionEvento"
                    />
                    <cfif isdefined("arRelacionEvento") and arRelacionEvento[1]>
						<cfset varNumeroEventoDP = arRelacionEvento[4]>
                    <cfelse>
                        <cfset varNumeroEventoDP = varNumeroEvento>
                    </cfif>
                    <cfquery datasource="#LvarGblConexion#">
                    	update DAplicacionCP
                        set NumeroEvento = <cfqueryparam cfsqltype="cf_sql_varchar" value="#varNumeroEventoDP#">
                        where ID = <cfqueryparam cfsqltype="cf_sql_numeric" value="#rsDocumentoAplica.ID#">
                        and DAlinea = <cfqueryparam cfsqltype="cf_sql_numeric" value="#rsDocumentoAplica.DAlinea#">
                    </cfquery>
            	</cfloop>
            </cfif>

			<cfset fnInsertaMovimientoImpuestos(LvarPorLinea)>
			<cfset fnContabilizaDiferencialDocFavor(varNumeroEvento)>
			<cfset fnContabilizaDiferencialDocAplic(varNumeroEvento)>
			<cfset fnContabilizaTrasladoImpuestos(varNumeroEvento)>
			<cfset fnContabilizaAplicacion(varNumeroEvento)>

			<cfif Arguments.FechaDoc EQ "S">
				<cfset LvarEfecha = LvarEAfecha>
			<cfelse>
				<cfset LvarEfecha = LvarFecha>
			</cfif>

			<cfset sbAfectacionIETU("CPAP", arguments.Ecodigo, LvarGblID,
						#LvarEfecha#, #LvarPeriodo#, #LvarMes#,
						Arguments.conexion)>

			<!---
				Ejecutar el Genera Asiento --- Asiento en Contabilidad General
			--->
			<cfinvoke component="CG_GeneraAsiento" method="GeneraAsiento" returnvariable="LvarIDcontable">
				<cfinvokeargument name="Ecodigo" value="#arguments.Ecodigo#"/>
				<cfinvokeargument name="Oorigen" value="CPAP"/>
				<cfinvokeargument name="Eperiodo" value="#LvarPeriodo#"/>
				<cfinvokeargument name="Emes" value="#LvarMes#"/>
				<cfinvokeargument name="Efecha" value="#LvarEfecha#"/>
				<cfinvokeargument name="Edescripcion" value="#LvarDescripcion#"/>
				<cfinvokeargument name="Edocbase" value="#arguments.Ddocumento#"/>
				<cfinvokeargument name="Ereferencia" value="#arguments.CPTcodigo#"/>
				<cfinvokeargument name="Ocodigo" value="#LvarOcodigo#"/>
				<cfinvokeargument name="Usucodigo" value="#arguments.Usucodigo#"/>
				<cfinvokeargument name="debug" value="no"/>
				<cfinvokeargument name="PintaAsiento" value="false"/>
				<cfinvokeargument name="DocaFavor" value="true"/>
<!--- Control Evento Inicia --->
        		<cfinvokeargument name='NumeroEvento' 		value="#varNumeroEvento#"/>
<!--- Control Evento Fin --->

			</cfinvoke>

			<cfinvoke component="IETU" method="IETU_ActualizaIDcontable" >
				<cfinvokeargument name="IDcontable"	value="#LvarIDcontable#">
				<cfinvokeargument name="conexion"	value="#Arguments.Conexion#">
			</cfinvoke>


			<!---
				Insertar en el Histórico de CxP los movimientos a los documentos
			--->
			<cfquery datasource="#LvarGblConexion#">
				insert into BMovimientosCxP (
					Ecodigo, CPTcodigo, Ddocumento,
					CPTRcodigo, DRdocumento, BMfecha,
					Ccuenta, Ocodigo, SNcodigo, Mcodigo,
					Dtipocambio, Dtotal, Dfecha, Dvencimiento,
					BMperiodo, BMmes, BMusuario,
					BMfactor, Mcodigoref, BMmontoref, IDcontable)
				select
					c.Ecodigo, c.CPTcodigo, c.Ddocumento,
					b.DAtransref, b.DAdocref, <cf_jdbcquery_param cfsqltype="cf_sql_timestamp" value="#LvarFecha#">,
					a.Ccuenta, a.Ocodigo, a.SNcodigo, c.Mcodigo,
					c.EAtipocambio, b.DAtotal,
					<cf_jdbcquery_param cfsqltype="cf_sql_date" value="#LvarEAfecha#">,
					<cf_jdbcquery_param cfsqltype="cf_sql_date" value="#LvarEAfecha#">,
					#LvarPeriodo#, #LvarMes#, c.EAusuario,
					b.DAtipocambio, a.Mcodigo, b.DAmontodoc, #LvarIDcontable#
				from EAplicacionCP c
					inner join DAplicacionCP b
						inner join EDocumentosCP a
						on  a.Ecodigo     = b.Ecodigo
						and a.CPTcodigo   = b.DAtransref
						and a.Ddocumento  = b.DAdocref
						and a.SNcodigo    = b.SNcodigo
						and a.IDdocumento = b.DAidref
					on b.ID = c.ID
				where c.ID = #LvarGblID#
			</cfquery>

			<!--- MEG 17/04/2015 --->
			<!--- Envía al Repositorio de  CFDI --->
			<!--- Si existe configurado un Repositorio de CFDIs --->
			<cfquery name="getContE" datasource="#Session.DSN#">
				select ERepositorio from Empresa
				where Ereferencia = #Session.Ecodigo#
			</cfquery>
			<cfquery name="rsLIneaNC" datasource="#Session.DSN#">
				select dc.Dlinea
				from DContables dc
				inner join EAplicacionCP c
					on dc.Ddocumento = c.Ddocumento
				where dc.IDcontable = #LvarIDcontable#
			</cfquery>
			<cfif isdefined("getContE.ERepositorio") and getContE.ERepositorio EQ "1">
				<!--- Comprobantes de la Linea de la Nota de Credito --->
				<cfquery name="rsDContable" datasource="#Session.DSN#">
					insert into CERepositorio(
						IdContable,IdDocumento,numDocumento,origen,linea,timbre,xmlTimbrado,archivoXML,
	                	archivo,nombreArchivo,extension, Ecodigo,BMUsucodigo,
						TipoComprobante,Serie,Mcodigo,TipoCambio,CEMetPago,rfc,total,
						CEtipoLinea,CESNB,CEtranOri,CEdocumentoOri,Miso4217)
					select dc.IDcontable, rep.IdDocumento, rep.numDocumento,
						'CPAP', #rsLIneaNC.Dlinea#, rep.timbre, rep.xmlTimbrado, rep.archivoXML, rep.archivo, rep.nombreArchivo,
	                    	rep.extension, #session.Ecodigo#,#session.Usucodigo#,
	                    	rep.TipoComprobante,rep.Serie,
	                    	rep.Mcodigo,
	                    	rep.TipoCambio,
	                    	rep.CEMetPago,
	                    	rep.rfc,
	                    	rep.total,
						rep.CEtipoLinea,rep.CESNB,rep.CEtranOri,rep.CEdocumentoOri,rep.Miso4217
					from DContables dc
					inner join (
						SELECT r.*
						FROM EAplicacionCP c
						inner join DAplicacionCP b
							on b.ID = c.ID
						inner join EDocumentosCP a
							on  a.Ecodigo     = b.Ecodigo
							and a.CPTcodigo   = b.DAtransref
							and a.Ddocumento  = b.DAdocref
							and a.SNcodigo    = b.SNcodigo
							and a.IDdocumento = b.DAidref
						inner join CERepositorio r
							on a.IDdocumento = r.IdDocumento
						where r.origen = 'CPFC'
						union all
						SELECT r.*
						FROM EAplicacionCP c
						inner join CERepositorio r
							on c.Ddocumento = r.numDocumento
						where r.origen = 'CPFC'
					) rep
						on dc.Ddocumento = rep.numDocumento
						and dc.Ecodigo = rep.Ecodigo
					where dc.IDcontable = #LvarIDcontable#
				</cfquery>
				<!--- Comprobante por linea --->
				<cfquery name="rsDContable" datasource="#Session.DSN#">
					insert into CERepositorio(
						IdContable,IdDocumento,numDocumento,origen,linea,timbre,xmlTimbrado,archivoXML,
	                	archivo,nombreArchivo,extension, Ecodigo,BMUsucodigo,
						TipoComprobante,Serie,Mcodigo,TipoCambio,CEMetPago,rfc,total,
						CEtipoLinea,CESNB,CEtranOri,CEdocumentoOri,Miso4217)
					select dc.IDcontable, rep.IdDocumento, rep.numDocumento,
						'CPAP', dc.Dlinea, rep.timbre, rep.xmlTimbrado, rep.archivoXML, rep.archivo, rep.nombreArchivo,
	                    	rep.extension, #session.Ecodigo#,#session.Usucodigo#,
	                    	rep.TipoComprobante,rep.Serie,
	                    	rep.Mcodigo,
	                    	rep.TipoCambio,
	                    	rep.CEMetPago,
	                    	rep.rfc,
	                    	rep.total,
						rep.CEtipoLinea,rep.CESNB,rep.CEtranOri,rep.CEdocumentoOri,rep.Miso4217
					from DContables dc
					inner join (
						SELECT r.*
						FROM EAplicacionCP c
						inner join DAplicacionCP b
							on b.ID = c.ID
						inner join EDocumentosCP a
							on  a.Ecodigo     = b.Ecodigo
							and a.CPTcodigo   = b.DAtransref
							and a.Ddocumento  = b.DAdocref
							and a.SNcodigo    = b.SNcodigo
							and a.IDdocumento = b.DAidref
						inner join CERepositorio r
							on a.IDdocumento = r.IdDocumento
						where r.origen = 'CPFC'
					) rep
						on dc.Ddocumento = rep.numDocumento
						and dc.Ecodigo = rep.Ecodigo
					where dc.IDcontable = #LvarIDcontable#
				</cfquery>
			</cfif>
			<!--- Fin ContabilidadElectronica --->
			<!---
				Actualizar el saldo de los documentos Afectados
			--->
			<cfquery datasource="#LvarGblConexion#" name="rsSQL">
				select distinct
					b.Ecodigo, b.DAtransref, b.DAdocref, b.DAidref, b.SNcodigo, b.DAidref
				from DAplicacionCP b
				where b.ID = #LvarGblID#
			</cfquery>
			<cfquery name="rsNC" datasource="#session.dsn#">
		        SELECT cxp.EDretencionVariable,r.isVariable FROM EDocumentosCP cxp
                inner join Retenciones r on cxp.Rcodigo=r.Rcodigo and cxp.Ecodigo=r.Ecodigo
                where r.isVariable=1 and IDdocumento=#LvarGblID# and cxp.Ecodigo = #session.ecodigo#
			</cfquery>
			<cfquery name="rsNC2" datasource="#session.dsn#">
		        SELECT sum(cxp.EDretencionVariable) retVariable FROM EDocumentosCP cxp
                inner join Retenciones r on cxp.Rcodigo=r.Rcodigo and cxp.Ecodigo=r.Ecodigo
                where r.isVariable=1 and IDdocumento in (#valueList(rsSQL.DAidref)#) and cxp.Ecodigo = #session.ecodigo#
			</cfquery>
			<cfloop query="rsSQL">
				<cfset LvarDEcodigo = rsSQL.Ecodigo>
				<cfset LvarDDAtransref = rsSQL.DAtransref>
				<cfset LvarDDAdocref = rsSQL.DAdocref>
				<cfset LvarDDAidref = rsSQL.DAidref>
				<cfset LvarDSNcodigo = rsSQL.SNcodigo>
				<cfset LvarDDAidref = rsSQL.DAidref>

				<!--- RESTA EL MONTO TOTAL DE LA NOTA DE CREDITO AL DE LA FACTURA. --->
				<cfif LvarPorLinea EQ false>
					<!--- La afectación será por los montos totales --->

					<!--- Actualiza saldo en la tabla de impuestos DE FORMA PROPORCIONAL--->
					<cfquery datasource="#LvarGblConexion#" name="rsUpdateSaldosIVA">
						UPDATE ImpDocumentosCxP
						SET MontoCalculado = (MontoBaseCalc * (Iporcentaje/100)) - isNull(MontoPagado,0)
						<!--- case iporcentaje when 0 then 0 else
							MontoCalculado *
						  (SELECT CAST((cast(e.EDsaldo-sum(da.DAmontodoc)as float))/e.EDsaldo AS float)
							FROM EDocumentosCP e
							INNER JOIN DAplicacionCP da ON e.IDdocumento = da.DAidref
							WHERE e.IDdocumento = <cfqueryparam cfsqltype="cf_sql_numeric" value="#LvarDDAidref#">
							GROUP BY e.EDsaldo) end
						  --->
						WHERE IDdocumento = <cfqueryparam cfsqltype="cf_sql_numeric" value="#LvarDDAidref#">
						  AND Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.Ecodigo#">
					</cfquery>
					<cfquery datasource="#LvarGblConexion#" name="rsUpdateSaldosIEPS">
						UPDATE ImpIEPSDocumentosCxP
						SET MontoCalculadoIeps = (MontoBaseCalc * (Iporcentaje/100)) - MontoPagadoIeps
						WHERE IDdocumento = <cfqueryparam cfsqltype="cf_sql_numeric" value="#LvarDDAidref#">
						  AND Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.Ecodigo#">
					</cfquery>


					<!--- Actualizacion de saldos a nivel Encabezado --->
					<cfquery datasource="#LvarGblConexion#">
						UPDATE EDocumentosCP
						SET EDsaldo = EDsaldo - coalesce(
						                                   ( SELECT sum(DAmontodoc)
						                                    FROM DAplicacionCP c
						                                    WHERE c.ID = #LvarGblID#
						                                      AND c.DAidref = EDocumentosCP.IDdocumento
						                                      AND c.Ecodigo = EDocumentosCP.Ecodigo
						                                      AND c.DAtransref = EDocumentosCP.CPTcodigo
						                                      AND c.DAdocref = EDocumentosCP.Ddocumento
						                                      AND c.SNcodigo = EDocumentosCP.SNcodigo
						                                      AND c.DAidref = EDocumentosCP.IDdocumento ), 0.00)
						WHERE EDocumentosCP.Ecodigo = #LvarDEcodigo#
						  AND EDocumentosCP.CPTcodigo = '#LvarDDAtransref#'
						  AND EDocumentosCP.Ddocumento = '#LvarDDAdocref#'
						  AND EDocumentosCP.IDdocumento = #LvarDDAidref#
						  AND EDocumentosCP.SNcodigo = #LvarDSNcodigo#
						  AND EDocumentosCP.IDdocumento = #LvarDDAidref#
					</cfquery>
					<!--- Se recalcula la el monto de retencion basado en el nuevo saldo --->
					<cfquery datasource="#LvarGblConexion#" name="rsRet">
						select round((cxp.EDsaldo *  ( 
							select sum(DDtotallin) 
							from DDocumentosCP dcxp
							where dcxp.IDdocumento = cxp.IDdocumento
								and dcxp.Ecodigo = cxp.Ecodigo
						) / cxp.Dtotal) * (case when rd.Rporcentaje is not null then rd.Rporcentaje else r.Rporcentaje end / 100.00),2) total
						from EDocumentosCP cxp
						inner join Retenciones r
									left join RetencionesComp rc
										inner join Retenciones rd
										on rd.Ecodigo = rc.Ecodigo
										and rd.Rcodigo = rc.RcodigoDet
									on rc.Ecodigo = r.Ecodigo
									and rc.Rcodigo = r.Rcodigo
								on r.Ecodigo = cxp.Ecodigo
								and r.Rcodigo = cxp.Rcodigo
						WHERE cxp.Ecodigo = #LvarDEcodigo#
						  AND cxp.CPTcodigo = '#LvarDDAtransref#'
						  AND cxp.Ddocumento = '#LvarDDAdocref#'
						  AND cxp.IDdocumento = #LvarDDAidref#
						  AND cxp.SNcodigo = #LvarDSNcodigo#
						  AND cxp.IDdocumento = #LvarDDAidref#
					</cfquery>

					<cfquery name="rsRetenciones" dbtype="query">
                        select sum(total) as Retenciones
						from rsRet
                    </cfquery>

					<cfquery datasource="#LvarGblConexion#">
						Update cxp
						set EDmontoretori = <cfqueryparam cfsqltype="cf_sql_money" value="#rsRetenciones.Retenciones#">
						from EDocumentosCP cxp
						WHERE cxp.Ecodigo = #LvarDEcodigo#
						  AND cxp.CPTcodigo = '#LvarDDAtransref#'
						  AND cxp.Ddocumento = '#LvarDDAdocref#'
						  AND cxp.IDdocumento = #LvarDDAidref#
						  AND cxp.SNcodigo = #LvarDSNcodigo#
						  AND cxp.IDdocumento = #LvarDDAidref#
					</cfquery>
				<cfelse>
					<!--- Se trata de afectación por línea. --->
					<cfloop query="rsConsultaRelaciones">
						<!--- Descuento del monto de la linea de la nota de credito, al monto de la linea de la Factura --->
						<cfquery datasource="#LvarGblConexion#" name="rsGetNC">
							UPDATE DDocumentosCP
							SET DDtotallin = (DDtotallin - (SELECT DDtotallin
														    FROM DDocumentosCP
														    WHERE DDlinea = <cfqueryparam cfsqltype="cf_sql_numeric" value="#rsConsultaRelaciones.NCId#">))
							WHERE DDlinea = <cfqueryparam cfsqltype="cf_sql_numeric" value="#rsConsultaRelaciones.FCId#">
							AND Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.Ecodigo#">
						</cfquery>
						<!--- Actualiza saldo en la tabla de impuestos --->

						<cfquery datasource="#LvarGblConexion#" name="rsUpdateSaldosImp">
							UPDATE ImpDocumentosCxP
							SET MontoCalculado = (MontoBaseCalc * (Iporcentaje/100)) - isNull(MontoPagado,0)
							  <!---MontoCalculado - (SELECT ((d.DDpreciou*i.Iporcentaje)/100) AS impuestoLin
							   FROM DDocumentosCP d
							   INNER JOIN Impuestos i ON d.Icodigo = i.Icodigo
							   INNER JOIN CPrelacionLineasNcFc r ON r.NCId = d.DDlinea
							   AND r.NCId = <cfqueryparam cfsqltype="cf_sql_numeric" value="#rsConsultaRelaciones.NCId#">)--->
							WHERE IDdocumento = <cfqueryparam cfsqltype="cf_sql_numeric" value="#LvarDDAidref#">
							  AND Icodigo = 'IVA16'
							  AND Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.Ecodigo#">
						</cfquery>
						<!--- Se recalcula la el monto de retencion basado en el nuevo saldo --->
						<cfquery datasource="#LvarGblConexion#" name="rsRet">
							select round(( 
									select sum(DDtotallin) 
									from DDocumentosCP dcxp
									where dcxp.IDdocumento = cxp.IDdocumento
										and dcxp.Ecodigo = cxp.Ecodigo
							) * (case when rd.Rporcentaje is not null then rd.Rporcentaje else r.Rporcentaje end / 100.00),2) as total
							from EDocumentosCP cxp
							inner join Retenciones r
										left join RetencionesComp rc
											inner join Retenciones rd
											on rd.Ecodigo = rc.Ecodigo
											and rd.Rcodigo = rc.RcodigoDet
										on rc.Ecodigo = r.Ecodigo
										and rc.Rcodigo = r.Rcodigo
									on r.Ecodigo = cxp.Ecodigo
									and r.Rcodigo = cxp.Rcodigo
							WHERE cxp.Ecodigo = #Session.Ecodigo#
							AND cxp.IDdocumento = #LvarDDAidref#
						</cfquery>

						<cfquery name="rsRetenciones" dbtype="query">
                            select sum(total) as Retenciones
							from rsRet
                        </cfquery>

						<cfquery datasource="#LvarGblConexion#">
							Update cxp
							set EDmontoretori = <cfqueryparam cfsqltype="cf_sql_money" value="#rsRetenciones.Retenciones#">
							from EDocumentosCP cxp
							WHERE cxp.Ecodigo = #Session.Ecodigo#
							AND cxp.IDdocumento = #LvarDDAidref#
						</cfquery>


						<!--- Actualiza saldo en la tabla de impuestos IEPS --->
						<cfset descMontoCalIeps = 0.00>
						<cfquery datasource="#LvarGblConexion#" name="rsGetDescMontoCalculado">
							SELECT ((d.DDpreciou*i.Iporcentaje)/100) AS impuestoLin
							FROM DDocumentosCP d
							INNER JOIN Impuestos i ON d.codIEPS = i.Icodigo
							INNER JOIN CPrelacionLineasNcFc r ON r.NCId = d.DDlinea
							AND r.NCId = <cfqueryparam cfsqltype="cf_sql_numeric" value="#rsConsultaRelaciones.NCId#">
						</cfquery>

						<cfif rsGetDescMontoCalculado.RecordCount GT 0>
							<cfset descMontoCalIeps = #rsGetDescMontoCalculado.impuestoLin#>
						</cfif>

						<cfquery datasource="#LvarGblConexion#" name="rsUpdateSaldosImpIEPS">
							UPDATE ImpIEPSDocumentosCxP
							SET MontoCalculadoIeps = MontoCalculadoIeps - <cfqueryparam cfsqltype="cf_sql_money" value="#descMontoCalIeps#">
							WHERE IDdocumento = <cfqueryparam cfsqltype="cf_sql_numeric" value="#LvarDDAidref#">
							  AND Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.Ecodigo#">
						</cfquery>

						<cfif arguments.debug eq 'S'>
							<cfquery datasource="#LvarGblConexion#" name="mySel1">
								select * from ImpDocumentosCxP where IDdocumento = #LvarDDAidref#;
							</cfquery>
							<cfquery datasource="#LvarGblConexion#" name="mySel2">
								select * from ImpIEPSDocumentosCxP where IDdocumento = #LvarDDAidref#;
							</cfquery>
						</cfif>
					</cfloop>
					<cfquery name="rsUpdateSaldoFC" datasource="#LvarGblConexion#">
						UPDATE EDocumentosCP
						SET EDsaldo = coalesce(EDsaldo -
						                         (SELECT coalesce(EAtotal, 0.00) AS EAtotal
						                          FROM EAplicacionCP b
						                          WHERE b.ID = <cfqueryparam cfsqltype="cf_sql_numeric" value="#LvarGblID#">), 0.00)
						<cfif LvarAfectIVA EQ true>
							, afecIVA = 1
						</cfif>
						WHERE IDdocumento = <cfqueryparam cfsqltype="cf_sql_numeric" value="#LvarDDAidref#">
						AND Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#Session.Ecodigo#">
					</cfquery>

				</cfif>

				<!--- Afectaciones a las retenciones variables --->
                <cfif rsNC.recordCount gt 0 and rsNC.isVariable eq 1 and rsNC2.retVariable gt 0>
                    <cfquery name="rsFC" datasource="#session.dsn#">
						SELECT cxp.EDretencionVariable,r.isVariable FROM EDocumentosCP cxp
						inner join Retenciones r on cxp.Rcodigo=r.Rcodigo and cxp.Ecodigo=r.Ecodigo
						where r.isVariable=1 and IDdocumento=#rsSQL.DAidref# and cxp.Ecodigo = #session.ecodigo#
					</cfquery>
                    <cfif rsFC.recordCount gt 0 and rsFC.isVariable eq 1>
						<cfquery datasource="#LvarGblConexion#">
							UPDATE EDocumentosCP
							SET EDretencionVariable = EDretencionVariable - #(rsNC.EDretencionVariable * rsFC.EDretencionVariable) / rsNC2.retVariable#
							WHERE EDocumentosCP.Ecodigo = #LvarDEcodigo#
							  AND EDocumentosCP.CPTcodigo = '#LvarDDAtransref#'
							  AND EDocumentosCP.Ddocumento = '#LvarDDAdocref#'
							  AND EDocumentosCP.IDdocumento = #LvarDDAidref#
							  AND EDocumentosCP.SNcodigo = #LvarDSNcodigo#
							  AND EDocumentosCP.IDdocumento = #LvarDDAidref#
						</cfquery>
					</cfif>
                </cfif>
			</cfloop>

			<!---
				Actualizar el saldo del Documento a Favor
			--->
			<cfquery datasource="#LvarGblConexion#" name="rsSQL">
				select Ecodigo, CPTcodigo, Ddocumento, SNcodigo, coalesce(EAtotal, 0.00) as EAtotal
				from EAplicacionCP b
				where b.ID = #LvarGblID#
			</cfquery>

			<cfset LvarEAtotal     = rsSQL.EAtotal>
			<cfset LvarEEcodigo    = rsSQL.Ecodigo>
			<cfset LvarECPTcodigo  = rsSQL.CPTcodigo>
			<cfset LvarEDdocumento = rsSQL.Ddocumento>
			<cfset LvarESNcodigo   = rsSQL.SNcodigo>

			<cfquery datasource="#LvarGblConexion#">
				update EDocumentosCP
				set EDsaldo = EDsaldo - #LvarEAtotal#
				where EDocumentosCP.Ecodigo    = #LvarEEcodigo#
				  and EDocumentosCP.CPTcodigo  = '#LvarECPTcodigo#'
				  and EDocumentosCP.Ddocumento = '#LvarEDdocumento#'
				  and EDocumentosCP.SNcodigo   = #LvarESNcodigo#
			</cfquery>

			<!--- SML 06042021 Se insertan en las tablas del historico --->
			<cfquery datasource="#LvarGblConexion#">
				insert into HEAplicacionCP(ID, Ecodigo, CPTcodigo, Ddocumento, SNcodigo, Mcodigo, CFid, EAtipocambio, 
					EAtotal, EAfecha, EAusuario, EAselect, BMUsucodigo,HEACPreversa)
				select ID, Ecodigo, CPTcodigo, Ddocumento, SNcodigo, Mcodigo, CFid, EAtipocambio, 
					EAtotal, EAfecha, EAusuario, EAselect, BMUsucodigo,0
				from EAplicacionCP
				where Ecodigo = #LvarEEcodigo# 
					and ID = #LvarGblID#
				<cf_dbidentity1 name="rsHEAplicacionCP" datasource="#Arguments.Conexion#">
			</cfquery>
			<cf_dbidentity2 name="rsHEAplicacionCP" datasource="#Arguments.Conexion#" returnvariable="HEACPid">

			<cfquery datasource="#LvarGblConexion#">
				insert into HDAplicacionCP(HEACPid, ID, DAlinea, Ecodigo, SNcodigo, CFid, DAidref, DAtransref, DAdocref, DAmonto, DAtotal,
					DAmontodoc, DAtipocambio,
					BMUsucodigo, Rmontodoc, NumeroEvento)
				select #HEACPid#, ID, DAlinea, Ecodigo, SNcodigo, CFid, DAidref, DAtransref, DAdocref, DAmonto, DAtotal,
					DAmontodoc, DAtipocambio,
					BMUsucodigo, Rmontodoc, NumeroEvento
				from DAplicacionCP
				where Ecodigo = #LvarEEcodigo#  
					and ID = #LvarGblID#
			</cfquery>
			
			<!--- 7) Eliminar la aplicacion de las Estructuras Transaccionales --->
			<cfquery datasource="#LvarGblConexion#">
				delete from DAplicacionCP
				where ID = #LvarGblID#
			</cfquery>
			<cfquery datasource="#LvarGblConexion#">
				delete from EAplicacionCP
				where ID = #LvarGblID#
			</cfquery>

			<cfif arguments.debug eq 'S'>
				<cftransaction action="rollback"/>
				<cfreturn>
			</cfif>
		</cftransaction>
		<cfreturn>
	</cffunction>

	<cffunction name="fnContabilizaAplicacion" access="private" output="no">
    	<cfargument name="NumeroEvento" type="string"   required="no" default="">
		<!---
			Contabiliza la aplicacion de la Nota de Credito a las Facturas de Proveedor

			Proceso:
				Se contabiliza la cuenta de la nota de crédito con signo contrario al signo del documento original
				Se contabiliza la cuenta de las facturas con signo contrario al signo del documento original
				Se genera el balance entre monedas en la cuenta de balance de monedas ( solamente si son cuentas distintas )
		--->
		<!---
			1) Crédito: Documento a Favor por el monto aplicado (PAGO)
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE,NumeroEvento,CFid)
			select
				'CPAP',
				1,
				a.Ddocumento,
				a.CPTcodigo,
				round(a.EAtotal * a.EAtipocambio,2),
				'C',
				<cf_dbfunction name="concat" args="'CxP: Doc a Favor ',a.CPTcodigo,'-',a.Ddocumento">,
				'#LvarfechaChar#',
				a.EAtipocambio,
				#LvarPeriodo#,
				#LvarMes#,
				b.Ccuenta,
				b.Mcodigo,
				b.Ocodigo,
				a.EAtotal
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP b
				on  a.ID = b.IDdocumento
				and a.Ecodigo = b.Ecodigo
				and a.CPTcodigo = b.CPTcodigo
				and a.Ddocumento = b.Ddocumento
				and a.SNcodigo = b.SNcodigo
			where a.ID = #LvarGblID#
		</cfquery>

		<!---
			2) Debito a cada uno de los Documentos Afectados, por el monto de la afectacion (CxP)
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE,NumeroEvento,CFid)
			select
				'CPAP',
				1,
				a.DAdocref,
				a.DAtransref,
				round(a.DAmontodoc * c.EAtipocambio / a.DAtipocambio,2)  * round(c.EAtipocambio,2),
				'D',
				<cf_dbfunction name="concat" args="'CxP: Pago Documento ',a.DAtransref,'-',a.DAdocref">,
				'#LvarfechaChar#',
				c.EAtipocambio / a.DAtipocambio,
				#LvarPeriodo#,
				#LvarMes#,
				b.Ccuenta,
				b.Mcodigo,
				b.Ocodigo,
				a.DAmontodoc
                ,a.NumeroEvento,c.CFid
			from EAplicacionCP c
				inner join DAplicacionCP a
					inner join EDocumentosCP b
					 on b.Ecodigo 	  = a.Ecodigo
					and b.CPTcodigo   = a.DAtransref
					and b.Ddocumento  = a.DAdocref
					and b.SNcodigo 	  = a.SNcodigo
					and b.IDdocumento = a.DAidref
				 on a.ID = c.ID
			where c.ID = #LvarGblID#
		</cfquery>
		<!---
			2.b) Credito a cada uno de los Documentos Afectados, por el monto de la Retención
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE,NumeroEvento,CFid)
			select
				'CPAP',
				1,
				a.DAdocref,
				a.DAtransref,
				round(a.Rmontodoc * c.EAtipocambio / a.DAtipocambio,2),
				'C',
				<cf_dbfunction name="concat" args="'CxP: Retención Documento ',a.DAtransref,'-',a.DAdocref">,
				'#LvarfechaChar#',
				c.EAtipocambio / a.DAtipocambio,
				#LvarPeriodo#,
				#LvarMes#,
				b.Ccuenta,
				b.Mcodigo,
				b.Ocodigo,
				a.Rmontodoc
                ,a.NumeroEvento,c.CFid
			from EAplicacionCP c
				inner join DAplicacionCP a
					inner join EDocumentosCP b
					 on b.Ecodigo 	  = a.Ecodigo
					and b.CPTcodigo   = a.DAtransref
					and b.Ddocumento  = a.DAdocref
					and b.SNcodigo 	  = a.SNcodigo
					and b.IDdocumento = a.DAidref
				 on a.ID = c.ID
			where c.ID = #LvarGblID#
			  and a.Rmontodoc <> 0
		</cfquery>

		<!---
			3) Debito a la cuenta de Balance por Moneda por las aplicaciones en moneda diferente
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE,NumeroEvento,CFid)
			select
				'CPAP',
				1,

				a.DAdocref,
				a.DAtransref,
				round(a.DAtotal * c.EAtipocambio,2),
				'D',
				<cf_dbfunction name="concat" args="'Balance Moneda Documento ',a.DAtransref,'-',a.DAdocref">,
				'#LvarfechaChar#',
				c.EAtipocambio,
				#LvarPeriodo#,
				#LvarMes#,
				#LvarCuentaPuente#,
				#LvarMonedaNC#,
				b.Ocodigo,
				a.DAtotal
                ,a.NumeroEvento,c.CFid
			from EAplicacionCP c
				inner join DAplicacionCP a
					inner join EDocumentosCP b
					on a.Ecodigo = b.Ecodigo
					and a.DAtransref = b.CPTcodigo
					and a.DAdocref = b.Ddocumento
					and a.SNcodigo = b.SNcodigo
					and a.DAidref = b.IDdocumento

				on a.ID = c.ID
			where c.ID = #LvarGblID#
			  and b.Mcodigo <> #LvarMonedaNC#
		</cfquery>

		<!---
			4) Credito a la cuenta de Balance por Moneda por las aplicaciones en moneda diferente
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE,NumeroEvento,CFid)
			select
				'CPAP',
				1,
				a.DAdocref,
				a.DAtransref,
				round( (a.DAmontodoc - a.Rmontodoc) * c.EAtipocambio / a.DAtipocambio,2),
				'C',
				<cf_dbfunction name="concat" args="'Balance Moneda Documento ',a.DAtransref,'-',a.DAdocref">,
				'#LvarfechaChar#',
				c.EAtipocambio / a.DAtipocambio,
				#LvarPeriodo#,
				#LvarMes#,
				#LvarCuentaPuente#,
				b.Mcodigo,
				b.Ocodigo,
				(a.DAmontodoc - a.Rmontodoc)
                ,a.NumeroEvento,c.CFid
			from EAplicacionCP c
				inner join DAplicacionCP a
					inner join EDocumentosCP b
					on a.Ecodigo = b.Ecodigo
					and a.DAtransref = b.CPTcodigo
					and a.DAdocref = b.Ddocumento
					and a.SNcodigo = b.SNcodigo
					and a.DAidref = b.IDdocumento
				on a.ID = c.ID
			where c.ID = #LvarGblID#
			  and b.Mcodigo <> #LvarMonedaNC#
		</cfquery>
	</cffunction>

	<cffunction name="fnInsertaMovimientoImpuestos" access="private" output="no">
    	<cfargument name="PorLinea" type="boolean"   required="no" default="true">

		<!--- Primero actualiza el monto pagado de los impuestos credito fiscal ( tabla ImpDocumentosCxP ) --->
		<cfquery name="rsMovimientoImpuestos" datasource="#LvarGblConexion#">
			select
				x.IDdocumento,
				b.Icodigo,
				b.Ecodigo,
				case b.IPorcentaje when 0 then 0 else
				round((#LvarEAmonto# * b.MontoCalculado)/b.TotalFac,2) end as Pagado
			from EAplicacionCP a
				inner join EDocumentosCP x
					on a.Ecodigo = x.Ecodigo
					and  a.CPTcodigo = x.CPTcodigo
					and  a.Ddocumento = x.Ddocumento
					and  a.SNcodigo = x.SNcodigo
				inner join ImpDocumentosCxP b
					on x.Ecodigo = b.Ecodigo
					and x.IDdocumento = b.IDdocumento
				inner join CPTransacciones d
					on x.Ecodigo = d.Ecodigo
					and x.CPTcodigo = d.CPTcodigo
				inner join Impuestos i
					on b.Ecodigo = i.Ecodigo
					and b.Icodigo = i.Icodigo
			where a.ID = #LvarGblID#
		</cfquery>

		<cfloop query="rsMovimientoImpuestos">
			<cfquery datasource="#LvarGblConexion#">
				update ImpDocumentosCxP
				set MontoPagado = MontoPagado + #NumberFormat(rsMovimientoImpuestos.Pagado,"0.00")#
				where IDdocumento = #rsMovimientoImpuestos.IDdocumento#
				  and Icodigo     = '#rsMovimientoImpuestos.Icodigo#'
				  and Ecodigo     = #rsMovimientoImpuestos.Ecodigo#
			</cfquery>

		</cfloop>

		<!----Query del ieps ---->

		<cfquery name="rsMovimientoIeps" datasource="#LvarGblConexion#">
			select
				x.IDdocumento,
				b.codIEPS,
				b.Ecodigo,
				round((#LvarEAmonto# * isNull(b.MontoCalculadoIeps,0))/b.TotalFac,2) as Pagadoieps,
				i.ieps, i.IEscalonado
			from EAplicacionCP a
				inner join EDocumentosCP x
					on a.Ecodigo = x.Ecodigo
					and  a.CPTcodigo = x.CPTcodigo
					and  a.Ddocumento = x.Ddocumento
					and  a.SNcodigo = x.SNcodigo
				inner join ImpIEPSDocumentosCxP b
					on x.Ecodigo = b.Ecodigo
					and x.IDdocumento = b.IDdocumento
				inner join CPTransacciones d
					on x.Ecodigo = d.Ecodigo
					and x.CPTcodigo = d.CPTcodigo
				inner join Impuestos i
					on b.Ecodigo = i.Ecodigo
					and b.codIEPS = i.Icodigo

			where a.ID = #LvarGblID#
		</cfquery>
		<!--- actualizacion del ieps ---->

		<!--- Revisa si la factura/documento posee ieps escalonado--->
		<cfset esEscalonado = false>

		<cfloop query="rsMovimientoIeps">
			<cfquery datasource="#LvarGblConexion#">
				update ImpIEPSDocumentosCxP
				set MontoPagadoIeps = MontoPagadoIeps + #rsMovimientoIeps.Pagadoieps#
				where IDdocumento = #rsMovimientoIeps.IDdocumento#
				  and codIEPS     = '#rsMovimientoIeps.codIEPS#'
				  and Ecodigo     =  #rsMovimientoIeps.Ecodigo#
			</cfquery>
			<cfif rsMovimientoIeps.IEPS eq 1 && rsMovimientoIeps.IEscalonado eq 1>
				<cfset esEscalonado = true>
			</cfif>
		</cfloop>

		<!--- Segundo:  Actualizar los montos pagados de los impuestos correspondientes a las facturas --->
		<cfquery name="rsMovimientoImpuestos" datasource="#LvarGblConexion#">
			select
				b.IDdocumento,
				b.Icodigo,
				b.Ecodigo,
				<cfif esEscalonado>
					<cfif arguments.PorLinea>
						0
					<cfelse>
						Round(((det.damontodoc) * b.MontoCalculado)/b.TotalFac,2)
					</cfif>
				<cfelse>
					<cfif arguments.PorLinea>
						0
					<cfelse>
						Round(((det.damontodoc - #NumberFormat(rsMovimientoIeps.Pagadoieps,"0.00")#) * b.MontoCalculado)/b.TotalFac,2)
					</cfif>
				</cfif>  as Pagado
			from EAplicacionCP a
				inner join DAplicacionCP det
					on a.ID =  det.ID
				inner join ImpDocumentosCxP b
					on det.Ecodigo = b.Ecodigo
					and det.DAidref  = b.IDdocumento
				inner join CPTransacciones d
					on det.Ecodigo = d.Ecodigo
					and det.DAtransref = d.CPTcodigo
				inner join Impuestos i
					on b.Ecodigo = i.Ecodigo
					and b.Icodigo = i.Icodigo
			where a.ID = #LvarGblID#
		</cfquery>

		<cfif arguments.PorLinea>
			<cfquery name="rsMovimientoImpuestos" datasource="#LvarGblConexion#">
				select A.Ecodigo, A.IDdocumento, A.DDtotallin, C.Dtotal,I1.Iporcentaje,
					isNull(I2.ValorCalculo,0) as ValorCalculo,
					A.codIEPS,A.Icodigo,
					((A.DDtotallin * (1+(isNull(I2.ValorCalculo,0)/100)))*(1+(isNull(I1.Iporcentaje,0)/100))) as TotalLinea,
					(A.DDtotallin * (1+(isNull(I2.ValorCalculo,0)/100)))*(isNull(I1.Iporcentaje,0)/100) as IVA,
					((A.DDtotallin * (1+(isNull(I2.ValorCalculo,0)/100)))*(isNull(I1.Iporcentaje,0)/100))*(B.TotalNC / B.TotalFC) as Pagado,
					B.TotalNC / B.TotalFC as porcentaje
				from DDocumentosCP A
					inner join CPrelacionLineasNcFc B
						on B.FCId = A.DDlinea
					inner join HEDocumentosCP C
						on C.IDdocumento = B.MovAplicacion
					left join Impuestos I1
						on I1.Icodigo = A.Icodigo
					left join Impuestos I2
						on I2.Icodigo = A.codIEPS
				where A.IDdocumento = #rsMovimientoImpuestos.IDdocumento#;
			</cfquery>
		</cfif>

		<cfloop query="rsMovimientoImpuestos">
			<cfquery datasource="#LvarGblConexion#">
				update ImpDocumentosCxP
				set MontoPagado = MontoPagado + #rsMovimientoImpuestos.Pagado#
				where IDdocumento = #rsMovimientoImpuestos.IDdocumento#
				  and Icodigo     = '#rsMovimientoImpuestos.Icodigo#'
				  and Ecodigo     = #rsMovimientoImpuestos.Ecodigo#
			</cfquery>
		</cfloop>

		<!--- Actualizacion de la tabla del DIOT ---->
		<cfquery name="rsMovimientoDiotLinea" datasource="#LvarGblConexion#">
				SELECT DISTINCT LTRIM(RTRIM(da.DAidref)) IDdocumento,
				                LTRIM(RTRIM(dd.Icodigo)) Icodigo,
				                ea.Ecodigo,
				                <!---dd.DDtotallin, ---->
								SUM(dd.DDtotallin) AS DDtotallin,
				                im.MontoCalculado,
				                diot.SNcodigo,
				                diot.OIVAAcreditable,
								diot.LIVAAcreditable,
								diot.DIOTivacodigo,
								da.DAdocref,
								e.Ddocumento,
								e.Dtipocambio
				FROM EAplicacionCP ea
				INNER JOIN DAplicacionCP da ON ea.ID = da.ID
				INNER JOIN EDocumentosCP e ON e.Ddocumento = ea.Ddocumento
				AND e.CPTcodigo = ea.CPTcodigo
				AND e.SNcodigo = ea.SNcodigo
				AND e.Ecodigo = ea.Ecodigo
				INNER JOIN DDocumentosCP dd ON e.IDdocumento = dd.IDdocumento
				INNER JOIN ImpDocumentosCxP im ON im.IDdocumento = e.IDdocumento
				AND im.Icodigo = dd.Icodigo
				INNER JOIN DIOT_Control diot ON diot.CampoId = im.IDdocumento
				AND diot.Icodigo = im.Icodigo AND diot.SNcodigo = e.SNcodigo
				INNER JOIN HEDocumentosCP he ON he.IDdocumento = diot.CampoId
				INNER JOIN CPTransacciones t ON ea.Ecodigo = t.Ecodigo
				AND da.DAtransref = t.CPTcodigo
				WHERE ea.ID = #LvarGblID#
				  AND da.Ecodigo = #session.Ecodigo#
				  GROUP BY da.DAidref,
         					dd.Icodigo,
				                ea.Ecodigo,
        					im.MontoCalculado,
				                diot.SNcodigo,
         					diot.OIVAAcreditable,
         					diot.LIVAAcreditable,
				                diot.DIOTivacodigo,
								da.DAdocref,
								e.Ddocumento,
								e.Dtipocambio
				ORDER BY LTRIM(RTRIM(dd.Icodigo)) DESC
			</cfquery>

			<cfif rsMovimientoDiotLinea.recordcount gt 0>
				<cfloop query="rsMovimientoDiotLinea">
					<cfquery name="rsGetUltimoRegistroDIOT" datasource="#session.dsn#">
						SELECT TOP 1 DIOTid,	
								Ecodigo,
								SNcodigo,	
								Oorigen,	
								TablaOrigen,	
								CampoId,
								Icodigo,	
								IPeriodo,	
								IMes,	
								OMontoBaseIVA,	
								isnull(OIVAAcreditable, 0) as OIVAAcreditable,
								OIVAPagado,	
								LMontoBaseIVA,	
								isnull(LIVAAcreditable, 0) as LIVAAcreditable,	
								LIVAPagado,	
								TipoCambioIVA,	
								Usucodigo,	
								BMUsucodigo,	
								ts_rversion,
								Documento,	
								DIOTivacodigo,	
								Pagado,	
								Bid,	
								MontoRetIVA,	
								DocRefPago,	
								SaldoLin
						FROM DIOT_Control
						WHERE CampoId = <cfqueryparam cfsqltype="cf_sql_numeric" value="#rsMovimientoDiotLinea.IDdocumento#">
						  AND Icodigo = <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsMovimientoDiotLinea.Icodigo#">
						ORDER BY DIOTid DESC
					</cfquery>

					<cfquery name="tipCambIva" datasource="#LvarGblConexion#">
						SELECT Dtipocambio,
						       Rcodigo,
						       CASE
						           WHEN coalesce(EDretporigen, 0)>0 THEN EDretporigen
						           WHEN coalesce(EDmontoretori, 0)>0 THEN EDmontoretori
						           WHEN coalesce(EDretencionVariable, 0)>0 THEN EDretencionVariable
						           ELSE 0
						       END AS MontoRetIVA
						FROM HEDocumentosCP
						WHERE IDdocumento = <cfqueryparam cfsqltype="cf_sql_numeric" value="#rsMovimientoDiotLinea.IDdocumento#">
						  AND Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#session.Ecodigo#">
					</cfquery>

					<cftry>
						<cfquery datasource="#LvarGblConexion#">
						  INSERT INTO DIOT_Control (Ecodigo, SNcodigo, Oorigen, TablaOrigen, CampoId, Icodigo, IPeriodo, IMes, OMontoBaseIVA,
							LMontoBaseIVA, OIVAPagado, LIVAPagado, 
							<cfif rsGetUltimoRegistroDIOT.recordCount neq 0> OIVAAcreditable, LIVAAcreditable, </cfif>
							TipoCambioIVA,	Usucodigo, BMUsucodigo,
							ts_rversion,DIOTivacodigo,Documento,Pagado,MontoRetIva,DocRefPago)
						  VALUES
						  		(<cfqueryparam cfsqltype="cf_sql_numeric" value="#session.Ecodigo#">,
								 <cfqueryparam cfsqltype="cf_sql_numeric" value="#rsMovimientoDiotLinea.SNcodigo#">,
								 <cfqueryparam cfsqltype="cf_sql_varchar" value="CPCM">,
								 <cfqueryparam cfsqltype="cf_sql_varchar" value="EAplicacionCP">,
								 <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsMovimientoDiotLinea.IDdocumento#">,
								 <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsMovimientoDiotLinea.Icodigo#">,
								 <cfqueryparam cfsqltype="cf_sql_numeric" value="#LvarPeriodo#">,
								 <cfqueryparam cfsqltype="cf_sql_numeric" value="#LvarMes#">,
								 <cfqueryparam cfsqltype="cf_sql_money" value="#rsMovimientoDiotLinea.DDtotallin#">,
								 <cfqueryparam cfsqltype="cf_sql_money" value="#rsMovimientoDiotLinea.DDtotallin * rsMovimientoDiotLinea.Dtipocambio#">,
								 <cfqueryparam cfsqltype="cf_sql_money" value="#rsMovimientoDiotLinea.MontoCalculado#">,
								 <cfqueryparam cfsqltype="cf_sql_money" value="#rsMovimientoDiotLinea.MontoCalculado * rsMovimientoDiotLinea.Dtipocambio#">,
								 <cfif rsGetUltimoRegistroDIOT.recordCount neq 0>
								 <cfqueryparam cfsqltype="cf_sql_money" value="#rsGetUltimoRegistroDIOT.OIVAAcreditable - rsMovimientoDiotLinea.OIVAAcreditable#">,
								 <cfqueryparam cfsqltype="cf_sql_money" value="#rsGetUltimoRegistroDIOT.LIVAAcreditable - ((rsMovimientoDiotLinea.OIVAAcreditable)*(rsMovimientoDiotLinea.Dtipocambio))#">,
								 </cfif>
								 <cfqueryparam cfsqltype="cf_sql_numeric" value="#rsMovimientoDiotLinea.Dtipocambio#">,
								 <cfqueryparam cfsqltype="cf_sql_numeric" value="#session.Usucodigo#">,
								 <cfqueryparam cfsqltype="cf_sql_numeric" value="#session.Usucodigo#">,
								 <cfqueryparam cfsqltype="cf_sql_date" value="#Now()#">,
								 <cfqueryparam cfsqltype="cf_sql_numeric" value="#rsMovimientoDiotLinea.DIOTivacodigo#">,
								 <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsMovimientoDiotLinea.DAdocref#">,
								 <cfqueryparam cfsqltype="cf_sql_numeric" value="5">,<!--- Para marcar que es NC --->
								 <cfif isDefined("rsMovimientoDiotLinea.Icodigo") AND #TRIM(UCASE(rsMovimientoDiotLinea.Icodigo))# EQ "IVA16">
									 <cfqueryparam cfsqltype="cf_sql_money" value="#tipCambIva.MontoRetIVA#">
								 <cfelse>
								 	 0
								 </cfif>,
								 <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsMovimientoDiotLinea.Ddocumento#">
						  		)
						</cfquery>
						<cfcatch>

						</cfcatch>
					</cftry>

					

					<cfquery name="rsUpdateDiotNC" datasource="#LvarGblConexion#">
						UPDATE DIOT_Control
						SET SaldoLin = SaldoLin - <cfqueryparam cfsqltype="cf_sql_money" value="#rsMovimientoDiotLinea.DDtotallin * rsMovimientoDiotLinea.Dtipocambio#">
						WHERE CampoId = <cfqueryparam cfsqltype="cf_sql_numeric" value="#rsMovimientoDiotLinea.IDdocumento#">
						AND Ecodigo = <cfqueryparam cfsqltype="cf_sql_numeric" value="#session.Ecodigo#">
						AND SaldoLin > 0
						AND Icodigo = <cfqueryparam cfsqltype="cf_sql_varchar" value="#rsMovimientoDiotLinea.Icodigo#">
					</cfquery>
				</cfloop>
			</cfif>

	<!--- SegundoIEPS:  Actualizar los montos pagados de los IEPS correspondientes a las facturas --->
	<cfset varPagado = ((rsMovimientoImpuestos.RecordCount gt 0 and rsMovimientoImpuestos.Pagado eq ''))? 0 : rsMovimientoImpuestos.Pagado>
		<cfquery name="rsMovimientoIEPS" datasource="#LvarGblConexion#">
			select
				b.IDdocumento,
				b.codIEPS,
				b.Ecodigo,
				<cfif esEscalonado>
					<cfif arguments.PorLinea>
						0
					<cfelse>
						Round((((det.DAmontodoc) * isNull(b.MontoCalculadoIeps,0))/b.TotalFac),2)
					</cfif>
				<cfelse>
					<cfif arguments.PorLinea>
						Round(( (det.damontodoc - #varPagado#) - ((det.damontodoc - #varPagado#)/(1+(b.Iporcentaje/100))) ), 2)
					<cfelse>
						Round((((det.DAmontodoc - #varPagado#) * isNull(b.MontoCalculadoIeps,0))/b.TotalFac),2)
					</cfif>
				</cfif> AS Pagadoieps
			from EAplicacionCP a
				inner join DAplicacionCP det
					on a.ID =  det.ID
				inner join ImpIEPSDocumentosCxP b
					on det.Ecodigo = b.Ecodigo
					and det.DAidref  = b.IDdocumento
				inner join CPTransacciones d
					on det.Ecodigo = d.Ecodigo
					and det.DAtransref = d.CPTcodigo
				inner join Impuestos i
					on b.Ecodigo = i.Ecodigo
					and b.codIEPS = i.Icodigo
			where a.ID = #LvarGblID#
		</cfquery>

		<cfif esEscalonado>
			<cfif arguments.PorLinea>
				<cfquery name="rsMovimientoIEPS" datasource="#LvarGblConexion#">
				select A.Ecodigo, A.IDdocumento, A.DDtotallin, C.Dtotal,I1.Iporcentaje,
						isNull(I2.ValorCalculo,0) as ValorCalculo,
						A.codIEPS,A.Icodigo,
						(A.DDtotallin * (1+(isNull(I2.ValorCalculo,0)/100))) as TotalLinea,
						(A.DDtotallin * (isNull(I2.ValorCalculo,0)/100)) as IEPS,
						(A.DDtotallin * (isNull(I2.ValorCalculo,0)/100))*(B.TotalNC / B.TotalFC) as PagadoIEPS,
						B.TotalNC / B.TotalFC as porcentaje
					from DDocumentosCP A
						inner join CPrelacionLineasNcFc B
							on B.FCId = A.DDlinea
						inner join HEDocumentosCP C
							on C.IDdocumento = B.MovAplicacion
						left join Impuestos I1
							on I1.Icodigo = A.Icodigo
						left join Impuestos I2
							on I2.Icodigo = A.codIEPS
					where A.IDdocumento = #rsMovimientoImpuestos.IDdocumento#;
				</cfquery>
			</cfif>
		</cfif>

		<cfloop query="rsMovimientoIEPS">
			<cfquery datasource="#LvarGblConexion#">
				update ImpIEPSDocumentosCxP
				set MontoPagadoIeps = MontoPagadoIeps + #rsMovimientoIEPS.Pagadoieps#
				where IDdocumento = #rsMovimientoIEPS.IDdocumento#
				  and codIEPS     = '#rsMovimientoIEPS.codIEPS#'
				  and Ecodigo     = #rsMovimientoIEPS.Ecodigo#
			</cfquery>
		</cfloop>

		<!---
		<cfquery name="sel" datasource="#session.dsn#">
			select IDdocumento,codIEPS, TotalFac, SubTotalFac,MontoCalculadoIeps,MontoBaseCalc,MontoPagadoIeps,Iporcentaje
			from ImpIEPSDocumentosCxP where IDdocumento = #rsMovimientoIeps.IDdocumento#;
		</cfquery>
	
		--->


		<!--- Inserta monto pagado por intereses en la tabla ImpDocumentosCxPMov --->
		<!---1.  Nota Crédito --->
		<cfquery datasource="#LvarGblConexion#">
			insert into ImpDocumentosCxPMov (
				IDdocumento,
				Icodigo,
				Ecodigo,
				Fecha,
				MontoPagado,
				CPTcodigo,
				Ddocumento,
				CPTpago,
				CcuentaAC,
				Periodo,
				Mes,
				BMUsucodigo,
				BMFecha,
				TpoCambio,
				MontoPagadoLocal
			)
			select
				x.IDdocumento,
				b.Icodigo,
				b.Ecodigo,
				a.EAfecha,
				round((#LvarEAmonto# * b.MontoCalculado)/b.TotalFac,2),
				a.CPTcodigo,
				a.Ddocumento,
				d.CPTpago,
				coalesce(i.CcuentaCxCAcred,i.Ccuenta),
				#LvarPeriodo#,
				#LvarMes#,

				b.BMUsucodigo,
				<cf_dbfunction name="now">,
				a.EAtipocambio,
				round(((#LvarEAmonto# * b.MontoCalculado)/b.TotalFac) * a.EAtipocambio,2)
			from EAplicacionCP a
				inner join EDocumentosCP x
				on a.Ecodigo = x.Ecodigo
				and  a.CPTcodigo = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo = x.SNcodigo

				inner join ImpDocumentosCxP b
				on x.Ecodigo = b.Ecodigo
				and x.IDdocumento = b.IDdocumento

				inner join CPTransacciones d
				on x.Ecodigo = d.Ecodigo
				and x.CPTcodigo = d.CPTcodigo

				inner join Impuestos i
				on b.Ecodigo = i.Ecodigo
				and b.Icodigo = i.Icodigo
			where a.ID = #LvarGblID#
		</cfquery>
<cfif rsMovimientoIEPS.recordcount gt 0>
			<!--- Inserta monto pagado por intereses en la tabla ImpIEPSDocumentosCxPMov --->
		<!---1.2  Nota Crédito --->
		<cfquery datasource="#LvarGblConexion#">
			insert into ImpIEPSDocumentosCxPMov (
				IDdocumento,
				codIEPS,
				Ecodigo,
				Fecha,
				MontoPagadoIeps,
				CPTcodigo,
				Ddocumento,
				CPTpago,
				CcuentaACIeps,
				Periodo,
				Mes,
				BMUsucodigo,
				BMFecha,
				TpoCambio,
				MontoPagadoLocalIeps
			)
			select
				x.IDdocumento,
				b.codIEPS,
				b.Ecodigo,
				a.EAfecha,
				round((#LvarEAmonto# * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2),
				a.CPTcodigo,
				a.Ddocumento,
				d.CPTpago,
				coalesce(ie.CcuentaCxCAcred,ie.Ccuenta),
				#LvarPeriodo#,
				#LvarMes#,

				b.BMUsucodigo,
				<cf_dbfunction name="now">,
				a.EAtipocambio,
				round(((#LvarEAmonto# * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac) * a.EAtipocambio,2)
			from EAplicacionCP a
				inner join EDocumentosCP x
				on a.Ecodigo = x.Ecodigo
				and  a.CPTcodigo = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo = x.SNcodigo

				inner join ImpIEPSDocumentosCxP b
				on x.Ecodigo = b.Ecodigo
				and x.IDdocumento = b.IDdocumento

				inner join CPTransacciones d
				on x.Ecodigo = d.Ecodigo
				and x.CPTcodigo = d.CPTcodigo

				inner join Impuestos ie
				on b.Ecodigo = ie.Ecodigo
				and b.codIEPS = ie.Icodigo
			where a.ID = #LvarGblID#
		</cfquery>
</cfif>


<cfif rsMovimientoIEPS.recordcount gt 0>
		<!--- 2. Facturas --->
		<cfquery datasource="#LvarGblConexion#">
			insert into ImpDocumentosCxPMov (
				IDdocumento,
				Icodigo,
				Ecodigo,
				Fecha,
				MontoPagado,
				CPTcodigo,
				Ddocumento,
				CPTpago,
				CcuentaAC,
				Periodo,
				Mes,
				BMUsucodigo,
				BMFecha,
				TpoCambio,
				MontoPagadoLocal
			)
			select
				b.IDdocumento,
				b.Icodigo,
				b.Ecodigo,
				a.EAfecha,
				round((det.DAmontodoc * b.MontoCalculado)/b.TotalFac,2),
				d.CPTcodigo,
				a.Ddocumento,
				d.CPTpago,
				coalesce(ie.CcuentaCxCAcred,ie.Ccuenta),
				#LvarPeriodo#,
				#LvarMes#,

				b.BMUsucodigo,
				<cf_dbfunction name="now">,
				(det.DAmonto / det.DAmontodoc * a.EAtipocambio),
				round(((det.DAmontodoc * b.MontoCalculado)/b.TotalFac) * (det.DAmonto / det.DAmontodoc * a.EAtipocambio),2)
			from EAplicacionCP a
				inner join DAplicacionCP det
					on a.ID = det.ID
					 and a.Ecodigo = det.Ecodigo
						inner join ImpDocumentosCxP b
						on det.Ecodigo = b.Ecodigo
						and det.DAidref  = b.IDdocumento

						inner join CPTransacciones d
						on det.Ecodigo = d.Ecodigo
						and det.DAtransref = d.CPTcodigo

						inner join Impuestos ie
						on b.Ecodigo = ie.Ecodigo
						and b.Icodigo = ie.Icodigo
			where a.ID = #LvarGblID#
		</cfquery>

		<!--- 2.2 Facturas ieps --->
		<cfquery datasource="#LvarGblConexion#">
			insert into ImpIEPSDocumentosCxPMov (
				IDdocumento,
				codIEPS,
				Ecodigo,
				Fecha,
				MontoPagadoIeps,
				CPTcodigo,
				Ddocumento,
				CPTpago,
				CcuentaACIeps,
				Periodo,
				Mes,
				BMUsucodigo,
				BMFecha,
				TpoCambio,
				MontoPagadoLocalIeps
			)
			select
				b.IDdocumento,
				b.codIEPS,
				b.Ecodigo,
				a.EAfecha,
				round((det.DAmontodoc * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2),
				d.CPTcodigo,
				a.Ddocumento,
				d.CPTpago,
				coalesce(ie.CcuentaCxCAcred,ie.Ccuenta),
				#LvarPeriodo#,
				#LvarMes#,

				b.BMUsucodigo,
				<cf_dbfunction name="now">,
				(det.DAmonto / det.DAmontodoc * a.EAtipocambio),
				round(((det.DAmontodoc * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac) * (det.DAmonto / det.DAmontodoc * a.EAtipocambio),2)
			from EAplicacionCP a
				inner join DAplicacionCP det
						inner join ImpIEPSDocumentosCxP b
						on det.Ecodigo = b.Ecodigo
						and det.DAidref  = b.IDdocumento

						inner join CPTransacciones d
						on det.Ecodigo = d.Ecodigo
						and det.DAtransref = d.CPTcodigo

						inner join Impuestos ie
						on b.Ecodigo = ie.Ecodigo
						and b.codIEPS = ie.Icodigo
				on a.ID = det.ID
			where a.ID = #LvarGblID#
		</cfquery>
</cfif>

		<cfreturn>
	</cffunction>

	<cffunction name="fnContabilizaDiferencialDocFavor" access="private" output="no">
    	<cfargument name="NumeroEvento" type="string"   required="no" default="">
		<!---
			Diferencial Cambiario Doc a Favor						D CtaCxP		round( ( round( a.EAtotal,2) ) * ( a.EAtipocambio - x.EDtcultrev), 2)
			Diferencial Cambiario Doc a Favor Impuesto CF			D CcuentaImp	round( ( round(((EAtotal * b.MontoCalculado)/b.TotalFac),2) ) * ( a.EAtipocambio - x.EDtcultrev) , 2)
			Ingreso/Gasto por Diferencial Cambiario Doc a Favor		D CtaDiff		(Diferencial Cambiario Doc a Favor) - sum(Diferencial Cambiario Doc a Favor Impuesto CF)
		--->

		<!--- 1. Diferencial Cambiario del Documento a Favor --->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				x.Ddocumento,
				x.CPTcodigo,
				round( ( round( a.EAtotal,2) ) * ( a.EAtipocambio - x.EDtcultrev), 2),
				d.CPTtipo,
				<cf_dbfunction name="concat" args="'Diferencial Cambiario (Doc a Favor): ', x.Ddocumento">,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				x.Ccuenta,
				x.Mcodigo,
				x.Ocodigo,
				0.00
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP x
						inner join CPTransacciones d
						on x.Ecodigo    = d.Ecodigo
						and x.CPTcodigo = d.CPTcodigo
				on   a.Ecodigo = x.Ecodigo
				and  a.CPTcodigo = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo = x.SNcodigo
			where a.ID = #LvarGblID#
			  and x.Mcodigo <> #LvarMonlocal#
		</cfquery>

		<!--- 2. Ajuste de Diferencial Cambiario a los Impuestos Credito Fiscal del Documento a Favor --->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				x.Ddocumento,
				x.CPTcodigo,
				round( ( round(((EAtotal * b.MontoCalculado)/b.TotalFac),2) ) * ( a.EAtipocambio - x.EDtcultrev) , 2),
				'C',
				<cf_dbfunction name="concat" args="'Diferencial Cambiario Impuesto CF (Doc a Favor): ',i.Icodigo">,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				CcuentaImp,
				x.Mcodigo,
				x.Ocodigo,
				0.00
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP x
					inner join CPTransacciones d
						on x.Ecodigo     = d.Ecodigo
						and x.CPTcodigo  = d.CPTcodigo

				 on  a.Ecodigo    = x.Ecodigo
				and  a.CPTcodigo  = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo   = x.SNcodigo

				inner join ImpDocumentosCxP b
					inner join Impuestos i
						on b.Ecodigo = i.Ecodigo
						and b.Icodigo = i.Icodigo
				 on x.Ecodigo      = b.Ecodigo
				and x.IDdocumento = b.IDdocumento

			where a.ID = #LvarGblID#
			and   x.Mcodigo <> #LvarMonlocal#
		</cfquery>

		<!--- 2.1 Ajuste de Diferencial Cambiario a los IEPS Credito Fiscal del Documento a Favor --->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				x.Ddocumento,
				x.CPTcodigo,
				round( ( round(((EAtotal * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac),2) ) * ( a.EAtipocambio - x.EDtcultrev) , 2),
				'C',
				<cf_dbfunction name="concat" args="'Diferencial Cambiario Impuesto CF (Doc a Favor): ',i.Icodigo">,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				CcuentaImpIeps,
				x.Mcodigo,
				x.Ocodigo,
				0.00
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP x
					inner join CPTransacciones d
						on x.Ecodigo     = d.Ecodigo
						and x.CPTcodigo  = d.CPTcodigo

				 on  a.Ecodigo    = x.Ecodigo
				and  a.CPTcodigo  = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo   = x.SNcodigo

				inner join ImpIEPSDocumentosCxP b
					inner join Impuestos i
						on b.Ecodigo = i.Ecodigo
						and b.codIEPS = i.Icodigo
				 on x.Ecodigo      = b.Ecodigo
				and x.IDdocumento = b.IDdocumento

			where a.ID = #LvarGblID#
			and   x.Mcodigo <> #LvarMonlocal#
		</cfquery>

		<!--- 3. Ingreso/Gasto por Diferencial Cambiario del Documento a Favor (Excluyendo el ajuste a los impuestos Credito Fiscal) --->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				x.Ddocumento,
				x.CPTcodigo,
				round( ( round( a.EAtotal,2) ) * ( a.EAtipocambio - x.EDtcultrev), 2) -
						coalesce(
							(
								select sum(round( ( round(((EAtotal * b.MontoCalculado)/b.TotalFac),2) ) * ( EAtipocambio - x.EDtcultrev) , 2))
								  from EAplicacionCP aa
									inner join EDocumentosCP x
										 on  a.Ecodigo    = x.Ecodigo
										and  a.CPTcodigo  = x.CPTcodigo
										and  a.Ddocumento = x.Ddocumento
										and  a.SNcodigo   = x.SNcodigo
									inner join ImpDocumentosCxP b
										 on x.Ecodigo      = b.Ecodigo
										and x.IDdocumento = b.IDdocumento
								 where aa.ID = a.ID
							)
						,0) -
						coalesce(
							(
								select sum(round( ( round(((EAtotal * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac),2)) * ( EAtipocambio - x.EDtcultrev) , 2))
								  from EAplicacionCP aa
									inner join EDocumentosCP x
										 on  a.Ecodigo    = x.Ecodigo
										and  a.CPTcodigo  = x.CPTcodigo
										and  a.Ddocumento = x.Ddocumento
										and  a.SNcodigo   = x.SNcodigo
									inner join ImpIEPSDocumentosCxP b
										 on x.Ecodigo      = b.Ecodigo
										and x.IDdocumento = b.IDdocumento
								 where aa.ID = a.ID
							)
						,0)
				,
				'C',
				case when a.EAtipocambio - x.EDtcultrev > 0
					then 'Ingreso por Diferencial Cambiario (Doc a Favor)'
					else 'Gasto por Diferencial Cambiario (Doc a Favor)'
				end,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				case when a.EAtipocambio - x.EDtcultrev > 0
					then #LvarCuentaIngDifCam#
					else #LvarCuentaGasDifCam#
				end,
				x.Mcodigo,
				x.Ocodigo,
				0.00
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP x
						inner join CPTransacciones d
						on x.Ecodigo    = d.Ecodigo
						and x.CPTcodigo = d.CPTcodigo
				on   a.Ecodigo = x.Ecodigo
				and  a.CPTcodigo = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo = x.SNcodigo
			where a.ID = #LvarGblID#
			  and x.Mcodigo <> #LvarMonlocal#
			  and a.EAtipocambio - x.EDtcultrev <> 0
		</cfquery>

		<cfreturn>
	</cffunction>

	<cffunction name="fnContabilizaDiferencialDocAplic" access="private" output="no">
    	<cfargument name="NumeroEvento" type="string"   required="no" default="">

		<!---
			Diferencial Cambiario Documento						D CtaCxP		round( ( round(DAmontodoc,2) ) * ( (DAmonto / DAmontodoc * a.EAtipocambio) - x.EDtcultrev) , 2)
			Diferencial Cambiario Documento Impuesto CF			D CcuentaImp	round( ( round(((DAmontodoc * b.MontoCalculado)/b.TotalFac),2) ) * ( (DAmonto / DAmontodoc * a.EAtipocambio) - x.EDtcultrev	) , 2),
			Ingreso/Gasto por Diferencial Cambiario Documento	D CtaDiff		(Diferencial Cambiario Documento) - sum(Diferencial Cambiario Documento Impuesto CF)
		--->

		<!--- 1. Diferencial Cambiario del Documento (Cuenta por pagar) --->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				x.Ddocumento,
				x.CPTcodigo,
				round( ( round(DAmontodoc,2) ) * ( (DAmonto / DAmontodoc * a.EAtipocambio) - x.EDtcultrev) , 2),
				d.CPTtipo,
				<cf_dbfunction name="concat" args="'Diferencial Cambiario (Documento): ', x.Ddocumento">,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				x.Ccuenta,
				x.Mcodigo,
				x.Ocodigo,
				0.00
                ,det.NumeroEvento,a.CFid
			from EAplicacionCP a
				inner join DAplicacionCP det
					inner join CPTransacciones d
					on det.Ecodigo = d.Ecodigo
					and det.DAtransref = d.CPTcodigo

					inner join EDocumentosCP x
					on det.Ecodigo = x.Ecodigo
					and  det.DAidref = x.IDdocumento

				on a.ID = det.ID
			where a.ID = #LvarGblID#
			and  x.Mcodigo <> #LvarMonlocal#
		</cfquery>

		<!--- 2. Ajuste por Diferencial Cambiario a los Impuestos Credito Fiscal de las Facturas  --->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				x.Ddocumento,
				x.CPTcodigo,
				round( (det.DAmontodoc * b.MontoCalculado)/b.TotalFac * ( (det.DAmonto / det.DAmontodoc * a.EAtipocambio) - x.EDtcultrev ) , 2),
				'D',
				<cf_dbfunction name="concat" args="'Diferencial Cambiario Impuesto CF (Documento): ', i.Icodigo">,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				CcuentaImp,
				x.Mcodigo,
				x.Ocodigo,
				0.00
                ,det.NumeroEvento,a.CFid
			from EAplicacionCP a
				inner join DAplicacionCP det
						inner join EDocumentosCP x
						on det.Ecodigo = x.Ecodigo
						and  det.DAidref = x.IDdocumento

						inner join ImpDocumentosCxP b
							inner join Impuestos i
							on b.Ecodigo = i.Ecodigo
							and b.Icodigo = i.Icodigo

						on det.Ecodigo = b.Ecodigo
						and det.DAidref  = b.IDdocumento

						inner join CPTransacciones d
						on det.Ecodigo = d.Ecodigo
						and det.DAtransref = d.CPTcodigo

				on a.ID = det.ID

			where a.ID = #LvarGblID#
			and  x.Mcodigo <> #LvarMonlocal#
		</cfquery>

		<!--- 2.1 Ajuste por Diferencial Cambiario a los IEPS Credito Fiscal de las Facturas  --->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				x.Ddocumento,
				x.CPTcodigo,
				round( (det.DAmontodoc * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac * ( (det.DAmonto / det.DAmontodoc * a.EAtipocambio) - x.EDtcultrev ) , 2),
				'D',
				<cf_dbfunction name="concat" args="'Diferencial Cambiario Impuesto CF (Documento): ', i.Icodigo">,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				CcuentaImpIeps,
				x.Mcodigo,
				x.Ocodigo,
				0.00
                ,det.NumeroEvento,a.CFid
			from EAplicacionCP a
				inner join DAplicacionCP det
						inner join EDocumentosCP x
						on det.Ecodigo = x.Ecodigo
						and  det.DAidref = x.IDdocumento

						inner join ImpIEPSDocumentosCxP b
							inner join Impuestos i
							on b.Ecodigo = i.Ecodigo
							and b.codIEPS = i.Icodigo

						on det.Ecodigo = b.Ecodigo
						and det.DAidref  = b.IDdocumento

						inner join CPTransacciones d
						on det.Ecodigo = d.Ecodigo
						and det.DAtransref = d.CPTcodigo

				on a.ID = det.ID

			where a.ID = #LvarGblID#
			and  x.Mcodigo <> #LvarMonlocal#
		</cfquery>

		<!--- 3. Ingreso/Gasto por Diferencial Cambiario de las Facturas (Excluyendo el ajuste a los impuestos Credito Fiscal) --->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON,
							  INTTIP, INTDES, INTFEC, INTCAM, Periodo,
							   Mes,   Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				x.Ddocumento,
				x.CPTcodigo,
				round(DAmontodoc * ( (det.DAmonto / det.DAmontodoc * a.EAtipocambio) - x.EDtcultrev),2) -
						coalesce(
							(
								select sum(round( (DAmontodoc * b.MontoCalculado)/b.TotalFac * ( (DAmonto / DAmontodoc * a.EAtipocambio) - x.EDtcultrev ) , 2))
								  from DAplicacionCP dett
									inner join ImpDocumentosCxP b
										 on b.Ecodigo 	  = dett.Ecodigo
										and b.IDdocumento = dett.DAidref
									inner join EAplicacionCP a
										 on a.ID = dett.ID
									inner join EDocumentosCP x
										 on x.Ecodigo 	  = dett.Ecodigo
										and x.IDdocumento = dett.DAidref
								 where dett.DAlinea = det.DAlinea
							)
						,0) -
						coalesce(
							(
							select sum(round( (DAmontodoc * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac * ( (DAmonto / DAmontodoc * a.EAtipocambio) - x.EDtcultrev ) , 2))
								  from DAplicacionCP dett
									inner join ImpIEPSDocumentosCxP b
										 on b.Ecodigo 	  = dett.Ecodigo
										and b.IDdocumento = dett.DAidref
									inner join EAplicacionCP a
										 on a.ID = dett.ID
									inner join EDocumentosCP x
										 on x.Ecodigo 	  = dett.Ecodigo
										and x.IDdocumento = dett.DAidref
								 where dett.DAlinea = det.DAlinea
							)
						,0)
				,
				'D',
				case when a.EAtipocambio - x.EDtcultrev > 0
					then 'Gasto por Diferencial Cambiario (Documento)'
					else 'Ingreso por Diferencial Cambiario (Documento)'
				end,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				case when a.EAtipocambio - x.EDtcultrev > 0
					then #LvarCuentaGasDifCam#
					else #LvarCuentaIngDifCam#
				end,
				x.Mcodigo,
				x.Ocodigo,
				0.00
                ,det.NumeroEvento,a.CFid
			from EAplicacionCP a
				inner join DAplicacionCP det
					inner join CPTransacciones d
					on det.Ecodigo = d.Ecodigo
					and det.DAtransref = d.CPTcodigo

					inner join EDocumentosCP x
					on det.Ecodigo = x.Ecodigo
					and  det.DAidref = x.IDdocumento

				on a.ID = det.ID
			where a.ID = #LvarGblID#
			  and x.Mcodigo <> #LvarMonlocal#
			  and a.EAtipocambio - x.EDtcultrev <> 0
		</cfquery>
		<cfreturn>
	</cffunction>

	<cffunction name="fnContabilizaTrasladoImpuestos" access="private" output="no">
    	<cfargument name="NumeroEvento" type="string"   required="no" default="">
		<!---
			Contabiliza el traslado de los montos de impuestos, de los documentos aplicados.
			La contabilización traslada de la cuenta contable de Impuestos por Acreditar a Impuestos Acreditados.
			Se debe de tomar en consideración que los Impuestos Acreditados se trasladan en la moneda local de la empresa
			Por este motivo, se realiza un balance entre monedas al trasladar los impuestos

			El proceso inicia por el traslado de impuestos de la nota de crédito del proveedor
			Continua trasladando los impuestos de las facturas asociadas
			Finaliza balanceando las monedas de los documentos y la moneda local

		--->
		<!---
			1.  Traslado de los impuestos asociados a la Nota Crédito
				Se contabiliza un movimiento a la cuenta de impuestos por acreditar de la tabla de impuestos
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				a.Ddocumento,
				a.CPTcodigo,
				round((a.EAtotal * b.MontoCalculado)/b.TotalFac,2) * round(a.EAtipocambio,2),
				d.CPTtipo,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Doc a Favor)'">,
				'#LvarfechaChar#',
				a.EAtipocambio,
				#LvarPeriodo#,
				#LvarMes#,
				CcuentaImp,
				a.Mcodigo,
				x.Ocodigo,
				round((a.EAtotal * b.MontoCalculado)/b.TotalFac,2)
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP x
				on   a.Ecodigo = x.Ecodigo
				and  a.CPTcodigo = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo = x.SNcodigo

				inner join ImpDocumentosCxP b
				on x.Ecodigo = b.Ecodigo
				and x.IDdocumento = b.IDdocumento

				inner join CPTransacciones d
				on x.Ecodigo = d.Ecodigo
				and x.CPTcodigo = d.CPTcodigo

				inner join Impuestos i
				on b.Ecodigo = i.Ecodigo
				and b.Icodigo = i.Icodigo
			where a.ID = #LvarGblID#
			and  x.Mcodigo <> #LvarMonlocal#
			and i.CcuentaCxPAcred is not null
		</cfquery>

		<!---
			1.2  Traslado de los IEPS asociados a la Nota Crédito
				Se contabiliza un movimiento a la cuenta de IEPS por acreditar de la tabla de impuestos
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				a.Ddocumento,
				a.CPTcodigo,
				round((a.EAtotal * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2) * round(a.EAtipocambio,2),
				d.CPTtipo,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Doc a Favor)'">,
				'#LvarfechaChar#',
				a.EAtipocambio,
				#LvarPeriodo#,
				#LvarMes#,
				CcuentaImpIeps,
				a.Mcodigo,
				x.Ocodigo,
				round((a.EAtotal * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2)
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP x
				on   a.Ecodigo = x.Ecodigo
				and  a.CPTcodigo = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo = x.SNcodigo

				inner join ImpIEPSDocumentosCxP b
				on x.Ecodigo = b.Ecodigo
				and x.IDdocumento = b.IDdocumento

				inner join CPTransacciones d
				on x.Ecodigo = d.Ecodigo
				and x.CPTcodigo = d.CPTcodigo

				inner join Impuestos i
				on b.Ecodigo = i.Ecodigo
				and b.codIEPS = i.Icodigo
			where a.ID = #LvarGblID#
			and  x.Mcodigo <> #LvarMonlocal#
			and i.CcuentaCxPAcred is not null
		</cfquery>

		<!---
			2.  Traslado de los impuestos asociados a la Nota Crédito
				Se contabiliza un movimiento a la cuenta de impuestos acreditatos, EN LA MONEDA LOCAL
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				a.Ddocumento,
				a.CPTcodigo,
				round((a.EAtotal * b.MontoCalculado)/b.TotalFac,2) * round(a.EAtipocambio,2),
				case when d.CPTtipo = 'D' then 'C' else 'D' end,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Doc a Favor  - Acreditada)'">,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				i.CcuentaCxPAcred,
				#LvarMonlocal#,
				x.Ocodigo,
				round((a.EAtotal * b.MontoCalculado)/b.TotalFac,2) * round(a.EAtipocambio,2)
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP x
						inner join ImpDocumentosCxP b
								inner join Impuestos i
								on b.Ecodigo = i.Ecodigo
								and b.Icodigo = i.Icodigo

						on x.Ecodigo      = b.Ecodigo
						and x.IDdocumento = b.IDdocumento

						inner join CPTransacciones d
						on x.Ecodigo = d.Ecodigo
						and x.CPTcodigo = d.CPTcodigo

				on   a.Ecodigo    = x.Ecodigo
				and  a.CPTcodigo  = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo   = x.SNcodigo

			where a.ID = #LvarGblID#
			and i.CcuentaCxPAcred is not null
			and  x.Mcodigo <> #LvarMonlocal#
		</cfquery>

		<!---
			2.1  Traslado de los IEPS asociados a la Nota Crédito
				Se contabiliza un movimiento a la cuenta de IEPS acreditatos, EN LA MONEDA LOCAL
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				a.Ddocumento,
				a.CPTcodigo,
				round((a.EAtotal * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2) * round(a.EAtipocambio,2),
				case when d.CPTtipo = 'D' then 'C' else 'D' end,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Doc a Favor  - Acreditada)'">,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				i.CcuentaCxPAcred,
				#LvarMonlocal#,
				x.Ocodigo,
				round((a.EAtotal * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2) * round(a.EAtipocambio,2)
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP x
						inner join ImpIEPSDocumentosCxP b
								inner join Impuestos i
								on b.Ecodigo = i.Ecodigo
								and b.codIEPS = i.Icodigo

						on x.Ecodigo      = b.Ecodigo
						and x.IDdocumento = b.IDdocumento

						inner join CPTransacciones d
						on x.Ecodigo = d.Ecodigo
						and x.CPTcodigo = d.CPTcodigo

				on   a.Ecodigo    = x.Ecodigo
				and  a.CPTcodigo  = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo   = x.SNcodigo

			where a.ID = #LvarGblID#
			and i.CcuentaCxPAcred is not null
			and  x.Mcodigo <> #LvarMonlocal#
		</cfquery>

		<!---
			3.  Hacer el balance multimoneda de los montos trasladados de impuestos crédito fiscal.
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				a.Ddocumento,
				a.CPTcodigo,
				round((a.EAtotal * b.MontoCalculado)/b.TotalFac,2) * round(a.EAtipocambio,2),
				case when d.CPTtipo = 'D' then 'C' else 'D' end,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Doc a Favor  - CuentaBalancemultimoneda)'">,
				'#LvarfechaChar#',
				a.EAtipocambio,
				#LvarPeriodo#,
				#LvarMes#,
				#LvarCuentabalancemultimoneda#,
				a.Mcodigo,
				x.Ocodigo,
				round((a.EAtotal * b.MontoCalculado)/b.TotalFac,2)
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP x
						inner join ImpDocumentosCxP b
								inner join Impuestos i
								on b.Ecodigo = i.Ecodigo
								and b.Icodigo = i.Icodigo
						on x.Ecodigo       = b.Ecodigo
						and x.IDdocumento = b.IDdocumento

						inner join CPTransacciones d
						on x.Ecodigo = d.Ecodigo
						and x.CPTcodigo = d.CPTcodigo

				on   a.Ecodigo    = x.Ecodigo
				and  a.CPTcodigo  = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo   = x.SNcodigo
			where a.ID = #LvarGblID#
			and i.CcuentaCxPAcred is not null
			and  x.Mcodigo <> #LvarMonlocal#
		</cfquery>

		<!---
			3.1  Hacer el balance multimoneda de los montos trasladados de IEPS crédito fiscal.
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				a.Ddocumento,
				a.CPTcodigo,
				round((a.EAtotal * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2) * round(a.EAtipocambio,2),
				case when d.CPTtipo = 'D' then 'C' else 'D' end,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Doc a Favor  - CuentaBalancemultimoneda)'">,
				'#LvarfechaChar#',
				a.EAtipocambio,
				#LvarPeriodo#,
				#LvarMes#,
				#LvarCuentabalancemultimoneda#,
				a.Mcodigo,
				x.Ocodigo,
				round((a.EAtotal * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2)
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP x
						inner join ImpIEPSDocumentosCxP b
								inner join Impuestos i
								on b.Ecodigo = i.Ecodigo
								and b.codIEPS = i.Icodigo
						on x.Ecodigo       = b.Ecodigo
						and x.IDdocumento = b.IDdocumento

						inner join CPTransacciones d
						on x.Ecodigo = d.Ecodigo
						and x.CPTcodigo = d.CPTcodigo

				on   a.Ecodigo    = x.Ecodigo
				and  a.CPTcodigo  = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo   = x.SNcodigo
			where a.ID = #LvarGblID#
			and i.CcuentaCxPAcred is not null
			and  x.Mcodigo <> #LvarMonlocal#
		</cfquery>

		<!---
			4.  Hacer el balance multimoneda de los montos trasladados de impuestos crédito fiscal.
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				a.Ddocumento,
				a.CPTcodigo,
				round((a.EAtotal * b.MontoCalculado)/b.TotalFac,2) * round(a.EAtipocambio,2),
				d.CPTtipo,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Doc a Favor (Acred) - CuentaBalancemultimoneda)'">,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				#LvarCuentabalancemultimoneda#,
				#LvarMonlocal#,
				x.Ocodigo,
				round((a.EAtotal * b.MontoCalculado)/b.TotalFac,2) * round(a.EAtipocambio,2)
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP x
						inner join ImpDocumentosCxP b
								inner join Impuestos i
								on b.Ecodigo = i.Ecodigo
								and b.Icodigo = i.Icodigo

						on x.Ecodigo      = b.Ecodigo
						and x.IDdocumento = b.IDdocumento

						inner join CPTransacciones d
						on x.Ecodigo = d.Ecodigo
						and x.CPTcodigo = d.CPTcodigo

				on   a.Ecodigo    = x.Ecodigo
				and  a.CPTcodigo  = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo   = x.SNcodigo
			where a.ID = #LvarGblID#
			  and x.Mcodigo <> #LvarMonlocal#
			  and i.CcuentaCxPAcred is not null
		</cfquery>

		<!---
			4.1  Hacer el balance multimoneda de los montos trasladados de IEPS crédito fiscal.
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				a.Ddocumento,
				a.CPTcodigo,
				round((a.EAtotal * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2) * round(a.EAtipocambio,2),
				d.CPTtipo,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Doc a Favor (Acred) - CuentaBalancemultimoneda)'">,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				#LvarCuentabalancemultimoneda#,
				#LvarMonlocal#,
				x.Ocodigo,
				round((a.EAtotal * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2) * round(a.EAtipocambio,2)
                ,'#Arguments.NumeroEvento#',a.CFid
			from EAplicacionCP a
				inner join EDocumentosCP x
						inner join ImpIEPSDocumentosCxP b
								inner join Impuestos i
								on b.Ecodigo = i.Ecodigo
								and b.codIEPS = i.Icodigo

						on x.Ecodigo      = b.Ecodigo
						and x.IDdocumento = b.IDdocumento

						inner join CPTransacciones d
						on x.Ecodigo = d.Ecodigo
						and x.CPTcodigo = d.CPTcodigo

				on   a.Ecodigo    = x.Ecodigo
				and  a.CPTcodigo  = x.CPTcodigo
				and  a.Ddocumento = x.Ddocumento
				and  a.SNcodigo   = x.SNcodigo
			where a.ID = #LvarGblID#
			  and x.Mcodigo <> #LvarMonlocal#
			  and i.CcuentaCxPAcred is not null
		</cfquery>

		<!---
			5. Trasladar el impuesto credito fiscal de las Facturas a las que se aplicó la Nota de Crédito
			Se contabiliza un movimiento a la cuenta de impuestos por acreditar de la tabla de impuestos
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				det.DAdocref,
				d.CPTcodigo,
				round((det.DAmontodoc * b.MontoCalculado)/b.TotalFac,2) * round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2),
				d.CPTtipo,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Documento)'">,
				'#LvarfechaChar#',
				round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2),
				#LvarPeriodo#,
				#LvarMes#,
				CcuentaImp,
				x.Mcodigo,
				x.Ocodigo,
				round((det.DAmontodoc * b.MontoCalculado)/b.TotalFac,2)
                ,det.NumeroEvento,a.CFid
			from EAplicacionCP a
				inner join DAplicacionCP det
						inner join EDocumentosCP x
						on det.Ecodigo = x.Ecodigo
						and  det.DAidref = x.IDdocumento
						and  x.Mcodigo <> #LvarMonlocal#

						inner join ImpDocumentosCxP b
								inner join Impuestos i
								on b.Ecodigo = i.Ecodigo
								and b.Icodigo = i.Icodigo

						on det.Ecodigo = b.Ecodigo
						and det.DAidref  = b.IDdocumento

						inner join CPTransacciones d
						on det.Ecodigo = d.Ecodigo
						and det.DAtransref = d.CPTcodigo

				on a.ID = det.ID

			where a.ID = #LvarGblID#
			and i.CcuentaCxPAcred is not null
		</cfquery>

		<!---
			5.1 Trasladar el ieps credito fiscal de las Facturas a las que se aplicó la Nota de Crédito
			Se contabiliza un movimiento a la cuenta de IEPS por acreditar de la tabla de impuestos
		--->
		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				det.DAdocref,
				d.CPTcodigo,
				round((det.DAmontodoc * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2) * round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2),
				d.CPTtipo,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Documento)'">,
				'#LvarfechaChar#',
				round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2),
				#LvarPeriodo#,
				#LvarMes#,
				CcuentaImpIeps,
				x.Mcodigo,
				x.Ocodigo,
				round((det.DAmontodoc * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2)
                ,det.NumeroEvento,a.CFid
			from EAplicacionCP a
				inner join DAplicacionCP det
						inner join EDocumentosCP x
						on det.Ecodigo = x.Ecodigo
						and  det.DAidref = x.IDdocumento
						and  x.Mcodigo <> #LvarMonlocal#

						inner join ImpIEPSDocumentosCxP b
								inner join Impuestos i
								on b.Ecodigo = i.Ecodigo
								and b.codIEPS = i.Icodigo

						on det.Ecodigo = b.Ecodigo
						and det.DAidref  = b.IDdocumento

						inner join CPTransacciones d
						on det.Ecodigo = d.Ecodigo
						and det.DAtransref = d.CPTcodigo

				on a.ID = det.ID

			where a.ID = #LvarGblID#
			and i.CcuentaCxPAcred is not null
		</cfquery>


		<!---
			6.  Traslado de los impuestos asociados a las Facturas a las que se aplicó la Nota Crédito
				Se contabiliza un movimiento a la cuenta de impuestos acreditatos, EN LA MONEDA LOCAL
		--->

		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				det.DAdocref,
				d.CPTcodigo,
				round((det.DAmontodoc * b.MontoCalculado)/b.TotalFac,2) * round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2),
				case when d.CPTtipo = 'D' then 'C' else 'D' end,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Documento - Acreditada)'">,
				'#LvarfechaChar#',
				a.EAtipocambio,
				#LvarPeriodo#,
				#LvarMes#,
				i.CcuentaCxPAcred,
				#LvarMonlocal#,
				x.Ocodigo,
				round((det.DAmontodoc * b.MontoCalculado)/b.TotalFac,2) * round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2)
                ,det.NumeroEvento,a.CFid
			from EAplicacionCP a
				inner join DAplicacionCP det
						inner join EDocumentosCP x
						on det.Ecodigo = x.Ecodigo
						and  det.DAidref = x.IDdocumento

						inner join ImpDocumentosCxP b
								inner join Impuestos i
								on b.Ecodigo = i.Ecodigo
								and b.Icodigo = i.Icodigo

						on det.Ecodigo = b.Ecodigo
						and det.DAidref  = b.IDdocumento

						inner join CPTransacciones d
						on det.Ecodigo = d.Ecodigo
						and det.DAtransref = d.CPTcodigo

				on a.ID = det.ID
			where a.ID = #LvarGblID#
			and  x.Mcodigo <> #LvarMonlocal#
			and i.CcuentaCxPAcred is not null

		</cfquery>

		<!---
			6.1  Traslado de los IEPS asociados a las Facturas a las que se aplicó la Nota Crédito
				Se contabiliza un movimiento a la cuenta de IEPS acreditatos, EN LA MONEDA LOCAL
		--->

		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				det.DAdocref,
				d.CPTcodigo,
				round((det.DAmontodoc * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2) * round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2),
				case when d.CPTtipo = 'D' then 'C' else 'D' end,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Documento - Acreditada)'">,
				'#LvarfechaChar#',
				a.EAtipocambio,
				#LvarPeriodo#,
				#LvarMes#,
				i.CcuentaCxPAcred,
				#LvarMonlocal#,
				x.Ocodigo,
				round((det.DAmontodoc * coalesce(b.MontoCalculadoIeps,0))/b.TotalFac,2) * round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2)
                ,det.NumeroEvento,a.CFid
			from EAplicacionCP a
				inner join DAplicacionCP det
						inner join EDocumentosCP x
						on det.Ecodigo = x.Ecodigo
						and  det.DAidref = x.IDdocumento

						inner join ImpIEPSDocumentosCxP b
								inner join Impuestos i
								on b.Ecodigo = i.Ecodigo
								and b.codIEPS = i.Icodigo

						on det.Ecodigo = b.Ecodigo
						and det.DAidref  = b.IDdocumento

						inner join CPTransacciones d
						on det.Ecodigo = d.Ecodigo
						and det.DAtransref = d.CPTcodigo

				on a.ID = det.ID
			where a.ID = #LvarGblID#
			and  x.Mcodigo <> #LvarMonlocal#
			and i.CcuentaCxPAcred is not null

		</cfquery>

		<!---
			7.  Hacer el balance multimoneda de los montos trasladados de impuestos crédito fiscal.
		--->

		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				det.DAdocref,
				d.CPTcodigo,
				round((det.DAmontodoc * b.MontoCalculado)/b.TotalFac,2) * round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2),
				case when d.CPTtipo = 'D' then 'C' else 'D' end,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Documento - CuentaBalancemultimoneda)'">,
				'#LvarfechaChar#',
				round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2),
				#LvarPeriodo#,
				#LvarMes#,
				#LvarCuentabalancemultimoneda#,
				x.Mcodigo,
				x.Ocodigo,
				round((det.DAmontodoc * b.MontoCalculado)/b.TotalFac,2)
                ,det.NumeroEvento, a.CFid
			from EAplicacionCP a
				inner join DAplicacionCP det
					inner join EDocumentosCP x
					on det.Ecodigo = x.Ecodigo
					and  det.DAidref = x.IDdocumento

					inner join ImpDocumentosCxP b
							inner join Impuestos i
							on b.Ecodigo = i.Ecodigo
							and b.Icodigo = i.Icodigo

					on det.Ecodigo = b.Ecodigo
					and det.DAidref  = b.IDdocumento

					inner join CPTransacciones d
					on det.Ecodigo = d.Ecodigo
					and det.DAtransref = d.CPTcodigo

				on a.ID = det.ID
			where a.ID = #LvarGblID#
			and  x.Mcodigo <> #LvarMonlocal#
			and i.CcuentaCxPAcred is not null
		</cfquery>

		<!---
			7.1  Hacer el balance multimoneda de los montos trasladados de impuestos crédito fiscal.
		--->

		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				det.DAdocref,
				d.CPTcodigo,
				round((det.DAmontodoc * b.MontoCalculadoIeps)/b.TotalFac,2) * round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2),
				case when d.CPTtipo = 'D' then 'C' else 'D' end,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Documento - CuentaBalancemultimoneda)'">,
				'#LvarfechaChar#',
				round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2),
				#LvarPeriodo#,
				#LvarMes#,
				#LvarCuentabalancemultimoneda#,
				x.Mcodigo,
				x.Ocodigo,
				round((det.DAmontodoc * b.MontoCalculadoIeps)/b.TotalFac,2)
                ,det.NumeroEvento, a.CFid
			from EAplicacionCP a
				inner join DAplicacionCP det
					inner join EDocumentosCP x
					on det.Ecodigo = x.Ecodigo
					and  det.DAidref = x.IDdocumento

					inner join ImpIEPSDocumentosCxP b
							inner join Impuestos i
							on b.Ecodigo = i.Ecodigo
							and b.codIEPS = i.Icodigo

					on det.Ecodigo = b.Ecodigo
					and det.DAidref  = b.IDdocumento

					inner join CPTransacciones d
					on det.Ecodigo = d.Ecodigo
					and det.DAtransref = d.CPTcodigo

				on a.ID = det.ID
			where a.ID = #LvarGblID#
			and  x.Mcodigo <> #LvarMonlocal#
			and i.CcuentaCxPAcred is not null
		</cfquery>

		<!---
			8.  Hacer el balance multimoneda de los montos trasladados de impuestos crédito fiscal.
		--->

		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				det.DAdocref,
				d.CPTcodigo,
				round((det.DAmontodoc * b.MontoCalculado)/b.TotalFac,2) * round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2),
				d.CPTtipo,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Documento (Acred) - CuentaBalancemultimoneda)'">,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				#LvarCuentabalancemultimoneda#,
				#LvarMonlocal#,
				x.Ocodigo,
				round((det.DAmontodoc * b.MontoCalculado)/b.TotalFac,2) * round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2)
                ,det.NumeroEvento,a.CFid
			from EAplicacionCP a
				inner join DAplicacionCP det
						inner join EDocumentosCP x
						on det.Ecodigo = x.Ecodigo
						and  det.DAidref = x.IDdocumento

						inner join ImpDocumentosCxP b
								inner join Impuestos i
								on b.Ecodigo = i.Ecodigo
								and b.Icodigo = i.Icodigo
						on det.Ecodigo = b.Ecodigo
						and det.DAidref  = b.IDdocumento

						inner join CPTransacciones d
						on det.Ecodigo = d.Ecodigo
						and det.DAtransref = d.CPTcodigo

				on a.ID = det.ID
			where a.ID = #LvarGblID#
			and i.CcuentaCxPAcred is not null
			and  x.Mcodigo <> #LvarMonlocal#
		</cfquery>

		<!---
			8.1  Hacer el balance multimoneda de los montos trasladados de IEPS crédito fiscal.
		--->

		<cfquery datasource="#LvarGblConexion#">
			insert into #intarc# ( INTORI, INTREL, INTDOC, INTREF, INTMON, INTTIP, INTDES, INTFEC, INTCAM, Periodo, Mes, Ccuenta, Mcodigo, Ocodigo, INTMOE, NumeroEvento,CFid)
			select
				'CPAP',
				1,
				det.DAdocref,
				d.CPTcodigo,
				round((det.DAmontodoc * b.MontoCalculadoIeps)/b.TotalFac,2) * round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2),
				d.CPTtipo,
				<cf_dbfunction name="concat" args="i.Idescripcion,' (Documento (Acred) - CuentaBalancemultimoneda)'">,
				'#LvarfechaChar#',
				1,
				#LvarPeriodo#,
				#LvarMes#,
				#LvarCuentabalancemultimoneda#,
				#LvarMonlocal#,
				x.Ocodigo,
				round((det.DAmontodoc * b.MontoCalculadoIeps)/b.TotalFac,2) * round((det.DAmonto / det.DAmontodoc * a.EAtipocambio),2)
                ,det.NumeroEvento,a.CFid
			from EAplicacionCP a
				inner join DAplicacionCP det
						inner join EDocumentosCP x
						on det.Ecodigo = x.Ecodigo
						and  det.DAidref = x.IDdocumento

						inner join ImpIEPSDocumentosCxP b
								inner join Impuestos i
								on b.Ecodigo = i.Ecodigo
								and b.codIEPS = i.Icodigo
						on det.Ecodigo = b.Ecodigo
						and det.DAidref  = b.IDdocumento

						inner join CPTransacciones d
						on det.Ecodigo = d.Ecodigo
						and det.DAtransref = d.CPTcodigo

				on a.ID = det.ID
			where a.ID = #LvarGblID#
			and i.CcuentaCxPAcred is not null
			and  x.Mcodigo <> #LvarMonlocal#
		</cfquery>

		<cfreturn>
	</cffunction>

	<cffunction name="sbAfectacionIETU" access="public"  output="false">
		<cfargument name="Oorigen"		type="string"	required="yes" >
		<cfargument name="Ecodigo"		type="numeric"	required="yes" >
		<cfargument name="ID" 			type='numeric' 	required="yes" >
		<cfargument name="Efecha"		type="date"		required="yes" >
		<cfargument name="Eperiodo"		type="numeric"	required="yes" >
		<cfargument name="Emes"			type="numeric"	required="yes" >
		<cfargument name='Conexion' 	type='string' 	required='true'>

		<!--- Verifica si es una aplicación de Anticipo --->
		<cfquery name="rsSQL" datasource="#Arguments.Conexion#">
			select TESRPTCietu
			  from EAplicacionCP e
					inner join EDocumentosCP doc
					 on doc.Ecodigo 	= e.Ecodigo
					and doc.CPTcodigo	= e.CPTcodigo
					and doc.Ddocumento	= e.Ddocumento
					and doc.SNcodigo	= e.SNcodigo
			where e.ID = #Arguments.ID#
		</cfquery>

		<cfif NOT (rsSQL.TESRPTCietu EQ "1" OR rsSQL.TESRPTCietu EQ "2" OR rsSQL.TESRPTCietu EQ "3")>
			<cfreturn>
		</cfif>

		<!---  1) Documento a favor a Aplicar --->
		<cfquery name="rsIETUpago" datasource="#Arguments.Conexion#">
			insert into #request.IETUpago# (
					EcodigoPago,TipoPago,ReferenciaPago,DocumentoPago,
					FechaPago,SNid,
					McodigoPago,MontoPago,MontoPagoLocal,
					ReversarCreacion
				)
			select 	e.Ecodigo,
					2, 	<!--- CxP --->
					<cf_dbfunction name="sPart"	args="e.CPTcodigo,1,2">,
					<cf_dbfunction name="sPart"	args="e.Ddocumento,1,20">,

					e.EAfecha,

					sn.SNid,

					e.Mcodigo,
					e.EAtotal,
					round(e.EAtotal * e.EAtipocambio,2),
					1		<!--- Es una Aplicacion de Anticipo --->
			   from EAplicacionCP e
					inner join SNegocios sn
					 on sn.Ecodigo  = e.Ecodigo
					and sn.SNcodigo = e.SNcodigo
			where e.ID = #LvarGblID#
			<cf_dbidentity1 name="rsIETUpago" datasource="#Arguments.Conexion#">
		</cfquery>
		<cf_dbidentity2 name="rsIETUpago" datasource="#Arguments.Conexion#" returnvariable="ID_IETU">

		<!---  2) Documentos Afectados --->
		<cfquery datasource="#Arguments.Conexion#">
			insert into #request.IETUdocs# (
					ID,
					EcodigoDoc,TipoDoc,ReferenciaDoc,DocumentoDoc,
					OcodigoDoc,FechaDoc,
					TipoAfectacion,
					McodigoDoc,MontoAplicadoDoc,MontoBaseDoc,MontoBasePago,MontoBaseLocal,
					TESRPTCid,
					ReversarEnAplicacion
				)
			select 	#ID_IETU#,
					doc.Ecodigo,
					2,	<!--- CxP --->
					<cf_dbfunction name="sPart"	args="doc.CPTcodigo,1,2">,
					<cf_dbfunction name="sPart"	args="doc.Ddocumento,1,20">,
					doc.Ocodigo,
					doc.Dfecha,

					-1,	<!--- Pago por Compra: Disminuye IETU --->

					doc.Mcodigo,
					round(d.DAmontodoc,2),

					<!---
						Proporcion aplicado al documento sobre el (Total - ImpuestosCF):
							MontoAplicado / Total * (Total-ImpuestosCF)
					--->
					round(d.DAmontodoc	*
						coalesce(
							(
								select (min(icp.TotalFac)-sum(icp.MontoCalculado) - sum(coalesce(iicp.MontoCalculadoIeps,0)) ) / min(icp.TotalFac)
								  from ImpDocumentosCxP icp
								  left join ImpIEPSDocumentosCxP iicp
								  	on icp.IDdocumento = iicp.IDdocumento
									and icp.Ecodigo = iicp.Ecodigo
								 where icp.IDdocumento = doc.IDdocumento
							)
						, 1)
					,2),
					round(d.DAmontodoc	*
						coalesce(
							(
								select (min(icp.TotalFac)-sum(icp.MontoCalculado) - sum(coalesce(iicp.MontoCalculadoIeps,0))) / min(icp.TotalFac)
								  from ImpDocumentosCxP icp
								  left join ImpIEPSDocumentosCxP iicp
								  	on icp.IDdocumento = iicp.IDdocumento
									and icp.Ecodigo = iicp.Ecodigo
								 where icp.IDdocumento = doc.IDdocumento
							)
						, 1) / d.DAtipocambio
					,2),
					round(d.DAmontodoc	*
						coalesce(
							(
								select (min(icp.TotalFac)-sum(icp.MontoCalculado) - sum(coalesce(iicp.MontoCalculadoIeps,0))) / min(icp.TotalFac)
								  from ImpDocumentosCxP icp
								  left join ImpIEPSDocumentosCxP iicp
								  	on icp.IDdocumento = iicp.IDdocumento
									and icp.Ecodigo = iicp.Ecodigo
								 where icp.IDdocumento = doc.IDdocumento
							)
						, 1) / d.DAtipocambio  * e.EAtipocambio
					,2),

					doc.TESRPTCid,
					0
			from EAplicacionCP e
				inner join DAplicacionCP d
					inner join EDocumentosCP doc
					 on doc.Ecodigo 	= d.Ecodigo
					and doc.CPTcodigo	= d.DAtransref
					and doc.Ddocumento	= d.DAdocref
					and doc.SNcodigo	= d.SNcodigo
					and doc.IDdocumento	= d.DAidref
				 on d.ID = e.ID
			where e.ID = #Arguments.ID#
		</cfquery>

		<cfinvoke component="IETU" method="IETU_Afectacion" >
			<cfinvokeargument name="Ecodigo"	value="#Arguments.Ecodigo#">
			<cfinvokeargument name="Oorigen"	value="#Arguments.Oorigen#">
			<cfinvokeargument name="Efecha"		value="#Arguments.Efecha#">
			<cfinvokeargument name="Eperiodo"	value="#Arguments.Eperiodo#">
			<cfinvokeargument name="Emes"		value="#Arguments.Emes#">
			<cfinvokeargument name="conexion"	value="#Arguments.Conexion#">
		</cfinvoke>
	</cffunction>
</cfcomponent>