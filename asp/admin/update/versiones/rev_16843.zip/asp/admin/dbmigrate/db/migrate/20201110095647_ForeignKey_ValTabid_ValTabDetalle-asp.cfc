<cfcomponent extends="asp.admin.dbmigrate.Migration" hint="ForeignKey_ValTabid_ValTabDetalle ">
  <cffunction name="up">
    <cfscript>
      execute('ALTER TABLE ValTabDetalle DROP CONSTRAINT FK_ValTabDetalle_ValTab');
      execute('ALTER TABLE ValTabDetalle ADD CONSTRAINT FK_ValTabDetalle_ValTab FOREIGN KEY (ValTabid) REFERENCES ValTab(id)');
    </cfscript>
  </cffunction>
  <cffunction name="down">
    <cfscript>
      execute('ALTER TABLE ValTabDetalle DROP CONSTRAINT FK_ValTabDetalle_ValTab');
    </cfscript>
  </cffunction>
</cfcomponent>

		

		

		
