﻿<cfset session.sitio.template = "/plantillas/Sutelgocr/plantilla_compat.cfm">
<cfset session.sitio.css = "/plantillas/Sutelgocr/css/soinasp01_compat.css">
<cfinclude template="styles_inc.cfm">
