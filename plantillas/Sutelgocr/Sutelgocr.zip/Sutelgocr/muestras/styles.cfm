﻿<cfparam name="url.skin" default="azul">
<cfset session.sitio.template = "/plantillas/Sutelgocr/plantilla.cfm">
<cfset session.sitio.css = "/plantillas/Sutelgocr/css/soinasp01_" & url.skin & ".css">
<cfinclude template="styles_inc.cfm">
